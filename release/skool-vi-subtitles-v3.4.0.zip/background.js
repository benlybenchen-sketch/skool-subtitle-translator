const Yc = (r, n) => new Promise((e, t) => {
  if (n?.aborted) return t(kn());
  const s = setTimeout(() => {
    n?.removeEventListener("abort", i), e();
  }, r), i = () => {
    clearTimeout(s), t(kn());
  };
  n?.addEventListener("abort", i, { once: !0 });
});
function kn(r = "Aborted") {
  const n = new Error(r);
  return n.name = "AbortError", n;
}
const Hu = (r) => r instanceof Error && (r.name === "AbortError" || r.name === "TimeoutError");
function si(r) {
  try {
    const n = new URL(r);
    return ["localhost", "127.0.0.1", "[::1]", "::1"].includes(n.hostname);
  } catch {
    return !1;
  }
}
function Du(r) {
  try {
    const n = new URL(r);
    return n.protocol !== "https:" && n.protocol !== "http:" ? null : `${n.protocol}//${n.hostname}/*`;
  } catch {
    return null;
  }
}
function Ku(r) {
  const n = atob(r), e = new Uint8Array(n.length);
  for (let t = 0; t < n.length; t++) e[t] = n.charCodeAt(t);
  return e;
}
function Bs(r, n) {
  if (!r.length) return 0;
  const e = [...r].sort((s, i) => s - i), t = Math.min(e.length - 1, Math.ceil(n / 100 * e.length) - 1);
  return e[Math.max(0, t)];
}
const Gu = `# One entry per line. "English => Vietnamese" forces a translation,
# a bare term is kept exactly as written. Lines starting with # are ignored.
Skool
dropshipping
Shopify
Facebook Ads
Google Ads
TikTok Ads
ROAS
CTR
CPC
CPM
CPA
KPI
SEO
API
SaaS
AI
ChatGPT
prompt
landing page => landing page (trang đích)
funnel => phễu bán hàng (funnel)
sales funnel => phễu bán hàng
conversion rate => tỷ lệ chuyển đổi
ad set => nhóm quảng cáo (ad set)
ad account => tài khoản quảng cáo
lead => khách hàng tiềm năng (lead)
retargeting => tiếp thị lại (retargeting)
upsell => bán thêm (upsell)
cross-sell => bán chéo
niche => thị trường ngách
supplier => nhà cung cấp
fulfillment => xử lý đơn hàng (fulfillment)
workflow => quy trình (workflow)
automation => tự động hóa
deploy => triển khai (deploy)
repository => repository (kho mã)
`, In = {
  enabled: !0,
  modePreference: "auto",
  displayMode: "vi",
  fontScale: 1,
  bottomOffsetPct: 14,
  background: !0,
  backgroundOpacity: 0.55,
  outline: !1,
  shadow: !0,
  showPanel: !0,
  provider: {
    kind: "local",
    endpoint: "http://localhost:8787",
    model: "default",
    temperature: 0.2
  },
  providerProfiles: {},
  stt: {
    kind: "local",
    endpoint: "http://localhost:8787",
    model: "whisper-1"
  },
  consent: { remoteTranslation: !1, remoteAudio: !1 },
  glossary: Gu,
  contextWindow: 3,
  translationMode: "balanced",
  modeModels: {},
  pretranslateAll: !0,
  autoStart: !0,
  autoEnableCaptions: !1,
  autoEnableCaptionsAsked: !1,
  autoInitOnNavigation: !0,
  sourceLanguage: "en",
  targetLanguage: "vi",
  mergeFragments: !0,
  customCaptionSelectors: "",
  costWarningUsd: 0
}, Oi = "settings", Nn = "secrets";
function Vu(r) {
  const n = r ?? {};
  return {
    ...In,
    ...n,
    provider: { ...In.provider, ...n.provider ?? {} },
    providerProfiles: { ...n.providerProfiles ?? {} },
    modeModels: { ...n.modeModels ?? {} },
    stt: { ...In.stt, ...n.stt ?? {} },
    consent: { ...In.consent, ...n.consent ?? {} }
  };
}
async function ii() {
  const r = await chrome.storage.sync.get(Oi);
  return Vu(r[Oi]);
}
async function ai() {
  const [r, n] = await Promise.all([
    chrome.storage.local.get(Nn),
    chrome.storage.session.get(Nn)
  ]);
  return { ...r[Nn] ?? {}, ...n[Nn] ?? {} };
}
function Xc(r) {
  return r.provider.kind !== "mock" && !si(r.provider.endpoint);
}
function Qc(r) {
  return r.stt.kind !== "mock" && !si(r.stt.endpoint);
}
function Ju(r) {
  const n = r.modeModels?.[r.translationMode]?.[r.provider.kind]?.trim();
  return n ? { ...r.provider, model: n } : r.provider;
}
function Zc(r, n, e) {
  return r.translationApiKeys?.[n] ?? (n === e ? r.translationApiKey : void 0);
}
const Ci = (r) => r.hostname.toLowerCase(), Yu = (r, ...n) => n.some((e) => Ci(r) === e || Ci(r).endsWith("." + e)), Xu = ["skool.com"], el = (r) => Yu(r, ...Xu);
function tl(r, n) {
  if (!r) return null;
  try {
    return new URL(r, n);
  } catch {
    return null;
  }
}
const se = "translations";
function es(r) {
  return new Promise((n, e) => {
    r.onsuccess = () => n(r.result), r.onerror = () => e(r.error);
  });
}
function Dt(r) {
  return new Promise((n, e) => {
    r.oncomplete = () => n(), r.onerror = () => e(r.error), r.onabort = () => e(r.error);
  });
}
class Qu {
  dbp = null;
  o;
  constructor(n = {}) {
    this.o = {
      dbName: n.dbName ?? "sst-cache",
      maxAgeMs: n.maxAgeMs ?? 1080 * 3600 * 1e3,
      maxEntries: n.maxEntries ?? 6e4,
      now: n.now ?? Date.now,
      indexedDB: n.indexedDB
    };
  }
  db() {
    if (!this.dbp) {
      const n = this.o.indexedDB ?? indexedDB;
      this.dbp = new Promise((e, t) => {
        const s = n.open(this.o.dbName, 1);
        s.onupgradeneeded = () => {
          const a = s.result.createObjectStore(se, { keyPath: "key" });
          a.createIndex("videoKey", "videoKey"), a.createIndex("lastUsedAt", "lastUsedAt");
        }, s.onsuccess = () => e(s.result), s.onerror = () => t(s.error);
      }), this.dbp.catch(() => this.dbp = null);
    }
    return this.dbp;
  }
  async getMany(n) {
    const e = /* @__PURE__ */ new Map();
    if (!n.length) return e;
    const s = (await this.db()).transaction(se, "readwrite"), i = s.objectStore(se), a = this.o.now();
    return await Promise.all(
      n.map(async (o) => {
        const l = await es(i.get(o));
        if (l) {
          if (a - l.lastUsedAt > this.o.maxAgeMs) {
            i.delete(o);
            return;
          }
          e.set(o, l.vi), a - l.lastUsedAt > 36e5 && i.put({ ...l, lastUsedAt: a });
        }
      })
    ), await Dt(s), e;
  }
  async putMany(n) {
    if (!n.length) return;
    const t = (await this.db()).transaction(se, "readwrite"), s = t.objectStore(se), i = this.o.now();
    for (const a of n)
      s.put({ ...a, createdAt: i, lastUsedAt: i, size: a.key.length + a.vi.length * 2 });
    await Dt(t);
  }
  async stats() {
    const t = (await this.db()).transaction(se, "readonly").objectStore(se), s = await es(t.count());
    let i = 0;
    return await new Promise((a, o) => {
      const l = t.openCursor();
      l.onsuccess = () => {
        const h = l.result;
        if (!h) return a();
        i += h.value.size ?? 0, h.continue();
      }, l.onerror = () => o(l.error);
    }), { entries: s, approxBytes: i };
  }
  async clear() {
    const e = (await this.db()).transaction(se, "readwrite");
    e.objectStore(se).clear(), await Dt(e);
  }
  /** Invalidate all cached translations of one video. */
  async deleteVideo(n) {
    const t = (await this.db()).transaction(se, "readwrite"), s = t.objectStore(se).index("videoKey");
    let i = 0;
    return await new Promise((a, o) => {
      const l = s.openCursor(IDBKeyRange.only(n));
      l.onsuccess = () => {
        const h = l.result;
        if (!h) return a();
        h.delete(), i++, h.continue();
      }, l.onerror = () => o(l.error);
    }), await Dt(t), i;
  }
  /** Remove expired entries and enforce the LRU cap. */
  async prune() {
    const e = (await this.db()).transaction(se, "readwrite"), t = e.objectStore(se), s = await es(t.count()), i = this.o.now() - this.o.maxAgeMs;
    let a = Math.max(0, s - this.o.maxEntries), o = 0;
    return await new Promise((l, h) => {
      const _ = t.index("lastUsedAt").openCursor();
      _.onsuccess = () => {
        const d = _.result;
        if (!d) return l();
        d.value.lastUsedAt < i || a > 0 ? (d.delete(), o++, a > 0 && a--, d.continue()) : l();
      }, _.onerror = () => h(_.error);
    }), await Dt(e), o;
  }
}
function An(r, n = 0) {
  let e = 3735928559 ^ n, t = 1103547991 ^ n;
  for (let s = 0; s < r.length; s++) {
    const i = r.charCodeAt(s);
    e = Math.imul(e ^ i, 2654435761), t = Math.imul(t ^ i, 1597334677);
  }
  return e = Math.imul(e ^ e >>> 16, 2246822507) ^ Math.imul(t ^ t >>> 13, 3266489909), t = Math.imul(t ^ t >>> 16, 2246822507) ^ Math.imul(e ^ e >>> 13, 3266489909), (4294967296 * (2097151 & t) + (e >>> 0)).toString(36);
}
class Me extends Error {
  constructor(n, e, t) {
    super(e), this.status = n, this.retryAfterMs = t, this.name = "HttpError";
  }
  get retryable() {
    return this.status === 408 || this.status === 409 || this.status === 425 || this.status === 429 || this.status >= 500;
  }
}
class me extends Error {
  constructor(n) {
    super(n), this.name = "ConfigError";
  }
}
class De extends Error {
  constructor(n) {
    super(n), this.name = "ParseError";
  }
}
function nl(r) {
  if (!r) return;
  const n = Number(r);
  if (Number.isFinite(n)) return Math.max(0, n * 1e3);
  const e = Date.parse(r);
  return Number.isFinite(e) ? Math.max(0, e - Date.now()) : void 0;
}
async function On(r, n) {
  if (r.ok) return r;
  let e = "";
  try {
    e = await r.text();
  } catch {
  }
  const t = e.slice(0, 300), s = e.match(/"retryDelay"\s*:\s*"(\d+(?:\.\d+)?)s"/), i = nl(r.headers.get("retry-after")) ?? (s ? Math.round(Number(s[1]) * 1e3) : void 0), a = r.status === 401 || r.status === 403 ? " (check the API key / permissions)" : r.status === 429 ? " (rate limited)" : "";
  throw new Me(r.status, `${n} HTTP ${r.status}${a}${t ? ": " + t : ""}`, i);
}
function rl(r) {
  const n = [], e = /* @__PURE__ */ new Set();
  for (const t of r.split(/\r?\n/)) {
    const s = t.trim();
    if (!s || s.startsWith("#")) continue;
    const [i, a] = s.split(/\s*(?:=>|→)\s*/, 2), o = i.trim().toLowerCase();
    !o || e.has(o) || (e.add(o), n.push({ term: i.trim(), translation: a?.trim() || void 0 }));
  }
  return n;
}
function Zu(r) {
  return An(rl(r).map((n) => `${n.term}=${n.translation ?? ""}`).join(`
`));
}
const ed = (r) => r.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
function td(r, n) {
  const e = n.join(`
`);
  return r.filter((t) => new RegExp(`(^|[^\\p{L}\\p{N}])${ed(t.term)}(?=$|[^\\p{L}\\p{N}])`, "iu").test(e));
}
const nd = {
  concurrency: 2,
  maxBatchItems: 24,
  maxBatchChars: 2600,
  minBatchChars: 200,
  maxRetries: 4,
  baseDelayMs: 800,
  maxDelayMs: 2e4,
  timeoutMs: 45e3,
  sleep: Yc,
  random: Math.random,
  now: () => Date.now()
};
class rd {
  opts;
  inflight = /* @__PURE__ */ new Map();
  groups = /* @__PURE__ */ new Map();
  active = 0;
  waiters = [];
  waiterSeq = 0;
  /** After an HTTP 429, NO request is sent until this time (shared by all batches/tabs). */
  cooldownUntil = 0;
  get rateLimitedForMs() {
    return Math.max(0, this.cooldownUntil - this.opts.now());
  }
  budget;
  constructor(n = {}) {
    this.opts = { ...nd, ...n }, this.budget = this.opts.maxBatchChars;
  }
  get batchBudget() {
    return this.budget;
  }
  get inflightCount() {
    return this.inflight.size;
  }
  cancelGroup(n) {
    this.groups.get(n)?.abort(), this.groups.delete(n);
  }
  groupSignal(n) {
    let e = this.groups.get(n);
    return (!e || e.signal.aborted) && (e = new AbortController(), this.groups.set(n, e)), e.signal;
  }
  async translate(n, e) {
    const t = this.groupSignal(e.group), s = /* @__PURE__ */ new Map(), i = [];
    for (const o of n) {
      if (s.has(o.key)) continue;
      const l = this.inflight.get(o.key);
      l ? s.set(o.key, l) : (i.push(o), s.set(o.key, null));
    }
    for (const o of this.makeBatches(i)) {
      const l = /* @__PURE__ */ new Map();
      for (const h of o) {
        const _ = new Promise((d, m) => l.set(h.key, { resolve: d, reject: m }));
        _.catch(() => {
        }), this.inflight.set(h.key, _), s.set(h.key, _), _.finally(() => {
          this.inflight.get(h.key) === _ && this.inflight.delete(h.key);
        }).catch(() => {
        });
      }
      this.runBatch(o, e, t, 0).then((h) => {
        for (const _ of o) {
          const d = l.get(_.key), m = h.get(_.key);
          m?.vi !== void 0 ? d.resolve(m.vi) : d.reject(m?.error ?? new Error("Translation missing"));
        }
      }).catch((h) => {
        for (const _ of l.values()) _.reject(h);
      });
    }
    const a = /* @__PURE__ */ new Map();
    return await Promise.all(
      [...s.entries()].map(async ([o, l]) => {
        try {
          a.set(o, { vi: await l });
        } catch (h) {
          a.set(o, { error: h });
        }
      })
    ), a;
  }
  makeBatches(n) {
    const e = [];
    let t = [], s = 0;
    for (const i of n)
      t.length && (t.length >= this.opts.maxBatchItems || s + i.text.length > this.budget) && (e.push(t), t = [], s = 0), t.push(i), s += i.text.length;
    return t.length && e.push(t), e;
  }
  async acquire(n, e) {
    const t = this.rateLimitedForMs;
    for (t > 0 && await this.opts.sleep(t, n); this.active >= this.opts.concurrency; )
      if (await new Promise((s) => this.waiters.push({ priority: e, seq: this.waiterSeq++, wake: s })), n.aborted) throw kn();
    this.active++;
  }
  /** Wake the most urgent waiter (lowest priority number, then FIFO). */
  release() {
    if (this.active--, !this.waiters.length) return;
    let n = 0;
    for (let e = 1; e < this.waiters.length; e++) {
      const t = this.waiters[e], s = this.waiters[n];
      (t.priority < s.priority || t.priority === s.priority && t.seq < s.seq) && (n = e);
    }
    this.waiters.splice(n, 1)[0].wake();
  }
  async runBatch(n, e, t, s) {
    if (t.aborted) throw kn();
    await this.acquire(t, e.priority ?? 2);
    const i = Date.now(), a = new AbortController(), o = setTimeout(() => a.abort(), this.opts.timeoutMs), l = sd([t, a.signal]), h = n.map((w, S) => ({ id: "s" + S, text: w.text }));
    let _, d, m = !1;
    try {
      this.opts.onEvent?.({ type: "request", size: n.length }, e.meta), d = await e.provider.translateBatch({
        segments: h,
        context: e.context,
        glossary: td(e.glossary, n.map((w) => w.text)),
        sourceLang: e.sourceLang ?? "en",
        targetLang: e.targetLang ?? "vi",
        signal: l,
        onUsage: (w) => {
          m = !0, this.opts.onEvent?.({ type: "usage", usage: w }, e.meta);
        }
      });
    } catch (w) {
      _ = a.signal.aborted && !t.aborted ? Object.assign(new Error("Translation request timed out"), { name: "TimeoutError" }) : w;
    } finally {
      clearTimeout(o), this.release();
    }
    if (d) {
      if (!m) {
        const x = 1600 + n.reduce((k, A) => k + A.text.length, 0) + e.context.join(" ").length, v = Object.values(d).reduce((k, A) => k + A.length, 0);
        this.opts.onEvent?.({ type: "usage", usage: { inputTokens: Math.ceil(x / 4), outputTokens: Math.ceil(v / 3), estimated: !0 } }, e.meta);
      }
      const w = /* @__PURE__ */ new Map(), S = [];
      if (n.forEach((x, v) => {
        const k = d[h[v].id];
        typeof k == "string" && k.trim() ? w.set(x.key, { vi: k.trim() }) : S.push(x);
      }), this.opts.onEvent?.({ type: "success", size: n.length - S.length, latencyMs: Date.now() - i }, e.meta), !S.length)
        return this.budget = Math.min(this.opts.maxBatchChars, Math.round(this.budget * 1.25)), w;
      if (s < this.opts.maxRetries) {
        const x = await this.retryLater(S, e, t, s, new De("Model omitted segments"));
        for (const [v, k] of x) w.set(v, k);
      } else for (const x of S) w.set(x.key, { error: new De("Model omitted this segment") });
      return w;
    }
    if (t.aborted || Hu(_) && _.name === "AbortError") throw kn();
    const g = _;
    if (!(g instanceof Me && g.retryable || g instanceof De || g.name === "TimeoutError" || g instanceof TypeError) || g instanceof me || s >= this.opts.maxRetries) {
      this.opts.onEvent?.({ type: "failure", size: n.length, reason: g.message }, e.meta);
      const w = /* @__PURE__ */ new Map();
      for (const S of n) w.set(S.key, { error: g });
      return w;
    }
    return (g instanceof De || g.name === "TimeoutError") && (this.budget = Math.max(this.opts.minBatchChars, Math.round(this.budget / 2))), this.retryLater(n, e, t, s, g);
  }
  async retryLater(n, e, t, s, i) {
    let a = Math.min(this.opts.maxDelayMs, this.opts.baseDelayMs * 2 ** s) * (0.75 + this.opts.random() * 0.5);
    if (i instanceof Me && i.status === 429 && (i.retryAfterMs !== void 0 && (a = Math.min(this.opts.maxDelayMs * 3, i.retryAfterMs)), this.cooldownUntil = Math.max(this.cooldownUntil, this.opts.now() + a), this.opts.onEvent?.({ type: "rate-limited", delayMs: a }, e.meta)), a = Math.round(a), this.opts.onEvent?.({ type: "retry", attempt: s + 1, delayMs: a, reason: i.message }, e.meta), i instanceof Me && i.status === 429 || await this.opts.sleep(a, t), (i instanceof De || i.name === "TimeoutError") && n.length > 1) {
      const o = Math.ceil(n.length / 2), [l, h] = await Promise.all([
        this.runBatch(n.slice(0, o), e, t, s + 1),
        this.runBatch(n.slice(o), e, t, s + 1)
      ]);
      return new Map([...l, ...h]);
    }
    return this.runBatch(n, e, t, s + 1);
  }
}
function sd(r) {
  const n = AbortSignal.any;
  if (n) return n(r);
  const e = new AbortController();
  for (const t of r) {
    if (t.aborted) {
      e.abort();
      break;
    }
    t.addEventListener("abort", () => e.abort(), { once: !0 });
  }
  return e.signal;
}
const id = "p4", oi = `You are a professional English→Vietnamese subtitle translator for online courses (marketing, digital advertising, e-commerce, dropshipping, software engineering, business strategy, AI and automation, technical tutorials).

Rules:
- Translate each segment into natural, fluent, spoken Vietnamese that a Vietnamese learner would understand immediately. Avoid stiff word-for-word translation, but never change the instructor's meaning.
- Keep technical terms, product names, brand names, people's names, code, commands, URLs and acronyms (ROAS, CTR, API, SEO…) unchanged unless the glossary says otherwise.
- Preserve all numbers, percentages, currencies, units and dates exactly (e.g. "$1,500" stays "$1,500", "30%" stays "30%").
- Follow the glossary strictly.
- Segments may be incomplete spoken sentences; translate them as natural incomplete Vietnamese, consistent with neighbouring segments. Use the context only for understanding — do NOT translate the context.
- Subtitles must be short and easy to read: keep each translation about as long as the original (or shorter). No explanations, notes or quotation marks.
- Return ONLY JSON: {"translations":[{"subtitle_id":"<id>","translated_text":"<vietnamese>"}]} with exactly one item per input id, same ids, no extra items.`, ad = {
  type: "OBJECT",
  properties: {
    translations: {
      type: "ARRAY",
      items: {
        type: "OBJECT",
        properties: { subtitle_id: { type: "STRING" }, translated_text: { type: "STRING" } },
        required: ["subtitle_id", "translated_text"]
      }
    }
  },
  required: ["translations"]
};
function ci(r) {
  const n = [];
  return r.glossary.length && n.push(
    `Glossary:
` + r.glossary.map((e) => e.translation ? `- ${e.term} => ${e.translation}` : `- ${e.term} => (keep as "${e.term}")`).join(`
`)
  ), r.context.length && n.push(`Context (previous lines, do not translate):
` + r.context.map((e) => `> ${e}`).join(`
`)), n.push(
    `Segments:
` + JSON.stringify(r.segments.map((e) => ({ subtitle_id: e.id, text: e.text })))
  ), n.join(`

`);
}
function li(r) {
  const n = r.trim().replace(/^```(?:json)?\s*/i, "").replace(/```\s*$/, "");
  try {
    return JSON.parse(n);
  } catch {
    const e = n.indexOf("{"), t = n.lastIndexOf("}");
    if (e >= 0 && t > e)
      try {
        return JSON.parse(n.slice(e, t + 1));
      } catch {
      }
    throw new De("Model reply is not valid JSON");
  }
}
function Dr(r, n) {
  let e = r;
  if (e && typeof e == "object" && !Array.isArray(e)) {
    const i = e;
    e = i.translations ?? i.t ?? i.items ?? i.segments;
  }
  if (!Array.isArray(e)) throw new De("Model reply has no translation list");
  const t = {}, s = new Set(n);
  return e.forEach((i, a) => {
    if (typeof i == "string") {
      n[a] && (t[n[a]] = i);
      return;
    }
    if (!i || typeof i != "object") return;
    const o = i, l = String(o.subtitle_id ?? o.i ?? o.id ?? n[a] ?? ""), h = o.translated_text ?? o.v ?? o.vi ?? o.text ?? o.translation;
    s.has(l) && !(l in t) && typeof h == "string" && h.trim() && (t[l] = h.trim());
  }), t;
}
const sl = (r) => /^(models\/)?gemini-3/i.test(r);
class od {
  constructor(n) {
    if (this.o = n, !n.endpoint) throw new me("Gemini endpoint is not configured");
  }
  id = "gemini";
  async translateBatch(n) {
    const e = this.o.fetchImpl ?? fetch, t = this.o.model.replace(/^models\//, ""), s = `${this.o.endpoint.replace(/\/+$/, "")}/models/${encodeURIComponent(t)}:generateContent`, i = { "Content-Type": "application/json" };
    this.o.apiKey && (i["x-goog-api-key"] = this.o.apiKey);
    const a = await e(s, {
      method: "POST",
      headers: i,
      signal: n.signal,
      body: JSON.stringify({
        systemInstruction: { parts: [{ text: oi }] },
        contents: [{ role: "user", parts: [{ text: ci(n) }] }],
        generationConfig: {
          temperature: this.o.temperature,
          responseMimeType: "application/json",
          responseSchema: ad,
          // Speed-first: minimal thinking (default for 3.5 Flash-Lite; sent explicitly).
          ...sl(t) ? { thinkingConfig: { thinkingLevel: "minimal" } } : {}
        }
      })
    });
    await On(a, "Gemini");
    const o = await a.json(), l = o.usageMetadata;
    if (l && n.onUsage?.({
      inputTokens: l.promptTokenCount ?? 0,
      outputTokens: (l.candidatesTokenCount ?? 0) + (l.thoughtsTokenCount ?? 0),
      cachedInputTokens: l.cachedContentTokenCount || void 0,
      reasoningTokens: l.thoughtsTokenCount || void 0
    }), o.promptFeedback?.blockReason) throw new me(`Gemini blocked the request: ${o.promptFeedback.blockReason}`);
    const h = o.candidates?.[0]?.content?.parts?.map((_) => _.text ?? "").join("") ?? "";
    return Dr(li(h), n.segments.map((_) => _.id));
  }
}
const Lt = [
  { match: "gemini-3.5-flash-lite", input: 0.3, output: 2.5, cachedInput: 0.03, note: "public pricing pages (web search), Nov 2026" },
  { match: "gpt-4o-mini", input: 0.15, output: 0.6, cachedInput: 0.075, note: "OpenAI list price (training data) — verify" },
  { match: "claude-opus-5-5", input: 4, output: 20, cachedInput: 0.2, cacheWrite: 5, note: "Claude API reference cached 2026-10-06; cache write = 1.25× input" },
  { match: "claude-sonnet-5-5", input: 2, output: 10, cachedInput: 0.2, cacheWrite: 2.5, note: "Claude API reference cached 2026-10-06; cache write = 1.25× input" },
  { match: "claude-haiku-5-5", input: 0.1, output: 0.5, cachedInput: 0.01, cacheWrite: 0.125, note: "Claude API reference cached 2026-10-06 (≤100K-token prompts)" }
];
function cd(r, n = Lt) {
  const e = r.replace(/^models\//, "").toLowerCase();
  let t = null;
  for (const s of n) s.match && e.startsWith(s.match.toLowerCase()) && (!t || s.match.length > t.match.length) && (t = s);
  return t;
}
function il(r, n, e = Lt) {
  if (r === "mock") return 0;
  const t = cd(r, e);
  if (!t) return null;
  const s = n.cachedInputTokens ?? 0, i = n.cacheWriteTokens ?? 0;
  return (Math.max(0, n.inputTokens - s - i) * t.input + s * (t.cachedInput ?? t.input) + i * (t.cacheWrite ?? t.input) + n.outputTokens * t.output) / 1e6;
}
function ld(r, n, e, t = Lt) {
  return il(r, { inputTokens: n, outputTokens: e }, t);
}
const $r = "pricingTable";
async function al() {
  try {
    const n = (await chrome.storage.local.get($r))[$r];
    return Array.isArray(n) && n.length ? n : Lt;
  } catch {
    return Lt;
  }
}
async function ud(r) {
  r ? await chrome.storage.local.set({ [$r]: r.filter((n) => n.match.trim()) }) : await chrome.storage.local.remove($r);
}
class dd {
  constructor(n) {
    if (this.o = n, !n.endpoint) throw new me("Local backend endpoint is not configured");
  }
  id = "local";
  async translateBatch(n) {
    const e = this.o.fetchImpl ?? fetch, t = { "Content-Type": "application/json" };
    this.o.apiKey && (t.Authorization = `Bearer ${this.o.apiKey}`);
    const s = await e(this.o.endpoint.replace(/\/+$/, "") + "/translate", {
      method: "POST",
      headers: t,
      signal: n.signal,
      body: JSON.stringify({
        source: n.sourceLang,
        target: n.targetLang,
        model: this.o.model,
        segments: n.segments,
        context: n.context,
        glossary: n.glossary
      })
    });
    await On(s, "Local backend");
    const i = await s.json();
    return i.usage && (i.usage.inputTokens || i.usage.outputTokens) && n.onUsage?.({ ...i.usage }), Dr(i, n.segments.map((a) => a.id));
  }
}
class hd {
  constructor(n = 0) {
    this.latencyMs = n;
  }
  id = "mock";
  calls = 0;
  async translateBatch(n) {
    this.calls++, this.latencyMs && await Yc(this.latencyMs, n.signal);
    const e = {};
    for (const t of n.segments) e[t.id] = `[VI] ${t.text}`;
    return e;
  }
}
class _d {
  constructor(n) {
    if (this.o = n, !n.endpoint) throw new me("OpenAI-compatible endpoint is not configured");
  }
  id = "openai";
  async translateBatch(n) {
    const e = this.o.fetchImpl ?? fetch, t = this.o.endpoint.replace(/\/+$/, "") + "/chat/completions", s = { "Content-Type": "application/json" };
    this.o.apiKey && (s.Authorization = `Bearer ${this.o.apiKey}`);
    const i = await e(t, {
      method: "POST",
      headers: s,
      signal: n.signal,
      body: JSON.stringify({
        model: this.o.model,
        temperature: this.o.temperature,
        response_format: { type: "json_object" },
        messages: [
          { role: "system", content: oi },
          { role: "user", content: ci(n) }
        ]
      })
    });
    await On(i, "OpenAI-compatible");
    const a = await i.json(), o = a.usage;
    o && n.onUsage?.({
      inputTokens: o.prompt_tokens ?? 0,
      outputTokens: o.completion_tokens ?? 0,
      cachedInputTokens: o.prompt_tokens_details?.cached_tokens || void 0,
      reasoningTokens: o.completion_tokens_details?.reasoning_tokens || void 0
    });
    const l = a.choices?.[0]?.message?.content ?? "";
    return Dr(li(l), n.segments.map((h) => h.id));
  }
}
function y(r, n, e, t, s) {
  if (typeof n == "function" ? r !== n || !0 : !n.has(r))
    throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return n.set(r, e), e;
}
function c(r, n, e, t) {
  if (e === "a" && !t)
    throw new TypeError("Private accessor was defined without a getter");
  if (typeof n == "function" ? r !== n || !t : !n.has(r))
    throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return e === "m" ? t : e === "a" ? t.call(r) : t ? t.value : n.get(r);
}
function dt(r) {
  return typeof r == "object" && r !== null && // Spec-compliant fetch implementations
  ("name" in r && r.name === "AbortError" || // Expo fetch
  "message" in r && String(r.message).includes("FetchRequestCanceledException"));
}
const Ir = (r) => {
  if (r instanceof Error)
    return r;
  if (typeof r == "object" && r !== null) {
    try {
      const n = Object.prototype.toString.call(r);
      if (n === "[object Error]" || n === "[object DOMException]") {
        const e = new Error(r.message, r.cause ? { cause: r.cause } : {});
        return r.stack && (e.stack = r.stack), r.cause && !e.cause && (e.cause = r.cause), r.name && (e.name = r.name), e;
      }
    } catch {
    }
    try {
      return new Error(JSON.stringify(r));
    } catch {
    }
  }
  return new Error(r);
};
var R = /* @__PURE__ */ (() => {
  class r extends Error {
  }
  return r;
})();
class j extends R {
  constructor(n, e, t, s, i) {
    super(`${j.makeMessage(n, e, t)}`), this.status = n, this.headers = s, this.requestID = s?.get("request-id"), this.workspaceID = s?.get("anthropic-workspace-id"), this.error = e, this.type = i ?? null;
  }
  static makeMessage(n, e, t) {
    const s = e?.message ? typeof e.message == "string" ? e.message : JSON.stringify(e.message) : e ? JSON.stringify(e) : t;
    return n && s ? `${n} ${s}` : n ? `${n} status code (no body)` : s || "(no status code or body)";
  }
  static generate(n, e, t, s) {
    if (!n || !s)
      return new qt({ message: t, cause: Ir(e) });
    const i = e, a = i?.error?.type;
    return n === 400 ? new ol(n, i, t, s, a) : n === 401 ? new cl(n, i, t, s, a) : n === 403 ? new ll(n, i, t, s, a) : n === 404 ? new ul(n, i, t, s, a) : n === 409 ? new dl(n, i, t, s, a) : n === 422 ? new hl(n, i, t, s, a) : n === 429 ? new _l(n, i, t, s, a) : n >= 500 ? new pl(n, i, t, s, a) : new j(n, i, t, s, a);
  }
}
class ue extends j {
  constructor({ message: n } = {}) {
    super(void 0, void 0, n || "Request was aborted.", void 0);
  }
}
class qt extends j {
  constructor({ message: n, cause: e }) {
    super(void 0, void 0, n || "Connection error.", void 0), e && (this.cause = e);
  }
}
class Us extends qt {
  constructor({ message: n } = {}) {
    super({ message: n ?? "Request timed out." });
  }
}
class pd extends R {
  constructor(n, { cause: e } = {}) {
    super(n ?? "Retryable error."), e !== void 0 && (this.cause = e);
  }
}
class ol extends j {
}
class cl extends j {
}
class ll extends j {
}
class ul extends j {
}
class dl extends j {
}
class hl extends j {
}
class _l extends j {
}
class pl extends j {
}
const fd = /^[a-z][a-z0-9+.-]*:/i, gd = (r) => fd.test(r);
let re = (r) => (re = Array.isArray, re(r)), $i = re;
function xn(r) {
  return typeof r != "object" ? {} : r ?? {};
}
function Ii(r) {
  if (!r)
    return !0;
  for (const n in r)
    return !1;
  return !0;
}
function md(r, n) {
  return Object.prototype.hasOwnProperty.call(r, n);
}
function Ni(r) {
  return r != null && typeof r == "object" && !Array.isArray(r);
}
const ts = (r, n) => {
  if (typeof n != "number" || !Number.isInteger(n))
    throw new R(`${r} must be an integer`);
  if (n < 0)
    throw new R(`${r} must be a positive integer`);
  return n;
}, fl = (r) => {
  try {
    return JSON.parse(r);
  } catch {
    return;
  }
};
const ct = (r, n) => new Promise((e) => {
  if (n?.aborted)
    return e();
  const t = () => {
    clearTimeout(s), e();
  }, s = setTimeout(() => {
    n?.removeEventListener("abort", t), e();
  }, r);
  n?.addEventListener("abort", t, { once: !0 });
}), Pe = "0.137.0", bd = () => (
  // @ts-ignore
  typeof window < "u" && // @ts-ignore
  typeof window.document < "u" && // @ts-ignore
  typeof navigator < "u"
);
function wd() {
  return typeof Deno < "u" && Deno.build != null ? "deno" : typeof EdgeRuntime < "u" ? "edge" : Object.prototype.toString.call(typeof globalThis.process < "u" ? globalThis.process : 0) === "[object process]" ? "node" : "unknown";
}
const yd = () => {
  const r = wd();
  if (r === "deno")
    return {
      "X-Stainless-Lang": "js",
      "X-Stainless-Package-Version": Pe,
      "X-Stainless-OS": qi(Deno.build.os),
      "X-Stainless-Arch": Li(Deno.build.arch),
      "X-Stainless-Runtime": "deno",
      "X-Stainless-Runtime-Version": typeof Deno.version == "string" ? Deno.version : Deno.version?.deno ?? "unknown"
    };
  if (typeof EdgeRuntime < "u")
    return {
      "X-Stainless-Lang": "js",
      "X-Stainless-Package-Version": Pe,
      "X-Stainless-OS": "Unknown",
      "X-Stainless-Arch": `other:${EdgeRuntime}`,
      "X-Stainless-Runtime": "edge",
      "X-Stainless-Runtime-Version": globalThis.process?.version ?? "unknown"
    };
  if (r === "node")
    return {
      "X-Stainless-Lang": "js",
      "X-Stainless-Package-Version": Pe,
      "X-Stainless-OS": qi(globalThis.process.platform ?? "unknown"),
      "X-Stainless-Arch": Li(globalThis.process.arch ?? "unknown"),
      "X-Stainless-Runtime": "node",
      "X-Stainless-Runtime-Version": globalThis.process.version ?? "unknown"
    };
  const n = vd();
  return n ? {
    "X-Stainless-Lang": "js",
    "X-Stainless-Package-Version": Pe,
    "X-Stainless-OS": "Unknown",
    "X-Stainless-Arch": "unknown",
    "X-Stainless-Runtime": `browser:${n.browser}`,
    "X-Stainless-Runtime-Version": n.version
  } : {
    "X-Stainless-Lang": "js",
    "X-Stainless-Package-Version": Pe,
    "X-Stainless-OS": "Unknown",
    "X-Stainless-Arch": "unknown",
    "X-Stainless-Runtime": "unknown",
    "X-Stainless-Runtime-Version": "unknown"
  };
};
function vd() {
  if (typeof navigator > "u" || !navigator)
    return null;
  const r = [
    { key: "edge", pattern: /Edge(?:\W+(\d+)\.(\d+)(?:\.(\d+))?)?/ },
    { key: "ie", pattern: /MSIE(?:\W+(\d+)\.(\d+)(?:\.(\d+))?)?/ },
    { key: "ie", pattern: /Trident(?:.*rv\:(\d+)\.(\d+)(?:\.(\d+))?)?/ },
    { key: "chrome", pattern: /Chrome(?:\W+(\d+)\.(\d+)(?:\.(\d+))?)?/ },
    { key: "firefox", pattern: /Firefox(?:\W+(\d+)\.(\d+)(?:\.(\d+))?)?/ },
    { key: "safari", pattern: /(?:Version\W+(\d+)\.(\d+)(?:\.(\d+))?)?(?:\W+Mobile\S*)?\W+Safari/ }
  ];
  for (const { key: n, pattern: e } of r) {
    const t = e.exec(navigator.userAgent);
    if (t) {
      const s = t[1] || 0, i = t[2] || 0, a = t[3] || 0;
      return { browser: n, version: `${s}.${i}.${a}` };
    }
  }
  return null;
}
const Li = (r) => r === "x32" ? "x32" : r === "x86_64" || r === "x64" ? "x64" : r === "arm" ? "arm" : r === "aarch64" || r === "arm64" ? "arm64" : r ? `other:${r}` : "unknown", qi = (r) => (r = r.toLowerCase(), r.includes("ios") ? "iOS" : r === "android" ? "Android" : r === "darwin" ? "MacOS" : r === "win32" ? "Windows" : r === "freebsd" ? "FreeBSD" : r === "openbsd" ? "OpenBSD" : r === "linux" ? "Linux" : r ? `Other:${r}` : "Unknown");
let Bi;
const ui = () => Bi ?? (Bi = yd()), Nr = /* @__PURE__ */ new WeakMap(), gl = typeof globalThis.FinalizationRegistry == "function" ? new globalThis.FinalizationRegistry((r) => lt(r)) : null;
function kd(r, n) {
  return () => r.removeEventListener("abort", n);
}
function Sd(r, n, e) {
  Nr.set(r, kd(n, e));
}
function Td(r, n) {
  Nr.has(n) && gl?.register(r, n, n);
}
function lt(r) {
  const n = Nr.get(r);
  n && (Nr.delete(r), gl?.unregister(r), n());
}
function Ad() {
  if (typeof fetch < "u")
    return fetch;
  throw new Error("`fetch` is not defined as a global; Either pass `fetch` to the client, `new Anthropic({ fetch })` or polyfill the global, `globalThis.fetch = fetch`");
}
function ml(...r) {
  const n = globalThis.ReadableStream;
  if (typeof n > "u")
    throw new Error("`ReadableStream` is not defined as a global; You will need to polyfill it, `globalThis.ReadableStream = ReadableStream`");
  return new n(...r);
}
function bl(r) {
  let n = Symbol.asyncIterator in r ? r[Symbol.asyncIterator]() : r[Symbol.iterator]();
  return ml({
    start() {
    },
    async pull(e) {
      const { done: t, value: s } = await n.next();
      t ? e.close() : e.enqueue(s);
    },
    async cancel() {
      await n.return?.();
    }
  });
}
function xd(r) {
  if (r[Symbol.asyncIterator])
    return r[Symbol.asyncIterator]();
  const n = r.getReader();
  return {
    async next() {
      try {
        const e = await n.read();
        return e?.done && n.releaseLock(), e;
      } catch (e) {
        throw n.releaseLock(), e;
      }
    },
    async return() {
      const e = n.cancel();
      return n.releaseLock(), await e, { done: !0, value: void 0 };
    }
  };
}
const Ui = typeof FinalizationRegistry > "u" ? void 0 : /* @__PURE__ */ new FinalizationRegistry(async (r) => {
  try {
    await r.return?.();
  } catch {
  }
});
async function* di(r) {
  const n = xd(r), e = {};
  Ui?.register(e, n, e);
  try {
    for await (const t of { [Symbol.asyncIterator]: () => n })
      yield t;
  } finally {
    Ui?.unregister(e);
  }
}
async function Ed(r) {
  if (r === null || typeof r != "object")
    return;
  if (r[Symbol.asyncIterator]) {
    await r[Symbol.asyncIterator]().return?.();
    return;
  }
  const n = r.getReader(), e = n.cancel();
  n.releaseLock(), await e;
}
const Rd = ({ headers: r, body: n }) => ({
  bodyHeaders: {
    "content-type": "application/json"
  },
  body: JSON.stringify(n)
}), Bt = "1.10.0", Fi = /^(\d+)\.(\d+)\.(\d+)(-(.+))?$/;
function Pd(r) {
  const n = /* @__PURE__ */ new Set([r]), e = /* @__PURE__ */ new Set(), t = r.match(Fi);
  if (!t) return () => !1;
  const s = {
    major: +t[1],
    minor: +t[2],
    patch: +t[3],
    prerelease: t[4]
  };
  if (s.prerelease != null) return function(l) {
    return l === r;
  };
  function i(o) {
    return e.add(o), !1;
  }
  function a(o) {
    return n.add(o), !0;
  }
  return function(l) {
    if (n.has(l)) return !0;
    if (e.has(l)) return !1;
    const h = l.match(Fi);
    if (!h) return i(l);
    const _ = {
      major: +h[1],
      minor: +h[2],
      patch: +h[3],
      prerelease: h[4]
    };
    return _.prerelease != null || s.major !== _.major ? i(l) : s.major === 0 ? s.minor === _.minor && s.patch <= _.patch ? a(l) : i(l) : s.minor <= _.minor ? a(l) : i(l);
  };
}
const zd = Pd(Bt), Md = Bt.split(".")[0], Lr = Symbol.for(`opentelemetry.js.api.${Md}`), qr = typeof globalThis == "object" ? globalThis : typeof self == "object" ? self : typeof window == "object" ? window : typeof global == "object" ? global : {};
function Od() {
  return Object.defineProperty({}, "version", {
    value: Bt,
    enumerable: !0,
    writable: !1,
    configurable: !1
  });
}
function jt(r, n, e, t = !1) {
  var s;
  const i = qr[Lr] = (s = qr[Lr]) !== null && s !== void 0 ? s : Od();
  if (!t && i[r]) {
    const a = /* @__PURE__ */ new Error(`@opentelemetry/api: Attempted duplicate registration of API: ${r}`);
    return e.error(a.stack || a.message), !1;
  }
  if (i.version !== "1.10.0") {
    const a = /* @__PURE__ */ new Error(`@opentelemetry/api: Registration of version v${i.version} for ${r} does not match previously registered API v${Bt}`);
    return e.error(a.stack || a.message), !1;
  }
  return i[r] = n, e.debug(`@opentelemetry/api: Registered a global for ${r} v${Bt}.`), !0;
}
let Wi;
function Ve(r) {
  const n = qr[Lr];
  if (n != null) {
    if (n !== Wi) {
      if (!n.version || !zd(n.version)) return;
      Wi = n;
    }
    return n[r];
  }
}
function Ht(r, n) {
  n.debug(`@opentelemetry/api: Unregistering a global for ${r} v${Bt}.`);
  const e = qr[Lr];
  e && delete e[r];
}
var Cd = class {
  constructor(r) {
    this._namespace = r.namespace || "DiagComponentLogger";
  }
  debug(...r) {
    return Kt("debug", this._namespace, r);
  }
  error(...r) {
    return Kt("error", this._namespace, r);
  }
  info(...r) {
    return Kt("info", this._namespace, r);
  }
  warn(...r) {
    return Kt("warn", this._namespace, r);
  }
  verbose(...r) {
    return Kt("verbose", this._namespace, r);
  }
};
function Kt(r, n, e) {
  const t = Ve("diag");
  if (t)
    return t[r](n, ...e);
}
function $d(r, n) {
  r < 0 ? r = 0 : r > 9999 && (r = 9999), n = n || {};
  function e(t, s) {
    const i = n[t];
    return typeof i == "function" && r >= s ? i.bind(n) : function() {
    };
  }
  return {
    error: e("error", 30),
    warn: e("warn", 50),
    info: e("info", 60),
    debug: e("debug", 70),
    verbose: e("verbose", 80)
  };
}
const Id = "diag";
var de = class wl {
  /** Get the singleton instance of the DiagAPI API */
  static instance() {
    return this._instance || (this._instance = new wl()), this._instance;
  }
  /**
  * Private internal constructor
  * @private
  */
  constructor() {
    function n(s) {
      return function(...i) {
        const a = Ve("diag");
        if (a)
          return a[s](...i);
      };
    }
    const e = this, t = (s, i = { logLevel: 60 }) => {
      var a;
      if (s === e) {
        var o;
        const d = /* @__PURE__ */ new Error("Cannot use diag as the logger for itself. Please use a DiagLogger implementation like ConsoleDiagLogger or a custom implementation");
        return e.error((o = d.stack) !== null && o !== void 0 ? o : d.message), !1;
      }
      typeof i == "number" && (i = { logLevel: i });
      const l = Ve("diag"), h = $d((a = i.logLevel) !== null && a !== void 0 ? a : 60, s);
      if (l && !i.suppressOverrideMessage) {
        var _;
        const d = (_ = (/* @__PURE__ */ new Error()).stack) !== null && _ !== void 0 ? _ : "<failed to generate stacktrace>";
        l.warn(`Current logger will be overwritten from ${d}`), h.warn(`Current logger will overwrite one already registered from ${d}`);
      }
      return jt("diag", h, e, !0);
    };
    e.setLogger = t, e.disable = () => {
      Ht(Id, e);
    }, e.createComponentLogger = (s) => new Cd(s), e.verbose = n("verbose"), e.debug = n("debug"), e.info = n("info"), e.warn = n("warn"), e.error = n("error");
  }
}, Nd = class vn {
  constructor(n) {
    this._entries = n ? new Map(n) : /* @__PURE__ */ new Map();
  }
  getEntry(n) {
    const e = this._entries.get(n);
    if (e)
      return Object.assign({}, e);
  }
  getAllEntries() {
    return Array.from(this._entries.entries());
  }
  setEntry(n, e) {
    const t = new vn(this._entries);
    return t._entries.set(n, e), t;
  }
  removeEntry(n) {
    const e = new vn(this._entries);
    return e._entries.delete(n), e;
  }
  removeEntries(...n) {
    const e = new vn(this._entries);
    for (const t of n) e._entries.delete(t);
    return e;
  }
  clear() {
    return new vn();
  }
};
de.instance();
function Ld(r = {}) {
  return new Nd(new Map(Object.entries(r)));
}
function yl(r) {
  return Symbol.for(r);
}
const qd = new class Fs {
  /**
  * Construct a new context which inherits values from an optional parent context.
  *
  * @param parentContext a context from which to inherit values
  */
  constructor(n) {
    const e = this;
    e._currentContext = n ? new Map(n) : /* @__PURE__ */ new Map(), e.getValue = (t) => e._currentContext.get(t), e.setValue = (t, s) => {
      const i = new Fs(e._currentContext);
      return i._currentContext.set(t, s), i;
    }, e.deleteValue = (t) => {
      const s = new Fs(e._currentContext);
      return s._currentContext.delete(t), s;
    };
  }
}();
var Bd = class {
  constructor() {
  }
  /**
  * @see {@link Meter.createGauge}
  */
  createGauge(r, n) {
    return Jd;
  }
  /**
  * @see {@link Meter.createHistogram}
  */
  createHistogram(r, n) {
    return Yd;
  }
  /**
  * @see {@link Meter.createCounter}
  */
  createCounter(r, n) {
    return Vd;
  }
  /**
  * @see {@link Meter.createUpDownCounter}
  */
  createUpDownCounter(r, n) {
    return Xd;
  }
  /**
  * @see {@link Meter.createObservableGauge}
  */
  createObservableGauge(r, n) {
    return Zd;
  }
  /**
  * @see {@link Meter.createObservableCounter}
  */
  createObservableCounter(r, n) {
    return Qd;
  }
  /**
  * @see {@link Meter.createObservableUpDownCounter}
  */
  createObservableUpDownCounter(r, n) {
    return eh;
  }
  /**
  * @see {@link Meter.addBatchObservableCallback}
  */
  addBatchObservableCallback(r, n) {
  }
  /**
  * @see {@link Meter.removeBatchObservableCallback}
  */
  removeBatchObservableCallback(r) {
  }
}, Kr = class {
}, Ud = class extends Kr {
  add(r, n) {
  }
}, Fd = class extends Kr {
  add(r, n) {
  }
}, Wd = class extends Kr {
  record(r, n) {
  }
}, jd = class extends Kr {
  record(r, n) {
  }
}, hi = class {
  addCallback(r) {
  }
  removeCallback(r) {
  }
}, Hd = class extends hi {
}, Dd = class extends hi {
}, Kd = class extends hi {
};
const Gd = new Bd(), Vd = new Ud(), Jd = new Wd(), Yd = new jd(), Xd = new Fd(), Qd = new Hd(), Zd = new Dd(), eh = new Kd();
var vl = class {
  emit(r) {
  }
  enabled() {
    return !1;
  }
};
const th = new vl(), nh = {
  get(r, n) {
    if (r != null)
      return r[n];
  },
  keys(r) {
    return r == null ? [] : Object.keys(r);
  }
}, rh = { set(r, n, e) {
  r != null && (r[n] = e);
} }, sh = "0000000000000000", ih = "00000000000000000000000000000000", ah = {
  traceId: ih,
  spanId: sh,
  traceFlags: 0
};
var Sn = class {
  constructor(r = ah) {
    this._spanContext = r;
  }
  spanContext() {
    return this._spanContext;
  }
  setAttribute(r, n) {
    return this;
  }
  setAttributes(r) {
    return this;
  }
  addEvent(r, n) {
    return this;
  }
  addLink(r) {
    return this;
  }
  addLinks(r) {
    return this;
  }
  setStatus(r) {
    return this;
  }
  updateName(r) {
    return this;
  }
  end(r) {
  }
  isRecording() {
    return !1;
  }
  recordException(r, n) {
  }
};
const Ln = new Uint8Array([
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  1,
  1,
  1,
  1,
  1,
  1,
  1,
  1,
  1,
  1,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  1,
  1,
  1,
  1,
  1,
  1,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  1,
  1,
  1,
  1,
  1,
  1
]);
function kl(r, n) {
  if (typeof r != "string" || r.length !== n) return !1;
  let e = 0;
  for (let t = 0; t < r.length; t += 4) e += (Ln[r.charCodeAt(t)] | 0) + (Ln[r.charCodeAt(t + 1)] | 0) + (Ln[r.charCodeAt(t + 2)] | 0) + (Ln[r.charCodeAt(t + 3)] | 0);
  return e === n;
}
function oh(r) {
  return kl(r, 32) && r !== "00000000000000000000000000000000";
}
function ch(r) {
  return kl(r, 16) && r !== "0000000000000000";
}
function Sl(r) {
  return oh(r.traceId) && ch(r.spanId);
}
function lh(r) {
  return new Sn(r);
}
var uh = class {
  active() {
    return qd;
  }
  with(r, n, e, ...t) {
    return n.call(e, ...t);
  }
  bind(r, n) {
    return n;
  }
  enable() {
    return this;
  }
  disable() {
    return this;
  }
  /** @experimental This API is experimental and may change in minor releases without prior notice. */
  attach(r) {
    return { dispose() {
    } };
  }
};
const ns = "context", dh = new uh(), hh = Object.freeze({ dispose: () => {
} });
var Gr = class Tl {
  /** Empty private constructor prevents end users from constructing a new instance of the API */
  constructor() {
    this._attachUnsupportedWarned = !1;
  }
  /** Get the singleton instance of the Context API */
  static getInstance() {
    return this._instance || (this._instance = new Tl()), this._instance;
  }
  /**
  * Set the current context manager.
  *
  * @returns true if the context manager was successfully registered, else false
  */
  setGlobalContextManager(n) {
    return jt(ns, n, de.instance());
  }
  /**
  * Get the currently active context
  */
  active() {
    return this._getContextManager().active();
  }
  /**
  * Execute a function with an active context
  *
  * @param context context to be active during function execution
  * @param fn function to execute in a context
  * @param thisArg optional receiver to be used for calling fn
  * @param args optional arguments forwarded to fn
  */
  with(n, e, t, ...s) {
    return this._getContextManager().with(n, e, t, ...s);
  }
  /**
  * Bind a context to a target function or event emitter
  *
  * @param context context to bind to the event emitter or function. Defaults to the currently active context
  * @param target function or event emitter to bind
  */
  bind(n, e) {
    return this._getContextManager().bind(n, e);
  }
  /**
  * Imperatively sets `context` as active, returning a {@link ContextManagementToken} whose
  * {@link ContextManagementToken.dispose} restores the previous context.
  *
  * This is a delicate, low-level API - prefer {@link with}/{@link bind}, which
  * restore context automatically. Use `attach` only to bridge callback
  * boundaries that `with` cannot wrap. Call `token.dispose()` when the
  * operation is done.
  *
  * **Caveat for async functions:** If called inside an async function before
  * the first `await`, the context change may leak into the caller's context
  * and remain active there. Prefer {@link with} for async code.
  *
  * Support is best-effort and varies by the active ContextManager (see
  * {@link ContextManager.attach}); if it does not implement `attach`, this logs
  * a warning and returns a no-op token.
  *
  * @param context The Context to attach
  * @returns A {@link ContextManagementToken} whose dispose() restores the previous Context
  * @since 1.10.0
  * @experimental This API is experimental and may change in minor releases without prior notice.
  */
  attach(n) {
    const e = this._getContextManager();
    return e.attach ? e.attach(n) : (this._attachUnsupportedWarned || (this._attachUnsupportedWarned = !0, de.instance().warn("The current ContextManager does not implement attach(). The context will not be attached. Use a ContextManager that supports attach() (e.g. AsyncLocalStorageContextManager) or use with()/bind() instead.")), hh);
  }
  _getContextManager() {
    return Ve(ns) || dh;
  }
  /** Disable and remove the global context manager */
  disable() {
    this._getContextManager().disable(), Ht(ns, de.instance());
  }
};
const _i = yl("OpenTelemetry Context Key SPAN");
function pi(r) {
  return r.getValue(_i) || void 0;
}
function _h() {
  return pi(Gr.getInstance().active());
}
function fi(r, n) {
  return r.setValue(_i, n);
}
function ph(r) {
  return r.deleteValue(_i);
}
function fh(r, n) {
  return fi(r, new Sn(n));
}
function Al(r) {
  var n;
  return (n = pi(r)) === null || n === void 0 ? void 0 : n.spanContext();
}
const rs = Gr.getInstance();
var xl = class {
  startSpan(r, n, e = rs.active()) {
    if (n?.root) return new Sn();
    const t = e && Al(e);
    return gh(t) && Sl(t) ? new Sn(t) : new Sn();
  }
  startActiveSpan(r, n, e, t) {
    var s;
    let i, a, o;
    if (arguments.length < 2) return;
    arguments.length === 2 ? o = n : arguments.length === 3 ? (i = n, o = e) : (i = n, a = e, o = t);
    const l = (s = a) !== null && s !== void 0 ? s : rs.active(), h = this.startSpan(r, i, l), _ = fi(l, h);
    return rs.with(_, o, void 0, h);
  }
};
function gh(r) {
  return r !== null && typeof r == "object" && "spanId" in r && typeof r.spanId == "string" && "traceId" in r && typeof r.traceId == "string" && "traceFlags" in r && typeof r.traceFlags == "number";
}
const mh = new xl();
var bh = class {
  constructor(r, n, e, t) {
    this._provider = r, this.name = n, this.version = e, this.options = t;
  }
  startSpan(r, n, e) {
    return this._getTracer().startSpan(r, n, e);
  }
  startActiveSpan(r, n, e, t) {
    const s = this._getTracer();
    return Reflect.apply(s.startActiveSpan, s, arguments);
  }
  /**
  * Try to get a tracer from the proxy tracer provider.
  * If the proxy tracer provider has no delegate, return a noop tracer.
  */
  _getTracer() {
    if (this._delegate) return this._delegate;
    const r = this._provider.getDelegateTracer(this.name, this.version, this.options);
    return r ? (this._delegate = r, this._delegate) : mh;
  }
};
let Vr = /* @__PURE__ */ (function(r) {
  return r[r.INTERNAL = 0] = "INTERNAL", r[r.SERVER = 1] = "SERVER", r[r.CLIENT = 2] = "CLIENT", r[r.PRODUCER = 3] = "PRODUCER", r[r.CONSUMER = 4] = "CONSUMER", r;
})({}), ht = /* @__PURE__ */ (function(r) {
  return r[r.UNSET = 0] = "UNSET", r[r.OK = 1] = "OK", r[r.ERROR = 2] = "ERROR", r;
})({});
var wh = class {
  getTracer(r, n, e) {
    return new xl();
  }
};
const yh = new wh();
var ji = class {
  /**
  * Get a {@link ProxyTracer}
  */
  getTracer(r, n, e) {
    var t;
    return (t = this.getDelegateTracer(r, n, e)) !== null && t !== void 0 ? t : new bh(this, r, n, e);
  }
  getDelegate() {
    var r;
    return (r = this._delegate) !== null && r !== void 0 ? r : yh;
  }
  /**
  * Set the delegate tracer provider
  */
  setDelegate(r) {
    this._delegate = r;
  }
  getDelegateTracer(r, n, e) {
    var t;
    return (t = this._delegate) === null || t === void 0 ? void 0 : t.getTracer(r, n, e);
  }
};
const he = Gr.getInstance();
de.instance();
var vh = class {
  getLogger(r, n, e) {
    return new vl();
  }
};
const kh = new vh();
var Sh = class {
  constructor(r, n, e, t) {
    this._provider = r, this.name = n, this.version = e, this.options = t;
  }
  /**
  * Emit a log record. This method should only be used by log appenders.
  *
  * @param logRecord
  */
  emit(r) {
    this._getLogger().emit(r);
  }
  enabled(r) {
    return this._getLogger().enabled(r);
  }
  /**
  * Try to get a logger from the proxy logger provider.
  * If the proxy logger provider has no delegate, return a noop logger.
  */
  _getLogger() {
    if (this._delegate) return this._delegate;
    const r = this._provider._getDelegateLogger(this.name, this.version, this.options);
    return r ? (this._delegate = r, this._delegate) : th;
  }
}, Hi = class {
  getLogger(r, n, e) {
    var t;
    return (t = this._getDelegateLogger(r, n, e)) !== null && t !== void 0 ? t : new Sh(this, r, n, e);
  }
  /**
  * Get the delegate logger provider.
  * Used by tests only.
  * @internal
  */
  _getDelegate() {
    var r;
    return (r = this._delegate) !== null && r !== void 0 ? r : kh;
  }
  /**
  * Set the delegate logger provider
  * @internal
  */
  _setDelegate(r) {
    this._delegate = r;
  }
  /**
  * @internal
  */
  _getDelegateLogger(r, n, e) {
    var t;
    return (t = this._delegate) === null || t === void 0 ? void 0 : t.getLogger(r, n, e);
  }
};
const ss = "logs";
var Th = class El {
  /** Empty private constructor prevents end users from constructing a new instance of the API */
  constructor() {
    this._proxyLoggerProvider = new Hi();
  }
  /** Get the singleton instance of the Logs API */
  static getInstance() {
    return this._instance || (this._instance = new El()), this._instance;
  }
  setGlobalLoggerProvider(n) {
    const e = jt(ss, n, de.instance());
    return e && this._proxyLoggerProvider._setDelegate(n), e;
  }
  /**
  * Returns the global logger provider.
  *
  * @returns LoggerProvider
  */
  getLoggerProvider() {
    return Ve(ss) || this._proxyLoggerProvider;
  }
  /**
  * Returns a Logger, creating one if one with the given name, version,
  * schemaUrl, and attributes is not already created.
  *
  * Getting a Logger may be expensive, especially when `attributes` are
  * provided. Reuse Logger instances where possible instead of calling
  * `getLogger()` on hot paths.
  *
  * @param name The name of the logger or instrumentation library.
  * @param version The version of the logger or instrumentation library.
  * @param options The options of the logger or instrumentation library.
  * @returns {@link Logger}
  */
  getLogger(n, e, t) {
    return this.getLoggerProvider().getLogger(n, e, t);
  }
  /** Remove the global logger provider */
  disable() {
    Ht(ss, de.instance()), this._proxyLoggerProvider = new Hi();
  }
};
Th.getInstance();
var Ah = class {
  getMeter(r, n, e) {
    return Gd;
  }
};
const xh = new Ah(), is = "metrics";
var Eh = class Rl {
  /** Empty private constructor prevents end users from constructing a new instance of the API */
  constructor() {
  }
  /** Get the singleton instance of the Metrics API */
  static getInstance() {
    return this._instance || (this._instance = new Rl()), this._instance;
  }
  /**
  * Set the current global meter provider.
  * Returns true if the meter provider was successfully registered, else false.
  */
  setGlobalMeterProvider(n) {
    return jt(is, n, de.instance());
  }
  /**
  * Returns the global meter provider.
  */
  getMeterProvider() {
    return Ve(is) || xh;
  }
  /**
  * Returns a meter from the global meter provider.
  */
  getMeter(n, e, t) {
    return this.getMeterProvider().getMeter(n, e, t);
  }
  /** Remove the global meter provider */
  disable() {
    Ht(is, de.instance());
  }
};
Eh.getInstance();
var Rh = class {
  /** Noop inject function does nothing */
  inject(r, n) {
  }
  /** Noop extract function does nothing and returns the input context */
  extract(r, n) {
    return r;
  }
  fields() {
    return [];
  }
};
const gi = yl("OpenTelemetry Baggage Key");
function Pl(r) {
  return r.getValue(gi) || void 0;
}
function Ph() {
  return Pl(Gr.getInstance().active());
}
function zh(r, n) {
  return r.setValue(gi, n);
}
function Mh(r) {
  return r.deleteValue(gi);
}
const as = "propagation", Oh = new Rh();
var Ch = class zl {
  /** Empty private constructor prevents end users from constructing a new instance of the API */
  constructor() {
    this.createBaggage = Ld, this.getBaggage = Pl, this.getActiveBaggage = Ph, this.setBaggage = zh, this.deleteBaggage = Mh;
  }
  /** Get the singleton instance of the Propagator API */
  static getInstance() {
    return this._instance || (this._instance = new zl()), this._instance;
  }
  /**
  * Set the current propagator.
  *
  * @returns true if the propagator was successfully registered, else false
  */
  setGlobalPropagator(n) {
    return jt(as, n, de.instance());
  }
  /**
  * Inject context into a carrier to be propagated inter-process
  *
  * @param context Context carrying tracing data to inject
  * @param carrier carrier to inject context into
  * @param setter Function used to set values on the carrier
  */
  inject(n, e, t = rh) {
    return this._getGlobalPropagator().inject(n, e, t);
  }
  /**
  * Extract context from a carrier
  *
  * @param context Context which the newly created context will inherit from
  * @param carrier Carrier to extract context from
  * @param getter Function used to extract keys from a carrier
  */
  extract(n, e, t = nh) {
    return this._getGlobalPropagator().extract(n, e, t);
  }
  /**
  * Return a list of all fields which may be used by the propagator.
  */
  fields() {
    return this._getGlobalPropagator().fields();
  }
  /** Remove the global propagator */
  disable() {
    Ht(as, de.instance());
  }
  _getGlobalPropagator() {
    return Ve(as) || Oh;
  }
};
const Ml = Ch.getInstance(), os = "trace";
var $h = class Ol {
  /** Empty private constructor prevents end users from constructing a new instance of the API */
  constructor() {
    this._proxyTracerProvider = new ji(), this.wrapSpanContext = lh, this.isSpanContextValid = Sl, this.deleteSpan = ph, this.getSpan = pi, this.getActiveSpan = _h, this.getSpanContext = Al, this.setSpan = fi, this.setSpanContext = fh;
  }
  /** Get the singleton instance of the Trace API */
  static getInstance() {
    return this._instance || (this._instance = new Ol()), this._instance;
  }
  /**
  * Set the current global tracer.
  *
  * @returns true if the tracer provider was successfully registered, else false
  */
  setGlobalTracerProvider(n) {
    const e = jt(os, this._proxyTracerProvider, de.instance());
    return e && this._proxyTracerProvider.setDelegate(n), e;
  }
  /**
  * Returns the global tracer provider.
  */
  getTracerProvider() {
    return Ve(os) || this._proxyTracerProvider;
  }
  /**
  * Returns a tracer from the global tracer provider.
  */
  getTracer(n, e) {
    return this.getTracerProvider().getTracer(n, e);
  }
  /** Remove the global tracer provider */
  disable() {
    Ht(os, de.instance()), this._proxyTracerProvider = new ji();
  }
};
const _t = $h.getInstance();
function Ih(r) {
  let n = 0;
  for (const s of r)
    n += s.length;
  const e = new Uint8Array(n);
  let t = 0;
  for (const s of r)
    e.set(s, t), t += s.length;
  return e;
}
let Di;
function Cl(r) {
  let n;
  return (Di ?? (n = new globalThis.TextEncoder(), Di = n.encode.bind(n)))(r);
}
let Ki;
function Ws(r) {
  let n;
  return (Ki ?? (n = new globalThis.TextDecoder(), Ki = n.decode.bind(n)))(r);
}
var ie, ae, mi = /* @__PURE__ */ (() => {
  class r {
    constructor() {
      ie.set(this, void 0), ae.set(this, void 0), y(this, ie, new Uint8Array()), y(this, ae, null);
    }
    decode(e) {
      if (e == null)
        return [];
      const t = e instanceof ArrayBuffer ? new Uint8Array(e) : typeof e == "string" ? Cl(e) : e;
      y(this, ie, Ih([c(this, ie, "f"), t]));
      const s = [];
      let i;
      for (; (i = Nh(c(this, ie, "f"), c(this, ae, "f"))) != null; ) {
        if (i.carriage && c(this, ae, "f") == null) {
          y(this, ae, i.index);
          continue;
        }
        if (c(this, ae, "f") != null && (i.index !== c(this, ae, "f") + 1 || i.carriage)) {
          s.push(Ws(c(this, ie, "f").subarray(0, c(this, ae, "f") - 1))), y(this, ie, c(this, ie, "f").subarray(c(this, ae, "f"))), y(this, ae, null);
          continue;
        }
        const a = c(this, ae, "f") !== null ? i.preceding - 1 : i.preceding, o = Ws(c(this, ie, "f").subarray(0, a));
        s.push(o), y(this, ie, c(this, ie, "f").subarray(i.index)), y(this, ae, null);
      }
      return s;
    }
    flush() {
      return c(this, ie, "f").length ? this.decode(`
`) : [];
    }
  }
  return ie = /* @__PURE__ */ new WeakMap(), ae = /* @__PURE__ */ new WeakMap(), r.NEWLINE_CHARS = /* @__PURE__ */ new Set([`
`, "\r"]), r.NEWLINE_REGEXP = /\r\n|[\n\r]/g, r;
})();
function Nh(r, n) {
  for (let s = n ?? 0; s < r.length; s++) {
    if (r[s] === 10)
      return { preceding: s, index: s + 1, carriage: !1 };
    if (r[s] === 13)
      return { preceding: s, index: s + 1, carriage: !0 };
  }
  return null;
}
const O = (r) => {
  if (typeof globalThis.process < "u")
    return globalThis.process.env?.[r]?.trim() || void 0;
  if (typeof globalThis.Deno < "u")
    return globalThis.Deno.env?.get?.(r)?.trim() || void 0;
}, Br = "warn", Ur = {
  off: 0,
  error: 200,
  warn: 300,
  info: 400,
  debug: 500
}, js = (r, n, e) => {
  if (r) {
    if (md(Ur, r))
      return r;
    e.warn(`${n} was set to ${JSON.stringify(r)}, expected one of ${JSON.stringify(Object.keys(Ur))}`);
  }
};
function Ot() {
}
function qn(r, n, e) {
  return !n || Ur[r] > Ur[e] ? Ot : n[r].bind(n);
}
const Lh = {
  error: Ot,
  warn: Ot,
  info: Ot,
  debug: Ot
};
let Gi = /* @__PURE__ */ new WeakMap();
function Hs(r, n) {
  const e = Gi.get(r);
  if (e && e[0] === n)
    return e[1];
  const t = {
    error: qn("error", r, n),
    warn: qn("warn", r, n),
    info: qn("info", r, n),
    debug: qn("debug", r, n)
  };
  return Gi.set(r, [n, t]), t;
}
function M(r) {
  const n = r.logger, e = r.logLevel ?? "off";
  return n ? Hs(n, e) : Lh;
}
let Vi, cs;
function $l() {
  const r = O("ANTHROPIC_LOG");
  return (!cs || r !== Vi) && (Vi = r, cs = Hs(console, js(r, "process.env['ANTHROPIC_LOG']", Hs(console, Br)) ?? Br)), cs;
}
function He(r, n, e) {
  r.debug !== Ot && r.debug(n, qh(e));
}
const qh = (r) => (r.options && (r.options = { ...r.options }, delete r.options.headers), r.headers && (r.headers = Object.fromEntries((r.headers instanceof Headers ? [...r.headers] : Object.entries(r.headers)).map(([n, e]) => [
  n,
  n.toLowerCase() === "authorization" || n.toLowerCase() === "proxy-authorization" || n.toLowerCase() === "api-key" || n.toLowerCase() === "x-api-key" || n.toLowerCase() === "x-amz-security-token" || n.toLowerCase() === "cookie" || n.toLowerCase() === "set-cookie" ? "***" : e
]))), "retryOfRequestLogID" in r && (r.retryOfRequestLogID && (r.retryOf = r.retryOfRequestLogID), delete r.retryOfRequestLogID), r);
var Gt, Oe = /* @__PURE__ */ (() => {
  class r {
    constructor(e, t, s) {
      this.iterator = e, Gt.set(this, void 0), this.controller = t, y(this, Gt, s);
    }
    /**
     * Iterate the raw Server-Sent Events from `response` — `{event, data, raw}`
     * objects, before any JSON parsing or event-name filtering.
     *
     * This reads `response.body` directly (not a clone), so the response is
     * consumed. Use this in middleware that fully replaces the stream body; for
     * read-only observation of parsed events, use `ctx.parse()` instead.
     */
    static rawEvents(e, t = new AbortController()) {
      return Ji(e, t);
    }
    static fromSSEResponse(e, t, s) {
      let i = !1;
      const a = s ? M(s) : console;
      async function* o() {
        if (i)
          throw new R("Cannot iterate over a consumed stream, use `.tee()` to split the stream.");
        i = !0;
        let l = !1;
        try {
          for await (const h of Ji(e, t))
            if (h.event !== "ping" && h.event !== null)
              if (h.event === "error") {
                const _ = fl(h.data) ?? h.data, d = _?.error?.type;
                throw new j(void 0, _, void 0, e.headers, d);
              } else {
                if (!h.data)
                  continue;
                try {
                  yield JSON.parse(h.data);
                } catch (_) {
                  throw a.error("Could not parse message into JSON:", h.data), a.error("From chunk:", h.raw), _;
                }
              }
          l = !0;
        } catch (h) {
          if (dt(h))
            return;
          throw h;
        } finally {
          l || t.abort(), lt(t);
        }
      }
      return new r(o, t, s);
    }
    /**
     * Generates a Stream from a newline-separated ReadableStream
     * where each item is a JSON value.
     */
    static fromReadableStream(e, t, s) {
      let i = !1;
      async function* a() {
        const l = new mi(), h = di(e);
        for await (const _ of h)
          for (const d of l.decode(_))
            yield d;
        for (const _ of l.flush())
          yield _;
      }
      async function* o() {
        if (i)
          throw new R("Cannot iterate over a consumed stream, use `.tee()` to split the stream.");
        i = !0;
        let l = !1;
        try {
          for await (const h of a())
            l || h && (yield JSON.parse(h));
          l = !0;
        } catch (h) {
          if (dt(h))
            return;
          throw h;
        } finally {
          l || t.abort(), lt(t);
        }
      }
      return new r(o, t, s);
    }
    [(Gt = /* @__PURE__ */ new WeakMap(), Symbol.asyncIterator)]() {
      return this.iterator();
    }
    /**
     * Splits the stream into two streams which can be
     * independently read from at different speeds.
     */
    tee() {
      const e = [], t = [], s = this[Symbol.asyncIterator](), i = (a) => ({
        next: () => {
          if (a.length === 0) {
            const o = s.next();
            e.push(o), t.push(o);
          }
          return a.shift();
        }
      });
      return [
        new r(() => i(e), this.controller, c(this, Gt, "f")),
        new r(() => i(t), this.controller, c(this, Gt, "f"))
      ];
    }
    /**
     * Converts this stream to a newline-separated ReadableStream of
     * JSON stringified values in the stream
     * which can be turned back into a Stream with `Stream.fromReadableStream()`.
     */
    toReadableStream() {
      const e = this;
      let t;
      return ml({
        async start() {
          t = e[Symbol.asyncIterator]();
        },
        async pull(s) {
          try {
            const { value: i, done: a } = await t.next();
            if (a)
              return s.close();
            const o = Cl(JSON.stringify(i) + `
`);
            s.enqueue(o);
          } catch (i) {
            s.error(i);
          }
        },
        async cancel() {
          await t.return?.();
        }
      });
    }
  }
  return r;
})();
async function* Ji(r, n) {
  if (!r.body)
    throw n.abort(), typeof globalThis.navigator < "u" && globalThis.navigator.product === "ReactNative" ? new R("The default react-native fetch implementation does not support streaming. Please use expo/fetch: https://docs.expo.dev/versions/latest/sdk/expo/#expofetch-api") : new R("Attempted to iterate over a response with no body");
  const e = new Bh(), t = new mi(), s = di(r.body);
  for await (const i of s)
    for (const a of t.decode(i)) {
      const o = e.decode(a);
      o && (yield o);
    }
  for (const i of t.flush()) {
    const a = e.decode(i);
    a && (yield a);
  }
}
class Bh {
  constructor() {
    this.event = null, this.data = [], this.chunks = [];
  }
  decode(n) {
    if (n.endsWith("\r") && (n = n.substring(0, n.length - 1)), !n) {
      if (!this.event && !this.data.length)
        return null;
      const i = {
        event: this.event,
        data: this.data.join(`
`),
        raw: this.chunks
      };
      return this.event = null, this.data = [], this.chunks = [], i;
    }
    if (this.chunks.push(n), n.startsWith(":"))
      return null;
    let [e, t, s] = Uh(n, ":");
    return s.startsWith(" ") && (s = s.substring(1)), e === "event" ? this.event = s : e === "data" && this.data.push(s), null;
  }
}
function Uh(r, n) {
  const e = r.indexOf(n);
  return e !== -1 ? [r.substring(0, e), n, r.substring(e + n.length)] : [r, "", ""];
}
const Il = Symbol.for("brand.privateNullableHeaders");
function* Fh(r) {
  if (!r)
    return;
  if (Il in r) {
    const { values: t, nulls: s } = r;
    yield* t.entries();
    for (const i of s)
      yield [i, null];
    return;
  }
  let n = !1, e;
  r instanceof Headers ? e = r.entries() : $i(r) ? e = r : (n = !0, e = Object.entries(r ?? {}));
  for (let t of e) {
    const s = t[0];
    if (typeof s != "string")
      throw new TypeError("expected header name to be a string");
    const i = $i(t[1]) ? t[1] : [t[1]];
    let a = !1;
    for (const o of i)
      o !== void 0 && (n && !a && (a = !0, yield [s, Pr]), yield [s, o]);
  }
}
const Pr = Symbol("clear"), Wh = /* @__PURE__ */ new Set(["x-stainless-helper"]), jh = (r, n) => {
  const e = r ? r.split(",").map((t) => t.trim()).filter(Boolean) : [];
  for (const t of n.split(",").map((s) => s.trim()))
    t && !e.includes(t) && e.push(t);
  return e.join(", ");
}, p = (r) => {
  const n = new Headers(), e = /* @__PURE__ */ new Set();
  for (const t of r) {
    const s = /* @__PURE__ */ new Set();
    for (const [i, a] of Fh(t)) {
      const o = i.toLowerCase();
      if (Wh.has(o)) {
        if (a === Pr)
          continue;
        a === null ? (n.delete(i), e.add(o)) : (n.set(i, jh(n.get(i), a)), e.delete(o));
        continue;
      }
      (a === Pr || !s.has(o)) && (n.delete(i), s.add(o), a === Pr) || (a === null ? (n.delete(i), e.add(o)) : (n.append(i, a), e.delete(o)));
    }
  }
  return { [Il]: !0, values: n, nulls: e };
}, Yi = "com.anthropic.sdk.typescript", Hh = "error.type", bi = "gen_ai.conversation.id", Jr = "gen_ai.provider.name", Dh = "http.request.method", Kh = "http.request.resend_count", wi = "http.response.status_code", Gh = "http.route", Vh = "server.address", Jh = "server.port", Yh = "url.full", Xh = "url.path", Qh = "url.query", Zh = "url.scheme", e_ = "anthropic.session.thread.id", t_ = 75e4;
function n_(r) {
  const { tracerProvider: n, propagation: e, traces: t } = r === !1 ? { traces: !1 } : r ?? r_(), { enabled: s, contentMode: i, maxContentBytes: a } = typeof t == "boolean" ? { enabled: t } : t ?? {};
  return Object.freeze({
    tracerProvider: n,
    propagation: e ?? !0,
    traces: Object.freeze({
      enabled: s ?? !0,
      contentMode: i === "content" ? "content" : "metadata_only",
      maxContentBytes: a !== void 0 && Number.isInteger(a) && a >= 1 ? a : t_
    })
  });
}
function r_() {
  return {
    propagation: O("ANTHROPIC_OPEN_TELEMETRY_PROPAGATION")?.toLowerCase() !== "false",
    traces: {
      enabled: O("ANTHROPIC_OPEN_TELEMETRY")?.toLowerCase() !== "false",
      contentMode: O("ANTHROPIC_OPEN_TELEMETRY_TRACES_CONTENT_MODE")?.toLowerCase() === "content" ? "content" : "metadata_only",
      // The variable holds decimal digits only: `1e3` and `0x10` are not sizes.
      maxContentBytes: Number(/^\d+$/.exec(O("ANTHROPIC_OPEN_TELEMETRY_TRACES_MAX_CONTENT_BYTES") ?? "")?.[0] ?? NaN)
    }
  };
}
function s_(r, n, e) {
  if (!r.traces.enabled)
    return;
  const t = e !== void 0 ? `${Yi}.${e}` : Yi;
  return (r.tracerProvider ?? _t.getTracerProvider()).getTracer(t, n);
}
function F(r, n) {
  try {
    return n();
  } catch (e) {
    r && M(r).debug("could not record telemetry", e);
    return;
  }
}
function u(r, n, e, t) {
  if (e?.__span)
    return e.__span;
  const s = r._tracer;
  if (s)
    return F(r, () => {
      const i = Date.now(), a = t?.attributes?.[e_], o = e?.openTelemetry?.conversationId ?? (typeof a == "string" ? a : void 0), l = s.startSpan(n, {
        kind: Vr.CLIENT,
        // On the span from its start, with what the method gives, for a sampler to decide on.
        attributes: {
          [Jr]: r._genAIProviderName,
          ...a_(r.baseURL),
          ...o != null ? { [bi]: o } : void 0,
          ...t?.route != null ? { [Gh]: t.route } : void 0,
          ...t?.attributes
        }
      });
      if (!(!l.isRecording() && !(r.openTelemetry.propagation ? Object.keys(Ll(l)).length > 0 : _t.isSpanContextValid(l.spanContext()))))
        return { ...t, span: l, name: n, startTime: i };
    });
}
function i_(r, n) {
  if (r.createdIDAttribute === void 0 || typeof n != "object" || n === null)
    return;
  const e = n[r.createdIDField ?? "id"];
  typeof e == "string" && r.span.setAttribute(r.createdIDAttribute, e);
}
function a_(r) {
  try {
    const { hostname: n, port: e, protocol: t } = new URL(r);
    return {
      // `URL.hostname` keeps an IPv6 literal's brackets, which delimit it in a URL;
      // `server.address` is the bare address.
      [Vh]: n.replace(/^\[(.*)\]$/, "$1"),
      [Jh]: e ? Number(e) : t === "http:" ? 80 : 443
    };
  } catch {
    return {};
  }
}
function o_(r, n, e, t = !1) {
  if (r.attempts = (r.attempts ?? 0) + 1, r.attempts > 1) {
    r.span.setAttribute(Kh, r.attempts - 1);
    return;
  }
  r.span.setAttribute(Dh, n);
  try {
    const { protocol: s, host: i, pathname: a, search: o } = new URL(e), l = l_(o.slice(1), r.queryParams, r.contentQueryParams);
    if (r.span.setAttributes({
      [Zh]: s.slice(0, -1),
      [Xh]: a
    }), l?.content && !t)
      return;
    r.span.setAttributes({
      ...l !== void 0 ? { [Qh]: l.value } : void 0,
      // With the recorded query, not the one sent.
      [Yh]: `${s}//${i}${a}${l !== void 0 ? `?${l.value}` : ""}`
    });
  } catch {
  }
}
const c_ = ["email", "path_prefix", "expected_content_sha256"];
function l_(r, n, e) {
  if (!r || !n?.length)
    return;
  let t = !1;
  const s = r.split("&").filter((i) => {
    try {
      const a = decodeURIComponent(i.split("=", 1)[0]), o = n.includes(a) || !a.endsWith("[]") ? a : a.slice(0, -2);
      return n.includes(o) ? (t || (t = c_.includes(o) || !!e?.includes(o)), !0) : !1;
    } catch {
      return !1;
    }
  });
  return s.length ? { value: s.join("&"), content: t } : void 0;
}
function u_(r, n) {
  const e = p([n]).values;
  for (const [t, s] of Object.entries(Ll(r)))
    e.set(t, s);
  return e;
}
function Tn(r, n) {
  if (r.isRecording()) {
    switch (h_(r, n), n.status) {
      case "success":
        r.setStatus({ code: ht.OK });
        break;
      case "error":
        Ke(r, n.error);
        break;
    }
    r.end();
  }
}
function Nl(r, n, e) {
  const t = r[Symbol.asyncIterator];
  let s = !1;
  const i = (l) => {
    if (!s) {
      s = !0, n.removeEventListener("abort", a);
      try {
        e.onEnd(l);
      } catch {
      }
    }
  }, a = () => i({ reason: "canceled" });
  if (n.aborted)
    return a();
  n.addEventListener("abort", a, { once: !0 });
  let o = !1;
  r[Symbol.asyncIterator] = function() {
    const l = t.call(this);
    if (o)
      return l;
    o = !0, n.removeEventListener("abort", a);
    const h = {
      async next() {
        let _;
        try {
          _ = await l.next();
        } catch (d) {
          throw i({ reason: "failed", error: d }), d;
        }
        if (_.done)
          i({ reason: n.aborted ? "canceled" : "completed" });
        else if (!s)
          try {
            e.onItem?.(_.value);
          } catch {
          }
        return _;
      },
      async return(_) {
        return a(), await l.return?.(_) ?? { done: !0, value: _ };
      },
      async throw(_) {
        if (a(), l.throw)
          return l.throw(_);
        throw _;
      },
      [Symbol.asyncIterator]: () => h
    };
    return h;
  };
}
function d_(r, n, e) {
  if (!r.isRecording())
    return;
  r.setAttribute(wi, e.response.status);
  const t = n instanceof Oe;
  Nl(n, e.controller.signal, {
    onEnd(s) {
      s.reason === "failed" ? Ke(r, s.error) : s.reason === "completed" && !t && r.setStatus({ code: ht.OK }), r.end();
    }
  });
}
function h_(r, n) {
  const e = n.response?.status ?? (n.status === "error" && n.error instanceof j ? n.error.status : void 0);
  e !== void 0 && r.setAttribute(wi, e);
}
function Ke(r, n, e) {
  n instanceof ue || dt(n) || (r.setStatus({ code: ht.ERROR }), r.setAttribute(Hh, e ?? __(n)));
}
function Ll(r) {
  const n = {};
  return Ml.inject(_t.setSpan(he.active(), r), n), n;
}
function __(r) {
  if (r instanceof Us)
    return "client_timeout_error";
  if (r instanceof qt)
    return "connection_error";
  if (r instanceof j) {
    if (r.type)
      return r.type;
    if (r.status !== void 0)
      return String(r.status);
  }
  return "client_error";
}
const ql = "RFC3986", Bl = (r) => String(r), Xi = {
  RFC1738: (r) => String(r).replace(/%20/g, "+"),
  RFC3986: Bl
}, p_ = "RFC1738";
let Ds = (r, n) => (Ds = Object.hasOwn ?? Function.prototype.call.bind(Object.prototype.hasOwnProperty), Ds(r, n));
const be = /* @__PURE__ */ (() => {
  const r = [];
  for (let n = 0; n < 256; ++n)
    r.push("%" + ((n < 16 ? "0" : "") + n.toString(16)).toUpperCase());
  return r;
})(), ls = 1024, f_ = (r, n, e, t, s) => {
  if (r.length === 0)
    return r;
  let i = r;
  if (typeof r == "symbol" ? i = Symbol.prototype.toString.call(r) : typeof r != "string" && (i = String(r)), e === "iso-8859-1")
    return escape(i).replace(/%u[0-9a-f]{4}/gi, function(o) {
      return "%26%23" + parseInt(o.slice(2), 16) + "%3B";
    });
  let a = "";
  for (let o = 0; o < i.length; o += ls) {
    const l = i.length >= ls ? i.slice(o, o + ls) : i, h = [];
    for (let _ = 0; _ < l.length; ++_) {
      let d = l.charCodeAt(_);
      if (d === 45 || // -
      d === 46 || // .
      d === 95 || // _
      d === 126 || // ~
      d >= 48 && d <= 57 || // 0-9
      d >= 65 && d <= 90 || // a-z
      d >= 97 && d <= 122 || // A-Z
      s === p_ && (d === 40 || d === 41)) {
        h[h.length] = l.charAt(_);
        continue;
      }
      if (d < 128) {
        h[h.length] = be[d];
        continue;
      }
      if (d < 2048) {
        h[h.length] = be[192 | d >> 6] + be[128 | d & 63];
        continue;
      }
      if (d < 55296 || d >= 57344) {
        h[h.length] = be[224 | d >> 12] + be[128 | d >> 6 & 63] + be[128 | d & 63];
        continue;
      }
      _ += 1, d = 65536 + ((d & 1023) << 10 | l.charCodeAt(_) & 1023), h[h.length] = be[240 | d >> 18] + be[128 | d >> 12 & 63] + be[128 | d >> 6 & 63] + be[128 | d & 63];
    }
    a += h.join("");
  }
  return a;
};
function g_(r) {
  return !r || typeof r != "object" ? !1 : !!(r.constructor && r.constructor.isBuffer && r.constructor.isBuffer(r));
}
function Qi(r, n) {
  if (re(r)) {
    const e = [];
    for (let t = 0; t < r.length; t += 1)
      e.push(n(r[t]));
    return e;
  }
  return n(r);
}
const Ul = {
  brackets(r) {
    return String(r) + "[]";
  },
  comma: "comma",
  indices(r, n) {
    return String(r) + "[" + n + "]";
  },
  repeat(r) {
    return String(r);
  }
}, Fl = function(r, n) {
  Array.prototype.push.apply(r, re(n) ? n : [n]);
};
let Zi;
const D = {
  addQueryPrefix: !1,
  allowDots: !1,
  allowEmptyArrays: !1,
  arrayFormat: "indices",
  charset: "utf-8",
  charsetSentinel: !1,
  delimiter: "&",
  encode: !0,
  encodeDotInKeys: !1,
  encoder: f_,
  encodeValuesOnly: !1,
  format: ql,
  formatter: Bl,
  /** @deprecated */
  indices: !1,
  serializeDate(r) {
    return (Zi ?? (Zi = Function.prototype.call.bind(Date.prototype.toISOString)))(r);
  },
  skipNulls: !1,
  strictNullHandling: !1
};
function m_(r) {
  return typeof r == "string" || typeof r == "number" || typeof r == "boolean" || typeof r == "symbol" || typeof r == "bigint";
}
const us = {};
function Wl(r, n, e, t, s, i, a, o, l, h, _, d, m, g, b, w, S, x) {
  let v = r, k = x, A = 0, E = !1;
  for (; (k = k.get(us)) !== void 0 && !E; ) {
    const C = k.get(r);
    if (A += 1, typeof C < "u") {
      if (C === A)
        throw new RangeError("Cyclic object value");
      E = !0;
    }
    typeof k.get(us) > "u" && (A = 0);
  }
  if (typeof h == "function" ? v = h(n, v) : v instanceof Date ? v = m?.(v) : e === "comma" && re(v) && (v = Qi(v, function(C) {
    return C instanceof Date ? m?.(C) : C;
  })), v === null) {
    if (i)
      return l && !w ? (
        // @ts-expect-error
        l(n, D.encoder, S, "key", g)
      ) : n;
    v = "";
  }
  if (m_(v) || g_(v)) {
    if (l) {
      const C = w ? n : l(n, D.encoder, S, "key", g);
      return [
        b?.(C) + "=" + // @ts-expect-error
        b?.(l(v, D.encoder, S, "value", g))
      ];
    }
    return [b?.(n) + "=" + b?.(String(v))];
  }
  const z = [];
  if (typeof v > "u")
    return z;
  let q;
  if (e === "comma" && re(v))
    w && l && (v = Qi(v, l)), q = [{ value: v.length > 0 ? v.join(",") || null : void 0 }];
  else if (re(h))
    q = h;
  else {
    const C = Object.keys(v);
    q = _ ? C.sort(_) : C;
  }
  const $ = o ? String(n).replace(/\./g, "%2E") : String(n), I = t && re(v) && v.length === 1 ? $ + "[]" : $;
  if (s && re(v) && v.length === 0)
    return I + "[]";
  for (let C = 0; C < q.length; ++C) {
    const _e = q[C], Ie = (
      // @ts-ignore
      typeof _e == "object" && typeof _e.value < "u" ? _e.value : v[_e]
    );
    if (a && Ie === null)
      continue;
    const Ne = d && o ? _e.replace(/\./g, "%2E") : _e, ju = re(v) ? typeof e == "function" ? e(I, Ne) : I : I + (d ? "." + Ne : "[" + Ne + "]");
    x.set(r, A);
    const Mi = /* @__PURE__ */ new WeakMap();
    Mi.set(us, x), Fl(z, Wl(
      Ie,
      ju,
      e,
      t,
      s,
      i,
      a,
      o,
      // @ts-ignore
      e === "comma" && w && re(v) ? null : l,
      h,
      _,
      d,
      m,
      g,
      b,
      w,
      S,
      Mi
    ));
  }
  return z;
}
function b_(r = D) {
  if (typeof r.allowEmptyArrays < "u" && typeof r.allowEmptyArrays != "boolean")
    throw new TypeError("`allowEmptyArrays` option can only be `true` or `false`, when provided");
  if (typeof r.encodeDotInKeys < "u" && typeof r.encodeDotInKeys != "boolean")
    throw new TypeError("`encodeDotInKeys` option can only be `true` or `false`, when provided");
  if (r.encoder !== null && typeof r.encoder < "u" && typeof r.encoder != "function")
    throw new TypeError("Encoder has to be a function.");
  const n = r.charset || D.charset;
  if (typeof r.charset < "u" && r.charset !== "utf-8" && r.charset !== "iso-8859-1")
    throw new TypeError("The charset option must be either utf-8, iso-8859-1, or undefined");
  let e = ql;
  if (typeof r.format < "u") {
    if (!Ds(Xi, r.format))
      throw new TypeError("Unknown format option provided.");
    e = r.format;
  }
  const t = Xi[e];
  let s = D.filter;
  (typeof r.filter == "function" || re(r.filter)) && (s = r.filter);
  let i;
  if (r.arrayFormat && r.arrayFormat in Ul ? i = r.arrayFormat : "indices" in r ? i = r.indices ? "indices" : "repeat" : i = D.arrayFormat, "commaRoundTrip" in r && typeof r.commaRoundTrip != "boolean")
    throw new TypeError("`commaRoundTrip` must be a boolean, or absent");
  const a = typeof r.allowDots > "u" ? r.encodeDotInKeys ? !0 : D.allowDots : !!r.allowDots;
  return {
    addQueryPrefix: typeof r.addQueryPrefix == "boolean" ? r.addQueryPrefix : D.addQueryPrefix,
    // @ts-ignore
    allowDots: a,
    allowEmptyArrays: typeof r.allowEmptyArrays == "boolean" ? !!r.allowEmptyArrays : D.allowEmptyArrays,
    arrayFormat: i,
    charset: n,
    charsetSentinel: typeof r.charsetSentinel == "boolean" ? r.charsetSentinel : D.charsetSentinel,
    commaRoundTrip: !!r.commaRoundTrip,
    delimiter: typeof r.delimiter > "u" ? D.delimiter : r.delimiter,
    encode: typeof r.encode == "boolean" ? r.encode : D.encode,
    encodeDotInKeys: typeof r.encodeDotInKeys == "boolean" ? r.encodeDotInKeys : D.encodeDotInKeys,
    encoder: typeof r.encoder == "function" ? r.encoder : D.encoder,
    encodeValuesOnly: typeof r.encodeValuesOnly == "boolean" ? r.encodeValuesOnly : D.encodeValuesOnly,
    filter: s,
    format: e,
    formatter: t,
    serializeDate: typeof r.serializeDate == "function" ? r.serializeDate : D.serializeDate,
    skipNulls: typeof r.skipNulls == "boolean" ? r.skipNulls : D.skipNulls,
    // @ts-ignore
    sort: typeof r.sort == "function" ? r.sort : null,
    strictNullHandling: typeof r.strictNullHandling == "boolean" ? r.strictNullHandling : D.strictNullHandling
  };
}
function w_(r, n = {}) {
  let e = r;
  const t = b_(n);
  let s, i;
  typeof t.filter == "function" ? (i = t.filter, e = i("", e)) : re(t.filter) && (i = t.filter, s = i);
  const a = [];
  if (typeof e != "object" || e === null)
    return "";
  const o = Ul[t.arrayFormat], l = o === "comma" && t.commaRoundTrip;
  s || (s = Object.keys(e)), t.sort && s.sort(t.sort);
  const h = /* @__PURE__ */ new WeakMap();
  for (let m = 0; m < s.length; ++m) {
    const g = s[m];
    t.skipNulls && e[g] === null || Fl(a, Wl(
      e[g],
      g,
      // @ts-expect-error
      o,
      l,
      t.allowEmptyArrays,
      t.strictNullHandling,
      t.skipNulls,
      t.encodeDotInKeys,
      t.encode ? t.encoder : null,
      t.filter,
      t.sort,
      t.allowDots,
      t.serializeDate,
      t.format,
      t.formatter,
      t.encodeValuesOnly,
      t.charset,
      h
    ));
  }
  const _ = a.join(t.delimiter);
  let d = t.addQueryPrefix === !0 ? "?" : "";
  return t.charsetSentinel && (t.charset === "iso-8859-1" ? d += "utf8=%26%2310003%3B&" : d += "utf8=%E2%9C%93&"), _.length > 0 ? d + _ : "";
}
function y_(r) {
  return w_(r, { arrayFormat: "brackets" });
}
const v_ = "urn:ietf:params:oauth:grant-type:jwt-bearer", k_ = "refresh_token", jl = "/v1/oauth/token", Fr = "oauth-2025-04-20", S_ = "oidc-federation-2026-04-01", T_ = 120, yi = 30, A_ = 5, ea = 1 << 20;
function Hl(r) {
  if (!r)
    return;
  let n;
  try {
    n = new URL(r);
  } catch (t) {
    throw new B(`Invalid token endpoint base URL "${r}": ${t}`);
  }
  if (n.protocol === "https:")
    return;
  const e = n.hostname.toLowerCase().replace(/^\[|\]$/g, "");
  if (!(n.protocol === "http:" && (e === "localhost" || e === "127.0.0.1" || e === "::1")))
    throw new B(`Refusing to send credential over non-https token endpoint "${r}"`);
}
async function Dl(r, n) {
  const e = await E_(r);
  let t;
  try {
    t = JSON.parse(e);
  } catch {
    throw new B(`Token endpoint returned non-JSON response (status ${r.status})`, r.status, fe(e), n);
  }
  if (!t.access_token)
    throw new B(`Token endpoint response missing access_token: ${JSON.stringify(fe(t))}`, r.status, fe(t), n);
  if (t.token_type && t.token_type.toLowerCase() !== "bearer")
    throw new B(`Token endpoint response: unsupported token_type "${t.token_type}" (want Bearer)`, r.status, fe(t), n);
  return t;
}
const ds = 2e3, x_ = /* @__PURE__ */ new Set(["error", "error_description", "error_uri"]);
function fe(r) {
  if (r == null)
    return r;
  if (typeof r == "string") {
    let n;
    try {
      n = JSON.parse(r);
    } catch {
      return r.length <= ds ? r : r.slice(0, ds) + `... <${r.length - ds} more chars>`;
    }
    return JSON.stringify(fe(n));
  }
  if (typeof r == "object" && !Array.isArray(r)) {
    const n = {};
    for (const [e, t] of Object.entries(r))
      x_.has(e) && (n[e] = t);
    return n;
  }
  return null;
}
async function Kl(r, n = (e) => console.warn(`anthropic-sdk: ${e}`)) {
  if (typeof process > "u" || process.platform === "win32")
    return;
  const { fs: e } = await Promise.resolve().then(() => $e);
  let t = r, s;
  try {
    t = await e.promises.realpath(r), s = await e.promises.stat(t);
  } catch {
    return;
  }
  const i = s.mode & 511;
  if (i & 18)
    throw new B(`Credentials file at ${t} is group/world-writable (mode 0o${i.toString(8)}); this allows other local users to plant tokens. Run \`chmod 600 ${t}\`.`);
  if (i & 36)
    throw new B(`Credentials file at ${t} is group/world-readable (mode 0o${i.toString(8)}); run \`chmod 600 ${t}\` before retrying.`);
  typeof process.getuid == "function" && s.uid !== process.getuid() && n(`credentials file at ${t} is owned by uid ${s.uid} (current process uid ${process.getuid()}); verify this is intentional.`);
}
async function Gl(r, n) {
  const { fs: e, path: t } = await Promise.resolve().then(() => $e), s = t.dirname(r);
  await e.promises.mkdir(s, { recursive: !0, mode: 448 });
  const i = `${r}.${process.pid}.${Math.random().toString(36).slice(2)}.tmp`;
  try {
    const a = await e.promises.open(i, "w", 384);
    try {
      await a.writeFile(JSON.stringify(n, null, 2)), await a.sync();
    } finally {
      await a.close();
    }
    await e.promises.rename(i, r);
  } catch (a) {
    throw await e.promises.unlink(i).catch(() => {
    }), a;
  }
  try {
    const a = await e.promises.open(s, "r");
    try {
      await a.sync();
    } finally {
      await a.close();
    }
  } catch {
  }
}
async function E_(r) {
  if (!r.body)
    return "";
  const n = r.body.getReader(), e = [];
  let t = 0;
  for (; ; ) {
    const { done: i, value: a } = await n.read();
    if (i)
      break;
    if (t + a.length > ea) {
      const o = ea - t;
      o > 0 && e.push(a.subarray(0, o)), await n.cancel();
      break;
    }
    e.push(a), t += a.length;
  }
  let s;
  if (e.length === 1)
    s = e[0];
  else {
    s = new Uint8Array(e.reduce((a, o) => a + o.length, 0));
    let i = 0;
    for (const a of e)
      s.set(a, i), i += a.length;
  }
  return new TextDecoder("utf-8").decode(s);
}
class B extends R {
  constructor(n, e = null, t = null, s = null) {
    super(n), this.statusCode = e, this.body = t, this.requestId = s;
  }
}
function ut() {
  return Math.floor(Date.now() / 1e3);
}
class R_ {
  constructor(n, e) {
    this.cached = null, this.pendingRefresh = null, this.nextForce = !1, this.lastAdvisoryError = 0, this.provider = n, this.onAdvisoryRefreshError = e;
  }
  async getToken() {
    const n = this.nextForce;
    this.nextForce = !1;
    const e = this.cached;
    if (n || e == null)
      return (await this.refresh(n)).token;
    if (e.expiresAt == null)
      return e.token;
    const t = e.expiresAt - ut();
    return t > T_ ? e.token : t > yi ? (this.backgroundRefresh(), e.token) : (await this.refresh()).token;
  }
  /**
   * Clears the cached token and marks the next {@link getToken} as a forced
   * refresh, so the underlying provider bypasses any on-disk freshness check.
   * Called after a 401 — the server has just told us the token is bad even
   * if its `expires_at` still looks fresh.
   */
  invalidate() {
    this.cached = null, this.nextForce = !0;
  }
  /**
   * Mandatory refresh. Joins any in-flight refresh unless forced — a forced
   * refresh must not coalesce into a non-forced one that may re-serve the
   * same stale disk token.
   */
  refresh(n = !1) {
    return this.pendingRefresh && !n ? this.pendingRefresh : this.doRefresh(n);
  }
  /**
   * Advisory background refresh. Shares the same in-flight promise as
   * mandatory refreshes for deduplication, but swallows errors so the
   * stale cached token keeps being served. Backs off for
   * {@link ADVISORY_REFRESH_BACKOFF_IN_SECONDS} after a failure so an
   * outage during the advisory window doesn't hammer the token endpoint.
   */
  backgroundRefresh() {
    this.pendingRefresh || ut() - this.lastAdvisoryError < A_ || this.doRefresh().catch((n) => {
      this.lastAdvisoryError = ut(), this.onAdvisoryRefreshError?.(n);
    });
  }
  /**
   * Core refresh. Sets {@link pendingRefresh} so concurrent callers
   * (both advisory and mandatory) coalesce into a single provider call.
   */
  doRefresh(n = !1) {
    return this.pendingRefresh = this.provider(n ? { forceRefresh: !0 } : void 0).then((e) => (this.cached = e, this.pendingRefresh = null, e), (e) => {
      throw this.pendingRefresh = null, e;
    }), this.pendingRefresh;
  }
}
const P_ = "gen_ai.agent.name", En = "gen_ai.input.messages", vi = "gen_ai.operation.name", Ut = "gen_ai.output.messages", Vl = "gen_ai.output.type", z_ = "gen_ai.request.max_tokens", Cn = "gen_ai.request.model", M_ = "gen_ai.request.reasoning.level", Ks = "gen_ai.request.stop_sequences", O_ = "gen_ai.request.stream", C_ = "gen_ai.request.temperature", $_ = "gen_ai.request.top_k", I_ = "gen_ai.request.top_p", N_ = "gen_ai.response.id", L_ = "gen_ai.response.model", q_ = "gen_ai.response.time_to_first_chunk", Rn = "gen_ai.system_instructions", B_ = "gen_ai.tool.call.arguments", U_ = "gen_ai.tool.call.id", F_ = "gen_ai.tool.description", W_ = "gen_ai.tool.name", j_ = "gen_ai.tool.type", H_ = "gen_ai.usage.cache_write.input_tokens", D_ = "gen_ai.usage.cache_read.input_tokens", K_ = "gen_ai.usage.input_tokens", G_ = "gen_ai.usage.output_tokens", V_ = "gen_ai.usage.reasoning.output_tokens", J_ = "chat", Y_ = "execute_tool", X_ = "invoke_agent", Jl = "json", Q_ = "function", Z_ = "anthropic.request.id", ep = "anthropic.organization.id", tp = "anthropic.workspace.id", np = "anthropic.beta", rp = "anthropic.content.truncated", sp = "anthropic.message.stop_reason", ip = "anthropic.message.count_tokens.input_tokens", ap = "anthropic.request.service_tier", op = "anthropic.response.service_tier", cp = "anthropic.thinking.budget_tokens", lp = "anthropic.thinking.type", Gs = "anthropic.tool_result.content", up = "anthropic.toolset.name", dp = "anthropic.usage.cache_creation.ephemeral_1h_input_tokens", hp = "anthropic.usage.cache_creation.ephemeral_5m_input_tokens", _p = "anthropic.usage.compaction.input_tokens", pp = "anthropic.usage.compaction.output_tokens", fp = [
  [Z_, "request-id"],
  [ep, "anthropic-organization-id"],
  [tp, "anthropic-workspace-id"]
];
function ki(r, n, e, t) {
  const s = r.span, i = r.requestContentSize;
  if (e !== void 0 && i !== void 0) {
    const o = JSON.stringify([{ role: "assistant", parts: Bn(e) }]);
    if (i + 3 * o.length <= t || i + Yr(o) <= t) {
      s.setAttribute(Ut, o);
      return;
    }
  }
  const a = Xl(s, {
    // An empty list sets no attribute.
    [Ks]: n.stop_sequences?.length ? [...n.stop_sequences] : void 0,
    [Rn]: n.system === void 0 ? void 0 : Bn(n.system),
    [En]: n.messages.map((o) => ({ role: o.role, parts: Bn(o.content) })),
    [Ut]: e === void 0 ? void 0 : [{ role: "assistant", parts: Bn(e) }]
  }, t);
  e === void 0 && (r.requestContentSize = a);
}
function Bn(r) {
  return typeof r == "string" ? [{ type: "text", content: r }] : r?.map(gp) ?? [];
}
function gp(r) {
  switch (r.type) {
    case "text":
      return { type: "text", content: r.text };
    case "thinking":
      return { type: "reasoning", content: r.thinking };
    case "tool_use":
      return {
        type: "tool_call",
        id: r.id,
        name: r.name,
        arguments: r.input,
        // Only a call to a member of a toolset, such as `computer`, has one.
        ...typeof r.toolset_name == "string" ? { anthropic_toolset_name: r.toolset_name } : void 0
      };
    case "server_tool_use":
      return { type: "tool_call", id: r.id, name: r.name, arguments: r.input };
    case "mcp_tool_use":
      return {
        type: "tool_call",
        id: r.id,
        name: r.name,
        arguments: r.input,
        anthropic_mcp_server_name: r.server_name
      };
    case "tool_result":
      return {
        type: "tool_call_response",
        id: r.tool_use_id,
        response: Yl(r.content)
      };
    default:
      return typeof r.type != "string" ? { type: "anthropic_unknown" } : r.type.endsWith("_tool_result") && "tool_use_id" in r ? {
        type: "tool_call_response",
        id: r.tool_use_id,
        response: mp(r.content)
      } : { type: `anthropic_${r.type}` };
  }
}
function Yl(r) {
  return r == null ? [] : typeof r == "string" ? [{ type: "text", text: r }] : r.map((n) => n.type === "text" || n.type === "search_result" ? Pn(n) : typeof n.type != "string" ? { type: "unknown" } : { type: n.type });
}
function mp(r) {
  return r == null ? [] : typeof r == "string" ? [{ type: "text", text: r }] : Array.isArray(r) ? r.map((n) => n.type === "text" || n.type === "search_result" || n.type === "web_search_result" ? Pn(n) : typeof n.type != "string" ? { type: "unknown" } : { type: n.type }) : [Pn(r)];
}
function Pn(r) {
  if (Array.isArray(r))
    return r.map(Pn);
  if (typeof r != "object" || r === null)
    return r;
  const { type: n, file_type: e } = r;
  if (n === "image" || n === "document")
    return { type: n };
  const t = n === "text_editor_code_execution_view_result" && (e === "image" || e === "pdf");
  return Object.fromEntries(Object.entries(r).filter(([s]) => !s.startsWith("encrypted_") && !(s === "content" && t)).map(([s, i]) => [s, Pn(i)]));
}
function Xl(r, n, e) {
  const { [Ks]: t, [Rn]: s, [En]: i, [Ut]: a, [Gs]: o, ...l } = n, h = {
    [Rn]: s,
    [En]: i,
    [Ut]: a
  }, _ = {}, d = o?.map((A) => JSON.stringify(A)), g = 3 * ([...t ?? [], ...d ?? []].reduce((A, E) => A + E.length + 1, 2) + hs(l, _) + hs(h, _)) <= e ? (A) => 3 * A.length : Yr, b = () => Object.keys(h).reduce((A, E) => A + g(_[E] ?? ""), 0), w = t?.reduce((A, E) => A + g(E), 0) ?? 0, S = t !== void 0 && w <= e;
  let x = S ? w : 0, v = t !== void 0 && !S;
  for (const A of Object.keys(l)) {
    const E = g(_[A] ?? "");
    E > e ? (delete _[A], v = !0) : x += E;
  }
  let k = b();
  if (x + k > e) {
    const { truncated: A, ...E } = bp(h, x + k - e);
    v || (v = A), hs(E, _), k = b();
  }
  if (x += k, d !== void 0) {
    const A = yp(d, e - x, g);
    _[Gs] = A.json, x += A.size, v || (v = A.truncated);
  }
  v && r.setAttribute(rp, !0), S && r.setAttribute(Ks, t);
  for (const [A, E] of Object.entries(_))
    r.setAttribute(A, E);
  return x;
}
function hs(r, n) {
  let e = 0;
  for (const [t, s] of Object.entries(r))
    s !== void 0 && (n[t] = JSON.stringify(s), e += n[t].length);
  return e;
}
function bp(r, n) {
  const e = (h) => h?.map((_) => ({ ..._, parts: [..._.parts] })), t = r[Rn]?.slice(), s = e(r[En]), i = e(r[Ut]), a = [t ?? [], ...[...s ?? [], ...i ?? []].map(({ parts: h }) => h)];
  let o = a.reduce((h, _) => h + _.length, 0), l = !1;
  for (const h of a) {
    let _ = 0;
    for (; n > 0 && _ < h.length; ) {
      const d = h[_], m = Yr(JSON.stringify(d)), g = d.content;
      if (o === 1 && d.type === "text" && typeof g == "string") {
        const b = wp(d, g, m - n);
        b !== g && (h[_] = { ...d, content: b }, l = !0);
        break;
      }
      n -= m + (_ + 1 < h.length ? 1 : 0), _++, o--, l = !0;
    }
    h.splice(0, _);
  }
  return {
    [Rn]: t,
    [En]: s,
    [Ut]: i,
    truncated: l
  };
}
function wp(r, n, e) {
  const t = e - Yr(JSON.stringify({ ...r, content: "" })), s = n.slice(0, Math.max(t, 0)), i = JSON.stringify(s);
  let a = 0, o = 0, l = 0;
  for (; a < s.length; ) {
    const h = i.codePointAt(1 + o), _ = h > 65535 ? 2 : 1, d = h !== 92 ? _ : i[2 + o] === "u" ? 6 : 2;
    if (l += h < 128 ? d : h < 2048 ? 2 : h < 65536 ? 3 : 4, l > t)
      break;
    o += d, a += _;
  }
  return n.slice(0, a);
}
function yp(r, n, e) {
  const t = [];
  let s = 2;
  for (const i of r) {
    const a = s + (t.length === 0 ? 0 : 1) + e(i);
    if (a > n)
      break;
    t.push(i), s = a;
  }
  return { json: "[" + t.join(",") + "]", size: s, truncated: t.length < r.length };
}
function Yr(r) {
  let n = 0;
  for (let e = 0; e < r.length; e++) {
    const t = r.charCodeAt(e);
    t < 128 ? n += 1 : t < 2048 ? n += 2 : t >= 55296 && t < 56320 && (r.charCodeAt(e + 1) & 64512) === 56320 ? (n += 4, e++) : n += 3;
  }
  return n;
}
function Ql(r, n, e, t) {
  r.setAttribute(N_, n.id), r.setAttribute(L_, n.model), r.setAttribute(K_, e.input_tokens + (e.cache_read_input_tokens ?? 0) + (e.cache_creation_input_tokens ?? 0)), e.cache_creation_input_tokens != null && r.setAttribute(H_, e.cache_creation_input_tokens), e.cache_read_input_tokens != null && r.setAttribute(D_, e.cache_read_input_tokens);
  const s = e.cache_creation;
  if (s != null && (r.setAttribute(hp, s.ephemeral_5m_input_tokens), r.setAttribute(dp, s.ephemeral_1h_input_tokens)), e.service_tier != null && r.setAttribute(op, e.service_tier), !t)
    return;
  r.setAttribute(G_, e.output_tokens);
  const i = e.output_tokens_details;
  i != null && r.setAttribute(V_, i.thinking_tokens);
  const a = e.iterations?.filter((o) => o.type === "compaction") ?? [];
  a.length > 0 && (r.setAttribute(_p, a.reduce((o, l) => o + l.input_tokens + l.cache_read_input_tokens + l.cache_creation_input_tokens, 0)), r.setAttribute(pp, a.reduce((o, l) => o + l.output_tokens, 0))), n.stop_reason != null && r.setAttribute(sp, n.stop_reason);
}
function zr(r, n, e) {
  if (n.isRecording())
    try {
      const t = e.status === "error" ? e.error : void 0, s = e.response?.headers ?? (t instanceof j ? t.headers : void 0);
      for (const [i, a] of fp) {
        const o = s?.get(a);
        o && n.setAttribute(i, o);
      }
    } catch (t) {
      M(r).debug("could not record the API call on its span", t);
    }
}
function Xr(r, n, e) {
  const t = {
    [vi]: J_,
    [Cn]: n.model
  };
  try {
    const s = (p([r._options.defaultHeaders, e]).values.get("anthropic-beta") ?? "").split(",").map((o) => o.trim()).filter(Boolean);
    s.length && (t[np] = s), t[z_] = n.max_tokens, n.temperature != null && (t[C_] = n.temperature), n.top_p != null && (t[I_] = n.top_p), n.top_k != null && (t[$_] = n.top_k), n.stream === !0 && (t[O_] = !0), n.output_config?.format?.type === "json_schema" && (t[Vl] = Jl);
    const i = n.output_config?.effort;
    i != null && (t[M_] = i), n.service_tier != null && (t[ap] = n.service_tier);
    const a = n.thinking;
    a != null && (t[lp] = a.type), a?.type === "enabled" && (t[cp] = a.budget_tokens);
  } catch (s) {
    M(r).debug("could not record the request on its span", s);
  }
  return { route: "/v1/messages", attributes: t };
}
function Zl(r, n, e) {
  if (!n?.span.isRecording())
    return n;
  try {
    const { contentMode: t, maxContentBytes: s } = r.openTelemetry.traces;
    t === "content" && ki(n, e, void 0, s);
  } catch (t) {
    M(r).debug("could not record the request on its span", t);
  }
  return n;
}
function eu(r, n, e, t) {
  if (!n?.span.isRecording() || t instanceof Oe)
    return;
  const s = n.span;
  try {
    Ql(s, t, t.usage, !0);
    const { contentMode: i, maxContentBytes: a } = r.openTelemetry.traces;
    i === "content" && ki(n, e, t.content, a);
  } catch (i) {
    M(r).debug("could not record the response on its span", i);
  }
}
function tu(r, n, e) {
  try {
    n?.span.setAttribute(ip, e.input_tokens);
  } catch (t) {
    M(r).debug("could not record the response on its span", t);
  }
}
function vp(r, n, e) {
  try {
    n?.span.setAttributes({
      [P_]: e.agent.name,
      [Cn]: e.agent.model.id
    });
  } catch (t) {
    M(r).debug("could not record the response on its span", t);
  }
}
function kp() {
  const r = /* @__PURE__ */ new Set(["traceparent", "tracestate", "baggage"]);
  try {
    for (const n of Ml.fields())
      r.add(n.toLowerCase());
  } catch (n) {
    $l().debug("could not record telemetry", n);
  }
  return r;
}
function nu(r) {
  const n = kp(), e = Array.from(r.entries()).filter(([t]) => n.has(t));
  for (const [t] of e)
    r.delete(t);
  return e;
}
function Sp(r) {
  return (n, e, t) => {
    const s = new Headers(n.headers), i = nu(s);
    return r({ ...n, headers: s }, (a) => {
      const o = new Headers(a.headers);
      for (const [l, h] of i)
        o.set(l, h);
      return e({ ...a, headers: o });
    }, t);
  };
}
function Si(r, n, e, t) {
  if (!(!n.span.isRecording() || r.openTelemetry.traces.contentMode !== "content"))
    try {
      ki(n, e, t.content, r.openTelemetry.traces.maxContentBytes);
    } catch (s) {
      M(r).debug("could not record the streamed message on its span", s);
    }
}
function Tp(r, n, e, t) {
  t.options.__span?.name === "anthropic.messages.create" && e instanceof Oe ? Ap(r, n, e, t) : d_(n, e, t);
}
function Ap(r, n, e, t) {
  if (!n.isRecording())
    return;
  n.setAttribute(wi, t.response.status);
  const s = t.options.__span, i = s?.startTime;
  let a, o, l = !1, h = !1, _ = !1;
  Nl(e, t.controller.signal, {
    onItem(d) {
      try {
        switch (d.type) {
          case "message_start": {
            const { id: m, model: g, stop_reason: b } = d.message;
            a = { id: m, model: g, stop_reason: b }, o = { ...d.message.usage };
            break;
          }
          case "content_block_start":
            a && d.content_block.type === "fallback" && (a.model = d.content_block.to.model);
            break;
          case "message_delta":
            a && o && (o.output_tokens = d.usage.output_tokens, d.usage.input_tokens != null && (o.input_tokens = d.usage.input_tokens), d.usage.cache_creation_input_tokens != null && (o.cache_creation_input_tokens = d.usage.cache_creation_input_tokens), d.usage.cache_read_input_tokens != null && (o.cache_read_input_tokens = d.usage.cache_read_input_tokens), d.usage.output_tokens_details != null && (o.output_tokens_details = d.usage.output_tokens_details), "iterations" in d.usage && d.usage.iterations != null && (o.iterations = d.usage.iterations), d.delta.stop_reason != null && (a.stop_reason = d.delta.stop_reason), h = !0);
            break;
          case "message_stop":
            _ = !0;
            break;
          case "content_block_delta":
            !l && i !== void 0 && n.setAttribute(q_, (Date.now() - i) / 1e3), l = !0;
            break;
          case "content_block_stop":
            break;
          default:
        }
      } catch (m) {
        M(r).debug("could not record the stream on its span", m);
      }
    },
    onEnd(d) {
      try {
        a && o && Ql(n, a, o, h || _);
      } catch (g) {
        M(r).debug("could not record the stream on its span", g);
      }
      const m = s?.failure;
      !_ && s?.streamed && m === void 0 && Si(r, s, s.streamed.body, s.streamed.message), d.reason === "failed" ? Ke(n, d.error) : m !== void 0 ? Ke(n, m, "client_error") : d.reason === "completed" && (_ ? n.setStatus({ code: ht.OK }) : Ke(n, new R("The stream ended before message_stop."), "api_error")), F(r, () => n.end());
    }
  });
}
function xp(r, n, e) {
  return r._tracer?.startSpan("anthropic.environment.work", {
    kind: Vr.INTERNAL,
    attributes: {
      [Jr]: r._genAIProviderName,
      "anthropic.environment.id": n.environment_id,
      "anthropic.environment.work.id": n.id,
      "anthropic.session.id": n.data.id
    }
  }, e);
}
function ru(r, n) {
  r?.isRecording() && (n.aborted || r.setStatus({ code: ht.OK }), r.end());
}
function su(r, n, e) {
  r?.isRecording() && (n.aborted || Ke(r, e), r.end());
}
async function Ep(r, n, e, t) {
  if (!n)
    return t();
  try {
    await he.with(_t.setSpan(he.active(), n), t);
  } catch (s) {
    throw F(r, () => su(n, e, s)), s;
  }
  F(r, () => ru(n, e));
}
const $n = "x-stainless-helper", Ti = "x-stainless-helper-method";
function iu(r) {
  return { [$n]: r };
}
const ze = Symbol("anthropic.sdk.stainlessHelper");
function ot(r) {
  return typeof r == "object" && r !== null && ze in r;
}
function au(r, n) {
  const e = /* @__PURE__ */ new Set();
  if (r)
    for (const t of r)
      ot(t) && e.add(t[ze]);
  if (n)
    for (const t of n) {
      ot(t) && e.add(t[ze]);
      const s = t.content;
      if (Array.isArray(s))
        for (const i of s) {
          ot(i) && e.add(i[ze]);
          const a = i?.tool?.definition;
          ot(a) && e.add(a[ze]);
        }
    }
  return Array.from(e);
}
function ou(r, n) {
  const e = au(r, n);
  return e.length === 0 ? {} : { [$n]: e.join(", ") };
}
function cu(r) {
  return ot(r) ? { [$n]: r[ze] } : {};
}
function Rp(r, n, e) {
  if (!r._tracer)
    return;
  const t = n.output_config?.format?.type === "json_schema" || n.output_format?.type === "json_schema";
  return r._tracer.startSpan("anthropic.messages.tool_runner", {
    kind: Vr.INTERNAL,
    attributes: {
      [vi]: X_,
      [Jr]: r._genAIProviderName,
      [Cn]: n.model,
      ...t ? { [Vl]: Jl } : void 0,
      ...e != null ? { [bi]: e } : void 0
    }
  });
}
async function Ai(r, n, e, t, s) {
  const i = r._tracer;
  if (!i)
    return s();
  const { signal: a, conversationId: o, sessionID: l, parentContext: h = he.active() } = t, _ = "description" in n ? n.description : void 0, d = {
    [vi]: Y_,
    [Jr]: r._genAIProviderName,
    [W_]: e.name,
    // Only a call to a member of a toolset, such as `computer`, has one.
    ..."toolset_name" in e && typeof e.toolset_name == "string" ? { [up]: e.toolset_name } : void 0,
    ..._ ? { [F_]: _ } : void 0,
    [U_]: e.id,
    [j_]: Q_,
    ...o != null ? { [bi]: o } : void 0,
    ...l != null ? { "anthropic.session.id": l } : void 0,
    // Only a Session event of a child thread has one.
    ..."session_thread_id" in e && e.session_thread_id != null ? { "anthropic.session.thread.id": e.session_thread_id } : void 0
  }, m = e.type === "agent.tool_use" ? "anthropic.tool_use" : ot(n) && n[ze] === "mcpTool" ? "anthropic.mcp_tool_use" : "anthropic.custom_tool_use", g = F(r, () => i.startSpan(`${m} ${e.name}`, { kind: Vr.INTERNAL, attributes: d }, h));
  if (!g)
    return s();
  let b;
  try {
    return b = await he.with(_t.setSpan(h, g), s), b;
  } finally {
    const w = b !== void 0 && !b.isError, S = !w && a?.aborted === !0, { contentMode: x, maxContentBytes: v } = r.openTelemetry.traces;
    if (x === "content" && g.isRecording())
      try {
        Xl(g, {
          [B_]: e.input,
          [Gs]: b && !S ? Yl(b.content) : void 0
        }, v);
      } catch (k) {
        M(r).debug("could not record the tool run on its span", k);
      }
    F(r, () => {
      w ? g.setStatus({ code: ht.OK }) : S || Ke(g, b, "tool_error"), g.end();
    });
  }
}
const Pp = (r) => {
  if (typeof globalThis.Buffer < "u") {
    const n = globalThis.Buffer.from(r, "base64");
    return new Uint8Array(n.buffer, n.byteOffset, n.byteLength);
  }
  if (typeof atob < "u") {
    const n = atob(r), e = new Uint8Array(n.length);
    for (let t = 0; t < n.length; t++)
      e[t] = n.charCodeAt(t);
    return e;
  }
  throw new R("Cannot decode base64 string; Expected `Buffer` or `atob` to be defined");
};
let Vs = function() {
  const { crypto: r } = globalThis;
  if (r?.randomUUID)
    return Vs = r.randomUUID.bind(r), r.randomUUID();
  const n = new Uint8Array(1), e = r ? () => r.getRandomValues(n)[0] : () => Math.random() * 255 & 255;
  return "10000000-1000-4000-8000-100000000000".replace(/[018]/g, (t) => (+t ^ e() & 15 >> +t / 4).toString(16));
};
const lu = "1.0", zp = /^[A-Za-z0-9_.-]+$/;
function uu(r) {
  if (!r)
    throw new Error("profile name is empty");
  if (r === "." || r === "..")
    throw new Error(`profile name "${r}" is not allowed`);
  if (r.includes("/") || r.includes("\\"))
    throw new Error(`profile name "${r}" must not contain path separators`);
  if (!zp.test(r))
    throw new Error(`profile name "${r}" contains disallowed characters (allowed: letters, digits, '_', '.', '-')`);
}
const Mp = async (r) => {
  var n, e;
  const t = await xi();
  if (t === null)
    return null;
  const s = r ?? await du();
  if (s === null)
    return null;
  uu(s);
  const { fs: i, path: a } = await Promise.resolve().then(() => $e), o = a.join(t, "configs", `${s}.json`);
  let l;
  try {
    l = await i.promises.readFile(o, "utf-8");
  } catch (d) {
    if (d?.code !== "ENOENT")
      throw new Error(`failed to read config file ${o}: ${d}`);
    l = null;
  }
  if (l === null) {
    const d = O("ANTHROPIC_ORGANIZATION_ID"), m = O("ANTHROPIC_IDENTITY_TOKEN_FILE"), g = O("ANTHROPIC_FEDERATION_RULE_ID");
    return g && d ? {
      fromFile: !1,
      config: {
        organization_id: d,
        // A defaulted-but-empty CI variable (`ANTHROPIC_WORKSPACE_ID=""`) is
        // treated as unset — readEnv coerces empty to undefined, and the body
        // builder's truthy check skips it — so `"workspace_id": ""` never goes
        // on the wire.
        workspace_id: O("ANTHROPIC_WORKSPACE_ID"),
        base_url: O("ANTHROPIC_BASE_URL"),
        authentication: {
          type: "oidc_federation",
          federation_rule_id: g,
          service_account_id: O("ANTHROPIC_SERVICE_ACCOUNT_ID"),
          identity_token: m ? { source: "file", path: m } : void 0,
          scope: O("ANTHROPIC_SCOPE")
        }
      }
    } : null;
  }
  let h;
  try {
    h = JSON.parse(l);
  } catch (d) {
    throw new Error(`failed to parse config file ${o}: ${d}`);
  }
  if (!h.authentication)
    throw new Error(`config file ${o} is missing "authentication"`);
  const _ = h.authentication.type;
  if (_ !== "oidc_federation" && _ !== "user_oauth")
    throw new Error(`authentication.type "${_}" is not a known authentication type`);
  if (h.organization_id ?? (h.organization_id = O("ANTHROPIC_ORGANIZATION_ID")), h.workspace_id ?? (h.workspace_id = O("ANTHROPIC_WORKSPACE_ID")), h.base_url ?? (h.base_url = O("ANTHROPIC_BASE_URL")), (n = h.authentication).scope ?? (n.scope = O("ANTHROPIC_SCOPE")), h.authentication.type === "oidc_federation") {
    if (!h.authentication.identity_token) {
      const d = O("ANTHROPIC_IDENTITY_TOKEN_FILE");
      d && (h.authentication.identity_token = {
        source: "file",
        path: d
      });
    }
    h.authentication.federation_rule_id || (h.authentication.federation_rule_id = O("ANTHROPIC_FEDERATION_RULE_ID") ?? ""), (e = h.authentication).service_account_id ?? (e.service_account_id = O("ANTHROPIC_SERVICE_ACCOUNT_ID"));
  }
  return { config: h, fromFile: !0 };
}, Op = async (r, n) => {
  if (r?.authentication.credentials_path)
    return r.authentication.credentials_path;
  const e = await xi();
  if (!e)
    return null;
  const t = n ?? await du();
  if (!t)
    return null;
  uu(t);
  const { path: s } = await Promise.resolve().then(() => $e);
  return s.join(e, "credentials", `${t}.json`);
}, xi = async () => {
  if (!Cp())
    return null;
  const { path: r } = await Promise.resolve().then(() => $e), n = O("ANTHROPIC_CONFIG_DIR");
  if (n)
    return n;
  if (ui()["X-Stainless-OS"] === "Windows") {
    const i = O("APPDATA");
    if (i)
      return r.join(i, "Anthropic");
    const a = O("USERPROFILE");
    return a ? r.join(a, "AppData", "Roaming", "Anthropic") : null;
  }
  const t = O("XDG_CONFIG_HOME");
  if (t)
    return r.join(t, "anthropic");
  const s = O("HOME");
  return s ? r.join(s, ".config", "anthropic") : null;
}, Cp = () => {
  const r = ui()["X-Stainless-Runtime"];
  return r === "node" || r === "deno";
}, du = async () => {
  const r = await xi();
  if (!r)
    return null;
  const n = O("ANTHROPIC_PROFILE");
  if (n)
    return n;
  const { fs: e, path: t } = await Promise.resolve().then(() => $e), s = t.join(r, "active_config");
  try {
    return (await e.promises.readFile(s, "utf-8")).trim() || "default";
  } catch (i) {
    if (i?.code !== "ENOENT")
      throw new Error(`failed to read ${s}: ${i}`);
    return "default";
  }
};
function ta(r) {
  if (!r)
    throw new R("Identity token file path is empty");
  return async () => {
    const { fs: n } = await Promise.resolve().then(() => $e);
    let e;
    try {
      e = await n.promises.readFile(r, "utf-8");
    } catch (s) {
      throw new R(`Failed to read identity token file at ${r}: ${s}`);
    }
    const t = e.trim();
    if (!t)
      throw new R(`Identity token file at ${r} is empty`);
    return t;
  };
}
function $p(r) {
  if (!r)
    throw new R("Identity token value is empty");
  return () => r;
}
function Ip(r) {
  return async () => {
    Hl(r.baseURL);
    const n = await r.identityTokenProvider();
    if (n.length > 16 * 1024)
      throw new B(`Identity token is ${Math.ceil(n.length / 1024)} KiB, exceeds the 16 KiB assertion limit`);
    const e = {
      grant_type: v_,
      assertion: n,
      federation_rule_id: r.federationRuleId,
      organization_id: r.organizationId
    };
    r.serviceAccountId && (e.service_account_id = r.serviceAccountId), r.workspaceId && (e.workspace_id = r.workspaceId);
    const t = `${r.baseURL}${jl}`;
    let s;
    try {
      s = await r.fetch(t, {
        method: "POST",
        redirect: "manual",
        headers: {
          "Content-Type": "application/json",
          "anthropic-beta": `${Fr},${S_}`,
          "User-Agent": r.userAgent || `anthropic-sdk-typescript/${Pe} oidcFederationProvider`
        },
        body: JSON.stringify(e)
      });
    } catch (l) {
      throw new B(`Failed to reach token endpoint ${t}: ${l}`);
    }
    const i = s.headers.get("Request-Id");
    if (!s.ok) {
      const l = await s.text().catch(() => ""), h = fe(l);
      let _ = "";
      throw s.status === 401 && (_ = ` Ensure your federation rule matches your identity token. ${r.workspaceId ? "" : "If your federation rule is scoped to multiple workspaces, set the ANTHROPIC_WORKSPACE_ID environment variable, the 'workspace_id' config key, or the `workspaceId` option. "}View your authentication events in the Workload identity page of Claude Console for more details.`), new B(`Token exchange failed with status ${s.status}${i ? ` (request-id ${i})` : ""}: ${h}${_}`, s.status, h, i);
    }
    const a = await Dl(s, i), o = Number(a.expires_in);
    if (!Number.isFinite(o))
      throw new B(`Token endpoint response missing required fields: ${JSON.stringify(fe(a))}`, s.status, fe(a), i);
    return {
      token: a.access_token,
      expiresAt: ut() + o
    };
  };
}
function Np(r) {
  return async (n) => {
    const { fs: e } = await Promise.resolve().then(() => $e);
    await Kl(r.credentialsPath, r.onSafetyWarning);
    let t;
    try {
      t = await e.promises.readFile(r.credentialsPath, "utf-8");
    } catch (S) {
      throw new B(`Credentials file not found at ${r.credentialsPath}: ${S}`);
    }
    let s;
    try {
      s = JSON.parse(t);
    } catch (S) {
      throw new B(`Credentials file at ${r.credentialsPath} is not valid JSON: ${S}`);
    }
    const i = s.access_token;
    if (!i)
      throw new B(`Credentials file at ${r.credentialsPath} must include 'access_token'`);
    const a = s.expires_at;
    if (!n?.forceRefresh && (a == null || ut() < a - yi))
      return { token: i, expiresAt: a ?? null };
    const o = s.refresh_token;
    if (!r.clientId || !o)
      throw new B(`Access token at ${r.credentialsPath} has expired and no refresh is available (client_id ${r.clientId ? "set" : "empty"}, refresh_token ${o ? "set" : "empty"})`);
    Hl(r.baseURL);
    const l = {
      grant_type: k_,
      refresh_token: o,
      client_id: r.clientId
    }, h = `${r.baseURL}${jl}`;
    let _;
    try {
      _ = await r.fetch(h, {
        method: "POST",
        redirect: "manual",
        headers: {
          "Content-Type": "application/json",
          "anthropic-beta": Fr,
          "User-Agent": r.userAgent || `anthropic-sdk-typescript/${Pe} userOAuthProvider`
        },
        body: JSON.stringify(l)
      });
    } catch (S) {
      throw new B(`User OAuth refresh failed to reach token endpoint: ${S}`);
    }
    const d = _.headers.get("Request-Id");
    if (!_.ok) {
      const S = await _.text().catch(() => "");
      throw new B(`User OAuth refresh failed (HTTP ${_.status}): ${fe(S)}`, _.status, fe(S), d);
    }
    const m = await Dl(_, d), g = Number(m.expires_in);
    if (!Number.isFinite(g))
      throw new B(`User OAuth refresh response missing or invalid expires_in: ${JSON.stringify(fe(m))}`, _.status, fe(m), d);
    const b = ut() + g, w = m.refresh_token || o;
    return await Gl(r.credentialsPath, {
      ...s,
      version: lu,
      type: "oauth_token",
      access_token: m.access_token,
      expires_at: b,
      refresh_token: w
    }), { token: m.access_token, expiresAt: b };
  };
}
function hu(r, n) {
  const e = r.authentication.credentials_path ?? null, t = (r.base_url || n.baseURL).replace(/\/+$/, ""), s = qp(r, e, t, n), i = {};
  return r.workspace_id && r.authentication.type === "user_oauth" && (i["anthropic-workspace-id"] = r.workspace_id), { provider: s, extraHeaders: i, baseURL: r.base_url || void 0 };
}
async function Lp(r, n) {
  const e = await Mp(n);
  if (!e)
    return null;
  const { config: t, fromFile: s } = e, i = t.authentication.credentials_path || !s ? t : {
    ...t,
    authentication: {
      ...t.authentication,
      credentials_path: await Op(t, n) ?? void 0
    }
  };
  return hu(i, r);
}
function qp(r, n, e, t) {
  switch (r.authentication.type) {
    case "oidc_federation": {
      const s = r.authentication, i = Bp(s);
      if (!i)
        throw new B("oidc_federation config requires an identity token (set authentication.identity_token, ANTHROPIC_IDENTITY_TOKEN_FILE, or ANTHROPIC_IDENTITY_TOKEN)");
      if (!s.federation_rule_id)
        throw new B("oidc_federation config requires 'federation_rule_id'. Set it in authentication.federation_rule_id in your profile, or via ANTHROPIC_FEDERATION_RULE_ID (profile takes precedence).");
      if (!r.organization_id)
        throw new B("oidc_federation config requires organization_id (set ANTHROPIC_ORGANIZATION_ID or config.organization_id)");
      const a = Ip({
        identityTokenProvider: i,
        federationRuleId: s.federation_rule_id,
        organizationId: r.organization_id,
        serviceAccountId: s.service_account_id,
        workspaceId: r.workspace_id,
        baseURL: e,
        fetch: t.fetch,
        userAgent: t.userAgent
      });
      return n ? Up(a, n, t.onCacheWriteError, t.onSafetyWarning) : a;
    }
    case "user_oauth": {
      if (!n)
        throw new B("user_oauth config requires authentication.credentials_path (or load via a profile so it defaults to <config_dir>/credentials/<profile>.json)");
      return Np({
        credentialsPath: n,
        clientId: r.authentication.client_id,
        baseURL: e,
        fetch: t.fetch,
        userAgent: t.userAgent,
        onSafetyWarning: t.onSafetyWarning
      });
    }
    default: {
      const s = r.authentication.type;
      throw new B(`authentication.type "${s}" is not a known authentication type`);
    }
  }
}
function Bp(r) {
  if (r.identity_token) {
    const t = r.identity_token.source;
    if (t !== "file")
      throw new B(`identity_token.source "${t}" is not supported by this SDK version (only "file")`);
    if (!r.identity_token.path)
      throw new B('identity_token.source "file" requires a non-empty path');
    return ta(r.identity_token.path);
  }
  const n = O("ANTHROPIC_IDENTITY_TOKEN_FILE");
  if (n)
    return ta(n);
  const e = O("ANTHROPIC_IDENTITY_TOKEN");
  return e ? $p(e) : null;
}
function Up(r, n, e, t) {
  return async (s) => {
    const { fs: i } = await Promise.resolve().then(() => $e);
    await Kl(n, t);
    let a;
    try {
      const l = await i.promises.readFile(n, "utf-8");
      a = JSON.parse(l);
      const h = a?.access_token;
      if (h && !s?.forceRefresh) {
        const _ = a?.expires_at;
        if (_ == null || ut() < _ - yi)
          return { token: h, expiresAt: _ ?? null };
      }
    } catch (l) {
      l?.code !== "ENOENT" && !(l instanceof SyntaxError) && e?.(l);
    }
    const o = await r(s);
    try {
      await Gl(n, {
        ...a ?? {},
        version: lu,
        type: "oauth_token",
        access_token: o.token,
        expires_at: o.expiresAt
      });
    } catch (l) {
      e?.(l);
    }
    return o;
  };
}
async function _u(r, n) {
  const { response: e, requestLogID: t, retryOfRequestLogID: s, startTime: i } = n, a = await (async () => {
    if (n.options.stream)
      return M(r).debug("response", e.status, e.url, e.headers, e.body), Oe.fromSSEResponse(e, n.controller, r);
    if (e.status === 204)
      return null;
    if (n.options.__binaryResponse)
      return e;
    const l = e.headers.get("content-type")?.split(";")[0]?.trim();
    if (l?.includes("application/json") || l?.endsWith("+json")) {
      if (e.headers.get("content-length") === "0")
        return;
      const m = await e.json();
      return Ei(m, e);
    }
    return await e.text();
  })().finally(() => {
    !n.options.stream && !n.options.__binaryResponse && lt(n.controller);
  });
  return He(M(r), `[${t}] response parsed`, {
    retryOfRequestLogID: s,
    url: e.url,
    status: e.status,
    body: a,
    durationMs: Date.now() - i
  }), a;
}
function Ei(r, n) {
  return !r || typeof r != "object" || Array.isArray(r) ? r : Object.defineProperties(r, {
    _request_id: { value: n.headers.get("request-id"), enumerable: !1 },
    _workspace_id: { value: n.headers.get("anthropic-workspace-id"), enumerable: !1 }
  });
}
const pu = /* @__PURE__ */ new WeakSet();
function fu(r) {
  return typeof r == "object" && r !== null && pu.has(r);
}
function Fp(r) {
  const n = /* @__PURE__ */ new Set();
  for (; typeof r == "object" && r !== null && !n.has(r); ) {
    if (n.add(r), fu(r) || dt(r) || r instanceof qt || r instanceof pd)
      return !0;
    r = r.cause;
  }
  return !1;
}
function na(r, n, e, t) {
  return async (s, i = {}) => {
    if (n.length === 0)
      return r.call(void 0, s, i);
    const a = i.headers instanceof Headers ? i.headers : new Headers(i.headers), o = await jp(r, n, e, t)({
      ...i,
      headers: a,
      url: typeof s == "string" ? s : s instanceof URL ? s.href : s.url
    });
    if (o.bodyUsed || o.body?.locked)
      throw new R("middleware consumed the response body; use response.clone() to inspect it, or return new Response(body, response) to consume and replace it");
    return o;
  };
}
function Wp(r, n) {
  const e = /* @__PURE__ */ new WeakMap();
  return {
    options: r,
    // Resolved per chain, so changes to the client's `logLevel`/`logger`
    // apply to subsequent requests.
    logger: n ? M(n) : $l(),
    parse(t) {
      if (r?.stream && t.ok)
        return ra(t, r, n);
      let s = e.get(t);
      return s || (s = ra(t, r, n), e.set(t, s)), s;
    }
  };
}
async function ra(r, n, e) {
  if (r.bodyUsed || r.body?.locked)
    throw new R("cannot ctx.parse() a response whose body was already consumed; call ctx.parse() instead of reading the body, or read via response.clone()");
  if (n?.stream && r.ok)
    return Oe.fromSSEResponse(r.clone(), new AbortController(), e);
  if (r.status === 204)
    return null;
  if (n?.__binaryResponse)
    return r;
  const s = r.headers.get("content-type")?.split(";")[0]?.trim();
  return s?.includes("application/json") || s?.endsWith("+json") ? r.headers.get("content-length") === "0" ? void 0 : Ei(await r.clone().json(), r) : await r.clone().text();
}
function jp(r, n, e, t) {
  let s = async ({ url: a, ...o }) => {
    try {
      return await r.call(void 0, a, o);
    } catch (l) {
      const h = Ir(l);
      throw pu.add(h), h;
    }
  };
  const i = Wp(e, t);
  for (let a = n.length - 1; a >= 0; a--) {
    const o = n[a], l = s;
    s = async (h) => o(h, l, i);
  }
  return s;
}
const gu = () => {
  if (typeof File > "u") {
    const { process: r } = globalThis, n = typeof r?.versions?.node == "string" && parseInt(r.versions.node.split(".")) < 20;
    throw new Error("`File` is not defined as a global, which is required for file uploads." + (n ? " Update to Node 20 LTS or newer, or set `globalThis.File` to `import('node:buffer').File`." : ""));
  }
};
function Ct(r, n, e) {
  return gu(), new File(r, n ?? "", e);
}
function Mr(r, n) {
  const e = typeof r == "object" && r !== null && ("name" in r && r.name && String(r.name) || "url" in r && r.url && String(r.url) || "filename" in r && r.filename && String(r.filename) || "path" in r && r.path && String(r.path)) || "";
  return n ? e.split(/[\\/]/).pop() || void 0 : e;
}
const Ri = (r) => r != null && typeof r == "object" && typeof r[Symbol.asyncIterator] == "function", Ce = async (r, n, e = !0) => {
  try {
    return { ...r, body: await Dp(r.body, n, e) };
  } catch (t) {
    const s = r.__span?.span;
    throw s && F(typeof n == "function" ? void 0 : n, () => Tn(s, { status: "error", options: r, error: t })), t;
  }
}, sa = /* @__PURE__ */ new WeakMap();
function Hp(r) {
  const n = typeof r == "function" ? r : r.fetch, e = sa.get(n);
  if (e)
    return e;
  const t = (async () => {
    try {
      const s = "Response" in n ? n.Response : (await n("data:,")).constructor, i = new FormData();
      return i.toString() !== await new s(i).text();
    } catch {
      return !0;
    }
  })();
  return sa.set(n, t), t;
}
const Dp = async (r, n, e = !0) => {
  if (!await Hp(n))
    throw new TypeError("The provided fetch function does not support file uploads with the current global FormData class.");
  const t = new FormData();
  return await Promise.all(Object.entries(r || {}).map(([s, i]) => Js(t, s, i, e))), t;
}, Js = async (r, n, e, t) => {
  if (e !== void 0) {
    if (e == null)
      throw new TypeError(`Received null for "${n}"; to pass null in FormData, you must use the string 'null'`);
    if (typeof e == "string" || typeof e == "number" || typeof e == "boolean")
      r.append(n, String(e));
    else if (e instanceof Response) {
      let s = {};
      const i = e.headers.get("Content-Type");
      i && (s = { type: i }), r.append(n, Ct([await e.blob()], Mr(e, t), s));
    } else if (Ri(e))
      r.append(n, Ct([await new Response(bl(e)).blob()], Mr(e, t)));
    else if (e instanceof Blob) {
      const i = typeof File < "u" && e instanceof File ? e.name : Mr(e, t);
      r.append(n, Ct([e], i, { type: e.type }));
    } else if (Array.isArray(e))
      await Promise.all(e.map((s) => Js(r, n + "[]", s, t)));
    else {
      if (typeof e.then == "function")
        throw new TypeError(`Received a Promise for "${n}"; await it first, e.g. \`await toFile(...)\``);
      if (e instanceof ArrayBuffer || ArrayBuffer.isView(e))
        throw new TypeError(`Received ${e.constructor.name} for "${n}"; to upload raw bytes, wrap them with \`await toFile(bytes, 'filename')\``);
      if (typeof e == "object")
        await Promise.all(Object.entries(e).map(([s, i]) => Js(r, `${n}[${s}]`, i, t)));
      else
        throw new TypeError(`Invalid value given to form, expected a string, number, boolean, object, Array, File or Blob but got ${e} instead`);
    }
  }
};
var V, Ys = /* @__PURE__ */ (() => {
  class r extends Promise {
    constructor(e, t, s = _u) {
      super((i) => {
        i(null);
      }), this.responsePromise = t, this.parseResponse = s, V.set(this, void 0), y(this, V, e);
    }
    _thenUnwrap(e) {
      return new r(c(this, V, "f"), this.responsePromise, async (t, s) => Ei(e(await this.parseResponse(t, s), s), s.response));
    }
    /**
     * Gets the raw `Response` instance instead of parsing the response
     * data.
     *
     * If you want to parse the response body but still get the `Response`
     * instance, you can use {@link withResponse()}.
     *
     * 👋 Getting the wrong TypeScript type for `Response`?
     * Try setting `"moduleResolution": "NodeNext"` or add `"lib": ["DOM"]`
     * to your `tsconfig.json`.
     */
    asResponse() {
      return this.responsePromise.then((e) => {
        const t = e.options.__span?.span;
        if (t && !this.parsedPromise) {
          const s = { status: "success", ...e, data: void 0 };
          zr(c(this, V, "f"), t, s), F(c(this, V, "f"), () => Tn(t, s));
        }
        return e.response;
      });
    }
    /**
     * Gets the parsed response data, the raw `Response` instance and the ID of the request,
     * returned via the `request-id` header which is useful for debugging requests and resporting
     * issues to Anthropic.
     *
     * If you just want to get the raw `Response` instance without parsing it,
     * you can use {@link asResponse()}.
     *
     * 👋 Getting the wrong TypeScript type for `Response`?
     * Try setting `"moduleResolution": "NodeNext"` or add `"lib": ["DOM"]`
     * to your `tsconfig.json`.
     */
    async withResponse() {
      const [e, t] = await Promise.all([this.parse(), this.asResponse()]);
      return {
        data: e,
        response: t,
        request_id: t.headers.get("request-id"),
        workspace_id: t.headers.get("anthropic-workspace-id")
      };
    }
    parse() {
      return this.parsedPromise || (this.parsedPromise = this.responsePromise.then((e) => this.parseResponseTraced(e))), this.parsedPromise;
    }
    /**
     * Parses the body of an API call. When the call has a span, the span ends with the parse, or,
     * when the parse returns a streamed body, when the application has read that stream.
     */
    async parseResponseTraced(e) {
      const t = e.options.__span;
      if (!t)
        return this.parseResponse(c(this, V, "f"), e);
      const { span: s } = t;
      let i;
      try {
        i = await this.parseResponse(c(this, V, "f"), e);
      } catch (o) {
        const l = { status: "error", ...e, error: o };
        throw zr(c(this, V, "f"), s, l), F(c(this, V, "f"), () => Tn(s, l)), o;
      }
      const a = { status: "success", ...e, data: i };
      return F(c(this, V, "f"), () => i_(t, i)), zr(c(this, V, "f"), s, a), e.options.stream && Ri(i) ? F(c(this, V, "f"), () => Tp(c(this, V, "f"), s, i, e)) : F(c(this, V, "f"), () => Tn(s, a)), i;
    }
    then(e, t) {
      return this.parse().then(e, t);
    }
    catch(e) {
      return this.parse().catch(e);
    }
    finally(e) {
      return this.parse().finally(e);
    }
  }
  return V = /* @__PURE__ */ new WeakMap(), r;
})(), Vt, Qr = /* @__PURE__ */ (() => {
  class r {
    constructor(e, t, s, i) {
      Vt.set(this, void 0), y(this, Vt, e), this.options = i, this.response = t, this.body = s;
    }
    hasNextPage() {
      return this.getPaginatedItems().length ? this.nextPageRequestOptions() != null : !1;
    }
    async getNextPage() {
      const e = this.nextPageRequestOptions();
      if (!e)
        throw new R("No next page expected; please check `.hasNextPage()` before calling `.getNextPage()`.");
      const t = this.options.__span;
      return await c(this, Vt, "f").requestAPIList(this.constructor, {
        ...e,
        __span: t && u(c(this, Vt, "f"), t.name, { openTelemetry: this.options.openTelemetry }, {
          route: t.route,
          queryParams: t.queryParams,
          contentQueryParams: t.contentQueryParams,
          attributes: t.attributes
        })
      });
    }
    async *iterPages() {
      let e = this;
      for (yield e; e.hasNextPage(); )
        e = await e.getNextPage(), yield e;
    }
    async *[(Vt = /* @__PURE__ */ new WeakMap(), Symbol.asyncIterator)]() {
      for await (const e of this.iterPages())
        for (const t of e.getPaginatedItems())
          yield t;
    }
  }
  return r;
})(), ia = /* @__PURE__ */ (() => {
  class r extends Ys {
    constructor(e, t, s) {
      super(e, t, async (i, a) => new s(i, a.response, await _u(i, a), a.options));
    }
    /**
     * Allow auto-paginating iteration on an unawaited list call, eg:
     *
     *    for await (const item of client.items.list()) {
     *      console.log(item)
     *    }
     */
    async *[Symbol.asyncIterator]() {
      const e = await this;
      for await (const t of e)
        yield t;
    }
  }
  return r;
})();
class Y extends Qr {
  constructor(n, e, t, s) {
    super(n, e, t, s), this.data = t.data || [], this.has_more = t.has_more || !1, this.first_id = t.first_id || null, this.last_id = t.last_id || null;
  }
  getPaginatedItems() {
    return this.data ?? [];
  }
  hasNextPage() {
    return this.has_more === !1 ? !1 : super.hasNextPage();
  }
  nextPageRequestOptions() {
    if (this.options.query?.before_id) {
      const e = this.first_id;
      return e ? {
        ...this.options,
        query: {
          ...xn(this.options.query),
          before_id: e
        }
      } : null;
    }
    const n = this.last_id;
    return n ? {
      ...this.options,
      query: {
        ...xn(this.options.query),
        after_id: n
      }
    } : null;
  }
}
class P extends Qr {
  constructor(n, e, t, s) {
    super(n, e, t, s), this.data = t.data || [], this.next_page = t.next_page || null;
  }
  getPaginatedItems() {
    return this.data ?? [];
  }
  hasNextPage() {
    return this.nextPageRequestOptions() != null;
  }
  nextPageRequestOptions() {
    const n = this.next_page;
    return n ? {
      ...this.options,
      query: {
        ...xn(this.options.query),
        page: n
      }
    } : null;
  }
}
class Kp extends Qr {
  constructor(n, e, t, s) {
    super(n, e, t, s), this.data = t.data || [], this.next_page = t.next_page || null, this.prev_page = t.prev_page || null;
  }
  getPaginatedItems() {
    return this.data ?? [];
  }
  hasNextPage() {
    return this.nextPageRequestOptions() != null;
  }
  nextPageRequestOptions() {
    const n = this.next_page;
    return n ? {
      ...this.options,
      query: {
        ...xn(this.options.query),
        page: n
      }
    } : null;
  }
}
class Zr extends Qr {
  constructor(n, e, t, s) {
    super(n, e, t, s), this.data = t.data || [], this.next_page = t.next_page || null, this.has_more = t.has_more || !1, this.data_refreshed_at = t.data_refreshed_at || null;
  }
  getPaginatedItems() {
    return this.data ?? [];
  }
  hasNextPage() {
    return this.has_more === !1 ? !1 : this.nextPageRequestOptions() != null;
  }
  nextPageRequestOptions() {
    const n = this.next_page;
    return n ? {
      ...this.options,
      query: {
        ...xn(this.options.query),
        page: n
      }
    } : null;
  }
}
const mu = (r) => r != null && typeof r == "object" && typeof r.size == "number" && typeof r.type == "string" && typeof r.text == "function" && typeof r.slice == "function" && typeof r.arrayBuffer == "function", Gp = (r) => r != null && typeof r == "object" && typeof r.name == "string" && typeof r.lastModified == "number" && mu(r), Vp = (r) => r != null && typeof r == "object" && typeof r.url == "string" && typeof r.blob == "function";
async function Jp(r, n, e) {
  if (gu(), r = await r, n || (n = r instanceof File ? r.name : Mr(r, !0)), Gp(r))
    return r instanceof File && n == null && e == null ? r : Ct([await r.arrayBuffer()], n ?? r.name, {
      type: r.type,
      lastModified: r.lastModified,
      ...e
    });
  if (Vp(r)) {
    const s = await r.blob();
    return n || (n = new URL(r.url).pathname.split(/[\\/]/).pop()), Ct(await Xs(s), n, e);
  }
  const t = await Xs(r);
  if (!e?.type) {
    const s = t.find((i) => typeof i == "object" && "type" in i && i.type);
    typeof s == "string" && (e = { ...e, type: s });
  }
  return Ct(t, n, e);
}
async function Xs(r) {
  let n = [];
  if (typeof r == "string" || ArrayBuffer.isView(r) || // includes Uint8Array, Buffer, etc.
  r instanceof ArrayBuffer)
    n.push(r);
  else if (mu(r))
    n.push(r instanceof Blob ? r : await r.arrayBuffer());
  else if (Ri(r))
    for await (const e of r)
      n.push(...await Xs(e));
  else {
    const e = r?.constructor?.name;
    throw new Error(`Unexpected data type: ${typeof r}${e ? `; constructor: ${e}` : ""}${Yp(r)}`);
  }
  return n;
}
function Yp(r) {
  return typeof r != "object" || r === null ? "" : `; props: [${Object.getOwnPropertyNames(r).map((e) => `"${e}"`).join(", ")}]`;
}
class T {
  constructor(n) {
    this._client = n;
  }
}
function bu(r, n) {
  const { user_profile_id: e, workspace_id: t, tools: s, messages: i } = r;
  return p([
    {
      ...e != null ? { "anthropic-user-profile-id": e } : void 0,
      ...t != null ? { "anthropic-workspace-id": t } : void 0
    },
    ou(s, i),
    n?.headers
  ]);
}
function Xp(r, n, e) {
  if (!r._tracer)
    return;
  const t = bu(n, e);
  return u(r, "anthropic.messages.create", e, Xr(r, { ...n, stream: !0 }, t));
}
function wu(r) {
  return r?.output_config?.format;
}
function aa(r, n, e) {
  const t = wu(n);
  return !n || !("parse" in (t ?? {})) ? {
    ...r,
    content: r.content.map((s) => s.type === "text" ? Object.defineProperty({ ...s }, "parsed_output", {
      value: null,
      enumerable: !1
    }) : s),
    parsed_output: null
  } : yu(r, n);
}
function yu(r, n, e) {
  let t = null;
  const s = r.content.map((i) => {
    if (i.type === "text") {
      const a = Qp(n, i.text);
      return t === null && (t = a), Object.defineProperty({ ...i }, "parsed_output", {
        value: a,
        enumerable: !1
      });
    }
    return i;
  });
  return {
    ...r,
    content: s,
    parsed_output: t
  };
}
function Qp(r, n) {
  const e = wu(r);
  if (e?.type !== "json_schema")
    return null;
  try {
    return "parse" in e ? e.parse(n) : JSON.parse(n);
  } catch (t) {
    throw new R(`Failed to parse structured output: ${t}`);
  }
}
const Zp = (r) => {
  let n = 0, e = [];
  for (; n < r.length; ) {
    let t = r[n];
    if (t === "\\") {
      n++;
      continue;
    }
    if (t === "{") {
      e.push({
        type: "brace",
        value: "{"
      }), n++;
      continue;
    }
    if (t === "}") {
      e.push({
        type: "brace",
        value: "}"
      }), n++;
      continue;
    }
    if (t === "[") {
      e.push({
        type: "paren",
        value: "["
      }), n++;
      continue;
    }
    if (t === "]") {
      e.push({
        type: "paren",
        value: "]"
      }), n++;
      continue;
    }
    if (t === ":") {
      e.push({
        type: "separator",
        value: ":"
      }), n++;
      continue;
    }
    if (t === ",") {
      e.push({
        type: "delimiter",
        value: ","
      }), n++;
      continue;
    }
    if (t === '"') {
      const o = n + 1;
      let l = o, h = !1;
      for (; ; ) {
        if (l = r.indexOf('"', l), l === -1) {
          h = !0;
          break;
        }
        let _ = 0, d = l - 1;
        for (; d >= o && r[d] === "\\"; )
          _++, d--;
        if (_ % 2 === 0)
          break;
        l++;
      }
      h ? n = r.length : (e.push({
        type: "string",
        value: r.slice(o, l)
      }), n = l + 1);
      continue;
    }
    if (t && /\s/.test(t)) {
      n++;
      continue;
    }
    let i = /[0-9]/;
    if (t && i.test(t) || t === "-" || t === ".") {
      let o = "";
      for (t === "-" && (o += t, t = r[++n]); t && (i.test(t) || t === "." || // exponent marker, e.g. `1e10` or `1.5E-9`
      t === "e" || t === "E" || // exponent sign, only valid immediately after the exponent marker
      (t === "-" || t === "+") && (o[o.length - 1] === "e" || o[o.length - 1] === "E")); )
        o += t, t = r[++n];
      e.push({
        type: "number",
        value: o,
        unterminated: n === r.length
      });
      continue;
    }
    let a = /[a-z]/i;
    if (t && a.test(t)) {
      let o = "";
      for (; t && a.test(t) && n !== r.length; )
        o += t, t = r[++n];
      if (o == "true" || o == "false" || o === "null")
        e.push({
          type: "name",
          value: o
        });
      else {
        n++;
        continue;
      }
      continue;
    }
    n++;
  }
  return e;
}, ef = (r) => {
  let n = [];
  for (const i of r)
    (i.type === "brace" || i.type === "paren") && (i.value === "{" || i.value === "[" ? n.push(i.value) : n.pop());
  let e = n[n.length - 1], t = r.length, s = /^-?(0|[1-9][0-9]*)(\.[0-9]+)?([eE][-+]?[0-9]+)?$/;
  for (; t > 0; ) {
    let i = r[t - 1];
    switch (i.type) {
      case "separator":
        t--;
        continue;
      case "number":
        if (i.unterminated || !s.test(i.value)) {
          t--;
          continue;
        }
        break;
      case "string":
        let a = r[t - 2];
        if (e === "{" && (a?.type === "delimiter" || a?.type === "brace" && a.value === "{")) {
          t--;
          continue;
        }
        break;
      case "delimiter":
        t--;
        break;
    }
    break;
  }
  return r.slice(0, t);
}, tf = (r) => {
  let n = [];
  return r.map((e) => {
    e.type === "brace" && (e.value === "{" ? n.push("}") : n.splice(n.lastIndexOf("}"), 1)), e.type === "paren" && (e.value === "[" ? n.push("]") : n.splice(n.lastIndexOf("]"), 1));
  }), n.length > 0 && n.reverse().map((e) => {
    e === "}" ? r.push({
      type: "brace",
      value: "}"
    }) : e === "]" && r.push({
      type: "paren",
      value: "]"
    });
  }), r;
}, nf = (r) => {
  let n = "";
  return r.map((e) => {
    switch (e.type) {
      case "string":
        n += '"' + e.value + '"';
        break;
      default:
        n += e.value;
        break;
    }
  }), n;
}, rf = (r) => JSON.parse(nf(tf(ef(Zp(r))))), $t = "__json_buf";
function vu(r, n) {
  const e = {};
  for (const i of Object.keys(r))
    i !== "input" && (e[i] = r[i]);
  Object.defineProperty(e, $t, { value: n, enumerable: !1, writable: !0 });
  let t, s = !1;
  return Object.defineProperty(e, "input", {
    enumerable: !0,
    configurable: !0,
    get() {
      return s || (t = n ? rf(n) : {}, s = !0), t;
    }
  }), e;
}
var pe, Le, we, Jt, Un, Yt, Xt, Fn, Qt, ye, Zt, Wn, jn, Je, Hn, Dn, Kn, en, Ye, X, _s, oa, ps, fs, gs, ms, ca;
function bs(r) {
  return r.type === "tool_use" || r.type === "server_tool_use";
}
var sf = /* @__PURE__ */ (() => {
  class r {
    constructor(e, t) {
      pe.add(this), this.messages = [], this.receivedMessages = [], Le.set(this, void 0), we.set(this, null), this.controller = new AbortController(), Jt.set(this, void 0), Un.set(this, () => {
      }), Yt.set(this, () => {
      }), Xt.set(this, void 0), Fn.set(this, () => {
      }), Qt.set(this, () => {
      }), ye.set(this, {}), Zt.set(this, !1), Wn.set(this, !1), jn.set(this, !1), Je.set(this, !1), Hn.set(this, void 0), Dn.set(this, void 0), Kn.set(this, void 0), en.set(this, void 0), Ye.set(this, void 0), X.set(this, void 0), ps.set(this, (s) => {
        if (y(this, Wn, !0), c(this, X, "f") && (c(this, X, "f").streamed = void 0), dt(s) && (s = new ue()), s instanceof ue)
          return y(this, jn, !0), this._emit("abort", s);
        if (s instanceof R)
          return this._emit("error", s);
        if (s instanceof Error) {
          const i = new R(s.message);
          return i.cause = s, this._emit("error", i);
        }
        return this._emit("error", new R(String(s)));
      }), y(this, Jt, new Promise((s, i) => {
        y(this, Un, s, "f"), y(this, Yt, i, "f");
      })), y(this, Xt, new Promise((s, i) => {
        y(this, Fn, s, "f"), y(this, Qt, i, "f");
      })), c(this, Jt, "f").catch(() => {
      }), c(this, Xt, "f").catch(() => {
      }), y(this, we, e), y(this, en, t?.logger ?? console), y(this, Ye, t?.client);
    }
    get response() {
      return c(this, Hn, "f");
    }
    get request_id() {
      return c(this, Dn, "f");
    }
    get workspace_id() {
      return c(this, Kn, "f");
    }
    /**
     * Returns the `MessageStream` data, the raw `Response` instance and the ID of the request,
     * returned vie the `request-id` header which is useful for debugging requests and resporting
     * issues to Anthropic.
     *
     * This is the same as the `APIPromise.withResponse()` method.
     *
     * This method will raise an error if you created the stream using `MessageStream.fromReadableStream`
     * as no `Response` is available.
     */
    async withResponse() {
      y(this, Je, !0);
      const e = await c(this, Jt, "f");
      if (!e)
        throw new Error("Could not resolve a `Response` object");
      return {
        data: this,
        response: e,
        request_id: e.headers.get("request-id"),
        workspace_id: e.headers.get("anthropic-workspace-id")
      };
    }
    /**
     * Intended for use on the frontend, consuming a stream produced with
     * `.toReadableStream()` on the backend.
     *
     * Note that messages sent to the model do not appear in `.on('message')`
     * in this context.
     */
    static fromReadableStream(e) {
      const t = new r(null);
      return t._run(() => t._fromReadableStream(e)), t;
    }
    static createMessage(e, t, s, { logger: i, client: a } = {}) {
      const o = new r(t, { logger: i, client: a });
      for (const l of t.messages)
        o._addMessageParam(l);
      return y(o, we, { ...t, stream: !0 }), o._run(() => o._createMessage(e, { ...t, stream: !0 }, { ...s, headers: { ...s?.headers, [Ti]: "stream" } })), o;
    }
    _run(e) {
      e().then(() => {
        this._emitFinal(), this._emit("end");
      }, c(this, ps, "f"));
    }
    _addMessageParam(e) {
      this.messages.push(e);
    }
    _addMessage(e, t = !0) {
      this.receivedMessages.push(e), t && this._emit("message", e);
    }
    async _createMessage(e, t, s) {
      const i = s?.signal;
      let a;
      i && (i.aborted && this.controller.abort(), a = this.controller.abort.bind(this.controller), i.addEventListener("abort", a));
      try {
        c(this, pe, "m", fs).call(this), y(this, X, s?.__span ?? (c(this, Ye, "f") && Xp(c(this, Ye, "f"), t, s)), "f");
        const { response: o, data: l } = await e.create({ ...t, stream: !0 }, { ...s, __span: c(this, X, "f"), signal: this.controller.signal }).withResponse();
        try {
          this._connected(o);
        } catch (h) {
          throw c(this, X, "f") && (c(this, X, "f").failure = h), l.controller.abort(), h;
        }
        for await (const h of l)
          try {
            c(this, pe, "m", gs).call(this, h);
          } catch (_) {
            throw c(this, X, "f") && (c(this, X, "f").failure = _), _;
          }
        if (l.controller.signal?.aborted)
          throw new ue();
        c(this, pe, "m", ms).call(this);
      } finally {
        i && a && i.removeEventListener("abort", a);
      }
    }
    _connected(e) {
      this.ended || (y(this, Hn, e), y(this, Dn, e?.headers.get("request-id")), y(this, Kn, e?.headers.get("anthropic-workspace-id")), c(this, Un, "f").call(this, e), this._emit("connect"));
    }
    get ended() {
      return c(this, Zt, "f");
    }
    get errored() {
      return c(this, Wn, "f");
    }
    get aborted() {
      return c(this, jn, "f");
    }
    abort() {
      this.controller.abort();
    }
    /**
     * Adds the listener function to the end of the listeners array for the event.
     * No checks are made to see if the listener has already been added. Multiple calls passing
     * the same combination of event and listener will result in the listener being added, and
     * called, multiple times.
     * @returns this MessageStream, so that calls can be chained
     */
    on(e, t) {
      return (c(this, ye, "f")[e] || (c(this, ye, "f")[e] = [])).push({ listener: t }), this;
    }
    /**
     * Removes the specified listener from the listener array for the event.
     * off() will remove, at most, one instance of a listener from the listener array. If any single
     * listener has been added multiple times to the listener array for the specified event, then
     * off() must be called multiple times to remove each instance.
     * @returns this MessageStream, so that calls can be chained
     */
    off(e, t) {
      const s = c(this, ye, "f")[e];
      if (!s)
        return this;
      const i = s.findIndex((a) => a.listener === t);
      return i >= 0 && s.splice(i, 1), this;
    }
    /**
     * Adds a one-time listener function for the event. The next time the event is triggered,
     * this listener is removed and then invoked.
     * @returns this MessageStream, so that calls can be chained
     */
    once(e, t) {
      return (c(this, ye, "f")[e] || (c(this, ye, "f")[e] = [])).push({ listener: t, once: !0 }), this;
    }
    /**
     * This is similar to `.once()`, but returns a Promise that resolves the next time
     * the event is triggered, instead of calling a listener callback.
     * @returns a Promise that resolves the next time given event is triggered,
     * or rejects if an error is emitted.  (If you request the 'error' event,
     * returns a promise that resolves with the error).
     *
     * Example:
     *
     *   const message = await stream.emitted('message') // rejects if the stream errors
     */
    emitted(e) {
      return new Promise((t, s) => {
        y(this, Je, !0), e !== "error" && this.once("error", s), this.once(e, t);
      });
    }
    async done() {
      y(this, Je, !0), await c(this, Xt, "f");
    }
    get currentMessage() {
      return c(this, Le, "f");
    }
    /**
     * @returns a promise that resolves with the the final assistant Message response,
     * or rejects if an error occurred or the stream ended prematurely without producing a Message.
     * If structured outputs were used, this will be a ParsedMessage with a `parsed_output` field.
     */
    async finalMessage() {
      return await this.done(), c(this, pe, "m", _s).call(this);
    }
    /**
     * @returns a promise that resolves with the the final assistant Message's text response, concatenated
     * together if there are more than one text blocks.
     * Rejects if an error occurred or the stream ended prematurely without producing a Message.
     */
    async finalText() {
      return await this.done(), c(this, pe, "m", oa).call(this);
    }
    _emit(e, ...t) {
      if (c(this, Zt, "f"))
        return;
      e === "end" && (y(this, Zt, !0), c(this, Fn, "f").call(this));
      const s = c(this, ye, "f")[e];
      if (s && (c(this, ye, "f")[e] = s.filter((i) => !i.once), s.forEach(({ listener: i }) => i(...t))), e === "abort") {
        const i = t[0];
        !c(this, Je, "f") && !s?.length && Promise.reject(i), c(this, Yt, "f").call(this, i), c(this, Qt, "f").call(this, i), this._emit("end");
        return;
      }
      if (e === "error") {
        const i = t[0];
        !c(this, Je, "f") && !s?.length && Promise.reject(i), c(this, Yt, "f").call(this, i), c(this, Qt, "f").call(this, i), this._emit("end");
      }
    }
    _emitFinal() {
      this.receivedMessages.at(-1) && this._emit("finalMessage", c(this, pe, "m", _s).call(this));
    }
    async _fromReadableStream(e, t) {
      const s = t?.signal;
      let i;
      s && (s.aborted && this.controller.abort(), i = this.controller.abort.bind(this.controller), s.addEventListener("abort", i));
      try {
        c(this, pe, "m", fs).call(this), this._connected(null);
        const a = Oe.fromReadableStream(e, this.controller);
        for await (const o of a)
          c(this, pe, "m", gs).call(this, o);
        if (a.controller.signal?.aborted)
          throw new ue();
        c(this, pe, "m", ms).call(this);
      } finally {
        s && i && s.removeEventListener("abort", i);
      }
    }
    [(Le = /* @__PURE__ */ new WeakMap(), we = /* @__PURE__ */ new WeakMap(), Jt = /* @__PURE__ */ new WeakMap(), Un = /* @__PURE__ */ new WeakMap(), Yt = /* @__PURE__ */ new WeakMap(), Xt = /* @__PURE__ */ new WeakMap(), Fn = /* @__PURE__ */ new WeakMap(), Qt = /* @__PURE__ */ new WeakMap(), ye = /* @__PURE__ */ new WeakMap(), Zt = /* @__PURE__ */ new WeakMap(), Wn = /* @__PURE__ */ new WeakMap(), jn = /* @__PURE__ */ new WeakMap(), Je = /* @__PURE__ */ new WeakMap(), Hn = /* @__PURE__ */ new WeakMap(), Dn = /* @__PURE__ */ new WeakMap(), Kn = /* @__PURE__ */ new WeakMap(), en = /* @__PURE__ */ new WeakMap(), Ye = /* @__PURE__ */ new WeakMap(), X = /* @__PURE__ */ new WeakMap(), ps = /* @__PURE__ */ new WeakMap(), pe = /* @__PURE__ */ new WeakSet(), _s = function() {
      if (this.receivedMessages.length === 0)
        throw new R("stream ended without producing a Message with role=assistant");
      return this.receivedMessages.at(-1);
    }, oa = function() {
      if (this.receivedMessages.length === 0)
        throw new R("stream ended without producing a Message with role=assistant");
      const t = this.receivedMessages.at(-1).content.filter((s) => s.type === "text").map((s) => s.text);
      if (t.length === 0)
        throw new R("stream ended without producing a content block with type=text");
      return t.join(" ");
    }, fs = function() {
      this.ended || y(this, Le, void 0);
    }, gs = function(t) {
      if (this.ended)
        return;
      const s = c(this, pe, "m", ca).call(this, t);
      if (this._emit("_rawEvent", t), !!s)
        switch (this._emit("streamEvent", t, s), t.type) {
          case "content_block_delta": {
            const i = s.content.at(-1);
            switch (t.delta.type) {
              case "text_delta": {
                i.type === "text" && this._emit("text", t.delta.text, i.text || "");
                break;
              }
              case "citations_delta": {
                i.type === "text" && this._emit("citation", t.delta.citation, i.citations ?? []);
                break;
              }
              case "input_json_delta": {
                bs(i) && c(this, ye, "f").inputJson?.length && this._emit("inputJson", t.delta.partial_json, i.input);
                break;
              }
              case "thinking_delta": {
                i.type === "thinking" && this._emit("thinking", t.delta.thinking, i.thinking);
                break;
              }
              case "signature_delta": {
                i.type === "thinking" && this._emit("signature", i.signature);
                break;
              }
              default:
                t.delta;
            }
            break;
          }
          case "message_stop": {
            c(this, Ye, "f") && c(this, X, "f") && c(this, we, "f") && Si(c(this, Ye, "f"), c(this, X, "f"), c(this, we, "f"), s), this._addMessageParam(s), this._addMessage(aa(s, c(this, we, "f"), { logger: c(this, en, "f") }), !0);
            break;
          }
          case "content_block_stop": {
            this._emit("contentBlock", s.content.at(-1));
            break;
          }
          case "message_start": {
            y(this, Le, s), c(this, X, "f") && c(this, we, "f") && (c(this, X, "f").streamed = { body: c(this, we, "f"), message: s });
            break;
          }
        }
    }, ms = function() {
      if (this.ended)
        throw new R("stream has ended, this shouldn't happen");
      const t = c(this, Le, "f");
      if (!t)
        throw new R("request ended without sending any chunks");
      return y(this, Le, void 0), aa(t, c(this, we, "f"), { logger: c(this, en, "f") });
    }, ca = function(t) {
      let s = c(this, Le, "f");
      if (t.type === "message_start") {
        if (s)
          throw new R(`Unexpected event order, got ${t.type} before receiving "message_stop"`);
        return t.message;
      }
      if (s)
        switch (t.type) {
          case "message_stop":
            return s;
          case "message_delta":
            return s.stop_reason = t.delta.stop_reason, s.stop_sequence = t.delta.stop_sequence, s.stop_details = t.delta.stop_details, s.usage.output_tokens = t.usage.output_tokens, t.delta.container != null && (s.container = t.delta.container), t.usage.input_tokens != null && (s.usage.input_tokens = t.usage.input_tokens), t.usage.cache_creation_input_tokens != null && (s.usage.cache_creation_input_tokens = t.usage.cache_creation_input_tokens), t.usage.cache_read_input_tokens != null && (s.usage.cache_read_input_tokens = t.usage.cache_read_input_tokens), t.usage.server_tool_use != null && (s.usage.server_tool_use = t.usage.server_tool_use), t.usage.output_tokens_details != null && (s.usage.output_tokens_details = t.usage.output_tokens_details), s;
          case "content_block_start":
            return s.content.push({ ...t.content_block }), s;
          case "content_block_delta": {
            const i = s.content.at(t.index);
            switch (t.delta.type) {
              case "text_delta": {
                i?.type === "text" && (s.content[t.index] = {
                  ...i,
                  text: (i.text || "") + t.delta.text
                });
                break;
              }
              case "citations_delta": {
                i?.type === "text" && (s.content[t.index] = {
                  ...i,
                  citations: [...i.citations ?? [], t.delta.citation]
                });
                break;
              }
              case "input_json_delta": {
                if (i && bs(i)) {
                  const a = (i[$t] || "") + t.delta.partial_json;
                  s.content[t.index] = vu(i, a);
                }
                break;
              }
              case "thinking_delta": {
                i?.type === "thinking" && (s.content[t.index] = {
                  ...i,
                  thinking: i.thinking + t.delta.thinking
                });
                break;
              }
              case "signature_delta": {
                i?.type === "thinking" && (s.content[t.index] = {
                  ...i,
                  signature: t.delta.signature
                });
                break;
              }
              default:
                t.delta;
            }
            return s;
          }
          case "content_block_stop": {
            const i = s.content.at(t.index);
            return i && bs(i) && $t in i && Object.defineProperty(i, "input", {
              value: i.input,
              enumerable: !0,
              configurable: !0,
              writable: !0
            }), s;
          }
          default:
            return s;
        }
    }, Symbol.asyncIterator)]() {
      const e = [], t = [];
      let s = !1;
      return this.on("_rawEvent", (i) => {
        const a = t.shift();
        a ? a.resolve(i) : e.push(i);
      }), this.on("end", () => {
        s = !0;
        for (const i of t)
          i.resolve(void 0);
        t.length = 0;
      }), this.on("abort", (i) => {
        s = !0;
        for (const a of t)
          a.reject(i);
        t.length = 0;
      }), this.on("error", (i) => {
        s = !0;
        for (const a of t)
          a.reject(i);
        t.length = 0;
      }), {
        next: async () => e.length ? { value: e.shift(), done: !1 } : s ? { value: void 0, done: !0 } : new Promise((a, o) => t.push({ resolve: a, reject: o })).then((a) => a ? { value: a, done: !1 } : { value: void 0, done: !0 }),
        return: async () => (this.abort(), { value: void 0, done: !0 })
      };
    }
    toReadableStream() {
      return new Oe(this[Symbol.asyncIterator].bind(this), this.controller).toReadableStream();
    }
  }
  return r;
})(), ku = /* @__PURE__ */ (() => {
  class r {
    constructor(e, t, s) {
      this.iterator = e, this.response = s, this.controller = t;
    }
    async *decoder() {
      const e = this.iterator;
      if (!e)
        throw new R("Cannot iterate over a consumed stream.");
      this.iterator = void 0;
      const t = new mi();
      for await (const s of e)
        for (const i of t.decode(s))
          yield JSON.parse(i);
      for (const s of t.flush())
        yield JSON.parse(s);
    }
    [Symbol.asyncIterator]() {
      return this.decoder();
    }
    static fromResponse(e, t) {
      if (!e.body)
        throw t.abort(), typeof globalThis.navigator < "u" && globalThis.navigator.product === "ReactNative" ? new R("The default react-native fetch implementation does not support streaming. Please use expo/fetch: https://docs.expo.dev/versions/latest/sdk/expo/#expofetch-api") : new R("Attempted to iterate over a response with no body");
      return new r(di(e.body), t, e);
    }
  }
  return r;
})();
function Su(r) {
  return r.replace(/[^A-Za-z0-9\-._~!$&'()*+,;=:@]+/g, encodeURIComponent);
}
const la = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.create(null)), af = (r = Su) => function(e, ...t) {
  if (e.length === 1)
    return e[0];
  let s = !1;
  const i = [], a = e.reduce((_, d, m) => {
    /[?#]/.test(d) && (s = !0);
    const g = t[m];
    let b = (s ? encodeURIComponent : r)("" + g);
    return m !== t.length && (g == null || typeof g == "object" && // handle values from other realms
    g.toString === Object.getPrototypeOf(Object.getPrototypeOf(g.hasOwnProperty ?? la) ?? la)?.toString) && (b = g + "", i.push({
      start: _.length + d.length,
      length: b.length,
      error: `Value of type ${Object.prototype.toString.call(g).slice(8, -1)} is not a valid path parameter`
    })), !s && b === "" && i.push({
      start: _.length + d.length,
      length: 0,
      error: `Value "" can't be safely passed as a path parameter`
    }), _ + d + (m === t.length ? "" : b);
  }, ""), o = a.split(/[?#]/, 1)[0], l = /(?<=^|\/)(?:\.|%2e){1,2}(?=\/|$)/gi;
  let h;
  for (; (h = l.exec(o)) !== null; )
    i.push({
      start: h.index,
      length: h[0].length,
      error: `Value "${h[0]}" can't be safely passed as a path parameter`
    });
  if (i.sort((_, d) => _.start - d.start), i.length > 0) {
    const _ = [];
    for (const m of i)
      for (let g = m.start; g < m.start + Math.max(1, m.length); g++)
        _[g] = "^";
    const d = Array.from(_, (m) => m ?? " ").join("");
    throw new R(`Path parameters result in path with invalid segments:
${i.map((m) => m.error).join(`
`)}
${a}
${d}`);
  }
  return a;
}, f = /* @__PURE__ */ af(Su);
let ua = class extends T {
  /**
   * Send a batch of Message creation requests.
   *
   * The Message Batches API can be used to process multiple Messages API requests at
   * once. Once a Message Batch is created, it begins processing immediately. Batches
   * can take up to 24 hours to complete.
   *
   * Learn more about the Message Batches API in our
   * [user guide](https://platform.claude.com/docs/en/build-with-claude/batch-processing)
   *
   * @example
   * ```ts
   * const messageBatch = await client.messages.batches.create({
   *   requests: [
   *     {
   *       custom_id: 'my-custom-id-1',
   *       params: {
   *         max_tokens: 1024,
   *         messages: [
   *           { content: 'Hello, world', role: 'user' },
   *         ],
   *         model: 'claude-opus-5-5',
   *       },
   *     },
   *   ],
   * });
   * ```
   */
  create(n, e) {
    const { user_profile_id: t, workspace_id: s, ...i } = n;
    return this._client.post("/v1/messages/batches", {
      body: i,
      ...e,
      headers: p([
        {
          ...t != null ? { "anthropic-user-profile-id": t } : void 0,
          ...s != null ? { "anthropic-workspace-id": s } : void 0
        },
        e?.headers
      ]),
      __span: u(this._client, "anthropic.messages.batches.create", e, {
        route: "/v1/messages/batches",
        // A request without `requests` is for the API to refuse, not for this line to throw on.
        attributes: { "anthropic.message.batch.request_count": i.requests?.length },
        createdIDAttribute: "anthropic.message.batch.id"
      })
    });
  }
  /**
   * This endpoint is idempotent and can be used to poll for Message Batch
   * completion. To access the results of a Message Batch, make a request to the
   * `results_url` field in the response.
   *
   * Learn more about the Message Batches API in our
   * [user guide](https://platform.claude.com/docs/en/build-with-claude/batch-processing)
   *
   * @example
   * ```ts
   * const messageBatch = await client.messages.batches.retrieve(
   *   'message_batch_id',
   * );
   * ```
   */
  retrieve(n, e = {}, t) {
    const { workspace_id: s } = e ?? {};
    return this._client.get(f`/v1/messages/batches/${n}`, {
      ...t,
      headers: p([
        { ...s != null ? { "anthropic-workspace-id": s } : void 0 },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.messages.batches.retrieve", t, {
        route: "/v1/messages/batches/{message_batch_id}",
        attributes: { "anthropic.message.batch.id": n }
      })
    });
  }
  /**
   * List all Message Batches within a Workspace. Most recently created batches are
   * returned first.
   *
   * Learn more about the Message Batches API in our
   * [user guide](https://platform.claude.com/docs/en/build-with-claude/batch-processing)
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const messageBatch of client.messages.batches.list()) {
   *   // ...
   * }
   * ```
   */
  list(n = {}, e) {
    const { workspace_id: t, ...s } = n ?? {};
    return this._client.getAPIList("/v1/messages/batches", Y, {
      query: s,
      ...e,
      headers: p([
        { ...t != null ? { "anthropic-workspace-id": t } : void 0 },
        e?.headers
      ]),
      __span: u(this._client, "anthropic.messages.batches.list", e, {
        route: "/v1/messages/batches",
        queryParams: ["after_id", "before_id", "limit"]
      })
    });
  }
  /**
   * Delete a Message Batch.
   *
   * Message Batches can only be deleted once they've finished processing. If you'd
   * like to delete an in-progress batch, you must first cancel it.
   *
   * Learn more about the Message Batches API in our
   * [user guide](https://platform.claude.com/docs/en/build-with-claude/batch-processing)
   *
   * @example
   * ```ts
   * const deletedMessageBatch =
   *   await client.messages.batches.delete('message_batch_id');
   * ```
   */
  delete(n, e = {}, t) {
    const { workspace_id: s } = e ?? {};
    return this._client.delete(f`/v1/messages/batches/${n}`, {
      ...t,
      headers: p([
        { ...s != null ? { "anthropic-workspace-id": s } : void 0 },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.messages.batches.delete", t, {
        route: "/v1/messages/batches/{message_batch_id}",
        attributes: { "anthropic.message.batch.id": n }
      })
    });
  }
  /**
   * Batches may be canceled any time before processing ends. Once cancellation is
   * initiated, the batch enters a `canceling` state, at which time the system may
   * complete any in-progress, non-interruptible requests before finalizing
   * cancellation.
   *
   * The number of canceled requests is specified in `request_counts`. To determine
   * which requests were canceled, check the individual results within the batch.
   * Note that cancellation may not result in any canceled requests if they were
   * non-interruptible.
   *
   * Learn more about the Message Batches API in our
   * [user guide](https://platform.claude.com/docs/en/build-with-claude/batch-processing)
   *
   * @example
   * ```ts
   * const messageBatch = await client.messages.batches.cancel(
   *   'message_batch_id',
   * );
   * ```
   */
  cancel(n, e = {}, t) {
    const { workspace_id: s } = e ?? {};
    return this._client.post(f`/v1/messages/batches/${n}/cancel`, {
      ...t,
      headers: p([
        { ...s != null ? { "anthropic-workspace-id": s } : void 0 },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.messages.batches.cancel", t, {
        route: "/v1/messages/batches/{message_batch_id}/cancel",
        attributes: { "anthropic.message.batch.id": n }
      })
    });
  }
  /**
   * Streams the results of a Message Batch as a `.jsonl` file.
   *
   * Each line in the file is a JSON object containing the result of a single request
   * in the Message Batch. Results are not guaranteed to be in the same order as
   * requests. Use the `custom_id` field to match results to requests.
   *
   * Learn more about the Message Batches API in our
   * [user guide](https://platform.claude.com/docs/en/build-with-claude/batch-processing)
   *
   * @example
   * ```ts
   * const stream = await client.messages.batches.results(
   *   'message_batch_id',
   * );
   * for await (const messageBatchIndividualResponse of stream) {
   *   // ...
   * }
   * ```
   */
  async results(n, e = {}, t) {
    const s = await this.retrieve(n, e, t);
    if (!s.results_url)
      throw new R(`No batch \`results_url\`; Has it finished processing? ${s.processing_status} - ${s.id}`);
    const { workspace_id: i } = e ?? {};
    return this._client.get(s.results_url, {
      ...t,
      headers: p([
        {
          Accept: "application/binary",
          ...i != null ? { "anthropic-workspace-id": i } : void 0
        },
        t?.headers
      ]),
      stream: !0,
      __binaryResponse: !0,
      __span: u(this._client, "anthropic.messages.batches.results", t, {
        route: "/v1/messages/batches/{message_batch_id}/results",
        attributes: { "anthropic.message.batch.id": n }
      })
    })._thenUnwrap((a, o) => ku.fromResponse(o.response, o.controller));
  }
};
const Tu = {
  "claude-opus-4@20250514": 8192,
  "anthropic.claude-opus-4-1-20250805-v1:0": 8192,
  "claude-opus-4-1@20250805": 8192
};
var da = /* @__PURE__ */ (() => {
  class r extends T {
    constructor() {
      super(...arguments), this.batches = new ua(this._client);
    }
    create(e, t) {
      const { user_profile_id: s, workspace_id: i, ...a } = e;
      a.model in ha && console.warn(`The model '${a.model}' is deprecated and will reach end-of-life on ${ha[a.model]}
Please migrate to a newer model. Visit https://docs.anthropic.com/en/docs/resources/model-deprecations for more information.`), of.includes(a.model) && a.thinking && a.thinking.type === "enabled" && console.warn(`Using Claude with ${a.model} and 'thinking.type=enabled' is deprecated. Use 'thinking.type=adaptive' instead which results in better model performance in our testing: https://platform.claude.com/docs/en/build-with-claude/adaptive-thinking`);
      let o = t?.timeout ?? this._client._options.timeout;
      if (!a.stream && o == null) {
        const d = Tu[a.model] ?? void 0;
        o = this._client.calculateNonstreamingTimeout(a.max_tokens, d);
      }
      const l = bu(e, t), h = this._client._tracer && u(this._client, "anthropic.messages.create", t, Xr(this._client, a, l));
      Zl(this._client, h, a);
      const _ = this._client.post("/v1/messages", {
        body: a,
        timeout: o ?? 6e5,
        ...t,
        __span: h,
        headers: l,
        stream: e.stream ?? !1
      });
      return h ? _._thenUnwrap((d) => (eu(this._client, h, a, d), d)) : _;
    }
    /**
     * Send a structured list of input messages with text and/or image content, along with an expected `output_config.format` and
     * the response will be automatically parsed and available in the `parsed_output` property of the message.
     *
     * @example
     * ```ts
     * const message = await client.messages.parse({
     *   model: 'claude-sonnet-5-5',
     *   max_tokens: 1024,
     *   messages: [{ role: 'user', content: 'What is 2+2?' }],
     *   output_config: {
     *     format: zodOutputFormat(z.object({ answer: z.number() })),
     *   },
     * });
     *
     * console.log(message.parsed_output?.answer); // 4
     * ```
     */
    parse(e, t) {
      return this.create(e, t).then((s) => yu(s, e, { logger: this._client.logger ?? console }));
    }
    /**
     * Create a Message stream.
     *
     * If `output_config.format` is provided with a parseable format (like `zodOutputFormat()`),
     * the final message will include a `parsed_output` property with the parsed content.
     *
     * @example
     * ```ts
     * const stream = client.messages.stream({
     *   model: 'claude-sonnet-5-5',
     *   max_tokens: 1024,
     *   messages: [{ role: 'user', content: 'What is 2+2?' }],
     *   output_config: {
     *     format: zodOutputFormat(z.object({ answer: z.number() })),
     *   },
     * });
     *
     * const message = await stream.finalMessage();
     * console.log(message.parsed_output?.answer); // 4
     * ```
     */
    stream(e, t) {
      const s = e;
      return sf.createMessage(this, s, t, {
        logger: this._client.logger ?? console,
        client: this._client
      });
    }
    /**
     * Count the number of tokens in a Message.
     *
     * The Token Count API can be used to count the number of tokens in a Message,
     * including tools, images, and documents, without creating it.
     *
     * Learn more about token counting in our
     * [user guide](https://platform.claude.com/docs/en/build-with-claude/token-counting)
     *
     * @example
     * ```ts
     * const messageTokensCount =
     *   await client.messages.countTokens({
     *     messages: [{ content: 'Hello, world', role: 'user' }],
     *     model: 'claude-opus-5-5',
     *   });
     * ```
     */
    countTokens(e, t) {
      const { user_profile_id: s, workspace_id: i, ...a } = e, o = p([
        {
          ...s != null ? { "anthropic-user-profile-id": s } : void 0,
          ...i != null ? { "anthropic-workspace-id": i } : void 0
        },
        t?.headers
      ]), l = u(this._client, "anthropic.messages.count_tokens", t, {
        route: "/v1/messages/count_tokens",
        attributes: { [Cn]: a.model }
      }), h = this._client.post("/v1/messages/count_tokens", {
        body: a,
        ...t,
        __span: l,
        headers: o
      });
      return l ? h._thenUnwrap((_) => (tu(this._client, l, _), _)) : h;
    }
  }
  return r.Batches = ua, r;
})();
const ha = {
  "claude-sonnet-4-5": "November 30th, 2026",
  "claude-sonnet-4-5-20250929": "November 30th, 2026"
}, of = ["claude-mythos-preview", "claude-opus-4-6"];
class _a extends T {
  /**
   * Get Deployment Run
   *
   * @example
   * ```ts
   * const betaManagedAgentsDeploymentRun =
   *   await client.beta.deploymentRuns.retrieve(
   *     'deployment_run_id',
   *   );
   * ```
   */
  retrieve(n, e = {}, t) {
    const { betas: s, workspace_id: i } = e ?? {};
    return this._client.get(f`/v1/deployment_runs/${n}?beta=true`, {
      ...t,
      headers: p([
        {
          "anthropic-beta": [...s ?? [], "managed-agents-2026-04-01"].toString(),
          ...i != null ? { "anthropic-workspace-id": i } : void 0
        },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.deployment_runs.retrieve", t, {
        route: "/v1/deployment_runs/{deployment_run_id}",
        attributes: { "anthropic.deployment_run.id": n }
      })
    });
  }
  /**
   * List Deployment Runs
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaManagedAgentsDeploymentRun of client.beta.deploymentRuns.list()) {
   *   // ...
   * }
   * ```
   */
  list(n = {}, e) {
    const { betas: t, workspace_id: s, ...i } = n ?? {};
    return this._client.getAPIList("/v1/deployment_runs?beta=true", P, {
      query: i,
      ...e,
      headers: p([
        {
          "anthropic-beta": [...t ?? [], "managed-agents-2026-04-01"].toString(),
          ...s != null ? { "anthropic-workspace-id": s } : void 0
        },
        e?.headers
      ]),
      __span: u(this._client, "anthropic.deployment_runs.list", e, {
        route: "/v1/deployment_runs",
        queryParams: [
          "created_at[gt]",
          "created_at[gte]",
          "created_at[lt]",
          "created_at[lte]",
          "deployment_id",
          "has_error",
          "limit",
          "page",
          "trigger_type"
        ]
      })
    });
  }
}
class pa extends T {
  /**
   * Create Deployment
   *
   * @example
   * ```ts
   * const betaManagedAgentsDeployment =
   *   await client.beta.deployments.create({
   *     agent: 'string',
   *     environment_id: 'x',
   *     initial_events: [
   *       {
   *         content: [
   *           {
   *             text: 'Where is my order #1234?',
   *             type: 'text',
   *           },
   *         ],
   *         type: 'user.message',
   *       },
   *     ],
   *     name: 'x',
   *   });
   * ```
   */
  create(n, e) {
    const { betas: t, workspace_id: s, ...i } = n;
    return this._client.post("/v1/deployments?beta=true", {
      body: i,
      ...e,
      headers: p([
        {
          "anthropic-beta": [...t ?? [], "managed-agents-2026-04-01"].toString(),
          ...s != null ? { "anthropic-workspace-id": s } : void 0
        },
        e?.headers
      ]),
      __span: u(this._client, "anthropic.deployments.create", e, {
        route: "/v1/deployments",
        createdIDAttribute: "anthropic.deployment.id"
      })
    });
  }
  /**
   * Get Deployment
   *
   * @example
   * ```ts
   * const betaManagedAgentsDeployment =
   *   await client.beta.deployments.retrieve(
   *     'depl_011CZkZcDH3vPqd7xnEfwTai',
   *   );
   * ```
   */
  retrieve(n, e = {}, t) {
    const { betas: s, workspace_id: i } = e ?? {};
    return this._client.get(f`/v1/deployments/${n}?beta=true`, {
      ...t,
      headers: p([
        {
          "anthropic-beta": [...s ?? [], "managed-agents-2026-04-01"].toString(),
          ...i != null ? { "anthropic-workspace-id": i } : void 0
        },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.deployments.retrieve", t, {
        route: "/v1/deployments/{deployment_id}",
        attributes: { "anthropic.deployment.id": n }
      })
    });
  }
  /**
   * Update Deployment
   *
   * @example
   * ```ts
   * const betaManagedAgentsDeployment =
   *   await client.beta.deployments.update(
   *     'depl_011CZkZcDH3vPqd7xnEfwTai',
   *   );
   * ```
   */
  update(n, e, t) {
    const { betas: s, workspace_id: i, ...a } = e;
    return this._client.post(f`/v1/deployments/${n}?beta=true`, {
      body: a,
      ...t,
      headers: p([
        {
          "anthropic-beta": [...s ?? [], "managed-agents-2026-04-01"].toString(),
          ...i != null ? { "anthropic-workspace-id": i } : void 0
        },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.deployments.update", t, {
        route: "/v1/deployments/{deployment_id}",
        attributes: { "anthropic.deployment.id": n }
      })
    });
  }
  /**
   * List Deployments
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaManagedAgentsDeployment of client.beta.deployments.list()) {
   *   // ...
   * }
   * ```
   */
  list(n = {}, e) {
    const { betas: t, workspace_id: s, ...i } = n ?? {};
    return this._client.getAPIList("/v1/deployments?beta=true", P, {
      query: i,
      ...e,
      headers: p([
        {
          "anthropic-beta": [...t ?? [], "managed-agents-2026-04-01"].toString(),
          ...s != null ? { "anthropic-workspace-id": s } : void 0
        },
        e?.headers
      ]),
      __span: u(this._client, "anthropic.deployments.list", e, {
        route: "/v1/deployments",
        queryParams: [
          "agent_id",
          "created_at[gte]",
          "created_at[lte]",
          "include_archived",
          "limit",
          "page",
          "status"
        ]
      })
    });
  }
  /**
   * Archive Deployment
   *
   * @example
   * ```ts
   * const betaManagedAgentsDeployment =
   *   await client.beta.deployments.archive(
   *     'depl_011CZkZcDH3vPqd7xnEfwTai',
   *   );
   * ```
   */
  archive(n, e = {}, t) {
    const { betas: s, workspace_id: i } = e ?? {};
    return this._client.post(f`/v1/deployments/${n}/archive?beta=true`, {
      ...t,
      headers: p([
        {
          "anthropic-beta": [...s ?? [], "managed-agents-2026-04-01"].toString(),
          ...i != null ? { "anthropic-workspace-id": i } : void 0
        },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.deployments.archive", t, {
        route: "/v1/deployments/{deployment_id}/archive",
        attributes: { "anthropic.deployment.id": n }
      })
    });
  }
  /**
   * Pause Deployment
   *
   * @example
   * ```ts
   * const betaManagedAgentsDeployment =
   *   await client.beta.deployments.pause(
   *     'depl_011CZkZcDH3vPqd7xnEfwTai',
   *   );
   * ```
   */
  pause(n, e = {}, t) {
    const { betas: s, workspace_id: i } = e ?? {};
    return this._client.post(f`/v1/deployments/${n}/pause?beta=true`, {
      ...t,
      headers: p([
        {
          "anthropic-beta": [...s ?? [], "managed-agents-2026-04-01"].toString(),
          ...i != null ? { "anthropic-workspace-id": i } : void 0
        },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.deployments.pause", t, {
        route: "/v1/deployments/{deployment_id}/pause",
        attributes: { "anthropic.deployment.id": n }
      })
    });
  }
  /**
   * Run Deployment Now
   *
   * @example
   * ```ts
   * const betaManagedAgentsDeploymentRun =
   *   await client.beta.deployments.run(
   *     'depl_011CZkZcDH3vPqd7xnEfwTai',
   *   );
   * ```
   */
  run(n, e = {}, t) {
    const { betas: s, workspace_id: i } = e ?? {};
    return this._client.post(f`/v1/deployments/${n}/run?beta=true`, {
      ...t,
      headers: p([
        {
          "anthropic-beta": [...s ?? [], "managed-agents-2026-04-01"].toString(),
          ...i != null ? { "anthropic-workspace-id": i } : void 0
        },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.deployments.run", t, {
        route: "/v1/deployments/{deployment_id}/run",
        attributes: { "anthropic.deployment.id": n }
      })
    });
  }
  /**
   * Unpause Deployment
   *
   * @example
   * ```ts
   * const betaManagedAgentsDeployment =
   *   await client.beta.deployments.unpause(
   *     'depl_011CZkZcDH3vPqd7xnEfwTai',
   *   );
   * ```
   */
  unpause(n, e = {}, t) {
    const { betas: s, workspace_id: i } = e ?? {};
    return this._client.post(f`/v1/deployments/${n}/unpause?beta=true`, {
      ...t,
      headers: p([
        {
          "anthropic-beta": [...s ?? [], "managed-agents-2026-04-01"].toString(),
          ...i != null ? { "anthropic-workspace-id": i } : void 0
        },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.deployments.unpause", t, {
        route: "/v1/deployments/{deployment_id}/unpause",
        attributes: { "anthropic.deployment.id": n }
      })
    });
  }
}
class fa extends T {
  /**
   * Start an asynchronous job that uses past sessions to produce a reorganized
   * version of a memory store and get back the dream to poll for the result.
   *
   * By default the dream writes its result to a new memory store and doesn't change
   * the input memory store. The response has `status` set to `pending` and an empty
   * `outputs` array. Poll the dream until `status` is `completed`, `failed`, or
   * `canceled`.
   *
   * See the
   * [Dreams guide](https://platform.claude.com/docs/en/managed-agents/dreams#create-a-dream)
   * to learn more about creating dreams.
   *
   * @example
   * ```ts
   * const betaDream = await client.beta.dreams.create({
   *   inputs: [{ memory_store_id: 'x', type: 'memory_store' }],
   *   model: 'string',
   * });
   * ```
   */
  create(n, e) {
    const { betas: t, workspace_id: s, ...i } = n;
    return this._client.post("/v1/dreams?beta=true", {
      body: i,
      ...e,
      headers: p([
        {
          "anthropic-beta": [...t ?? [], "dreaming-2026-04-21"].toString(),
          ...s != null ? { "anthropic-workspace-id": s } : void 0
        },
        e?.headers
      ]),
      __span: u(this._client, "anthropic.dreams.create", e, {
        route: "/v1/dreams",
        createdIDAttribute: "anthropic.dream.id"
      })
    });
  }
  /**
   * Get a dream by ID to check its status, output memory store, and token usage.
   *
   * Archived dreams are returned too.
   *
   * See the
   * [Dreams guide](https://platform.claude.com/docs/en/managed-agents/dreams#track-progress)
   * for how to poll a dream and what each status means.
   *
   * @example
   * ```ts
   * const betaDream = await client.beta.dreams.retrieve(
   *   'dream_id',
   * );
   * ```
   */
  retrieve(n, e = {}, t) {
    const { betas: s, workspace_id: i } = e ?? {};
    return this._client.get(f`/v1/dreams/${n}?beta=true`, {
      ...t,
      headers: p([
        {
          "anthropic-beta": [...s ?? [], "dreaming-2026-04-21"].toString(),
          ...i != null ? { "anthropic-workspace-id": i } : void 0
        },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.dreams.retrieve", t, {
        route: "/v1/dreams/{dream_id}",
        attributes: { "anthropic.dream.id": n }
      })
    });
  }
  /**
   * List the dreams in the workspace, newest first.
   *
   * Archived dreams are left out unless `include_archived` is `true`.
   *
   * See the
   * [Dreams guide](https://platform.claude.com/docs/en/managed-agents/dreams#list-dreams)
   * for how to page through dreams.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaDream of client.beta.dreams.list()) {
   *   // ...
   * }
   * ```
   */
  list(n = {}, e) {
    const { betas: t, workspace_id: s, ...i } = n ?? {};
    return this._client.getAPIList("/v1/dreams?beta=true", P, {
      query: i,
      ...e,
      headers: p([
        {
          "anthropic-beta": [...t ?? [], "dreaming-2026-04-21"].toString(),
          ...s != null ? { "anthropic-workspace-id": s } : void 0
        },
        e?.headers
      ]),
      __span: u(this._client, "anthropic.dreams.list", e, {
        route: "/v1/dreams",
        queryParams: ["created_at[gt]", "created_at[lt]", "include_archived", "limit", "page", "statuses"]
      })
    });
  }
  /**
   * Hide a `completed`, `failed`, or `canceled` dream from the default list of
   * dreams.
   *
   * Archiving a `pending` or `running` dream returns a 400 error, so cancel it
   * first. Archiving an archived dream returns it unchanged. An archived dream can
   * still be fetched by ID. Archiving can't be undone.
   *
   * See the
   * [Dreams guide](https://platform.claude.com/docs/en/managed-agents/dreams#archive-a-dream)
   * to learn more about archiving dreams.
   *
   * @example
   * ```ts
   * const betaDream = await client.beta.dreams.archive(
   *   'dream_id',
   * );
   * ```
   */
  archive(n, e = {}, t) {
    const { betas: s, workspace_id: i } = e ?? {};
    return this._client.post(f`/v1/dreams/${n}/archive?beta=true`, {
      ...t,
      headers: p([
        {
          "anthropic-beta": [...s ?? [], "dreaming-2026-04-21"].toString(),
          ...i != null ? { "anthropic-workspace-id": i } : void 0
        },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.dreams.archive", t, {
        route: "/v1/dreams/{dream_id}/archive",
        attributes: { "anthropic.dream.id": n }
      })
    });
  }
  /**
   * Stop a `pending` or `running` dream.
   *
   * The response shows `status` as `canceled`, unless the dream reached `completed`
   * or `failed` first. `usage` can keep changing after the response. Canceling a
   * `canceled` dream returns it unchanged. Canceling a `completed` or `failed` dream
   * returns a 400 error.
   *
   * See the
   * [Dreams guide](https://platform.claude.com/docs/en/managed-agents/dreams#cancel-a-dream)
   * to learn more about canceling dreams.
   *
   * @example
   * ```ts
   * const betaDream = await client.beta.dreams.cancel(
   *   'dream_id',
   * );
   * ```
   */
  cancel(n, e = {}, t) {
    const { betas: s, workspace_id: i } = e ?? {};
    return this._client.post(f`/v1/dreams/${n}/cancel?beta=true`, {
      ...t,
      headers: p([
        {
          "anthropic-beta": [...s ?? [], "dreaming-2026-04-21"].toString(),
          ...i != null ? { "anthropic-workspace-id": i } : void 0
        },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.dreams.cancel", t, {
        route: "/v1/dreams/{dream_id}/cancel",
        attributes: { "anthropic.dream.id": n }
      })
    });
  }
}
let ga = class extends T {
  /**
   * List Files
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaFileMetadata of client.beta.files.list()) {
   *   // ...
   * }
   * ```
   */
  list(n = {}, e) {
    const { betas: t, workspace_id: s, ...i } = n ?? {};
    return this._client.getAPIList("/v1/files?beta=true", P, {
      query: i,
      ...e,
      headers: p([
        {
          ...t?.toString() != null ? { "anthropic-beta": t?.toString() } : void 0,
          ...s != null ? { "anthropic-workspace-id": s } : void 0
        },
        e?.headers
      ]),
      __span: u(this._client, "anthropic.files.list", e, {
        route: "/v1/files",
        queryParams: ["ids", "limit", "page", "scope_id"]
      })
    });
  }
  /**
   * Delete File
   *
   * @example
   * ```ts
   * const betaDeletedFile = await client.beta.files.delete(
   *   'file_id',
   * );
   * ```
   */
  delete(n, e = {}, t) {
    const { betas: s, workspace_id: i } = e ?? {};
    return this._client.delete(f`/v1/files/${n}?beta=true`, {
      ...t,
      headers: p([
        {
          ...s?.toString() != null ? { "anthropic-beta": s?.toString() } : void 0,
          ...i != null ? { "anthropic-workspace-id": i } : void 0
        },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.files.delete", t, {
        route: "/v1/files/{file_id}",
        attributes: { "anthropic.file.id": n }
      })
    });
  }
  /**
   * Download File
   *
   * @example
   * ```ts
   * const response = await client.beta.files.download(
   *   'file_id',
   * );
   *
   * const content = await response.blob();
   * console.log(content);
   * ```
   */
  download(n, e = {}, t) {
    const { betas: s, workspace_id: i } = e ?? {};
    return this._client.get(f`/v1/files/${n}/content?beta=true`, {
      ...t,
      headers: p([
        {
          Accept: "application/binary",
          ...s?.toString() != null ? { "anthropic-beta": s?.toString() } : void 0,
          ...i != null ? { "anthropic-workspace-id": i } : void 0
        },
        t?.headers
      ]),
      __binaryResponse: !0,
      __span: u(this._client, "anthropic.files.download", t, {
        route: "/v1/files/{file_id}/content",
        attributes: { "anthropic.file.id": n }
      })
    });
  }
  /**
   * Get File Metadata
   *
   * @example
   * ```ts
   * const betaFileMetadata =
   *   await client.beta.files.retrieveMetadata('file_id');
   * ```
   */
  retrieveMetadata(n, e = {}, t) {
    const { betas: s, workspace_id: i } = e ?? {};
    return this._client.get(f`/v1/files/${n}?beta=true`, {
      ...t,
      headers: p([
        {
          ...s?.toString() != null ? { "anthropic-beta": s?.toString() } : void 0,
          ...i != null ? { "anthropic-workspace-id": i } : void 0
        },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.files.retrieve_metadata", t, {
        route: "/v1/files/{file_id}",
        attributes: { "anthropic.file.id": n }
      })
    });
  }
  /**
   * Upload File
   *
   * @example
   * ```ts
   * const betaFileMetadata = await client.beta.files.upload({
   *   file: fs.createReadStream('path/to/file'),
   * });
   * ```
   */
  upload(n, e) {
    const { betas: t, workspace_id: s, ...i } = n;
    return this._client.post("/v1/files?beta=true", Ce({
      body: i,
      ...e,
      headers: p([
        {
          ...t?.toString() != null ? { "anthropic-beta": t?.toString() } : void 0,
          ...s != null ? { "anthropic-workspace-id": s } : void 0
        },
        cu(i.file),
        e?.headers
      ]),
      __span: u(this._client, "anthropic.files.upload", e, {
        route: "/v1/files",
        createdIDAttribute: "anthropic.file.id"
      })
    }, this._client));
  }
}, ma = class extends T {
  /**
   * Get a specific model.
   *
   * The Models API response can be used to determine information about a specific
   * model or resolve a model alias to a model ID.
   *
   * @example
   * ```ts
   * const betaModelInfo = await client.beta.models.retrieve(
   *   'model_id',
   * );
   * ```
   */
  retrieve(n, e = {}, t) {
    const { betas: s, workspace_id: i } = e ?? {};
    return this._client.get(f`/v1/models/${n}?beta=true`, {
      ...t,
      headers: p([
        {
          ...s?.toString() != null ? { "anthropic-beta": s?.toString() } : void 0,
          ...i != null ? { "anthropic-workspace-id": i } : void 0
        },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.models.retrieve", t, {
        route: "/v1/models/{model_id}",
        attributes: { "anthropic.model.id": n }
      })
    });
  }
  /**
   * List available models.
   *
   * The Models API response can be used to determine which models are available for
   * use in the API. More recently released models are listed first.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaModelInfo of client.beta.models.list()) {
   *   // ...
   * }
   * ```
   */
  list(n = {}, e) {
    const { betas: t, workspace_id: s, ...i } = n ?? {};
    return this._client.getAPIList("/v1/models?beta=true", Y, {
      query: i,
      ...e,
      headers: p([
        {
          ...t?.toString() != null ? { "anthropic-beta": t?.toString() } : void 0,
          ...s != null ? { "anthropic-workspace-id": s } : void 0
        },
        e?.headers
      ]),
      __span: u(this._client, "anthropic.models.list", e, {
        route: "/v1/models",
        queryParams: ["after_id", "before_id", "lifecycle", "limit"]
      })
    });
  }
};
var Xe = {}, Q = {}, ba;
function cf() {
  if (ba) return Q;
  ba = 1;
  var r = Q && Q.__extends || /* @__PURE__ */ (function() {
    var _ = function(d, m) {
      return _ = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(g, b) {
        g.__proto__ = b;
      } || function(g, b) {
        for (var w in b) b.hasOwnProperty(w) && (g[w] = b[w]);
      }, _(d, m);
    };
    return function(d, m) {
      _(d, m);
      function g() {
        this.constructor = d;
      }
      d.prototype = m === null ? Object.create(m) : (g.prototype = m.prototype, new g());
    };
  })();
  Object.defineProperty(Q, "__esModule", { value: !0 });
  var n = 256, e = (
    /** @class */
    (function() {
      function _(d) {
        d === void 0 && (d = "="), this._paddingCharacter = d;
      }
      return _.prototype.encodedLength = function(d) {
        return this._paddingCharacter ? (d + 2) / 3 * 4 | 0 : (d * 8 + 5) / 6 | 0;
      }, _.prototype.encode = function(d) {
        for (var m = "", g = 0; g < d.length - 2; g += 3) {
          var b = d[g] << 16 | d[g + 1] << 8 | d[g + 2];
          m += this._encodeByte(b >>> 18 & 63), m += this._encodeByte(b >>> 12 & 63), m += this._encodeByte(b >>> 6 & 63), m += this._encodeByte(b >>> 0 & 63);
        }
        var w = d.length - g;
        if (w > 0) {
          var b = d[g] << 16 | (w === 2 ? d[g + 1] << 8 : 0);
          m += this._encodeByte(b >>> 18 & 63), m += this._encodeByte(b >>> 12 & 63), w === 2 ? m += this._encodeByte(b >>> 6 & 63) : m += this._paddingCharacter || "", m += this._paddingCharacter || "";
        }
        return m;
      }, _.prototype.maxDecodedLength = function(d) {
        return this._paddingCharacter ? d / 4 * 3 | 0 : (d * 6 + 7) / 8 | 0;
      }, _.prototype.decodedLength = function(d) {
        return this.maxDecodedLength(d.length - this._getPaddingLength(d));
      }, _.prototype.decode = function(d) {
        if (d.length === 0)
          return new Uint8Array(0);
        for (var m = this._getPaddingLength(d), g = d.length - m, b = new Uint8Array(this.maxDecodedLength(g)), w = 0, S = 0, x = 0, v = 0, k = 0, A = 0, E = 0; S < g - 4; S += 4)
          v = this._decodeChar(d.charCodeAt(S + 0)), k = this._decodeChar(d.charCodeAt(S + 1)), A = this._decodeChar(d.charCodeAt(S + 2)), E = this._decodeChar(d.charCodeAt(S + 3)), b[w++] = v << 2 | k >>> 4, b[w++] = k << 4 | A >>> 2, b[w++] = A << 6 | E, x |= v & n, x |= k & n, x |= A & n, x |= E & n;
        if (S < g - 1 && (v = this._decodeChar(d.charCodeAt(S)), k = this._decodeChar(d.charCodeAt(S + 1)), b[w++] = v << 2 | k >>> 4, x |= v & n, x |= k & n), S < g - 2 && (A = this._decodeChar(d.charCodeAt(S + 2)), b[w++] = k << 4 | A >>> 2, x |= A & n), S < g - 3 && (E = this._decodeChar(d.charCodeAt(S + 3)), b[w++] = A << 6 | E, x |= E & n), x !== 0)
          throw new Error("Base64Coder: incorrect characters for decoding");
        return b;
      }, _.prototype._encodeByte = function(d) {
        var m = d;
        return m += 65, m += 25 - d >>> 8 & 6, m += 51 - d >>> 8 & -75, m += 61 - d >>> 8 & -15, m += 62 - d >>> 8 & 3, String.fromCharCode(m);
      }, _.prototype._decodeChar = function(d) {
        var m = n;
        return m += (42 - d & d - 44) >>> 8 & -n + d - 43 + 62, m += (46 - d & d - 48) >>> 8 & -n + d - 47 + 63, m += (47 - d & d - 58) >>> 8 & -n + d - 48 + 52, m += (64 - d & d - 91) >>> 8 & -n + d - 65 + 0, m += (96 - d & d - 123) >>> 8 & -n + d - 97 + 26, m;
      }, _.prototype._getPaddingLength = function(d) {
        var m = 0;
        if (this._paddingCharacter) {
          for (var g = d.length - 1; g >= 0 && d[g] === this._paddingCharacter; g--)
            m++;
          if (d.length < 4 || m > 2)
            throw new Error("Base64Coder: incorrect padding");
        }
        return m;
      }, _;
    })()
  );
  Q.Coder = e;
  var t = new e();
  function s(_) {
    return t.encode(_);
  }
  Q.encode = s;
  function i(_) {
    return t.decode(_);
  }
  Q.decode = i;
  var a = (
    /** @class */
    (function(_) {
      r(d, _);
      function d() {
        return _ !== null && _.apply(this, arguments) || this;
      }
      return d.prototype._encodeByte = function(m) {
        var g = m;
        return g += 65, g += 25 - m >>> 8 & 6, g += 51 - m >>> 8 & -75, g += 61 - m >>> 8 & -13, g += 62 - m >>> 8 & 49, String.fromCharCode(g);
      }, d.prototype._decodeChar = function(m) {
        var g = n;
        return g += (44 - m & m - 46) >>> 8 & -n + m - 45 + 62, g += (94 - m & m - 96) >>> 8 & -n + m - 95 + 63, g += (47 - m & m - 58) >>> 8 & -n + m - 48 + 52, g += (64 - m & m - 91) >>> 8 & -n + m - 65 + 0, g += (96 - m & m - 123) >>> 8 & -n + m - 97 + 26, g;
      }, d;
    })(e)
  );
  Q.URLSafeCoder = a;
  var o = new a();
  function l(_) {
    return o.encode(_);
  }
  Q.encodeURLSafe = l;
  function h(_) {
    return o.decode(_);
  }
  return Q.decodeURLSafe = h, Q.encodedLength = function(_) {
    return t.encodedLength(_);
  }, Q.maxDecodedLength = function(_) {
    return t.maxDecodedLength(_);
  }, Q.decodedLength = function(_) {
    return t.decodedLength(_);
  }, Q;
}
var Or = { exports: {} }, lf = Or.exports, wa;
function uf() {
  return wa || (wa = 1, (function(r) {
    (function(n, e) {
      var t = {};
      e(t);
      var s = t.default;
      for (var i in t)
        s[i] = t[i];
      r.exports = s;
    })(lf, function(n) {
      n.__esModule = !0, n.digestLength = 32, n.blockSize = 64;
      var e = new Uint32Array([
        1116352408,
        1899447441,
        3049323471,
        3921009573,
        961987163,
        1508970993,
        2453635748,
        2870763221,
        3624381080,
        310598401,
        607225278,
        1426881987,
        1925078388,
        2162078206,
        2614888103,
        3248222580,
        3835390401,
        4022224774,
        264347078,
        604807628,
        770255983,
        1249150122,
        1555081692,
        1996064986,
        2554220882,
        2821834349,
        2952996808,
        3210313671,
        3336571891,
        3584528711,
        113926993,
        338241895,
        666307205,
        773529912,
        1294757372,
        1396182291,
        1695183700,
        1986661051,
        2177026350,
        2456956037,
        2730485921,
        2820302411,
        3259730800,
        3345764771,
        3516065817,
        3600352804,
        4094571909,
        275423344,
        430227734,
        506948616,
        659060556,
        883997877,
        958139571,
        1322822218,
        1537002063,
        1747873779,
        1955562222,
        2024104815,
        2227730452,
        2361852424,
        2428436474,
        2756734187,
        3204031479,
        3329325298
      ]);
      function t(m, g, b, w, S) {
        for (var x, v, k, A, E, z, q, $, I, C, _e, Ie, Ne; S >= 64; ) {
          for (x = g[0], v = g[1], k = g[2], A = g[3], E = g[4], z = g[5], q = g[6], $ = g[7], C = 0; C < 16; C++)
            _e = w + C * 4, m[C] = (b[_e] & 255) << 24 | (b[_e + 1] & 255) << 16 | (b[_e + 2] & 255) << 8 | b[_e + 3] & 255;
          for (C = 16; C < 64; C++)
            I = m[C - 2], Ie = (I >>> 17 | I << 15) ^ (I >>> 19 | I << 13) ^ I >>> 10, I = m[C - 15], Ne = (I >>> 7 | I << 25) ^ (I >>> 18 | I << 14) ^ I >>> 3, m[C] = (Ie + m[C - 7] | 0) + (Ne + m[C - 16] | 0);
          for (C = 0; C < 64; C++)
            Ie = (((E >>> 6 | E << 26) ^ (E >>> 11 | E << 21) ^ (E >>> 25 | E << 7)) + (E & z ^ ~E & q) | 0) + ($ + (e[C] + m[C] | 0) | 0) | 0, Ne = ((x >>> 2 | x << 30) ^ (x >>> 13 | x << 19) ^ (x >>> 22 | x << 10)) + (x & v ^ x & k ^ v & k) | 0, $ = q, q = z, z = E, E = A + Ie | 0, A = k, k = v, v = x, x = Ie + Ne | 0;
          g[0] += x, g[1] += v, g[2] += k, g[3] += A, g[4] += E, g[5] += z, g[6] += q, g[7] += $, w += 64, S -= 64;
        }
        return w;
      }
      var s = (
        /** @class */
        (function() {
          function m() {
            this.digestLength = n.digestLength, this.blockSize = n.blockSize, this.state = new Int32Array(8), this.temp = new Int32Array(64), this.buffer = new Uint8Array(128), this.bufferLength = 0, this.bytesHashed = 0, this.finished = !1, this.reset();
          }
          return m.prototype.reset = function() {
            return this.state[0] = 1779033703, this.state[1] = 3144134277, this.state[2] = 1013904242, this.state[3] = 2773480762, this.state[4] = 1359893119, this.state[5] = 2600822924, this.state[6] = 528734635, this.state[7] = 1541459225, this.bufferLength = 0, this.bytesHashed = 0, this.finished = !1, this;
          }, m.prototype.clean = function() {
            for (var g = 0; g < this.buffer.length; g++)
              this.buffer[g] = 0;
            for (var g = 0; g < this.temp.length; g++)
              this.temp[g] = 0;
            this.reset();
          }, m.prototype.update = function(g, b) {
            if (b === void 0 && (b = g.length), this.finished)
              throw new Error("SHA256: can't update because hash was finished.");
            var w = 0;
            if (this.bytesHashed += b, this.bufferLength > 0) {
              for (; this.bufferLength < 64 && b > 0; )
                this.buffer[this.bufferLength++] = g[w++], b--;
              this.bufferLength === 64 && (t(this.temp, this.state, this.buffer, 0, 64), this.bufferLength = 0);
            }
            for (b >= 64 && (w = t(this.temp, this.state, g, w, b), b %= 64); b > 0; )
              this.buffer[this.bufferLength++] = g[w++], b--;
            return this;
          }, m.prototype.finish = function(g) {
            if (!this.finished) {
              var b = this.bytesHashed, w = this.bufferLength, S = b / 536870912 | 0, x = b << 3, v = b % 64 < 56 ? 64 : 128;
              this.buffer[w] = 128;
              for (var k = w + 1; k < v - 8; k++)
                this.buffer[k] = 0;
              this.buffer[v - 8] = S >>> 24 & 255, this.buffer[v - 7] = S >>> 16 & 255, this.buffer[v - 6] = S >>> 8 & 255, this.buffer[v - 5] = S >>> 0 & 255, this.buffer[v - 4] = x >>> 24 & 255, this.buffer[v - 3] = x >>> 16 & 255, this.buffer[v - 2] = x >>> 8 & 255, this.buffer[v - 1] = x >>> 0 & 255, t(this.temp, this.state, this.buffer, 0, v), this.finished = !0;
            }
            for (var k = 0; k < 8; k++)
              g[k * 4 + 0] = this.state[k] >>> 24 & 255, g[k * 4 + 1] = this.state[k] >>> 16 & 255, g[k * 4 + 2] = this.state[k] >>> 8 & 255, g[k * 4 + 3] = this.state[k] >>> 0 & 255;
            return this;
          }, m.prototype.digest = function() {
            var g = new Uint8Array(this.digestLength);
            return this.finish(g), g;
          }, m.prototype._saveState = function(g) {
            for (var b = 0; b < this.state.length; b++)
              g[b] = this.state[b];
          }, m.prototype._restoreState = function(g, b) {
            for (var w = 0; w < this.state.length; w++)
              this.state[w] = g[w];
            this.bytesHashed = b, this.finished = !1, this.bufferLength = 0;
          }, m;
        })()
      );
      n.Hash = s;
      var i = (
        /** @class */
        (function() {
          function m(g) {
            this.inner = new s(), this.outer = new s(), this.blockSize = this.inner.blockSize, this.digestLength = this.inner.digestLength;
            var b = new Uint8Array(this.blockSize);
            if (g.length > this.blockSize)
              new s().update(g).finish(b).clean();
            else
              for (var w = 0; w < g.length; w++)
                b[w] = g[w];
            for (var w = 0; w < b.length; w++)
              b[w] ^= 54;
            this.inner.update(b);
            for (var w = 0; w < b.length; w++)
              b[w] ^= 106;
            this.outer.update(b), this.istate = new Uint32Array(8), this.ostate = new Uint32Array(8), this.inner._saveState(this.istate), this.outer._saveState(this.ostate);
            for (var w = 0; w < b.length; w++)
              b[w] = 0;
          }
          return m.prototype.reset = function() {
            return this.inner._restoreState(this.istate, this.inner.blockSize), this.outer._restoreState(this.ostate, this.outer.blockSize), this;
          }, m.prototype.clean = function() {
            for (var g = 0; g < this.istate.length; g++)
              this.ostate[g] = this.istate[g] = 0;
            this.inner.clean(), this.outer.clean();
          }, m.prototype.update = function(g) {
            return this.inner.update(g), this;
          }, m.prototype.finish = function(g) {
            return this.outer.finished ? this.outer.finish(g) : (this.inner.finish(g), this.outer.update(g, this.digestLength).finish(g)), this;
          }, m.prototype.digest = function() {
            var g = new Uint8Array(this.digestLength);
            return this.finish(g), g;
          }, m;
        })()
      );
      n.HMAC = i;
      function a(m) {
        var g = new s().update(m), b = g.digest();
        return g.clean(), b;
      }
      n.hash = a, n.default = a;
      function o(m, g) {
        var b = new i(m).update(g), w = b.digest();
        return b.clean(), w;
      }
      n.hmac = o;
      function l(m, g, b, w) {
        var S = w[0];
        if (S === 0)
          throw new Error("hkdf: cannot expand more");
        g.reset(), S > 1 && g.update(m), b && g.update(b), g.update(w), g.finish(m), w[0]++;
      }
      var h = new Uint8Array(n.digestLength);
      function _(m, g, b, w) {
        g === void 0 && (g = h), w === void 0 && (w = 32);
        for (var S = new Uint8Array([1]), x = o(g, m), v = new i(x), k = new Uint8Array(v.digestLength), A = k.length, E = new Uint8Array(w), z = 0; z < w; z++)
          A === k.length && (l(k, v, b, S), A = 0), E[z] = k[A++];
        return v.clean(), k.fill(0), S.fill(0), E;
      }
      n.hkdf = _;
      function d(m, g, b, w) {
        for (var S = new i(m), x = S.digestLength, v = new Uint8Array(4), k = new Uint8Array(x), A = new Uint8Array(x), E = new Uint8Array(w), z = 0; z * x < w; z++) {
          var q = z + 1;
          v[0] = q >>> 24 & 255, v[1] = q >>> 16 & 255, v[2] = q >>> 8 & 255, v[3] = q >>> 0 & 255, S.reset(), S.update(g), S.update(v), S.finish(A);
          for (var $ = 0; $ < x; $++)
            k[$] = A[$];
          for (var $ = 2; $ <= b; $++) {
            S.reset(), S.update(A).finish(A);
            for (var I = 0; I < x; I++)
              k[I] ^= A[I];
          }
          for (var $ = 0; $ < x && z * x + $ < w; $++)
            E[z * x + $] = k[$];
        }
        for (var z = 0; z < x; z++)
          k[z] = A[z] = 0;
        for (var z = 0; z < 4; z++)
          v[z] = 0;
        return S.clean(), E;
      }
      n.pbkdf2 = d;
    });
  })(Or)), Or.exports;
}
var Gn = {}, ya;
function df() {
  if (ya) return Gn;
  ya = 1, Object.defineProperty(Gn, "__esModule", { value: !0 }), Gn.timingSafeEqual = n;
  function r(e, t = "") {
    if (!e)
      throw new Error(t);
  }
  function n(e, t) {
    if (e.byteLength !== t.byteLength)
      return !1;
    e instanceof DataView || (e = new DataView(ArrayBuffer.isView(e) ? e.buffer : e)), t instanceof DataView || (t = new DataView(ArrayBuffer.isView(t) ? t.buffer : t)), r(e instanceof DataView), r(t instanceof DataView);
    const s = e.byteLength;
    let i = 0, a = -1;
    for (; ++a < s; )
      i |= e.getUint8(a) ^ t.getUint8(a);
    return i === 0;
  }
  return Gn;
}
var va;
function hf() {
  if (va) return Xe;
  va = 1, Object.defineProperty(Xe, "__esModule", { value: !0 }), Xe.Webhook = Xe.WebhookVerificationError = void 0;
  const r = cf(), n = uf(), e = df(), t = 300;
  class s extends Error {
    constructor(l) {
      super(l), Object.setPrototypeOf(this, s.prototype), this.name = "ExtendableError", this.stack = new Error(l).stack;
    }
  }
  class i extends s {
    constructor(l) {
      super(l), Object.setPrototypeOf(this, i.prototype), this.name = "WebhookVerificationError";
    }
  }
  Xe.WebhookVerificationError = i;
  class a {
    constructor(l, h) {
      if (h?.format === "raw")
        l instanceof Uint8Array ? this.key = l : this.key = Uint8Array.from(l, (_) => _.charCodeAt(0));
      else {
        if (typeof l != "string")
          throw new Error("Expected secret to be of type string");
        l.startsWith(a.prefix) && (l = l.substring(a.prefix.length)), this.key = r.decode(l);
      }
      if (this.key.length === 0)
        throw new Error("Secret can't be empty.");
    }
    verify(l, h, _) {
      var d;
      const m = (d = _?.jsonParse) !== null && d !== void 0 ? d : !0, g = {};
      for (const z of Object.keys(h))
        g[z.toLowerCase()] = h[z];
      const b = g["webhook-id"], w = g["webhook-signature"], S = g["webhook-timestamp"];
      if (!w || !b || !S)
        throw new i("Missing required headers");
      const x = this.verifyTimestamp(S), k = this.sign(b, x, l).split(",")[1], A = w.split(" "), E = new globalThis.TextEncoder();
      for (const z of A) {
        const [q, $] = z.split(",");
        if (q === "v1" && (0, e.timingSafeEqual)(E.encode($), E.encode(k))) {
          const I = l.toString();
          return I === "" ? void 0 : m ? JSON.parse(I) : void 0;
        }
      }
      throw new i("No matching signature found");
    }
    sign(l, h, _) {
      if (typeof _ != "string") if (_.constructor.name === "Buffer")
        _ = _.toString();
      else
        throw new Error("Expected payload to be of type string or Buffer.");
      const d = new TextEncoder(), m = Math.floor(h.getTime() / 1e3), g = d.encode(`${l}.${m}.${_}`);
      return `v1,${r.encode(n.hmac(this.key, g))}`;
    }
    verifyTimestamp(l) {
      const h = Math.floor(Date.now() / 1e3), _ = parseInt(l, 10);
      if (Number.isNaN(_))
        throw new i("Invalid Signature Headers");
      if (h - _ > t)
        throw new i("Message timestamp too old");
      if (_ > h + t)
        throw new i("Message timestamp too new");
      return new Date(_ * 1e3);
    }
  }
  return Xe.Webhook = a, a.prefix = "whsec_", Xe;
}
var _f = hf();
let ka = class extends T {
  /**
   * Parses a webhook payload into an event without verifying its signature. Prefer
   * `unwrap()` unless you have already verified the signature yourself.
   */
  parseUnverified(n) {
    return JSON.parse(n);
  }
  /**
   * Verifies the webhook signature from the `webhook-id`, `webhook-timestamp` and
   * `webhook-signature` headers using your webhook signing key, then parses the
   * payload into an event. Fails if the signature is missing or invalid.
   */
  unwrap(n, e) {
    const t = e?.headers;
    if (t == null)
      throw new Error("Webhook headers are required in order to verify the signature");
    const s = e.key === void 0 ? this._client.webhookKey : e.key;
    if (!s)
      throw new Error("Webhook key must not be null or empty in order to unwrap");
    return new _f.Webhook(s).verify(n, t), JSON.parse(n);
  }
}, Sa = class extends T {
  /**
   * List Agent Versions
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaManagedAgentsAgent of client.beta.agents.versions.list(
   *   'agent_011CZkYpogX7uDKUyvBTophP',
   * )) {
   *   // ...
   * }
   * ```
   */
  list(n, e = {}, t) {
    const { betas: s, workspace_id: i, ...a } = e ?? {};
    return this._client.getAPIList(f`/v1/agents/${n}/versions?beta=true`, P, {
      query: a,
      ...t,
      headers: p([
        {
          "anthropic-beta": [...s ?? [], "managed-agents-2026-04-01"].toString(),
          ...i != null ? { "anthropic-workspace-id": i } : void 0
        },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.agents.versions.list", t, {
        route: "/v1/agents/{agent_id}/versions",
        queryParams: ["limit", "page"],
        attributes: { "gen_ai.agent.id": n }
      })
    });
  }
};
var Ta = /* @__PURE__ */ (() => {
  class r extends T {
    constructor() {
      super(...arguments), this.versions = new Sa(this._client);
    }
    /**
     * Create Agent
     *
     * @example
     * ```ts
     * const betaManagedAgentsAgent =
     *   await client.beta.agents.create({
     *     model: 'claude-opus-5-5',
     *     name: 'My First Agent',
     *   });
     * ```
     */
    create(e, t) {
      const { betas: s, workspace_id: i, ...a } = e;
      return this._client.post("/v1/agents?beta=true", {
        body: a,
        ...t,
        headers: p([
          {
            "anthropic-beta": [...s ?? [], "managed-agents-2026-04-01"].toString(),
            ...i != null ? { "anthropic-workspace-id": i } : void 0
          },
          t?.headers
        ]),
        __span: u(this._client, "anthropic.agents.create", t, {
          route: "/v1/agents",
          createdIDAttribute: "gen_ai.agent.id"
        })
      });
    }
    /**
     * Get Agent
     *
     * @example
     * ```ts
     * const betaManagedAgentsAgent =
     *   await client.beta.agents.retrieve(
     *     'agent_011CZkYpogX7uDKUyvBTophP',
     *   );
     * ```
     */
    retrieve(e, t = {}, s) {
      const { betas: i, workspace_id: a, ...o } = t ?? {};
      return this._client.get(f`/v1/agents/${e}?beta=true`, {
        query: o,
        ...s,
        headers: p([
          {
            "anthropic-beta": [...i ?? [], "managed-agents-2026-04-01"].toString(),
            ...a != null ? { "anthropic-workspace-id": a } : void 0
          },
          s?.headers
        ]),
        __span: u(this._client, "anthropic.agents.retrieve", s, {
          route: "/v1/agents/{agent_id}",
          queryParams: ["version"],
          attributes: { "gen_ai.agent.id": e }
        })
      });
    }
    /**
     * Update Agent
     *
     * @example
     * ```ts
     * const betaManagedAgentsAgent =
     *   await client.beta.agents.update(
     *     'agent_011CZkYpogX7uDKUyvBTophP',
     *     { description: 'updated' },
     *   );
     * ```
     */
    update(e, t, s) {
      const { betas: i, workspace_id: a, ...o } = t;
      return this._client.post(f`/v1/agents/${e}?beta=true`, {
        body: o,
        ...s,
        headers: p([
          {
            "anthropic-beta": [...i ?? [], "managed-agents-2026-04-01"].toString(),
            ...a != null ? { "anthropic-workspace-id": a } : void 0
          },
          s?.headers
        ]),
        __span: u(this._client, "anthropic.agents.update", s, {
          route: "/v1/agents/{agent_id}",
          attributes: { "gen_ai.agent.id": e }
        })
      });
    }
    /**
     * List Agents
     *
     * @example
     * ```ts
     * // Automatically fetches more pages as needed.
     * for await (const betaManagedAgentsAgent of client.beta.agents.list()) {
     *   // ...
     * }
     * ```
     */
    list(e = {}, t) {
      const { betas: s, workspace_id: i, ...a } = e ?? {};
      return this._client.getAPIList("/v1/agents?beta=true", P, {
        query: a,
        ...t,
        headers: p([
          {
            "anthropic-beta": [...s ?? [], "managed-agents-2026-04-01"].toString(),
            ...i != null ? { "anthropic-workspace-id": i } : void 0
          },
          t?.headers
        ]),
        __span: u(this._client, "anthropic.agents.list", t, {
          route: "/v1/agents",
          queryParams: ["created_at[gte]", "created_at[lte]", "include_archived", "limit", "page"]
        })
      });
    }
    /**
     * Archive Agent
     *
     * @example
     * ```ts
     * const betaManagedAgentsAgent =
     *   await client.beta.agents.archive(
     *     'agent_011CZkYpogX7uDKUyvBTophP',
     *   );
     * ```
     */
    archive(e, t = {}, s) {
      const { betas: i, workspace_id: a } = t ?? {};
      return this._client.post(f`/v1/agents/${e}/archive?beta=true`, {
        ...s,
        headers: p([
          {
            "anthropic-beta": [...i ?? [], "managed-agents-2026-04-01"].toString(),
            ...a != null ? { "anthropic-workspace-id": a } : void 0
          },
          s?.headers
        ]),
        __span: u(this._client, "anthropic.agents.archive", s, {
          route: "/v1/agents/{agent_id}/archive",
          attributes: { "gen_ai.agent.id": e }
        })
      });
    }
  }
  return r.Versions = Sa, r;
})();
function zn(r, n) {
  if (!r)
    return () => {
    };
  if (r.aborted)
    return n.abort(), () => {
    };
  const e = () => n.abort();
  return r.addEventListener("abort", e), () => r.removeEventListener("abort", e);
}
function It(r, n) {
  return r instanceof j && r.status === n;
}
function pf(r) {
  return r instanceof j && typeof r.status == "number" && r.status >= 400 && r.status < 500;
}
function Wr(r) {
  return pf(r) && !It(r, 408) && !It(r, 409) && !It(r, 429);
}
function Au(r, n, e) {
  return Math.min(n * 2 ** r, e);
}
function ff(r, n) {
  return r + Math.random() * (n - r);
}
function xu(r) {
  return r * (1 - Math.random() * 0.25);
}
function Eu(r, { authToken: n, helper: e }) {
  if (!n)
    throw new R(`copyClientForHelper: expected a non-empty authToken but received ${JSON.stringify(n)}`);
  const t = r._options.defaultHeaders, s = r._authState?.extraHeaders, i = s ? Object.fromEntries(Object.entries(s).filter(([o]) => {
    const l = o.toLowerCase();
    return l !== "authorization" && l !== "x-api-key";
  })) : void 0, a = p([
    i,
    t,
    { [$n]: e }
  ]);
  return r.withOptions({
    apiKey: null,
    authToken: n,
    baseURL: r.baseURL,
    credentials: void 0,
    defaultHeaders: a
  });
}
var pt, Vn, Z, Jn, Yn, Xn, tn, nn, ft, gt, Qn, mt, rn;
const gf = 999, mf = 1e3, bf = 6e4, wf = 3e5;
var Qs = /* @__PURE__ */ (() => {
  class r {
    constructor(e) {
      pt.set(this, void 0), Vn.set(this, !1), Z.set(this, void 0), Jn.set(this, void 0), Yn.set(this, void 0), Xn.set(this, void 0), tn.set(this, void 0), nn.set(this, void 0), ft.set(this, void 0), this.client = e.client, this.environmentId = e.environmentId, this.environmentKey = e.environmentKey, this.workerId = e.workerId ?? kf(), y(this, pt, Eu(e.client, {
        authToken: e.environmentKey,
        helper: "environments-work-poller"
      })), y(this, Yn, e.autoStop ?? !0), y(this, Xn, e.drain ?? !1), y(this, tn, e.blockMs === void 0 ? gf : e.blockMs), y(this, nn, e.reclaimOlderThanMs ?? null), y(this, ft, e.requestOptions), y(this, Z, new AbortController()), y(this, Jn, zn(e.signal, c(this, Z, "f")));
    }
    /** Read-only view of this iterator's abort signal. */
    get signal() {
      return c(this, Z, "f").signal;
    }
    /** Abort the iterator. The current `for await` will exit cleanly. */
    abort() {
      c(this, Z, "f").abort();
    }
    async *[(pt = /* @__PURE__ */ new WeakMap(), Vn = /* @__PURE__ */ new WeakMap(), Z = /* @__PURE__ */ new WeakMap(), Jn = /* @__PURE__ */ new WeakMap(), Yn = /* @__PURE__ */ new WeakMap(), Xn = /* @__PURE__ */ new WeakMap(), tn = /* @__PURE__ */ new WeakMap(), nn = /* @__PURE__ */ new WeakMap(), ft = /* @__PURE__ */ new WeakMap(), Symbol.asyncIterator)]() {
      if (c(this, Vn, "f"))
        throw new R("Cannot iterate over a consumed WorkPoller");
      y(this, Vn, !0);
      let e = he.active();
      const t = M(this.client);
      t.info("poller starting", {
        component: "work-poller",
        environment_id: this.environmentId
      });
      const s = new vf(t, this.environmentId);
      try {
        let i = 0;
        for (; !c(this, Z, "f").signal.aborted; ) {
          let a;
          try {
            a = await c(this, pt, "f").beta.environments.work.poll(this.environmentId, {
              "Anthropic-Worker-ID": this.workerId,
              ...c(this, tn, "f") !== null ? { block_ms: c(this, tn, "f") } : {},
              ...c(this, nn, "f") !== null ? { reclaim_older_than_ms: c(this, nn, "f") } : {}
            }, { headers: p([c(this, ft, "f")?.headers]), signal: c(this, Z, "f").signal });
          } catch (o) {
            if (c(this, Z, "f").signal.aborted)
              return;
            if (Wr(o))
              throw t.error("poll failed permanently, stopping poller", { error: String(o) }), o;
            const l = xu(yf(i));
            t.warn("poll failed, backing off", { error: String(o), backoff_ms: l }), i++, await ct(l, c(this, Z, "f").signal);
            continue;
          }
          if (i = 0, a == null) {
            if (c(this, Xn, "f"))
              return;
            s.onEmptyPoll(), await ct(ff(1e3, 3e3), c(this, Z, "f").signal);
            continue;
          }
          s.onClaim(), this._workSpan = F(this.client, () => xp(this.client, a, e)), t.info("claimed work", {
            component: "work-poller",
            environment_id: this.environmentId,
            work_id: a.id,
            work_type: a.data.type
          });
          try {
            await c(this, pt, "f").beta.environments.work.ack(a.id, { environment_id: a.environment_id }, { headers: p([c(this, ft, "f")?.headers]), signal: c(this, Z, "f").signal });
          } catch (o) {
            t.error("ack failed", { work_id: a.id, error: String(o) }), F(this.client, () => su(this._workSpan, c(this, Z, "f").signal, o));
            continue;
          }
          try {
            yield a, e = he.active();
          } finally {
            if (c(this, Yn, "f"))
              try {
                await c(this, pt, "f").beta.environments.work.stop(a.id, { environment_id: a.environment_id }, { headers: p([c(this, ft, "f")?.headers]) });
              } catch (o) {
                It(o, 409) || t.warn("stop failed", { work_id: a.id, error: String(o) });
              }
            F(this.client, () => ru(this._workSpan, c(this, Z, "f").signal));
          }
        }
      } finally {
        c(this, Jn, "f").call(this);
      }
    }
  }
  return r;
})();
function yf(r) {
  return Au(r, mf, bf);
}
var vf = /* @__PURE__ */ (() => {
  class r {
    constructor(e, t) {
      gt.set(this, void 0), Qn.set(this, void 0), mt.set(this, void 0), rn.set(this, 0), y(this, gt, e), y(this, Qn, t);
    }
    onEmptyPoll() {
      const e = Date.now(), t = { component: "work-poller", environment_id: c(this, Qn, "f") };
      c(this, mt, "f") === void 0 ? (y(this, mt, y(this, rn, e, "f")), c(this, gt, "f").info("idle; polling for work", t)) : e - c(this, rn, "f") >= wf ? (y(this, rn, e), c(this, gt, "f").info(`still polling; idle for ${Math.round((e - c(this, mt, "f")) / 1e3)}s`, t)) : c(this, gt, "f").debug("poll returned no work", t);
    }
    onClaim() {
      y(this, mt, void 0);
    }
  }
  return gt = /* @__PURE__ */ new WeakMap(), Qn = /* @__PURE__ */ new WeakMap(), mt = /* @__PURE__ */ new WeakMap(), rn = /* @__PURE__ */ new WeakMap(), r;
})();
function kf() {
  const n = globalThis.process?.env?.HOSTNAME;
  return n ? `${n}-${Vs()}` : Vs();
}
var bt, qe, wt, Sf = /* @__PURE__ */ (() => {
  class r {
    constructor() {
      bt.set(this, []), qe.set(this, []), wt.set(this, !1);
    }
    /** Enqueue an item, or hand it directly to a waiting reader. Returns `false` once closed. */
    push(e) {
      if (c(this, wt, "f"))
        return !1;
      const t = c(this, qe, "f").shift();
      return t ? t({ done: !1, value: e }) : c(this, bt, "f").push(e), !0;
    }
    /** Mark the queue done. Idempotent; wakes every pending reader with `done: true`. */
    close() {
      if (!c(this, wt, "f"))
        for (y(this, wt, !0); c(this, qe, "f").length > 0; )
          c(this, qe, "f").shift()({ done: !0, value: void 0 });
    }
    /**
     * Resolve with the next item, or `done: true` once the queue is closed and
     * drained. When `signal` is supplied, aborting it resolves a pending read
     * with `done: true` (cancellation is pushed down here rather than handled by
     * an outer `Promise.race`).
     */
    next(e) {
      return c(this, bt, "f").length > 0 ? Promise.resolve({ done: !1, value: c(this, bt, "f").shift() }) : c(this, wt, "f") || e?.aborted ? Promise.resolve({ done: !0, value: void 0 }) : new Promise((t) => {
        const s = (a) => {
          e?.removeEventListener("abort", i), t(a);
        }, i = () => {
          const a = c(this, qe, "f").indexOf(s);
          a >= 0 && c(this, qe, "f").splice(a, 1), t({ done: !0, value: void 0 });
        };
        c(this, qe, "f").push(s), e?.addEventListener("abort", i, { once: !0 });
      });
    }
    /** Synchronously remove and return the next buffered item, or `undefined` if empty. */
    tryShift() {
      return c(this, bt, "f").shift();
    }
  }
  return bt = /* @__PURE__ */ new WeakMap(), qe = /* @__PURE__ */ new WeakMap(), wt = /* @__PURE__ */ new WeakMap(), r;
})(), Pi = /* @__PURE__ */ (() => {
  class r extends Error {
    constructor(e) {
      const t = typeof e == "string" ? e : e.map((s) => s.type === "text" ? s.text : `[${s.type}]`).join(" ");
      super(t), this.name = "ToolError", this.content = e;
    }
  }
  return r;
})();
const Tf = "\\x00-\\x1f\\x7f-\\x9f\\u061c\\u200e\\u200f\\u2028\\u2029\\u202a-\\u202e\\u2066-\\u2069", Af = new RegExp(`[${Tf}]+`, "g"), xf = /[\uD800-\uDFFF]/gu;
function jr(r) {
  return r.replace(xf, "�");
}
const Ru = 4096, Ef = 200;
function Rf(r, n = Ru) {
  return zu(jr(r).replace(Af, " ").trim(), n);
}
function Pf(r) {
  return Rf(r, Ef);
}
function Ge(r) {
  return Pf(r).replace(/[' ]+/g, " ").trim();
}
function Pu(r) {
  return `Error: ${r instanceof Error ? r.message : String(r)}`;
}
function zf(r) {
  return zu(jr(Pu(r)), Ru);
}
function zu(r, n) {
  if (r.length <= n)
    return r;
  let e = 0, t = 0;
  for (const s of r) {
    if (t === n)
      break;
    t += 1, e += s.length;
  }
  return r.slice(0, e);
}
function Mf(r) {
  return typeof r == "string" ? jr(r) : r.filter((n) => n.type === "text" && n.text !== "").map((n) => ({ ...n, text: jr(n.text) }));
}
function Aa(r) {
  return "name" in r ? r.name : "mcp_server_name" in r ? r.mcp_server_name : r.type;
}
function Of(r) {
  return r instanceof Pi ? r.content : Pu(r);
}
async function Mu(r, n, e) {
  try {
    const t = r.parse ? r.parse(n) : n;
    return { content: await r.run(t, e), isError: !1 };
  } catch (t) {
    return { content: Of(t), isError: !0 };
  }
}
var sn, Zn, yt, Qe, ge, U, er, K, tr, vt, nr, H, kt, oe, St, Be, Tt, Ae, rr, an, ce, sr, on, cn, ir, xa, Ea, Ra, ws, Pa, ys, za, ar, or, vs, Ma, Oa;
const Ca = 500, Cf = 1e4, $f = 12e4, If = 3e4, Nf = 1e3, Lf = 3e4, qf = 5 * 6e4, Bf = 6e4;
function Ou(r) {
  return r.type !== "session.status_idle" ? !1 : r.stop_reason?.type !== "requires_action";
}
var Uf = /* @__PURE__ */ (() => {
  class r {
    constructor(e, t) {
      sn.set(this, void 0), Zn.set(this, void 0), yt.set(this, /* @__PURE__ */ new Set()), Qe.set(this, !1), ge.set(this, void 0), y(this, sn, e), y(this, Zn, t);
    }
    /**
     * Arm on an idle that ends the turn; disarm otherwise. `user.tool_confirmation`
     * is neutral: it signals neither agent activity nor an idle, and its effect
     * on the clock flows through {@link block} / {@link unblock} instead —
     * disarming here would discard the pending arm the verdict is about to
     * settle.
     */
    noteEvent(e) {
      e.type !== "user.tool_confirmation" && (Ou(e) ? this.arm() : this.disarm());
    }
    /** Register gated work that must resolve before an idle countdown starts. */
    block(e) {
      c(this, yt, "f").add(e), c(this, ge, "f") !== void 0 && (y(this, Qe, !0), clearTimeout(c(this, ge, "f")), y(this, ge, void 0));
    }
    /**
     * Retire gated work (a no-op for ids never blocked); applies a pending arm —
     * with a fresh full `maxIdleMs` window — once the last blocker retires.
     */
    unblock(e) {
      c(this, yt, "f").delete(e), c(this, yt, "f").size === 0 && c(this, Qe, "f") && this.arm();
    }
    /**
     * (Re)start the idle countdown — or, while blockers are outstanding, hold
     * the arm pending instead. Stopping then would drop a held call when its
     * verdict later arrives, or cut the runner off before a released call's
     * result can drive the next turn.
     */
    arm() {
      if (!(c(this, sn, "f") <= 0)) {
        if (c(this, yt, "f").size > 0) {
          y(this, Qe, !0);
          return;
        }
        y(this, Qe, !1), c(this, ge, "f") !== void 0 && clearTimeout(c(this, ge, "f")), y(this, ge, setTimeout(c(this, Zn, "f"), c(this, sn, "f")));
      }
    }
    /**
     * Cancel the idle countdown and any pending arm. Blockers persist — they
     * track real outstanding work, retired only by {@link unblock}.
     */
    disarm() {
      y(this, Qe, !1), c(this, ge, "f") !== void 0 && (clearTimeout(c(this, ge, "f")), y(this, ge, void 0));
    }
  }
  return sn = /* @__PURE__ */ new WeakMap(), Zn = /* @__PURE__ */ new WeakMap(), yt = /* @__PURE__ */ new WeakMap(), Qe = /* @__PURE__ */ new WeakMap(), ge = /* @__PURE__ */ new WeakMap(), r;
})(), Zs = /* @__PURE__ */ (() => {
  class r {
    constructor(e, t) {
      U.add(this), er.set(this, !1), K.set(this, void 0), tr.set(this, void 0), vt.set(this, void 0), nr.set(this, void 0), H.set(this, void 0), kt.set(this, /* @__PURE__ */ new Set()), oe.set(this, /* @__PURE__ */ new Set()), St.set(this, /* @__PURE__ */ new Map()), Be.set(this, /* @__PURE__ */ new Map()), Tt.set(this, new Sf()), Ae.set(this, 0), rr.set(this, qf), an.set(this, null), ce.set(this, void 0), sr.set(this, void 0), on.set(this, void 0), cn.set(this, !1), this.client = t.client, this.sessionId = e, this.tools = t.tools, this.maxIdleMs = t.maxIdleMs ?? Bf, y(this, H, M(t.client)), y(this, nr, new Map(t.tools.map((s) => [Aa(s), s]))), y(this, K, new AbortController()), y(this, tr, zn(t.signal, c(this, K, "f"))), y(this, vt, t.requestOptions), y(this, ce, new Uf(this.maxIdleMs, () => {
        c(this, H, "f").info("session idle after its turn ended; stopping", {
          component: "session-tool-runner",
          session_id: this.sessionId,
          max_idle_ms: this.maxIdleMs
        }), c(this, K, "f").abort();
      }));
    }
    /** Read-only view of this runner's abort signal. */
    get signal() {
      return c(this, K, "f").signal;
    }
    /** Abort the runner. Background tasks will wind down and `for await` will exit cleanly. */
    abort() {
      c(this, K, "f").abort();
    }
    /**
     * @internal
     * `EnvironmentWorker` keeps this equal to the lease TTL each heartbeat
     * reports; applies to a send already retrying.
     */
    _setSendRetryWindow(e) {
      y(this, rr, e);
    }
    async *[(er = /* @__PURE__ */ new WeakMap(), K = /* @__PURE__ */ new WeakMap(), tr = /* @__PURE__ */ new WeakMap(), vt = /* @__PURE__ */ new WeakMap(), nr = /* @__PURE__ */ new WeakMap(), H = /* @__PURE__ */ new WeakMap(), kt = /* @__PURE__ */ new WeakMap(), oe = /* @__PURE__ */ new WeakMap(), St = /* @__PURE__ */ new WeakMap(), Be = /* @__PURE__ */ new WeakMap(), Tt = /* @__PURE__ */ new WeakMap(), Ae = /* @__PURE__ */ new WeakMap(), rr = /* @__PURE__ */ new WeakMap(), an = /* @__PURE__ */ new WeakMap(), ce = /* @__PURE__ */ new WeakMap(), sr = /* @__PURE__ */ new WeakMap(), on = /* @__PURE__ */ new WeakMap(), cn = /* @__PURE__ */ new WeakMap(), U = /* @__PURE__ */ new WeakSet(), Symbol.asyncIterator)]() {
      if (c(this, er, "f"))
        throw new R("Cannot iterate over a consumed SessionToolRunner");
      y(this, er, !0), y(this, sr, this.client._tracer ? he.active() : void 0), c(this, H, "f").info("session tool runner starting", {
        component: "session-tool-runner",
        session_id: this.sessionId
      });
      const e = c(this, U, "m", xa).call(this).catch((t) => {
        c(this, K, "f").signal.aborted || c(this, H, "f").error("stream loop failed", { error: String(t) }), c(this, K, "f").abort();
      });
      try {
        for (; ; ) {
          const s = await c(this, Tt, "f").next(c(this, K, "f").signal);
          if (s.done)
            break;
          yield s.value;
        }
        await e;
        let t;
        for (; (t = c(this, Tt, "f").tryShift()) !== void 0; )
          yield t;
      } finally {
        c(this, K, "f").abort(), c(this, ce, "f").disarm(), await e;
        try {
          await c(this, U, "m", Oa).call(this);
        } catch (t) {
          c(this, H, "f").warn("drain failed", { error: String(t) });
        }
        c(this, Tt, "f").close();
        for (const t of this.tools)
          try {
            await t.close?.();
          } catch (s) {
            c(this, H, "f").warn("tool.close failed", { tool: Aa(t), error: String(s) });
          }
        c(this, tr, "f").call(this);
      }
    }
  }
  return ir = function() {
    return {
      ...c(this, vt, "f"),
      headers: p([iu("session-tool-runner"), c(this, vt, "f")?.headers]),
      signal: c(this, K, "f").signal
    };
  }, xa = // ===== event stream =====
  async function() {
    const e = c(this, K, "f");
    let t = Ca;
    for (; !e.signal.aborted; ) {
      try {
        const s = await this.client.beta.sessions.events.stream(this.sessionId, {}, c(this, U, "m", ir).call(this));
        await c(this, U, "m", Ea).call(this);
        for await (const i of s)
          if (t = Ca, await c(this, U, "m", Pa).call(this, i))
            return;
      } catch (s) {
        if (e.signal.throwIfAborted(), Wr(s))
          throw c(this, H, "f").error("permanent stream failure, shutting down", { error: String(s) }), e.abort(), s;
        c(this, H, "f").warn("stream disconnected, reconnecting", {
          error: String(s),
          backoff_ms: t
        });
      }
      e.signal.throwIfAborted(), await ct(t, e.signal), t = Math.min(t * 2, Cf);
    }
  }, Ea = /**
   * Read full history before dispatching so a `tool_use` whose result appears
   * later in the same history is not re-executed. Runs after the live stream is
   * already attached (see {@link SessionToolRunner.#streamLoop}).
   */
  async function() {
    const e = c(this, K, "f"), t = [];
    let s = !1;
    y(this, cn, !1);
    try {
      for await (const o of this.client.beta.sessions.events.list(this.sessionId, { limit: 1e3 }, c(this, U, "m", ir).call(this)))
        c(this, U, "m", Ra).call(this, o, t), o.type !== "user.tool_confirmation" && (s = Ou(o));
    } catch (o) {
      e.signal.throwIfAborted(), c(this, H, "f").warn("reconcile list failed", { error: String(o) });
      for (const l of t)
        c(this, kt, "f").delete(l.id);
      return;
    }
    y(this, cn, !0);
    const i = t.filter((o) => !c(this, oe, "f").has(o.id));
    c(this, ce, "f").disarm();
    for (const o of i)
      await c(this, U, "m", ys).call(this, o);
    for (const o of [...c(this, Be, "f").values()]) {
      const l = c(this, St, "f").get(o.id);
      l !== void 0 && await c(this, U, "m", ar).call(this, o, l);
    }
    const a = i.filter((o) => !c(this, oe, "f").has(o.id) && !c(this, Be, "f").has(o.id));
    s && a.length === 0 ? c(this, ce, "f").arm() : c(this, ce, "f").disarm();
  }, Ra = function(e, t) {
    c(this, U, "m", ws).call(this, e), e.type === "agent.tool_use" || e.type === "agent.custom_tool_use" ? (c(this, kt, "f").add(e.id), c(this, oe, "f").has(e.id) || t.push(e)) : e.type === "user.tool_result" ? c(this, oe, "f").add(e.tool_use_id) : e.type === "user.custom_tool_result" ? c(this, oe, "f").add(e.custom_tool_use_id) : e.type === "user.tool_confirmation" && (c(this, oe, "f").has(e.tool_use_id) || c(this, St, "f").set(e.tool_use_id, e.result));
  }, ws = function(e) {
    if (!(!this.client._tracer || c(this, on, "f") !== void 0))
      switch (e.type) {
        case "session.thread_status_running":
        case "session.thread_status_idle":
        case "session.thread_status_rescheduled":
        case "session.thread_status_terminated":
          y(this, on, e.session_thread_id);
      }
  }, Pa = /** Returns true when the runner should exit. */
  async function(e) {
    switch (c(this, ce, "f").noteEvent(e), c(this, cn, "f") && c(this, U, "m", ws).call(this, e), e.type) {
      case "agent.tool_use":
      case "agent.custom_tool_use":
        return c(this, kt, "f").has(e.id) || (c(this, kt, "f").add(e.id), await c(this, U, "m", ys).call(this, e)), !1;
      case "user.tool_confirmation":
        return await c(this, U, "m", za).call(this, e), !1;
      case "user.tool_result":
        return c(this, oe, "f").add(e.tool_use_id), !1;
      case "user.custom_tool_result":
        return c(this, oe, "f").add(e.custom_tool_use_id), !1;
      case "session.status_terminated":
      case "session.deleted":
        return c(this, H, "f").info("session terminated", {
          component: "session-tool-runner",
          session_id: this.sessionId
        }), c(this, K, "f").abort(), !0;
      default:
        return !1;
    }
  }, ys = // ===== confirmation gating (always_ask tools) =====
  /**
   * Dispatch `ev`, honoring its evaluated permission. A call the server gated
   * (`evaluated_permission == "ask"`) is held until its `user.tool_confirmation`
   * arrives. Fails closed: only an explicit `allow` verdict releases a gated
   * call; a server-side `deny` overrides any recorded verdict; an unrecognized
   * permission is held like `ask` and an unrecognized verdict is denied.
   */
  async function(e) {
    const t = e.evaluated_permission, s = t === "deny" ? "deny" : c(this, St, "f").get(e.id);
    if (s === void 0) {
      t === void 0 || t === "allow" ? await c(this, U, "m", vs).call(this, e, void 0) : c(this, Be, "f").has(e.id) || (c(this, H, "f").info("tool call awaiting confirmation; holding", {
        component: "session-tool-runner",
        session_id: this.sessionId,
        tool: e.name,
        tool_use_id: e.id
      }), c(this, Be, "f").set(e.id, e), c(this, ce, "f").block(e.id));
      return;
    }
    await c(this, U, "m", ar).call(this, e, s);
  }, za = /** Record an allow/deny verdict and release the held call it gates, if any. */
  async function(e) {
    c(this, St, "f").set(e.tool_use_id, e.result);
    const t = c(this, Be, "f").get(e.tool_use_id);
    t !== void 0 && await c(this, U, "m", ar).call(this, t, e.result);
  }, ar = /**
   * Dispatch or resolve a gated call according to its verdict.
   *
   * The idle-clock blocker accounting lives here: a denial retires the held
   * call's blocker, while an allow keeps one on the call — taking it now if the
   * verdict was already known when the call was routed, so it was never held —
   * until `#execute` has finished with it. The countdown must not run over
   * gated work that is still in flight.
   */
  async function(e, t) {
    const s = c(this, Be, "f").delete(e.id);
    if (t === "allow") {
      c(this, H, "f").info("tool call confirmed", {
        component: "session-tool-runner",
        session_id: this.sessionId,
        tool: e.name,
        tool_use_id: e.id
      }), s || c(this, ce, "f").block(e.id);
      try {
        await c(this, U, "m", vs).call(this, e, "allow");
      } finally {
        c(this, ce, "f").unblock(e.id);
      }
      return;
    }
    s && c(this, ce, "f").unblock(e.id), c(this, oe, "f").add(e.id), c(this, H, "f").info("tool call denied; not executing", {
      component: "session-tool-runner",
      session_id: this.sessionId,
      tool: e.name,
      tool_use_id: e.id
    }), c(this, U, "m", or).call(this, {
      event: e,
      toolUseId: e.id,
      name: e.name,
      isError: !1,
      posted: !1,
      confirmation: "deny"
    });
  }, or = function(e) {
    c(this, Tt, "f").push(e);
  }, vs = // ===== tool execution =====
  async function(e, t) {
    var s, i;
    if (!c(this, oe, "f").has(e.id)) {
      c(this, H, "f").info("executing tool", {
        component: "session-tool-runner",
        session_id: this.sessionId,
        tool: e.name,
        tool_use_id: e.id
      }), y(this, Ae, (s = c(this, Ae, "f"), s++, s));
      try {
        const a = c(this, nr, "f").get(e.name);
        if (!a) {
          c(this, H, "f").info("tool not owned by this runner; leaving the tool_use_id pending for its owner", {
            component: "session-tool-runner",
            session_id: this.sessionId,
            tool: e.name,
            tool_use_id: e.id
          }), t === "allow" && c(this, ce, "f").disarm(), c(this, U, "m", or).call(this, {
            event: e,
            toolUseId: e.id,
            name: e.name,
            isError: !1,
            posted: !1,
            confirmation: t
          });
          return;
        }
        let o, l;
        const h = c(this, vt, "f")?.openTelemetry?.conversationId ?? (e.session_thread_id || c(this, on, "f")), _ = new AbortController(), d = zn(c(this, K, "f").signal, _), m = setTimeout(() => _.abort(), $f);
        try {
          const w = {
            signal: c(this, K, "f").signal,
            conversationId: h,
            sessionID: this.sessionId,
            parentContext: c(this, sr, "f")
          }, S = await Ai(this.client, a, e, w, async () => {
            const x = await Mu(a, e.input, {
              toolUse: e,
              toolUseBlock: e,
              signal: _.signal
            }), v = Wf(x.content), k = this.client._tracer ? v.map((A, E) => {
              const z = typeof x.content == "string" ? void 0 : x.content[E];
              return z && z.type !== "text" && A.type === "text" ? z : A;
            }) : v;
            return { sent: v, content: k, isError: x.isError };
          });
          o = S.sent, l = S.isError;
        } finally {
          clearTimeout(m), d();
        }
        const g = Ff(e, l, o), b = await c(this, U, "m", Ma).call(this, g, e.id, h);
        c(this, U, "m", or).call(this, {
          event: e,
          result: g,
          toolUseId: e.id,
          name: e.name,
          isError: l,
          posted: b,
          confirmation: t
        });
      } finally {
        y(this, Ae, (i = c(this, Ae, "f"), i--, i)), c(this, Ae, "f") === 0 && c(this, an, "f")?.call(this);
      }
    }
  }, Ma = async function(e, t, s) {
    const i = c(this, K, "f"), a = Date.now();
    let o, l = 0;
    for (; ; ) {
      l++, i.signal.throwIfAborted();
      try {
        return await this.client.beta.sessions.events.send(this.sessionId, { events: [e] }, { ...c(this, U, "m", ir).call(this), openTelemetry: { conversationId: s } }), c(this, oe, "f").add(t), !0;
      } catch (h) {
        if (o = h, Wr(h))
          break;
        const _ = c(this, rr, "f") - (Date.now() - a);
        if (_ <= 0)
          break;
        const d = Math.min(xu(Au(l - 1, Nf, Lf)), _);
        c(this, H, "f").warn("tool result send failed; retrying", {
          tool_use_id: t,
          attempt: l,
          backoff_ms: d,
          error: String(h)
        }), await ct(d, i.signal);
      }
    }
    return c(this, H, "f").error("failed to send tool result", {
      tool_use_id: t,
      attempts: l,
      error: String(o)
    }), !1;
  }, Oa = /** Wait (bounded) for in-flight tool executions to finish during teardown. */
  async function() {
    c(this, Ae, "f") !== 0 && (await Promise.race([new Promise((e) => y(this, an, e)), ct(If)]), y(this, an, null), c(this, Ae, "f") > 0 && c(this, H, "f").warn("drain timeout exceeded"));
  }, r;
})();
function Ff(r, n, e) {
  return r.type === "agent.custom_tool_use" ? { type: "user.custom_tool_result", custom_tool_use_id: r.id, is_error: n, content: e } : { type: "user.tool_result", tool_use_id: r.id, is_error: n, content: e };
}
function Wf(r) {
  if (typeof r == "string")
    return [{ type: "text", text: r || "(no output)" }];
  const n = r.map((e) => e.type === "text" ? { type: "text", text: e.text || "(no output)" } : e.type === "image" || e.type === "document" ? e : e.type === "search_result" ? {
    type: "search_result",
    source: e.source,
    title: e.title,
    content: e.content.map((t) => ({ type: "text", text: t.text })),
    citations: { enabled: e.citations?.enabled ?? !1 }
  } : { type: "text", text: JSON.stringify(e) });
  return n.length > 0 ? n : [{ type: "text", text: "(no output)" }];
}
const jf = 15e3, ei = 5e3;
function Hf(r, n) {
  if (!(r >= ei))
    throw new R(`${n} must be at least ${ei}ms (got ${r}); to run without memory sync, pass \`memorySyncIntervalMs: null\` to the worker instead`);
}
var cr, ln, ks, un, Ze;
const $a = 3e4, Df = 9e4, Kf = "NO_HEARTBEAT";
function Gf(r) {
  return r.resources.some((n) => n.type === "memory_store");
}
function Vf(r) {
  if (!r)
    return null;
  let n;
  try {
    const t = r.replace(/-/g, "+").replace(/_/g, "/"), s = t.padEnd(Math.ceil(t.length / 4) * 4, "=");
    n = JSON.parse(Ws(Pp(s)));
  } catch {
    return null;
  }
  if (n === null || typeof n != "object" || Array.isArray(n))
    return null;
  const e = n.sessions_token;
  return typeof e == "string" && e !== "" ? e : null;
}
var Ia = /* @__PURE__ */ (() => {
  class r {
    constructor(e) {
      if (cr.add(this), ln.set(this, void 0), e.unrestrictedPaths !== void 0)
        throw new R("The `unrestrictedPaths` option you passed to EnvironmentWorker (or client.beta.environments.work.worker()) is no longer supported. The worker's file tools (read, write, edit, glob, grep) are now always confined to `workdir` plus the session's memory folders. Remove `unrestrictedPaths` from your options; to let the file tools reach any other directory, add it to `AgentToolContext.allowedRoots` from a `tools` factory.");
      this.client = e.client, this.environmentId = e.environmentId, this.environmentKey = e.environmentKey, this.tools = e.tools, this.workdir = e.workdir ?? process.cwd(), this.maxFileBytes = e.maxFileBytes, this.maxIdleMs = e.maxIdleMs, e.memorySyncIntervalMs != null && Hf(e.memorySyncIntervalMs, "memorySyncIntervalMs"), this.memorySyncIntervalMs = e.memorySyncIntervalMs, this.memorySyncDeletions = e.memorySyncDeletions ?? "enabled", this.workerId = e.workerId, this.requestOptions = e.requestOptions, y(this, ln, e.signal);
    }
    /**
     * Poll the environment and service each claimed session until the supplied
     * signal (or the one passed to the constructor) aborts. Throws if
     * `environmentId` / `environmentKey` were not provided to the constructor.
     */
    async run(e) {
      const { environmentId: t, environmentKey: s } = this;
      if (t === void 0 || s === void 0)
        throw new R("EnvironmentWorker.run: environmentId and environmentKey are required to poll for work");
      const i = e ?? c(this, ln, "f"), a = new Qs({
        client: this.client,
        environmentId: t,
        environmentKey: s,
        ...this.workerId !== void 0 ? { workerId: this.workerId } : {},
        ...i ? { signal: i } : {},
        ...this.requestOptions !== void 0 ? { requestOptions: this.requestOptions } : {},
        // The per-item handler stops or releases every work item on exit; let it
        // be the single owner of `work.stop` rather than double-posting from the
        // poller.
        autoStop: !1
      });
      for await (const o of a) {
        const l = a._workSpan;
        try {
          await Ep(this.client, l, a.signal, () => c(this, cr, "m", ks).call(this, o, s, a.signal, l));
        } catch (h) {
          if (a.signal?.aborted)
            throw h;
          M(this.client).error("work item failed", { work_id: o.id, error: String(h) });
        }
      }
    }
    /**
     * Service a single, already-claimed work item without the poll loop: build the
     * per-session {@link AgentToolContext} (workdir from this worker's options),
     * download the session agent's skills (`setupSkills`), run a
     * {@link SessionToolRunner} for the session while heartbeating the work-item
     * lease, and force-stop the work item on exit (whether the runner finishes
     * normally, throws, or the control plane signals shutdown). The one
     * exception is a lost lease: the item then belongs to the queue or another
     * worker and is left alone.
     *
     * Use this when something else does the claiming — e.g. a `worker poll
     * --on-work` script that hands an already-claimed item to a fresh process. The
     * work id / environment id / session id each fall back to `ANTHROPIC_WORK_ID` /
     * `ANTHROPIC_ENVIRONMENT_ID` / `ANTHROPIC_SESSION_ID` (the env vars that
     * command sets) when not passed; the environment key resolves from this
     * option, then the worker's own `environmentKey`, then
     * `ANTHROPIC_ENVIRONMENT_KEY`, and is needed only when the work item's
     * `secret` yields no sessions token — a host that receives only the
     * per-item secret runs without ever holding the key. With no arguments
     * inside that command it just works. Throws a clear error naming the first
     * required value still missing after resolution, and — rather than ever
     * running unauthenticated — when neither a sessions token nor an
     * environment key resolved. Throws `SessionMemoryError` when the
     * session has memory stores attached but they cannot be mounted — the work
     * item carried no sessions token (unless `memorySyncIntervalMs` turned
     * memory off), or a store failed to download.
     *
     * `workSecret` is the work item's per-item `secret` payload from the poll
     * response, falling back to `ANTHROPIC_WORK_SECRET`; unlike the others it is
     * optional — when present, the sessions token extracted from it is preferred
     * as the Bearer credential for this item's heartbeat / force-stop / session
     * calls; when absent (or undecodable) those calls use the environment key.
     */
    async handleItem(e) {
      const t = e?.workId ?? O("ANTHROPIC_WORK_ID"), s = e?.environmentId ?? O("ANTHROPIC_ENVIRONMENT_ID"), i = e?.sessionId ?? O("ANTHROPIC_SESSION_ID"), a = (e?.environmentKey ?? this.environmentKey ?? O("ANTHROPIC_ENVIRONMENT_KEY")) || void 0, o = e?.workSecret || O("ANTHROPIC_WORK_SECRET") || null;
      if (!t)
        throw new R("handleItem: workId is required — pass it or set ANTHROPIC_WORK_ID");
      if (!s)
        throw new R("handleItem: environmentId is required — pass it or set ANTHROPIC_ENVIRONMENT_ID");
      if (!i)
        throw new R("handleItem: sessionId is required — pass it or set ANTHROPIC_SESSION_ID");
      if (!a && !o)
        throw new R("handleItem: environmentKey is required when there is no work secret — pass it, construct the worker with it, or set ANTHROPIC_ENVIRONMENT_KEY");
      const l = {
        id: t,
        environment_id: s,
        secret: o,
        data: { type: "session", id: i }
      };
      await c(this, cr, "m", ks).call(this, l, a, e?.signal ?? c(this, ln, "f"));
    }
  }
  return ln = /* @__PURE__ */ new WeakMap(), cr = /* @__PURE__ */ new WeakSet(), ks = /**
   * The per-item body shared by {@link EnvironmentWorker.run}'s poll loop and
   * {@link EnvironmentWorker.handleItem}: run a {@link SessionToolRunner} for the
   * work item's session while heartbeating its lease, force-stopping on exit
   * unless the lease was lost. Non-session work items are ignored.
   *
   * When the poll response carried a per-item `secret` (a short-lived payload
   * scoped to this work item), the sessions token extracted from it is
   * preferred over `environmentKey` as the Bearer credential for those
   * per-item calls; a missing/undecodable secret falls back to
   * `environmentKey` unchanged.
   */
  async function(e, t, s, i) {
    const a = M(this.client), o = Vf(e.secret), l = o ?? t;
    if (l === void 0)
      throw new R("handleItem: the work item carried a secret payload but no sessions token could be extracted, and there is no environment key to fall back to; the poller must issue a secret whose payload carries `sessions_token`, or provide the environment key (pass it, construct the worker with it, or set ANTHROPIC_ENVIRONMENT_KEY)");
    e.secret && o === null && a.warn("work item carried a secret payload but no sessions token could be extracted; falling back to the environment key", { work_id: e.id });
    const h = Eu(this.client, {
      authToken: l,
      helper: "environments-worker"
    }), _ = e.data.id, d = new AbortController(), m = zn(s, d), g = new Yf(d), b = await Promise.resolve().then(() => hm);
    let w, S;
    const x = Qf(h, e, g, a, this.requestOptions, (E) => {
      w = E, S?._setSendRetryWindow(E);
    }).catch((E) => {
      d.signal.aborted || a.error("heartbeat loop failed", { work_id: e.id, error: String(E) }), d.abort();
    });
    let v = async () => {
    }, k, A = !1;
    try {
      if (e.data.type !== "session") {
        a.debug("skipping non-session work item", { work_id: e.id, type: e.data.type });
        return;
      }
      const E = await h.beta.sessions.retrieve(_);
      if (o === null && this.memorySyncIntervalMs !== null && Gf(E))
        throw new b.SessionMemoryError(`cannot mount the session's memories: the work item carried no sessions token (work_id=${e.id}, session_id=${_}); the memory endpoints reject the environment key, so the poller must issue a per-item \`secret\` carrying \`sessions_token\`, or set \`memorySyncIntervalMs: null\` to run without memory`);
      const z = {
        workdir: this.workdir,
        // The scoped sub-client, not the parent: the skill download
        // `setupSkills` performs for this session rides the same per-item
        // credential as every other per-item call.
        client: h,
        session: E,
        ...this.maxFileBytes !== void 0 ? { maxFileBytes: this.maxFileBytes } : {}
      };
      try {
        v = await b.setupSkills(z);
      } catch ($) {
        a.warn("skill setup failed", { session_id: _, work_id: e.id, error: String($) });
      }
      o !== null && this.memorySyncIntervalMs !== null ? (k = new b.SessionMemoryStores(h, {
        workdir: this.workdir,
        ...this.memorySyncIntervalMs !== void 0 ? { syncIntervalMs: this.memorySyncIntervalMs } : {},
        syncDeletions: this.memorySyncDeletions
      }), await k.download(E), z.allowedRoots = k.roots, z.readOnlyRoots = k.readOnlyRoots) : a.debug("memory stores disabled for this item", { work_id: e.id });
      const q = typeof this.tools == "function" ? this.tools(z) : this.tools ?? b.betaAgentToolset20260401(z);
      S = new Zs(_, {
        client: h,
        tools: q,
        ...this.maxIdleMs !== void 0 ? { maxIdleMs: this.maxIdleMs } : {},
        ...this.requestOptions !== void 0 ? { requestOptions: this.requestOptions } : {},
        signal: d.signal
      }), w !== void 0 && S._setSendRetryWindow(w);
      for await (const $ of S)
        k && await k.syncIfDue();
      A = !d.signal.aborted;
    } finally {
      try {
        await v().catch((E) => {
          a.warn("skill cleanup failed", { session_id: _, work_id: e.id, error: String(E) });
        });
      } finally {
        if (k) {
          const E = b.MEMORY_FLUSH_TIMEOUT_MS;
          A && await Na(k.finish(), E) && a.warn(`final memory sync cut off after ${E}ms; the flush that follows still uploads changed files`, { session_id: _, work_id: e.id });
          const z = new AbortController();
          await Na(k.flushWrites(z.signal), E) && (z.abort(), a.warn(`memory flush cut off after ${E}ms; changed files it had not uploaded yet are not saved`, { session_id: _, work_id: e.id })), await k.dispose().catch(($) => {
            a.warn("memory store cleanup failed", {
              session_id: _,
              work_id: e.id,
              error: String($)
            });
          });
        }
      }
      g.finish("runner_done"), m(), await x, g.lost ? a.info("lease lost; released without stopping it", { session_id: _, work_id: e.id }) : await Jf(h, e, a, this.requestOptions), (g.lost || g.rejected) && F(this.client, () => i?.end());
    }
  }, r;
})();
async function Na(r, n) {
  let e;
  try {
    return await Promise.race([
      r.then(() => !1, () => !1),
      new Promise((t) => {
        e = setTimeout(() => t(!0), n);
      })
    ]);
  } finally {
    e !== void 0 && clearTimeout(e);
  }
}
async function Jf(r, n, e, t) {
  try {
    await r.beta.environments.work.stop(
      n.id,
      { environment_id: n.environment_id, force: !0 },
      // Caller's headers pass through; the helper-tag header is on the scoped
      // sub-client's default_headers via copyClientForHelper, so no per-call
      // re-stamping needed.
      { ...t, headers: p([t?.headers]) }
    );
  } catch (s) {
    It(s, 409) || e.error("force-stop on exit failed", { work_id: n.id, error: String(s) });
  }
}
var Yf = /* @__PURE__ */ (() => {
  class r {
    constructor(e) {
      un.set(this, void 0), Ze.set(this, void 0), y(this, un, e);
    }
    get signal() {
      return c(this, un, "f").signal;
    }
    finish(e) {
      y(this, Ze, c(this, Ze, "f") ?? e), c(this, un, "f").abort();
    }
    /** True once the item belongs to the queue or another worker. */
    get lost() {
      return c(this, Ze, "f") === "lease_lost" || c(this, Ze, "f") === "assumed_lost";
    }
    /** True once the API rejected a heartbeat for good, so the worker cannot keep the lease. */
    get rejected() {
      return c(this, Ze, "f") === "heartbeat_rejected";
    }
  }
  return un = /* @__PURE__ */ new WeakMap(), Ze = /* @__PURE__ */ new WeakMap(), r;
})();
function Xf(r) {
  let n = r instanceof j ? r.error : void 0;
  for (const e of ["error", "details", "current_state"]) {
    if (!Ni(n))
      return {};
    n = n[e];
  }
  return Ni(n) ? n : {};
}
async function Qf(r, n, e, t, s, i) {
  let a = $a, o = Df, l = Date.now(), h = Kf;
  const _ = async () => {
    const d = new AbortController(), m = zn(e.signal, d), g = setTimeout(() => d.abort(), a);
    try {
      const b = await r.beta.environments.work.heartbeat(n.id, { environment_id: n.environment_id, expected_last_heartbeat: h }, { ...s, headers: p([s?.headers]), signal: d.signal });
      l = Date.now(), h = b.last_heartbeat, b.ttl_seconds > 0 && (o = b.ttl_seconds * 1e3, a = Math.max(1e3, Math.min(o / 2, $a)), i?.(o)), (b.state === "stopping" || b.state === "stopped") && (t.info("heartbeat signals shutdown", { work_id: n.id, state: b.state }), e.finish("control_plane_stop")), b.lease_extended || (t.warn("lease not extended, shutting down", { work_id: n.id }), e.finish("control_plane_stop"));
    } catch (b) {
      if (e.signal.throwIfAborted(), It(b, 412)) {
        const w = Xf(b);
        t.error("lease lost: heartbeat precondition failed", {
          work_id: n.id,
          server_state: w.state,
          server_ttl_seconds: w.ttl_seconds,
          server_last_heartbeat: w.last_heartbeat
        }), e.finish("lease_lost");
        return;
      }
      if (Wr(b))
        throw t.error("permanent heartbeat failure", { work_id: n.id, error: String(b) }), e.finish("heartbeat_rejected"), b;
      if (Date.now() - l > o) {
        t.error("lease assumed lost: no successful heartbeat in ttl", {
          work_id: n.id,
          ttl_ms: o,
          error: String(b)
        }), e.finish("assumed_lost");
        return;
      }
      t.warn("transient heartbeat failure", { work_id: n.id, error: String(b) });
    } finally {
      clearTimeout(g), m();
    }
  };
  for (await _(); !e.signal.aborted; )
    await ct(a, e.signal), e.signal.throwIfAborted(), await _();
}
var La = /* @__PURE__ */ (() => {
  class r extends T {
    /**
     * Note: these endpoints are called automatically by the pre-built environment
     * worker provided in the SDKs and CLI, for orchestrating sessions with self-hosted
     * sandbox environments. They are included here as a reference; you do not need to
     * invoke them directly.
     *
     * Retrieve detailed information about a specific work item.
     *
     * @example
     * ```ts
     * const betaSelfHostedWork =
     *   await client.beta.environments.work.retrieve('work_id', {
     *     environment_id: 'env_011CZkZ9X2dpNyB7HsEFoRfW',
     *   });
     * ```
     */
    retrieve(e, t, s) {
      const { environment_id: i, betas: a, workspace_id: o } = t;
      return this._client.get(f`/v1/environments/${i}/work/${e}?beta=true`, {
        ...s,
        headers: p([
          {
            "anthropic-beta": [...a ?? [], "managed-agents-2026-04-01"].toString(),
            ...o != null ? { "anthropic-workspace-id": o } : void 0
          },
          s?.headers
        ]),
        __span: u(this._client, "anthropic.environments.work.retrieve", s, {
          route: "/v1/environments/{environment_id}/work/{work_id}",
          attributes: { "anthropic.environment.id": i, "anthropic.environment.work.id": e }
        })
      });
    }
    /**
     * Note: these endpoints are called automatically by the pre-built environment
     * worker provided in the SDKs and CLI, for orchestrating sessions with self-hosted
     * sandbox environments. They are included here as a reference; you do not need to
     * invoke them directly.
     *
     * Update work item metadata with merge semantics.
     *
     * @example
     * ```ts
     * const betaSelfHostedWork =
     *   await client.beta.environments.work.update('work_id', {
     *     environment_id: 'env_011CZkZ9X2dpNyB7HsEFoRfW',
     *     metadata: { foo: 'string' },
     *   });
     * ```
     */
    update(e, t, s) {
      const { environment_id: i, betas: a, workspace_id: o, ...l } = t;
      return this._client.post(f`/v1/environments/${i}/work/${e}?beta=true`, {
        body: l,
        ...s,
        headers: p([
          {
            "anthropic-beta": [...a ?? [], "managed-agents-2026-04-01"].toString(),
            ...o != null ? { "anthropic-workspace-id": o } : void 0
          },
          s?.headers
        ]),
        __span: u(this._client, "anthropic.environments.work.update", s, {
          route: "/v1/environments/{environment_id}/work/{work_id}",
          attributes: { "anthropic.environment.id": i, "anthropic.environment.work.id": e }
        })
      });
    }
    /**
     * Note: these endpoints are called automatically by the pre-built environment
     * worker provided in the SDKs and CLI, for orchestrating sessions with self-hosted
     * sandbox environments. They are included here as a reference; you do not need to
     * invoke them directly.
     *
     * List work items in an environment.
     *
     * @example
     * ```ts
     * // Automatically fetches more pages as needed.
     * for await (const betaSelfHostedWork of client.beta.environments.work.list(
     *   'env_011CZkZ9X2dpNyB7HsEFoRfW',
     * )) {
     *   // ...
     * }
     * ```
     */
    list(e, t = {}, s) {
      const { betas: i, ...a } = t ?? {};
      return this._client.getAPIList(f`/v1/environments/${e}/work?beta=true`, P, {
        query: a,
        ...s,
        headers: p([
          { "anthropic-beta": [...i ?? [], "managed-agents-2026-04-01"].toString() },
          s?.headers
        ]),
        __span: u(this._client, "anthropic.environments.work.list", s, {
          route: "/v1/environments/{environment_id}/work",
          queryParams: ["limit", "page"],
          attributes: { "anthropic.environment.id": e }
        })
      });
    }
    /**
     * Note: these endpoints are called automatically by the pre-built environment
     * worker provided in the SDKs and CLI, for orchestrating sessions with self-hosted
     * sandbox environments. They are included here as a reference; you do not need to
     * invoke them directly.
     *
     * Acknowledge receipt of a work item, transitioning it from 'queued' to 'starting'
     * and removing it from the queue.
     *
     * @example
     * ```ts
     * const betaSelfHostedWork =
     *   await client.beta.environments.work.ack('work_id', {
     *     environment_id: 'env_011CZkZ9X2dpNyB7HsEFoRfW',
     *   });
     * ```
     */
    ack(e, t, s) {
      const { environment_id: i, betas: a } = t;
      return this._client.post(f`/v1/environments/${i}/work/${e}/ack?beta=true`, {
        ...s,
        headers: p([
          { "anthropic-beta": [...a ?? [], "managed-agents-2026-04-01"].toString() },
          s?.headers
        ]),
        __span: u(this._client, "anthropic.environments.work.ack", s, {
          route: "/v1/environments/{environment_id}/work/{work_id}/ack",
          attributes: { "anthropic.environment.id": i, "anthropic.environment.work.id": e }
        })
      });
    }
    /**
     * Note: these endpoints are called automatically by the pre-built environment
     * worker provided in the SDKs and CLI, for orchestrating sessions with self-hosted
     * sandbox environments. They are included here as a reference; you do not need to
     * invoke them directly.
     *
     * Record a heartbeat for a work item to maintain the lease.
     *
     * @example
     * ```ts
     * const betaSelfHostedWorkHeartbeatResponse =
     *   await client.beta.environments.work.heartbeat('work_id', {
     *     environment_id: 'env_011CZkZ9X2dpNyB7HsEFoRfW',
     *   });
     * ```
     */
    heartbeat(e, t, s) {
      const { environment_id: i, desired_ttl_seconds: a, expected_last_heartbeat: o, betas: l } = t;
      return this._client.post(f`/v1/environments/${i}/work/${e}/heartbeat?beta=true`, {
        query: { desired_ttl_seconds: a, expected_last_heartbeat: o },
        ...s,
        headers: p([
          { "anthropic-beta": [...l ?? [], "managed-agents-2026-04-01"].toString() },
          s?.headers
        ]),
        __span: u(this._client, "anthropic.environments.work.heartbeat", s, {
          route: "/v1/environments/{environment_id}/work/{work_id}/heartbeat",
          queryParams: ["desired_ttl_seconds", "expected_last_heartbeat"],
          attributes: { "anthropic.environment.id": i, "anthropic.environment.work.id": e }
        })
      });
    }
    /**
     * Note: these endpoints are called automatically by the pre-built environment
     * worker provided in the SDKs and CLI, for orchestrating sessions with self-hosted
     * sandbox environments. They are included here as a reference; you do not need to
     * invoke them directly.
     *
     * Long poll for work items in the queue.
     *
     * @example
     * ```ts
     * const betaSelfHostedWork =
     *   await client.beta.environments.work.poll(
     *     'env_011CZkZ9X2dpNyB7HsEFoRfW',
     *   );
     * ```
     */
    poll(e, t = {}, s) {
      const { betas: i, "Anthropic-Worker-ID": a, ...o } = t ?? {};
      return this._client.get(f`/v1/environments/${e}/work/poll?beta=true`, {
        query: o,
        ...s,
        headers: p([
          {
            "anthropic-beta": [...i ?? [], "managed-agents-2026-04-01"].toString(),
            ...a != null ? { "Anthropic-Worker-ID": a } : void 0
          },
          s?.headers
        ]),
        __span: u(this._client, "anthropic.environments.work.poll", s, {
          route: "/v1/environments/{environment_id}/work/poll",
          queryParams: ["block_ms", "reclaim_older_than_ms"],
          attributes: { "anthropic.environment.id": e }
        })
      });
    }
    /**
     * Get statistics about the work queue for an environment.
     *
     * @example
     * ```ts
     * const betaSelfHostedWorkQueueStats =
     *   await client.beta.environments.work.stats(
     *     'env_011CZkZ9X2dpNyB7HsEFoRfW',
     *   );
     * ```
     */
    stats(e, t = {}, s) {
      const { betas: i, workspace_id: a } = t ?? {};
      return this._client.get(f`/v1/environments/${e}/work/stats?beta=true`, {
        ...s,
        headers: p([
          {
            "anthropic-beta": [...i ?? [], "managed-agents-2026-04-01"].toString(),
            ...a != null ? { "anthropic-workspace-id": a } : void 0
          },
          s?.headers
        ]),
        __span: u(this._client, "anthropic.environments.work.stats", s, {
          route: "/v1/environments/{environment_id}/work/stats",
          attributes: { "anthropic.environment.id": e }
        })
      });
    }
    /**
     * Note: these endpoints are called automatically by the pre-built environment
     * worker provided in the SDKs and CLI, for orchestrating sessions with self-hosted
     * sandbox environments. They are included here as a reference; you do not need to
     * invoke them directly.
     *
     * Stop a work item, initiating graceful or forced shutdown.
     *
     * @example
     * ```ts
     * const betaSelfHostedWork =
     *   await client.beta.environments.work.stop('work_id', {
     *     environment_id: 'env_011CZkZ9X2dpNyB7HsEFoRfW',
     *   });
     * ```
     */
    stop(e, t, s) {
      const { environment_id: i, betas: a, workspace_id: o, ...l } = t;
      return this._client.post(f`/v1/environments/${i}/work/${e}/stop?beta=true`, {
        body: l,
        ...s,
        headers: p([
          {
            "anthropic-beta": [...a ?? [], "managed-agents-2026-04-01"].toString(),
            ...o != null ? { "anthropic-workspace-id": o } : void 0
          },
          s?.headers
        ]),
        __span: u(this._client, "anthropic.environments.work.stop", s, {
          route: "/v1/environments/{environment_id}/work/{work_id}/stop",
          attributes: { "anthropic.environment.id": i, "anthropic.environment.work.id": e }
        })
      });
    }
    /**
     * Continuously claim work from a self-hosted environment, ack each item,
     * and yield it. Posts `stop` automatically when the consumer's loop body
     * returns or when iteration ends.
     *
     * @example
     * ```ts
     * for await (const work of client.beta.environments.work.poller({
     *   environmentId,
     *   environmentKey,
     * })) {
     *   if (work.data.type !== 'session') continue;
     *   // ...service the work...
     * }
     * ```
     */
    poller(e) {
      return new Qs({ ...e, client: this._client });
    }
    worker(e) {
      return new Ia({ ...e, client: this._client });
    }
  }
  return r.WorkPoller = Qs, r.EnvironmentWorker = Ia, r;
})(), qa = /* @__PURE__ */ (() => {
  class r extends T {
    constructor() {
      super(...arguments), this.work = new La(this._client);
    }
    /**
     * Create a new environment with the specified configuration.
     *
     * @example
     * ```ts
     * const betaEnvironment =
     *   await client.beta.environments.create({
     *     name: 'python-data-analysis',
     *   });
     * ```
     */
    create(e, t) {
      const { betas: s, workspace_id: i, ...a } = e;
      return this._client.post("/v1/environments?beta=true", {
        body: a,
        ...t,
        headers: p([
          {
            "anthropic-beta": [...s ?? [], "managed-agents-2026-04-01"].toString(),
            ...i != null ? { "anthropic-workspace-id": i } : void 0
          },
          t?.headers
        ]),
        __span: u(this._client, "anthropic.environments.create", t, {
          route: "/v1/environments",
          createdIDAttribute: "anthropic.environment.id"
        })
      });
    }
    /**
     * Retrieve a specific environment by ID.
     *
     * @example
     * ```ts
     * const betaEnvironment =
     *   await client.beta.environments.retrieve(
     *     'env_011CZkZ9X2dpNyB7HsEFoRfW',
     *   );
     * ```
     */
    retrieve(e, t = {}, s) {
      const { betas: i, workspace_id: a } = t ?? {};
      return this._client.get(f`/v1/environments/${e}?beta=true`, {
        ...s,
        headers: p([
          {
            "anthropic-beta": [...i ?? [], "managed-agents-2026-04-01"].toString(),
            ...a != null ? { "anthropic-workspace-id": a } : void 0
          },
          s?.headers
        ]),
        __span: u(this._client, "anthropic.environments.retrieve", s, {
          route: "/v1/environments/{environment_id}",
          attributes: { "anthropic.environment.id": e }
        })
      });
    }
    /**
     * Update an existing environment's configuration.
     *
     * @example
     * ```ts
     * const betaEnvironment =
     *   await client.beta.environments.update(
     *     'env_011CZkZ9X2dpNyB7HsEFoRfW',
     *   );
     * ```
     */
    update(e, t, s) {
      const { betas: i, workspace_id: a, ...o } = t;
      return this._client.post(f`/v1/environments/${e}?beta=true`, {
        body: o,
        ...s,
        headers: p([
          {
            "anthropic-beta": [...i ?? [], "managed-agents-2026-04-01"].toString(),
            ...a != null ? { "anthropic-workspace-id": a } : void 0
          },
          s?.headers
        ]),
        __span: u(this._client, "anthropic.environments.update", s, {
          route: "/v1/environments/{environment_id}",
          attributes: { "anthropic.environment.id": e }
        })
      });
    }
    /**
     * List environments with pagination support.
     *
     * @example
     * ```ts
     * // Automatically fetches more pages as needed.
     * for await (const betaEnvironment of client.beta.environments.list()) {
     *   // ...
     * }
     * ```
     */
    list(e = {}, t) {
      const { betas: s, workspace_id: i, ...a } = e ?? {};
      return this._client.getAPIList("/v1/environments?beta=true", P, {
        query: a,
        ...t,
        headers: p([
          {
            "anthropic-beta": [...s ?? [], "managed-agents-2026-04-01"].toString(),
            ...i != null ? { "anthropic-workspace-id": i } : void 0
          },
          t?.headers
        ]),
        __span: u(this._client, "anthropic.environments.list", t, {
          route: "/v1/environments",
          queryParams: ["include_archived", "limit", "page"]
        })
      });
    }
    /**
     * Delete an environment by ID. Returns a confirmation of the deletion.
     *
     * @example
     * ```ts
     * const betaEnvironmentDeleteResponse =
     *   await client.beta.environments.delete(
     *     'env_011CZkZ9X2dpNyB7HsEFoRfW',
     *   );
     * ```
     */
    delete(e, t = {}, s) {
      const { betas: i, workspace_id: a } = t ?? {};
      return this._client.delete(f`/v1/environments/${e}?beta=true`, {
        ...s,
        headers: p([
          {
            "anthropic-beta": [...i ?? [], "managed-agents-2026-04-01"].toString(),
            ...a != null ? { "anthropic-workspace-id": a } : void 0
          },
          s?.headers
        ]),
        __span: u(this._client, "anthropic.environments.delete", s, {
          route: "/v1/environments/{environment_id}",
          attributes: { "anthropic.environment.id": e }
        })
      });
    }
    /**
     * Archive an environment by ID. Archived environments cannot be used to create new
     * sessions.
     *
     * @example
     * ```ts
     * const betaEnvironment =
     *   await client.beta.environments.archive(
     *     'env_011CZkZ9X2dpNyB7HsEFoRfW',
     *   );
     * ```
     */
    archive(e, t = {}, s) {
      const { betas: i, workspace_id: a } = t ?? {};
      return this._client.post(f`/v1/environments/${e}/archive?beta=true`, {
        ...s,
        headers: p([
          {
            "anthropic-beta": [...i ?? [], "managed-agents-2026-04-01"].toString(),
            ...a != null ? { "anthropic-workspace-id": a } : void 0
          },
          s?.headers
        ]),
        __span: u(this._client, "anthropic.environments.archive", s, {
          route: "/v1/environments/{environment_id}/archive",
          attributes: { "anthropic.environment.id": e }
        })
      });
    }
  }
  return r.Work = La, r;
})();
class Ba extends T {
  /**
   * Create a Memory
   *
   * @example
   * ```ts
   * const betaManagedAgentsMemory =
   *   await client.beta.memoryStores.memories.create(
   *     'memory_store_id',
   *     { content: 'content', path: 'xx' },
   *   );
   * ```
   */
  create(n, e, t) {
    const { view: s, betas: i, workspace_id: a, ...o } = e;
    return this._client.post(f`/v1/memory_stores/${n}/memories?beta=true`, {
      query: { view: s },
      body: o,
      ...t,
      headers: p([
        {
          "anthropic-beta": [...i ?? [], "agent-memory-2026-07-22"].toString(),
          ...a != null ? { "anthropic-workspace-id": a } : void 0
        },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.memory_stores.memories.create", t, {
        route: "/v1/memory_stores/{memory_store_id}/memories",
        queryParams: ["view"],
        attributes: { "gen_ai.memory.store.id": n },
        createdIDAttribute: "gen_ai.memory.record.id"
      })
    });
  }
  /**
   * Retrieve a Memory
   *
   * @example
   * ```ts
   * const betaManagedAgentsMemory =
   *   await client.beta.memoryStores.memories.retrieve(
   *     'memory_id',
   *     { memory_store_id: 'memory_store_id' },
   *   );
   * ```
   */
  retrieve(n, e, t) {
    const { memory_store_id: s, betas: i, workspace_id: a, ...o } = e;
    return this._client.get(f`/v1/memory_stores/${s}/memories/${n}?beta=true`, {
      query: o,
      ...t,
      headers: p([
        {
          "anthropic-beta": [...i ?? [], "agent-memory-2026-07-22"].toString(),
          ...a != null ? { "anthropic-workspace-id": a } : void 0
        },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.memory_stores.memories.retrieve", t, {
        route: "/v1/memory_stores/{memory_store_id}/memories/{memory_id}",
        queryParams: ["view"],
        attributes: { "gen_ai.memory.store.id": s, "gen_ai.memory.record.id": n }
      })
    });
  }
  /**
   * Update a Memory
   *
   * @example
   * ```ts
   * const betaManagedAgentsMemory =
   *   await client.beta.memoryStores.memories.update(
   *     'memory_id',
   *     { memory_store_id: 'memory_store_id' },
   *   );
   * ```
   */
  update(n, e, t) {
    const { memory_store_id: s, view: i, betas: a, workspace_id: o, ...l } = e;
    return this._client.post(f`/v1/memory_stores/${s}/memories/${n}?beta=true`, {
      query: { view: i },
      body: l,
      ...t,
      headers: p([
        {
          "anthropic-beta": [...a ?? [], "agent-memory-2026-07-22"].toString(),
          ...o != null ? { "anthropic-workspace-id": o } : void 0
        },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.memory_stores.memories.update", t, {
        route: "/v1/memory_stores/{memory_store_id}/memories/{memory_id}",
        queryParams: ["view"],
        attributes: { "gen_ai.memory.store.id": s, "gen_ai.memory.record.id": n }
      })
    });
  }
  /**
   * List Memories
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaManagedAgentsMemoryListItem of client.beta.memoryStores.memories.list(
   *   'memory_store_id',
   * )) {
   *   // ...
   * }
   * ```
   */
  list(n, e = {}, t) {
    const { betas: s, workspace_id: i, ...a } = e ?? {};
    return this._client.getAPIList(f`/v1/memory_stores/${n}/memories?beta=true`, P, {
      query: a,
      ...t,
      headers: p([
        {
          "anthropic-beta": [...s ?? [], "agent-memory-2026-07-22"].toString(),
          ...i != null ? { "anthropic-workspace-id": i } : void 0
        },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.memory_stores.memories.list", t, {
        route: "/v1/memory_stores/{memory_store_id}/memories",
        queryParams: ["depth", "limit", "page", "path_prefix", "view"],
        contentQueryParams: ["page"],
        attributes: { "gen_ai.memory.store.id": n }
      })
    });
  }
  /**
   * Delete a Memory
   *
   * @example
   * ```ts
   * const betaManagedAgentsDeletedMemory =
   *   await client.beta.memoryStores.memories.delete(
   *     'memory_id',
   *     { memory_store_id: 'memory_store_id' },
   *   );
   * ```
   */
  delete(n, e, t) {
    const { memory_store_id: s, expected_content_sha256: i, betas: a, workspace_id: o } = e;
    return this._client.delete(f`/v1/memory_stores/${s}/memories/${n}?beta=true`, {
      query: { expected_content_sha256: i },
      ...t,
      headers: p([
        {
          "anthropic-beta": [...a ?? [], "agent-memory-2026-07-22"].toString(),
          ...o != null ? { "anthropic-workspace-id": o } : void 0
        },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.memory_stores.memories.delete", t, {
        route: "/v1/memory_stores/{memory_store_id}/memories/{memory_id}",
        queryParams: ["expected_content_sha256"],
        attributes: { "gen_ai.memory.store.id": s, "gen_ai.memory.record.id": n }
      })
    });
  }
}
class Ua extends T {
  /**
   * Retrieve a Memory Version
   *
   * @example
   * ```ts
   * const betaManagedAgentsMemoryVersion =
   *   await client.beta.memoryStores.memoryVersions.retrieve(
   *     'memory_version_id',
   *     { memory_store_id: 'memory_store_id' },
   *   );
   * ```
   */
  retrieve(n, e, t) {
    const { memory_store_id: s, betas: i, workspace_id: a, ...o } = e;
    return this._client.get(f`/v1/memory_stores/${s}/memory_versions/${n}?beta=true`, {
      query: o,
      ...t,
      headers: p([
        {
          "anthropic-beta": [...i ?? [], "agent-memory-2026-07-22"].toString(),
          ...a != null ? { "anthropic-workspace-id": a } : void 0
        },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.memory_stores.memory_versions.retrieve", t, {
        route: "/v1/memory_stores/{memory_store_id}/memory_versions/{memory_version_id}",
        queryParams: ["view"],
        attributes: {
          "gen_ai.memory.store.id": s,
          "anthropic.memory_store.memory_version.id": n
        }
      })
    });
  }
  /**
   * List Memory Versions
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaManagedAgentsMemoryVersion of client.beta.memoryStores.memoryVersions.list(
   *   'memory_store_id',
   * )) {
   *   // ...
   * }
   * ```
   */
  list(n, e = {}, t) {
    const { betas: s, workspace_id: i, ...a } = e ?? {};
    return this._client.getAPIList(f`/v1/memory_stores/${n}/memory_versions?beta=true`, P, {
      query: a,
      ...t,
      headers: p([
        {
          "anthropic-beta": [...s ?? [], "agent-memory-2026-07-22"].toString(),
          ...i != null ? { "anthropic-workspace-id": i } : void 0
        },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.memory_stores.memory_versions.list", t, {
        route: "/v1/memory_stores/{memory_store_id}/memory_versions",
        queryParams: [
          "api_key_id",
          "created_at[gte]",
          "created_at[lte]",
          "limit",
          "memory_id",
          "operation",
          "page",
          "service_account_id",
          "session_id",
          "view"
        ],
        attributes: { "gen_ai.memory.store.id": n }
      })
    });
  }
  /**
   * Redact a Memory Version
   *
   * @example
   * ```ts
   * const betaManagedAgentsMemoryVersion =
   *   await client.beta.memoryStores.memoryVersions.redact(
   *     'memory_version_id',
   *     { memory_store_id: 'memory_store_id' },
   *   );
   * ```
   */
  redact(n, e, t) {
    const { memory_store_id: s, betas: i, workspace_id: a } = e;
    return this._client.post(f`/v1/memory_stores/${s}/memory_versions/${n}/redact?beta=true`, {
      ...t,
      headers: p([
        {
          "anthropic-beta": [...i ?? [], "agent-memory-2026-07-22"].toString(),
          ...a != null ? { "anthropic-workspace-id": a } : void 0
        },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.memory_stores.memory_versions.redact", t, {
        route: "/v1/memory_stores/{memory_store_id}/memory_versions/{memory_version_id}/redact",
        attributes: {
          "gen_ai.memory.store.id": s,
          "anthropic.memory_store.memory_version.id": n
        }
      })
    });
  }
}
var Fa = /* @__PURE__ */ (() => {
  class r extends T {
    constructor() {
      super(...arguments), this.memories = new Ba(this._client), this.memoryVersions = new Ua(this._client);
    }
    /**
     * Create a Memory Store
     *
     * @example
     * ```ts
     * const betaManagedAgentsMemoryStore =
     *   await client.beta.memoryStores.create({ name: 'x' });
     * ```
     */
    create(e, t) {
      const { betas: s, workspace_id: i, ...a } = e;
      return this._client.post("/v1/memory_stores?beta=true", {
        body: a,
        ...t,
        headers: p([
          {
            "anthropic-beta": [...s ?? [], "agent-memory-2026-07-22"].toString(),
            ...i != null ? { "anthropic-workspace-id": i } : void 0
          },
          t?.headers
        ]),
        __span: u(this._client, "anthropic.memory_stores.create", t, {
          route: "/v1/memory_stores",
          createdIDAttribute: "gen_ai.memory.store.id"
        })
      });
    }
    /**
     * Retrieve a Memory Store
     *
     * @example
     * ```ts
     * const betaManagedAgentsMemoryStore =
     *   await client.beta.memoryStores.retrieve(
     *     'memory_store_id',
     *   );
     * ```
     */
    retrieve(e, t = {}, s) {
      const { betas: i, workspace_id: a } = t ?? {};
      return this._client.get(f`/v1/memory_stores/${e}?beta=true`, {
        ...s,
        headers: p([
          {
            "anthropic-beta": [...i ?? [], "agent-memory-2026-07-22"].toString(),
            ...a != null ? { "anthropic-workspace-id": a } : void 0
          },
          s?.headers
        ]),
        __span: u(this._client, "anthropic.memory_stores.retrieve", s, {
          route: "/v1/memory_stores/{memory_store_id}",
          attributes: { "gen_ai.memory.store.id": e }
        })
      });
    }
    /**
     * Update a Memory Store
     *
     * @example
     * ```ts
     * const betaManagedAgentsMemoryStore =
     *   await client.beta.memoryStores.update('memory_store_id');
     * ```
     */
    update(e, t, s) {
      const { betas: i, workspace_id: a, ...o } = t;
      return this._client.post(f`/v1/memory_stores/${e}?beta=true`, {
        body: o,
        ...s,
        headers: p([
          {
            "anthropic-beta": [...i ?? [], "agent-memory-2026-07-22"].toString(),
            ...a != null ? { "anthropic-workspace-id": a } : void 0
          },
          s?.headers
        ]),
        __span: u(this._client, "anthropic.memory_stores.update", s, {
          route: "/v1/memory_stores/{memory_store_id}",
          attributes: { "gen_ai.memory.store.id": e }
        })
      });
    }
    /**
     * List Memory Stores
     *
     * @example
     * ```ts
     * // Automatically fetches more pages as needed.
     * for await (const betaManagedAgentsMemoryStore of client.beta.memoryStores.list()) {
     *   // ...
     * }
     * ```
     */
    list(e = {}, t) {
      const { betas: s, workspace_id: i, ...a } = e ?? {};
      return this._client.getAPIList("/v1/memory_stores?beta=true", P, {
        query: a,
        ...t,
        headers: p([
          {
            "anthropic-beta": [...s ?? [], "agent-memory-2026-07-22"].toString(),
            ...i != null ? { "anthropic-workspace-id": i } : void 0
          },
          t?.headers
        ]),
        __span: u(this._client, "anthropic.memory_stores.list", t, {
          route: "/v1/memory_stores",
          queryParams: ["created_at[gte]", "created_at[lte]", "include_archived", "limit", "page"]
        })
      });
    }
    /**
     * Delete a Memory Store
     *
     * @example
     * ```ts
     * const betaManagedAgentsDeletedMemoryStore =
     *   await client.beta.memoryStores.delete('memory_store_id');
     * ```
     */
    delete(e, t = {}, s) {
      const { betas: i, workspace_id: a } = t ?? {};
      return this._client.delete(f`/v1/memory_stores/${e}?beta=true`, {
        ...s,
        headers: p([
          {
            "anthropic-beta": [...i ?? [], "agent-memory-2026-07-22"].toString(),
            ...a != null ? { "anthropic-workspace-id": a } : void 0
          },
          s?.headers
        ]),
        __span: u(this._client, "anthropic.memory_stores.delete", s, {
          route: "/v1/memory_stores/{memory_store_id}",
          attributes: { "gen_ai.memory.store.id": e }
        })
      });
    }
    /**
     * Archive a Memory Store
     *
     * @example
     * ```ts
     * const betaManagedAgentsMemoryStore =
     *   await client.beta.memoryStores.archive('memory_store_id');
     * ```
     */
    archive(e, t = {}, s) {
      const { betas: i, workspace_id: a } = t ?? {};
      return this._client.post(f`/v1/memory_stores/${e}/archive?beta=true`, {
        ...s,
        headers: p([
          {
            "anthropic-beta": [...i ?? [], "agent-memory-2026-07-22"].toString(),
            ...a != null ? { "anthropic-workspace-id": a } : void 0
          },
          s?.headers
        ]),
        __span: u(this._client, "anthropic.memory_stores.archive", s, {
          route: "/v1/memory_stores/{memory_store_id}/archive",
          attributes: { "gen_ai.memory.store.id": e }
        })
      });
    }
  }
  return r.Memories = Ba, r.MemoryVersions = Ua, r;
})();
class Wa extends T {
  /**
   * Send a batch of Message creation requests.
   *
   * The Message Batches API can be used to process multiple Messages API requests at
   * once. Once a Message Batch is created, it begins processing immediately. Batches
   * can take up to 24 hours to complete.
   *
   * Learn more about the Message Batches API in our
   * [user guide](https://platform.claude.com/docs/en/build-with-claude/batch-processing)
   *
   * @example
   * ```ts
   * const betaMessageBatch =
   *   await client.beta.messages.batches.create({
   *     requests: [
   *       {
   *         custom_id: 'my-custom-id-1',
   *         params: {
   *           max_tokens: 1024,
   *           messages: [
   *             { content: 'Hello, world', role: 'user' },
   *           ],
   *           model: 'claude-opus-5-5',
   *         },
   *       },
   *     ],
   *   });
   * ```
   */
  create(n, e) {
    const { betas: t, user_profile_id: s, workspace_id: i, ...a } = n;
    return this._client.post("/v1/messages/batches?beta=true", {
      body: a,
      ...e,
      headers: p([
        {
          "anthropic-beta": [...t ?? [], "message-batches-2024-09-24"].toString(),
          ...s != null ? { "anthropic-user-profile-id": s } : void 0,
          ...i != null ? { "anthropic-workspace-id": i } : void 0
        },
        e?.headers
      ]),
      __span: u(this._client, "anthropic.messages.batches.create", e, {
        route: "/v1/messages/batches",
        // A request without `requests` is for the API to refuse, not for this line to throw on.
        attributes: { "anthropic.message.batch.request_count": a.requests?.length },
        createdIDAttribute: "anthropic.message.batch.id"
      })
    });
  }
  /**
   * This endpoint is idempotent and can be used to poll for Message Batch
   * completion. To access the results of a Message Batch, make a request to the
   * `results_url` field in the response.
   *
   * Learn more about the Message Batches API in our
   * [user guide](https://platform.claude.com/docs/en/build-with-claude/batch-processing)
   *
   * @example
   * ```ts
   * const betaMessageBatch =
   *   await client.beta.messages.batches.retrieve(
   *     'message_batch_id',
   *   );
   * ```
   */
  retrieve(n, e = {}, t) {
    const { betas: s, workspace_id: i } = e ?? {};
    return this._client.get(f`/v1/messages/batches/${n}?beta=true`, {
      ...t,
      headers: p([
        {
          "anthropic-beta": [...s ?? [], "message-batches-2024-09-24"].toString(),
          ...i != null ? { "anthropic-workspace-id": i } : void 0
        },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.messages.batches.retrieve", t, {
        route: "/v1/messages/batches/{message_batch_id}",
        attributes: { "anthropic.message.batch.id": n }
      })
    });
  }
  /**
   * List all Message Batches within a Workspace. Most recently created batches are
   * returned first.
   *
   * Learn more about the Message Batches API in our
   * [user guide](https://platform.claude.com/docs/en/build-with-claude/batch-processing)
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaMessageBatch of client.beta.messages.batches.list()) {
   *   // ...
   * }
   * ```
   */
  list(n = {}, e) {
    const { betas: t, workspace_id: s, ...i } = n ?? {};
    return this._client.getAPIList("/v1/messages/batches?beta=true", Y, {
      query: i,
      ...e,
      headers: p([
        {
          "anthropic-beta": [...t ?? [], "message-batches-2024-09-24"].toString(),
          ...s != null ? { "anthropic-workspace-id": s } : void 0
        },
        e?.headers
      ]),
      __span: u(this._client, "anthropic.messages.batches.list", e, {
        route: "/v1/messages/batches",
        queryParams: ["after_id", "before_id", "limit"]
      })
    });
  }
  /**
   * Delete a Message Batch.
   *
   * Message Batches can only be deleted once they've finished processing. If you'd
   * like to delete an in-progress batch, you must first cancel it.
   *
   * Learn more about the Message Batches API in our
   * [user guide](https://platform.claude.com/docs/en/build-with-claude/batch-processing)
   *
   * @example
   * ```ts
   * const betaDeletedMessageBatch =
   *   await client.beta.messages.batches.delete(
   *     'message_batch_id',
   *   );
   * ```
   */
  delete(n, e = {}, t) {
    const { betas: s, workspace_id: i } = e ?? {};
    return this._client.delete(f`/v1/messages/batches/${n}?beta=true`, {
      ...t,
      headers: p([
        {
          "anthropic-beta": [...s ?? [], "message-batches-2024-09-24"].toString(),
          ...i != null ? { "anthropic-workspace-id": i } : void 0
        },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.messages.batches.delete", t, {
        route: "/v1/messages/batches/{message_batch_id}",
        attributes: { "anthropic.message.batch.id": n }
      })
    });
  }
  /**
   * Batches may be canceled any time before processing ends. Once cancellation is
   * initiated, the batch enters a `canceling` state, at which time the system may
   * complete any in-progress, non-interruptible requests before finalizing
   * cancellation.
   *
   * The number of canceled requests is specified in `request_counts`. To determine
   * which requests were canceled, check the individual results within the batch.
   * Note that cancellation may not result in any canceled requests if they were
   * non-interruptible.
   *
   * Learn more about the Message Batches API in our
   * [user guide](https://platform.claude.com/docs/en/build-with-claude/batch-processing)
   *
   * @example
   * ```ts
   * const betaMessageBatch =
   *   await client.beta.messages.batches.cancel(
   *     'message_batch_id',
   *   );
   * ```
   */
  cancel(n, e = {}, t) {
    const { betas: s, workspace_id: i } = e ?? {};
    return this._client.post(f`/v1/messages/batches/${n}/cancel?beta=true`, {
      ...t,
      headers: p([
        {
          "anthropic-beta": [...s ?? [], "message-batches-2024-09-24"].toString(),
          ...i != null ? { "anthropic-workspace-id": i } : void 0
        },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.messages.batches.cancel", t, {
        route: "/v1/messages/batches/{message_batch_id}/cancel",
        attributes: { "anthropic.message.batch.id": n }
      })
    });
  }
  /**
   * Streams the results of a Message Batch as a `.jsonl` file.
   *
   * Each line in the file is a JSON object containing the result of a single request
   * in the Message Batch. Results are not guaranteed to be in the same order as
   * requests. Use the `custom_id` field to match results to requests.
   *
   * Learn more about the Message Batches API in our
   * [user guide](https://platform.claude.com/docs/en/build-with-claude/batch-processing)
   *
   * @example
   * ```ts
   * const stream = await client.beta.messages.batches.results(
   *   'message_batch_id',
   * );
   * for await (const betaMessageBatchIndividualResponse of stream) {
   *   // ...
   * }
   * ```
   */
  async results(n, e = {}, t) {
    const s = await this.retrieve(n, e, t);
    if (!s.results_url)
      throw new R(`No batch \`results_url\`; Has it finished processing? ${s.processing_status} - ${s.id}`);
    const { betas: i, workspace_id: a } = e ?? {};
    return this._client.get(s.results_url, {
      ...t,
      headers: p([
        {
          "anthropic-beta": [...i ?? [], "message-batches-2024-09-24"].toString(),
          Accept: "application/binary",
          ...a != null ? { "anthropic-workspace-id": a } : void 0
        },
        t?.headers
      ]),
      stream: !0,
      __binaryResponse: !0,
      __span: u(this._client, "anthropic.messages.batches.results", t, {
        route: "/v1/messages/batches/{message_batch_id}/results",
        attributes: { "anthropic.message.batch.id": n }
      })
    })._thenUnwrap((o, l) => ku.fromResponse(l.response, l.controller));
  }
}
function Cu(r) {
  return r?.output_format ?? r?.output_config?.format;
}
function ja(r, n, e) {
  const t = Cu(n);
  return !n || !("parse" in (t ?? {})) ? {
    ...r,
    content: r.content.map((s) => {
      if (s.type === "text") {
        const i = Object.defineProperty({ ...s }, "parsed_output", {
          value: null,
          enumerable: !1
        });
        return Object.defineProperty(i, "parsed", {
          get() {
            return e.logger.warn("The `parsed` property on `text` blocks is deprecated, please use `parsed_output` instead."), null;
          },
          enumerable: !1
        });
      }
      return s;
    }),
    parsed_output: null
  } : $u(r, n, e);
}
function $u(r, n, e) {
  let t = null;
  const s = r.content.map((i) => {
    if (i.type === "text") {
      const a = Zf(n, i.text);
      t === null && (t = a);
      const o = Object.defineProperty({ ...i }, "parsed_output", {
        value: a,
        enumerable: !1
      });
      return Object.defineProperty(o, "parsed", {
        get() {
          return e.logger.warn("The `parsed` property on `text` blocks is deprecated, please use `parsed_output` instead."), a;
        },
        enumerable: !1
      });
    }
    return i;
  });
  return {
    ...r,
    content: s,
    parsed_output: t
  };
}
function Zf(r, n) {
  const e = Cu(r);
  if (e?.type !== "json_schema")
    return null;
  try {
    return "parse" in e ? e.parse(n) : JSON.parse(n);
  } catch (t) {
    throw new R(`Failed to parse structured output: ${t}`);
  }
}
function Iu(r, n) {
  const { betas: e, user_profile_id: t, workspace_id: s, tools: i, messages: a } = r;
  return p([
    {
      ...e?.toString() != null ? { "anthropic-beta": e?.toString() } : void 0,
      ...t != null ? { "anthropic-user-profile-id": t } : void 0,
      ...s != null ? { "anthropic-workspace-id": s } : void 0
    },
    ou(i, a),
    n?.headers
  ]);
}
function eg(r, n, e) {
  if (!r._tracer)
    return;
  const t = Iu(n, e);
  return u(r, "anthropic.messages.create", e, Xr(r, { ...ti(n), stream: !0 }, t));
}
function ti(r) {
  if (!r.output_format)
    return r;
  if (r.output_config?.format)
    throw new R("Both output_format and output_config.format were provided. Please use only output_config.format (output_format is deprecated).");
  const { output_format: n, ...e } = r;
  return {
    ...e,
    output_config: {
      ...r.output_config,
      format: n
    }
  };
}
var ee, Ue, ve, dn, lr, hn, _n, ur, pn, ke, fn, dr, hr, et, _r, pr, fr, gn, tt, te, Ss, Ha, mn, Ts, As, xs, Da, Es;
function Rs(r) {
  return r.type === "tool_use" || r.type === "server_tool_use" || r.type === "mcp_tool_use";
}
var Nu = /* @__PURE__ */ (() => {
  class r {
    constructor(e, t) {
      ee.add(this), this.messages = [], this.receivedMessages = [], Ue.set(this, void 0), ve.set(this, null), this.controller = new AbortController(), dn.set(this, void 0), lr.set(this, () => {
      }), hn.set(this, () => {
      }), _n.set(this, void 0), ur.set(this, () => {
      }), pn.set(this, () => {
      }), ke.set(this, {}), fn.set(this, !1), dr.set(this, !1), hr.set(this, !1), et.set(this, !1), _r.set(this, void 0), pr.set(this, void 0), fr.set(this, void 0), gn.set(this, void 0), tt.set(this, void 0), te.set(this, void 0), mn.set(this, (s) => {
        if (y(this, dr, !0), c(this, te, "f") && (c(this, te, "f").streamed = void 0), dt(s) && (s = new ue()), s instanceof ue)
          return y(this, hr, !0), this._emit("abort", s);
        if (s instanceof R)
          return this._emit("error", s);
        if (s instanceof Error) {
          const i = new R(s.message);
          return i.cause = s, this._emit("error", i);
        }
        return this._emit("error", new R(String(s)));
      }), y(this, dn, new Promise((s, i) => {
        y(this, lr, s, "f"), y(this, hn, i, "f");
      })), y(this, _n, new Promise((s, i) => {
        y(this, ur, s, "f"), y(this, pn, i, "f");
      })), c(this, dn, "f").catch(() => {
      }), c(this, _n, "f").catch(() => {
      }), y(this, ve, e), y(this, gn, t?.logger ?? console), y(this, tt, t?.client);
    }
    get response() {
      return c(this, _r, "f");
    }
    get request_id() {
      return c(this, pr, "f");
    }
    get workspace_id() {
      return c(this, fr, "f");
    }
    /**
     * Returns the `MessageStream` data, the raw `Response` instance and the ID of the request,
     * returned vie the `request-id` header which is useful for debugging requests and resporting
     * issues to Anthropic.
     *
     * This is the same as the `APIPromise.withResponse()` method.
     *
     * This method will raise an error if you created the stream using `MessageStream.fromReadableStream`
     * as no `Response` is available.
     */
    async withResponse() {
      y(this, et, !0);
      const e = await c(this, dn, "f");
      if (!e)
        throw new Error("Could not resolve a `Response` object");
      return {
        data: this,
        response: e,
        request_id: e.headers.get("request-id"),
        workspace_id: e.headers.get("anthropic-workspace-id")
      };
    }
    /**
     * Intended for use on the frontend, consuming a stream produced with
     * `.toReadableStream()` on the backend.
     *
     * Note that messages sent to the model do not appear in `.on('message')`
     * in this context.
     */
    static fromReadableStream(e) {
      const t = new r(null);
      return t._run(() => t._fromReadableStream(e)), t;
    }
    static createMessage(e, t, s, { logger: i, client: a } = {}) {
      const o = new r(t, {
        logger: i,
        client: a
      });
      for (const l of t.messages)
        o._addMessageParam(l);
      return y(o, ve, { ...t, stream: !0 }), o._run(() => o._createMessage(e, { ...t, stream: !0 }, { ...s, headers: { ...s?.headers, [Ti]: "stream" } })), o;
    }
    _run(e) {
      e().then(() => {
        this._emitFinal(), this._emit("end");
      }, c(this, mn, "f"));
    }
    _addMessageParam(e) {
      this.messages.push(e);
    }
    _addMessage(e, t = !0) {
      this.receivedMessages.push(e), t && this._emit("message", e);
    }
    async _createMessage(e, t, s) {
      const i = s?.signal;
      let a;
      i && (i.aborted && this.controller.abort(), a = this.controller.abort.bind(this.controller), i.addEventListener("abort", a));
      try {
        c(this, ee, "m", Ts).call(this), y(this, te, s?.__span ?? (c(this, tt, "f") && eg(c(this, tt, "f"), t, s)), "f");
        const { response: o, data: l } = await e.create({ ...t, stream: !0 }, { ...s, __span: c(this, te, "f"), signal: this.controller.signal }).withResponse();
        try {
          this._connected(o);
        } catch (h) {
          throw c(this, te, "f") && (c(this, te, "f").failure = h), l.controller.abort(), h;
        }
        for await (const h of l)
          try {
            c(this, ee, "m", As).call(this, h);
          } catch (_) {
            throw c(this, te, "f") && (c(this, te, "f").failure = _), _;
          }
        if (l.controller.signal?.aborted)
          throw new ue();
        c(this, ee, "m", xs).call(this);
      } finally {
        i && a && i.removeEventListener("abort", a);
      }
    }
    _connected(e) {
      this.ended || (y(this, _r, e), y(this, pr, e?.headers.get("request-id")), y(this, fr, e?.headers.get("anthropic-workspace-id")), c(this, lr, "f").call(this, e), this._emit("connect"));
    }
    get ended() {
      return c(this, fn, "f");
    }
    get errored() {
      return c(this, dr, "f");
    }
    get aborted() {
      return c(this, hr, "f");
    }
    abort() {
      this.controller.abort();
    }
    /**
     * Adds the listener function to the end of the listeners array for the event.
     * No checks are made to see if the listener has already been added. Multiple calls passing
     * the same combination of event and listener will result in the listener being added, and
     * called, multiple times.
     * @returns this MessageStream, so that calls can be chained
     */
    on(e, t) {
      return (c(this, ke, "f")[e] || (c(this, ke, "f")[e] = [])).push({ listener: t }), this;
    }
    /**
     * Removes the specified listener from the listener array for the event.
     * off() will remove, at most, one instance of a listener from the listener array. If any single
     * listener has been added multiple times to the listener array for the specified event, then
     * off() must be called multiple times to remove each instance.
     * @returns this MessageStream, so that calls can be chained
     */
    off(e, t) {
      const s = c(this, ke, "f")[e];
      if (!s)
        return this;
      const i = s.findIndex((a) => a.listener === t);
      return i >= 0 && s.splice(i, 1), this;
    }
    /**
     * Adds a one-time listener function for the event. The next time the event is triggered,
     * this listener is removed and then invoked.
     * @returns this MessageStream, so that calls can be chained
     */
    once(e, t) {
      return (c(this, ke, "f")[e] || (c(this, ke, "f")[e] = [])).push({ listener: t, once: !0 }), this;
    }
    /**
     * This is similar to `.once()`, but returns a Promise that resolves the next time
     * the event is triggered, instead of calling a listener callback.
     * @returns a Promise that resolves the next time given event is triggered,
     * or rejects if an error is emitted.  (If you request the 'error' event,
     * returns a promise that resolves with the error).
     *
     * Example:
     *
     *   const message = await stream.emitted('message') // rejects if the stream errors
     */
    emitted(e) {
      return new Promise((t, s) => {
        y(this, et, !0), e !== "error" && this.once("error", s), this.once(e, t);
      });
    }
    async done() {
      y(this, et, !0), await c(this, _n, "f");
    }
    get currentMessage() {
      return c(this, Ue, "f");
    }
    /**
     * @returns a promise that resolves with the the final assistant Message response,
     * or rejects if an error occurred or the stream ended prematurely without producing a Message.
     * If structured outputs were used, this will be a ParsedMessage with a `parsed` field.
     */
    async finalMessage() {
      return await this.done(), c(this, ee, "m", Ss).call(this);
    }
    /**
     * @returns a promise that resolves with the the final assistant Message's text response, concatenated
     * together if there are more than one text blocks.
     * Rejects if an error occurred or the stream ended prematurely without producing a Message.
     */
    async finalText() {
      return await this.done(), c(this, ee, "m", Ha).call(this);
    }
    _emit(e, ...t) {
      if (c(this, fn, "f"))
        return;
      e === "end" && (y(this, fn, !0), c(this, ur, "f").call(this));
      const s = c(this, ke, "f")[e];
      if (s && (c(this, ke, "f")[e] = s.filter((i) => !i.once), s.forEach(({ listener: i }) => i(...t))), e === "abort") {
        const i = t[0];
        !c(this, et, "f") && !s?.length && Promise.reject(i), c(this, hn, "f").call(this, i), c(this, pn, "f").call(this, i), this._emit("end");
        return;
      }
      if (e === "error") {
        const i = t[0];
        !c(this, et, "f") && !s?.length && Promise.reject(i), c(this, hn, "f").call(this, i), c(this, pn, "f").call(this, i), this._emit("end");
      }
    }
    _emitFinal() {
      this.receivedMessages.at(-1) && this._emit("finalMessage", c(this, ee, "m", Ss).call(this));
    }
    /** @internal A method so that the tool runner's stream can act before and after an event's listeners. */
    _deliverEvent(e, t) {
      this._emit("_rawEvent", e), t && this._emit("streamEvent", e, t);
    }
    async _fromReadableStream(e, t) {
      const s = t?.signal;
      let i;
      s && (s.aborted && this.controller.abort(), i = this.controller.abort.bind(this.controller), s.addEventListener("abort", i));
      try {
        c(this, ee, "m", Ts).call(this), this._connected(null);
        const a = Oe.fromReadableStream(e, this.controller);
        for await (const o of a)
          c(this, ee, "m", As).call(this, o);
        if (a.controller.signal?.aborted)
          throw new ue();
        c(this, ee, "m", xs).call(this);
      } finally {
        s && i && s.removeEventListener("abort", i);
      }
    }
    [(Ue = /* @__PURE__ */ new WeakMap(), ve = /* @__PURE__ */ new WeakMap(), dn = /* @__PURE__ */ new WeakMap(), lr = /* @__PURE__ */ new WeakMap(), hn = /* @__PURE__ */ new WeakMap(), _n = /* @__PURE__ */ new WeakMap(), ur = /* @__PURE__ */ new WeakMap(), pn = /* @__PURE__ */ new WeakMap(), ke = /* @__PURE__ */ new WeakMap(), fn = /* @__PURE__ */ new WeakMap(), dr = /* @__PURE__ */ new WeakMap(), hr = /* @__PURE__ */ new WeakMap(), et = /* @__PURE__ */ new WeakMap(), _r = /* @__PURE__ */ new WeakMap(), pr = /* @__PURE__ */ new WeakMap(), fr = /* @__PURE__ */ new WeakMap(), gn = /* @__PURE__ */ new WeakMap(), tt = /* @__PURE__ */ new WeakMap(), te = /* @__PURE__ */ new WeakMap(), mn = /* @__PURE__ */ new WeakMap(), ee = /* @__PURE__ */ new WeakSet(), Ss = function() {
      if (this.receivedMessages.length === 0)
        throw new R("stream ended without producing a Message with role=assistant");
      return this.receivedMessages.at(-1);
    }, Ha = function() {
      if (this.receivedMessages.length === 0)
        throw new R("stream ended without producing a Message with role=assistant");
      const t = this.receivedMessages.at(-1).content.filter((s) => s.type === "text").map((s) => s.text);
      if (t.length === 0)
        throw new R("stream ended without producing a content block with type=text");
      return t.join(" ");
    }, Ts = function() {
      this.ended || y(this, Ue, void 0);
    }, As = function(t) {
      if (this.ended)
        return;
      const s = c(this, ee, "m", Da).call(this, t);
      if (this._deliverEvent(t, s), !!s)
        switch (t.type) {
          case "content_block_delta": {
            const i = s.content.at(-1);
            switch (t.delta.type) {
              case "text_delta": {
                i.type === "text" && this._emit("text", t.delta.text, i.text || "");
                break;
              }
              case "citations_delta": {
                i.type === "text" && this._emit("citation", t.delta.citation, i.citations ?? []);
                break;
              }
              case "input_json_delta": {
                if (Rs(i) && c(this, ke, "f").inputJson?.length) {
                  let a;
                  try {
                    a = i.input;
                  } catch (o) {
                    c(this, mn, "f").call(this, c(this, ee, "m", Es).call(this, i, o));
                    break;
                  }
                  this._emit("inputJson", t.delta.partial_json, a);
                }
                break;
              }
              case "thinking_delta": {
                i.type === "thinking" && this._emit("thinking", t.delta.thinking, i.thinking);
                break;
              }
              case "signature_delta": {
                i.type === "thinking" && this._emit("signature", i.signature);
                break;
              }
              case "compaction_delta": {
                i.type === "compaction" && i.content && this._emit("compaction", i.content);
                break;
              }
              default:
                t.delta;
            }
            break;
          }
          case "message_stop": {
            c(this, tt, "f") && c(this, te, "f") && c(this, ve, "f") && Si(c(this, tt, "f"), c(this, te, "f"), c(this, ve, "f"), s), this._addMessageParam(s), this._addMessage(ja(s, c(this, ve, "f"), { logger: c(this, gn, "f") }), !0);
            break;
          }
          case "content_block_stop": {
            this._emit("contentBlock", s.content.at(-1));
            break;
          }
          case "message_start": {
            y(this, Ue, s), c(this, te, "f") && c(this, ve, "f") && (c(this, te, "f").streamed = { body: c(this, ve, "f"), message: s });
            break;
          }
        }
    }, xs = function() {
      if (this.ended)
        throw new R("stream has ended, this shouldn't happen");
      const t = c(this, Ue, "f");
      if (!t)
        throw new R("request ended without sending any chunks");
      return y(this, Ue, void 0), ja(t, c(this, ve, "f"), { logger: c(this, gn, "f") });
    }, Da = function(t) {
      let s = c(this, Ue, "f");
      if (t.type === "message_start") {
        if (s)
          throw new R(`Unexpected event order, got ${t.type} before receiving "message_stop"`);
        return t.message;
      }
      if (s)
        switch (t.type) {
          case "message_stop":
            return s;
          case "message_delta":
            return s.stop_reason = t.delta.stop_reason, s.stop_sequence = t.delta.stop_sequence, s.stop_details = t.delta.stop_details, s.usage.output_tokens = t.usage.output_tokens, t.delta.container != null && (s.container = t.delta.container), t.context_management != null && (s.context_management = t.context_management), t.input_transformations != null && (s.input_transformations = t.input_transformations), t.usage.input_tokens != null && (s.usage.input_tokens = t.usage.input_tokens), t.usage.cache_creation_input_tokens != null && (s.usage.cache_creation_input_tokens = t.usage.cache_creation_input_tokens), t.usage.cache_read_input_tokens != null && (s.usage.cache_read_input_tokens = t.usage.cache_read_input_tokens), t.usage.server_tool_use != null && (s.usage.server_tool_use = t.usage.server_tool_use), t.usage.iterations != null && (s.usage.iterations = t.usage.iterations), t.usage.fallback_credit != null && (s.usage.fallback_credit = t.usage.fallback_credit), t.usage.output_tokens_details != null && (s.usage.output_tokens_details = t.usage.output_tokens_details), s;
          case "content_block_start":
            return s.content.push(t.content_block), t.content_block.type === "fallback" && (s.model = t.content_block.to.model), s;
          case "content_block_delta": {
            const i = s.content.at(t.index);
            switch (t.delta.type) {
              case "text_delta": {
                i?.type === "text" && (s.content[t.index] = {
                  ...i,
                  text: (i.text || "") + t.delta.text
                });
                break;
              }
              case "citations_delta": {
                i?.type === "text" && (s.content[t.index] = {
                  ...i,
                  citations: [...i.citations ?? [], t.delta.citation]
                });
                break;
              }
              case "input_json_delta": {
                if (i && Rs(i)) {
                  const a = (i[$t] || "") + t.delta.partial_json;
                  s.content[t.index] = vu(i, a);
                }
                break;
              }
              case "thinking_delta": {
                i?.type === "thinking" && (s.content[t.index] = {
                  ...i,
                  thinking: i.thinking + t.delta.thinking
                });
                break;
              }
              case "signature_delta": {
                i?.type === "thinking" && (s.content[t.index] = {
                  ...i,
                  signature: t.delta.signature
                });
                break;
              }
              case "compaction_delta": {
                if (i?.type === "compaction") {
                  const a = { ...i, content: t.delta.content };
                  "encrypted_content" in t.delta && (a.encrypted_content = t.delta.encrypted_content), s.content[t.index] = a;
                }
                break;
              }
              default:
                t.delta;
            }
            return s;
          }
          case "content_block_stop": {
            const i = s.content.at(t.index);
            if (i && Rs(i) && $t in i) {
              let a;
              try {
                a = i.input;
              } catch (o) {
                a = {}, c(this, mn, "f").call(this, c(this, ee, "m", Es).call(this, i, o));
              }
              Object.defineProperty(i, "input", {
                value: a,
                enumerable: !0,
                configurable: !0,
                writable: !0
              });
            }
            return s;
          }
          default:
            return s;
        }
    }, Es = function(t, s) {
      const i = t[$t];
      return new R(`Unable to parse tool parameter JSON from model. Please retry your request or adjust your prompt. Error: ${s}. JSON: ${i}`);
    }, Symbol.asyncIterator)]() {
      const e = [], t = [];
      let s = !1;
      return this.on("_rawEvent", (i) => {
        const a = t.shift();
        a ? a.resolve(i) : e.push(i);
      }), this.on("end", () => {
        s = !0;
        for (const i of t)
          i.resolve(void 0);
        t.length = 0;
      }), this.on("abort", (i) => {
        s = !0;
        for (const a of t)
          a.reject(i);
        t.length = 0;
      }), this.on("error", (i) => {
        s = !0;
        for (const a of t)
          a.reject(i);
        t.length = 0;
      }), {
        next: async () => e.length ? { value: e.shift(), done: !1 } : s ? { value: void 0, done: !0 } : new Promise((a, o) => t.push({ resolve: a, reject: o })).then((a) => a ? { value: a, done: !1 } : { value: void 0, done: !0 }),
        return: async () => (this.abort(), { value: void 0, done: !0 })
      };
    }
    toReadableStream() {
      return new Oe(this[Symbol.asyncIterator].bind(this), this.controller).toReadableStream();
    }
  }
  return r;
})();
const Lu = {
  browser_toolset_20260801: "browser",
  computer_toolset_20260801: "computer"
};
function Ft(r) {
  return Lu[r.type];
}
function Mn(r) {
  return "run" in r && r.type != null && Object.prototype.hasOwnProperty.call(Lu, r.type);
}
class qu extends R {
  constructor(n, e) {
    super(n), this.name = "ToolsetUsageError", e && "cause" in e && (this.cause = e.cause);
  }
}
class Cr extends qu {
  constructor(n, e) {
    super(n, e), this.name = "ToolsetContractError";
  }
}
const Bu = "Not executed: an earlier action in this turn failed.", Ka = {
  browser: Bu,
  computer: "Not executed: an earlier computer action in this turn failed."
};
function tg(r) {
  return Object.prototype.hasOwnProperty.call(Ka, r) ? Ka[r] : Bu;
}
function Hr(r, n, e = !1) {
  return e && (n === "" || Array.isArray(n) && n.length === 0) && (n = "The tool call failed with an empty error message."), {
    type: "tool_result",
    tool_use_id: r.id,
    toolset_name: r.toolset_name ?? null,
    content: n,
    ...e ? { is_error: !0 } : {}
  };
}
function ng(r, n) {
  if (r instanceof qu)
    throw r;
  rg(n.signal);
}
function rg(r) {
  if (r?.aborted)
    throw new ue();
}
async function sg(r, n, e = {}) {
  const t = Ft(r);
  if (n.toolset_name !== t)
    throw new Cr(`tool_use ${JSON.stringify(n.id)} (toolset_name=${JSON.stringify(n.toolset_name ?? null)}, name=${JSON.stringify(n.name)}) is not a member call of the ${JSON.stringify(t)} toolset`);
  const s = { ...e, toolUse: n, toolUseBlock: n };
  try {
    return Hr(n, await r.run(s, n));
  } catch (i) {
    return ng(i, s), Hr(n, Mf(i instanceof Pi ? i.content : zf(i)), !0);
  }
}
let Ga = class extends T {
  /**
   * Get API Key
   *
   * @example
   * ```ts
   * const betaAPIKey =
   *   await client.beta.organization.apiKeys.retrieve(
   *     'api_key_id',
   *   );
   * ```
   */
  retrieve(n, e) {
    return this._client.get(f`/v1/organizations/api_keys/${n}?beta=true`, {
      ...e,
      __span: u(this._client, "anthropic.organization.api_keys.retrieve", e, {
        route: "/v1/organizations/api_keys/{api_key_id}",
        attributes: { "anthropic.organization.api_key.id": n }
      })
    });
  }
  /**
   * Update API Key
   *
   * @example
   * ```ts
   * const betaAPIKey =
   *   await client.beta.organization.apiKeys.update(
   *     'api_key_id',
   *   );
   * ```
   */
  update(n, e, t) {
    return this._client.post(f`/v1/organizations/api_keys/${n}?beta=true`, {
      body: e,
      ...t,
      __span: u(this._client, "anthropic.organization.api_keys.update", t, {
        route: "/v1/organizations/api_keys/{api_key_id}",
        attributes: { "anthropic.organization.api_key.id": n }
      })
    });
  }
  /**
   * List API Keys
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaAPIKey of client.beta.organization.apiKeys.list()) {
   *   // ...
   * }
   * ```
   */
  list(n = {}, e) {
    return this._client.getAPIList("/v1/organizations/api_keys?beta=true", Y, {
      query: n,
      ...e,
      __span: u(this._client, "anthropic.organization.api_keys.list", e, {
        route: "/v1/organizations/api_keys",
        queryParams: ["after_id", "before_id", "created_by_user_id", "limit", "status", "workspace_id"]
      })
    });
  }
};
class Va extends T {
  /**
   * Get artifact-creation activity for a given day, broken out by MIME type.
   *
   * Returns the full (`artifact_type`, `is_shared`) cube for the organization;
   * `next_page` is null except for grouped queries, which paginate. The cube can be
   * broken out per product, per member, or per RBAC group via `group_by[]`, and
   * scoped via `filter[]`. Requires an API key with the `read:analytics` scope.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaAnalyticsArtifactActivity of client.beta.organization.analytics.artifacts.list(
   *   { date: '2019-12-27' },
   * )) {
   *   // ...
   * }
   * ```
   */
  list(n, e) {
    return this._client.getAPIList("/v1/organizations/analytics/artifacts?beta=true", P, {
      query: n,
      ...e,
      __span: u(this._client, "anthropic.organization.analytics.artifacts.list", e, {
        route: "/v1/organizations/analytics/artifacts",
        queryParams: ["date", "filter", "group_by", "limit", "page"]
      })
    });
  }
}
class Ja extends T {
  /**
   * Get per-connector usage for a given day, with cursor-based pagination.
   *
   * Returns connector usage metrics for the organization, sorted by connector name.
   * Connector names are normalized from their various sources — for example,
   * "Atlassian MCP server" and "mcp-atlassian" both appear as "atlassian". Use
   * `group_by[]` to break usage out per member, per RBAC group, or per product
   * surface, and `filter[]` to scope results; the parameter descriptions list the
   * supported dimensions. Available to organizations on a Claude Enterprise plan.
   * Requires an API key with the `read:analytics` scope.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaAnalyticsConnectorActivity of client.beta.organization.analytics.connectors.list()) {
   *   // ...
   * }
   * ```
   */
  list(n = {}, e) {
    return this._client.getAPIList("/v1/organizations/analytics/connectors?beta=true", P, {
      query: n,
      ...e,
      __span: u(this._client, "anthropic.organization.analytics.connectors.list", e, {
        route: "/v1/organizations/analytics/connectors",
        queryParams: [
          "date",
          "ending_date",
          "filter",
          "group_by",
          "limit",
          "order",
          "order_by",
          "page",
          "starting_date"
        ],
        contentQueryParams: ["filter"]
      })
    });
  }
}
class Ya extends T {
  /**
   * Get cost in USD over time across a date range.
   *
   * Returns cost bucketed by minute, hour, or day, optionally broken down by
   * product, model, context window, inference region, speed, cost type, or token
   * type. Available to organizations on a Claude Enterprise plan. Requires an API
   * key with the `read:analytics` scope.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaAnalyticsCostReportTimeBucket of client.beta.organization.analytics.costReport.list(
   *   { starting_at: '2019-12-27T18:11:19.117Z' },
   * )) {
   *   // ...
   * }
   * ```
   */
  list(n, e) {
    return this._client.getAPIList("/v1/organizations/analytics/cost_report?beta=true", Zr, {
      query: n,
      ...e,
      __span: u(this._client, "anthropic.organization.analytics.cost_report.list", e, {
        route: "/v1/organizations/analytics/cost_report",
        queryParams: [
          "bucket_width",
          "claude_tag_categories",
          "claude_tag_user_ids",
          "context_windows",
          "ending_at",
          "group_by",
          "inference_geos",
          "limit",
          "models",
          "page",
          "products",
          "rbac_group_ids",
          "slack_channel_ids",
          "speeds",
          "starting_at",
          "user_ids"
        ]
      })
    });
  }
}
let Xa = class extends T {
  /**
   * Get per-plugin install + invocation usage for a given day, with pagination.
   *
   * Returns plugin usage metrics for the organization across Cowork and Claude Code,
   * sorted by plugin name. The `plugin_name` value `third-party` is an aggregate
   * bucket, not a plugin: it collects plugin activity, from either surface, for
   * which the reporting client did not provide a plugin name — so an organization's
   * own plugins can contribute both to their own named rows and to this bucket. Use
   * `group_by[]` to break usage out per member, per RBAC group, or per product
   * surface (Cowork / Claude Code), and `filter[]` to scope results; the parameter
   * descriptions list the supported dimensions. Requires an API key with the
   * `read:analytics` scope. `starting_date` / `ending_date` select range-rollup mode
   * like `/skills`.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaAnalyticsPluginActivity of client.beta.organization.analytics.plugins.list()) {
   *   // ...
   * }
   * ```
   */
  list(n = {}, e) {
    return this._client.getAPIList("/v1/organizations/analytics/plugins?beta=true", P, {
      query: n,
      ...e,
      __span: u(this._client, "anthropic.organization.analytics.plugins.list", e, {
        route: "/v1/organizations/analytics/plugins",
        queryParams: [
          "date",
          "ending_date",
          "filter",
          "group_by",
          "limit",
          "order",
          "order_by",
          "page",
          "starting_date"
        ],
        contentQueryParams: ["filter"]
      })
    });
  }
}, Qa = class extends T {
  /**
   * Get per-skill usage for a given day, with cursor-based pagination.
   *
   * Returns skill usage metrics for the organization, sorted by skill name. Use
   * `group_by[]` to break usage out per member, per RBAC group, or per product
   * surface, and `filter[]` to scope results; the parameter descriptions list the
   * supported dimensions. Available to organizations on a Claude Enterprise plan.
   * Requires an API key with the `read:analytics` scope.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaAnalyticsSkillActivity of client.beta.organization.analytics.skills.list()) {
   *   // ...
   * }
   * ```
   */
  list(n = {}, e) {
    return this._client.getAPIList("/v1/organizations/analytics/skills?beta=true", P, {
      query: n,
      ...e,
      __span: u(this._client, "anthropic.organization.analytics.skills.list", e, {
        route: "/v1/organizations/analytics/skills",
        queryParams: [
          "date",
          "ending_date",
          "filter",
          "group_by",
          "limit",
          "order",
          "order_by",
          "page",
          "starting_date"
        ],
        contentQueryParams: ["filter"]
      })
    });
  }
};
class Za extends T {
  /**
   * Get organization-wide activity summaries for a date range.
   *
   * Returns one entry per day from `starting_date` (inclusive) to `ending_date`
   * (exclusive) in `data`, the same `data` / `next_page` envelope as the other
   * analytics list endpoints; the series is currently returned in full, so
   * `next_page` is always null. Data is typically available with a 1-day lag and may
   * be revised by a few percent over the following days: when `ending_date` is
   * omitted it defaults to the most recent available day + 1, so the last entry
   * covers the most recent available day. The series can be scoped to an RBAC group
   * via `filter[]=rbac_group_id:{id}`. Available to organizations on a Claude
   * Enterprise plan. Requires an API key with the `read:analytics` scope.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaAnalyticsSingleDayActivitySummary of client.beta.organization.analytics.summaries.list(
   *   { starting_date: '2019-12-27' },
   * )) {
   *   // ...
   * }
   * ```
   */
  list(n, e) {
    return this._client.getAPIList("/v1/organizations/analytics/summaries?beta=true", P, {
      query: n,
      ...e,
      __span: u(this._client, "anthropic.organization.analytics.summaries.list", e, {
        route: "/v1/organizations/analytics/summaries",
        queryParams: ["ending_date", "filter", "limit", "page", "starting_date"]
      })
    });
  }
}
class eo extends T {
  /**
   * Get token usage over time across a date range.
   *
   * Returns token usage bucketed by minute, hour, or day, optionally broken down by
   * product, model, context window, inference region, or speed. Available to
   * organizations on a Claude Enterprise plan. Requires an API key with the
   * `read:analytics` scope.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaAnalyticsUsageReportTimeBucket of client.beta.organization.analytics.usageReport.list(
   *   { starting_at: '2019-12-27T18:11:19.117Z' },
   * )) {
   *   // ...
   * }
   * ```
   */
  list(n, e) {
    return this._client.getAPIList("/v1/organizations/analytics/usage_report?beta=true", Zr, {
      query: n,
      ...e,
      __span: u(this._client, "anthropic.organization.analytics.usage_report.list", e, {
        route: "/v1/organizations/analytics/usage_report",
        queryParams: [
          "bucket_width",
          "claude_tag_categories",
          "claude_tag_user_ids",
          "context_windows",
          "ending_at",
          "group_by",
          "inference_geos",
          "limit",
          "models",
          "page",
          "products",
          "rbac_group_ids",
          "slack_channel_ids",
          "speeds",
          "starting_at",
          "user_ids"
        ]
      })
    });
  }
}
class to extends T {
  /**
   * Get per-user cost in USD across a date range.
   *
   * Returns one row per user, ranked by spend. Use this to see which users account
   * for the most cost. Only cost attributable to a seat user is included; for
   * organization-wide totals including direct API-key and automation traffic, use
   * the bucketed `/v1/organizations/analytics/cost_report` endpoint. Available to
   * organizations on a Claude Enterprise plan. Requires an API key with the
   * `read:analytics` scope.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaAnalyticsCostUsersItem of client.beta.organization.analytics.userCostReport.list(
   *   { starting_at: '2019-12-27T18:11:19.117Z' },
   * )) {
   *   // ...
   * }
   * ```
   */
  list(n, e) {
    return this._client.getAPIList("/v1/organizations/analytics/user_cost_report?beta=true", Zr, {
      query: n,
      ...e,
      __span: u(this._client, "anthropic.organization.analytics.user_cost_report.list", e, {
        route: "/v1/organizations/analytics/user_cost_report",
        queryParams: [
          "bucket_width",
          "claude_tag_categories",
          "claude_tag_user_ids",
          "context_windows",
          "ending_at",
          "exclude_deleted_users",
          "group_by",
          "inference_geos",
          "limit",
          "models",
          "order",
          "order_by",
          "page",
          "products",
          "rbac_group_ids",
          "slack_channel_ids",
          "speeds",
          "starting_at",
          "user_ids"
        ]
      })
    });
  }
}
class no extends T {
  /**
   * Get per-user token usage across a date range.
   *
   * Returns one row per user, ranked by the chosen token metric. Use this to see
   * which users consume the most tokens. Only usage attributable to a seat user is
   * included; for organization-wide totals including direct API-key and automation
   * traffic, use the bucketed `/v1/organizations/analytics/usage_report` endpoint.
   * Available to organizations on a Claude Enterprise plan. Requires an API key with
   * the `read:analytics` scope.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaAnalyticsUsageUsersItem of client.beta.organization.analytics.userUsageReport.list(
   *   { starting_at: '2019-12-27T18:11:19.117Z' },
   * )) {
   *   // ...
   * }
   * ```
   */
  list(n, e) {
    return this._client.getAPIList("/v1/organizations/analytics/user_usage_report?beta=true", Zr, {
      query: n,
      ...e,
      __span: u(this._client, "anthropic.organization.analytics.user_usage_report.list", e, {
        route: "/v1/organizations/analytics/user_usage_report",
        queryParams: [
          "bucket_width",
          "claude_tag_categories",
          "claude_tag_user_ids",
          "context_windows",
          "ending_at",
          "exclude_deleted_users",
          "group_by",
          "inference_geos",
          "limit",
          "models",
          "order",
          "order_by",
          "page",
          "products",
          "rbac_group_ids",
          "slack_channel_ids",
          "speeds",
          "starting_at",
          "user_ids"
        ]
      })
    });
  }
}
let ro = class extends T {
  /**
   * Get per-user activity for a given day, with cursor-based pagination.
   *
   * Returns activity metrics for each user in the organization, sorted by email
   * address. Use `group_by[]` for per-RBAC-group aggregates, or `filter[]` to scope
   * results to specific members, groups, or a chat project. Available to
   * organizations on a Claude Enterprise plan. Requires an API key with the
   * `read:analytics` scope.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaAnalyticsUserActivity of client.beta.organization.analytics.users.list()) {
   *   // ...
   * }
   * ```
   */
  list(n = {}, e) {
    return this._client.getAPIList("/v1/organizations/analytics/users?beta=true", P, {
      query: n,
      ...e,
      __span: u(this._client, "anthropic.organization.analytics.users.list", e, {
        route: "/v1/organizations/analytics/users",
        queryParams: [
          "date",
          "ending_date",
          "filter",
          "group_by",
          "limit",
          "order",
          "order_by",
          "page",
          "starting_date"
        ],
        contentQueryParams: ["page"]
      })
    });
  }
};
class so extends T {
  /**
   * Get per-project activity for a given day, with cursor-based pagination.
   *
   * Returns activity metrics for each project in the organization, sorted by project
   * ID. Use `group_by[]` to break projects out per member or per RBAC group, and
   * `filter[]` to scope results; the parameter descriptions list the supported
   * dimensions. Available to organizations on a Claude Enterprise plan. Requires an
   * API key with the `read:analytics` scope.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaAnalyticsProjectActivity of client.beta.organization.analytics.apps.chat.projects.list()) {
   *   // ...
   * }
   * ```
   */
  list(n = {}, e) {
    return this._client.getAPIList("/v1/organizations/analytics/apps/chat/projects?beta=true", P, {
      query: n,
      ...e,
      __span: u(this._client, "anthropic.organization.analytics.apps.chat.projects.list", e, {
        route: "/v1/organizations/analytics/apps/chat/projects",
        queryParams: [
          "date",
          "ending_date",
          "filter",
          "group_by",
          "limit",
          "order",
          "order_by",
          "page",
          "starting_date"
        ]
      })
    });
  }
}
var io = /* @__PURE__ */ (() => {
  class r extends T {
    constructor() {
      super(...arguments), this.projects = new so(this._client);
    }
  }
  return r.Projects = so, r;
})(), ao = /* @__PURE__ */ (() => {
  class r extends T {
    constructor() {
      super(...arguments), this.chat = new io(this._client);
    }
  }
  return r.Chat = io, r;
})(), oo = /* @__PURE__ */ (() => {
  class r extends T {
    constructor() {
      super(...arguments), this.summaries = new Za(this._client), this.users = new ro(this._client), this.apps = new ao(this._client), this.connectors = new Ja(this._client), this.plugins = new Xa(this._client), this.skills = new Qa(this._client), this.artifacts = new Va(this._client), this.usageReport = new eo(this._client), this.userUsageReport = new no(this._client), this.costReport = new Ya(this._client), this.userCostReport = new to(this._client);
    }
  }
  return r.Summaries = Za, r.Users = ro, r.Apps = ao, r.Connectors = Ja, r.Plugins = Xa, r.Skills = Qa, r.Artifacts = Va, r.UsageReport = eo, r.UserUsageReport = no, r.CostReport = Ya, r.UserCostReport = to, r;
})();
let co = class extends T {
  /**
   * Retrieve your organization's Compliance Settings.
   *
   * Compliance Settings is a singleton resource: there is exactly one per
   * organization, addressed without an identifier. The `state` field reflects
   * whether the Compliance API is enabled. An organization with a parent
   * organization reads the state inherited from the parent's configuration.
   *
   * @example
   * ```ts
   * const betaComplianceSettings =
   *   await client.beta.organization.complianceSettings.retrieve();
   * ```
   */
  retrieve(n) {
    return this._client.get("/v1/organizations/compliance_settings?beta=true", {
      ...n,
      __span: u(this._client, "anthropic.organization.compliance_settings.retrieve", n, {
        route: "/v1/organizations/compliance_settings"
      })
    });
  }
  /**
   * Update your organization's Compliance Settings.
   *
   * Setting `state` to `enabled` turns on the Compliance API and begins capturing
   * organization activity events. Setting it to `disabled` turns both off. `state`
   * reflects whether the Compliance API is enabled.
   *
   * A request that sets `state` to its current value succeeds and leaves the
   * resource unchanged. A `disabled` request stays in effect until a later `enabled`
   * request or the organization's next provisioning action that enables Access
   * Transparency: enabling Access Transparency also enables the Compliance API,
   * which serves its activity events, so such provisioning (including re-runs)
   * re-enables the Compliance API even after a `disabled` request. Automated
   * provisioning never disables compliance settings.
   *
   * @example
   * ```ts
   * const betaComplianceSettings =
   *   await client.beta.organization.complianceSettings.update({
   *     state: { type: 'enabled' },
   *   });
   * ```
   */
  update(n, e) {
    return this._client.post("/v1/organizations/compliance_settings?beta=true", {
      body: n,
      ...e,
      __span: u(this._client, "anthropic.organization.compliance_settings.update", e, {
        route: "/v1/organizations/compliance_settings"
      })
    });
  }
}, lo = class extends T {
  /**
   * Create an external key config owned by the caller's organization.
   *
   * @example
   * ```ts
   * const betaExternalKey =
   *   await client.beta.organization.externalKeys.create({
   *     provider_config: {
   *       kms_arn:
   *         'arn:aws:kms:us-east-1:111122223333:key/abcd1234-5678-90ab-cdef-000011112222',
   *       type: 'aws',
   *     },
   *   });
   * ```
   */
  create(n, e) {
    return this._client.post("/v1/organizations/external_keys?beta=true", {
      body: n,
      ...e,
      __span: u(this._client, "anthropic.organization.external_keys.create", e, {
        route: "/v1/organizations/external_keys",
        createdIDAttribute: "anthropic.organization.external_key.id"
      })
    });
  }
  /**
   * Retrieve a single external key config in the caller's organization by ID.
   *
   * @example
   * ```ts
   * const betaExternalKey =
   *   await client.beta.organization.externalKeys.retrieve(
   *     'external_key_id',
   *   );
   * ```
   */
  retrieve(n, e) {
    return this._client.get(f`/v1/organizations/external_keys/${n}?beta=true`, {
      ...e,
      __span: u(this._client, "anthropic.organization.external_keys.retrieve", e, {
        route: "/v1/organizations/external_keys/{external_key_id}",
        attributes: { "anthropic.organization.external_key.id": n }
      })
    });
  }
  /**
   * Partially update an external key config. Omitted fields are left unchanged.
   *
   * `display_name` is always editable. `geo` and `provider_config` cannot be changed
   * once any workspace references this config, because previously encrypted data
   * requires the original key identity to decrypt.
   *
   * @example
   * ```ts
   * const betaExternalKey =
   *   await client.beta.organization.externalKeys.update(
   *     'external_key_id',
   *   );
   * ```
   */
  update(n, e, t) {
    return this._client.post(f`/v1/organizations/external_keys/${n}?beta=true`, {
      body: e,
      ...t,
      __span: u(this._client, "anthropic.organization.external_keys.update", t, {
        route: "/v1/organizations/external_keys/{external_key_id}",
        attributes: { "anthropic.organization.external_key.id": n }
      })
    });
  }
  /**
   * List external key configs in the caller's organization.
   *
   * Results are ordered by creation time (newest first). Use the `next_page` cursor
   * from the response to fetch subsequent pages.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaExternalKey of client.beta.organization.externalKeys.list()) {
   *   // ...
   * }
   * ```
   */
  list(n = {}, e) {
    return this._client.getAPIList("/v1/organizations/external_keys?beta=true", P, {
      query: n,
      ...e,
      __span: u(this._client, "anthropic.organization.external_keys.list", e, {
        route: "/v1/organizations/external_keys",
        queryParams: ["limit", "page"]
      })
    });
  }
  /**
   * Delete an external key config.
   *
   * The request is rejected if any workspace still references this config.
   *
   * @example
   * ```ts
   * const externalKey =
   *   await client.beta.organization.externalKeys.delete(
   *     'external_key_id',
   *   );
   * ```
   */
  delete(n, e) {
    return this._client.delete(f`/v1/organizations/external_keys/${n}?beta=true`, {
      ...e,
      __span: u(this._client, "anthropic.organization.external_keys.delete", e, {
        route: "/v1/organizations/external_keys/{external_key_id}",
        attributes: { "anthropic.organization.external_key.id": n }
      })
    });
  }
  /**
   * Validate an external key config against the customer's KMS.
   *
   * Anthropic performs an encrypt/decrypt roundtrip against the configured KMS key
   * and waits up to 30 seconds for the result. The response status is `success` if
   * the roundtrip succeeded, or `failure` with an error message if it failed or
   * timed out.
   *
   * @example
   * ```ts
   * const response =
   *   await client.beta.organization.externalKeys.validate(
   *     'external_key_id',
   *   );
   * ```
   */
  validate(n, e) {
    return this._client.post(f`/v1/organizations/external_keys/${n}/validate?beta=true`, {
      ...e,
      __span: u(this._client, "anthropic.organization.external_keys.validate", e, {
        route: "/v1/organizations/external_keys/{external_key_id}/validate",
        attributes: { "anthropic.organization.external_key.id": n }
      })
    });
  }
}, uo = class extends T {
  /**
   * **Requires an OAuth access token with the `org:admin` scope**, from
   * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
   * API keys are not accepted. See
   * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
   *
   * Register an OIDC issuer that Anthropic will trust for workload identity
   * federation in your organization.
   *
   * The `jwks` field controls how the issuer's signing keys are obtained and takes
   * one of three shapes selected by `type`: `discovery` (resolve keys through OIDC
   * discovery), `explicit_url` (fetch keys from a fixed JWKS URL), or `inline`
   * (provide a static key set). When `jwks.type` is `discovery` and no
   * `discovery_base` is set, the issuer URL must be publicly reachable over HTTPS so
   * Anthropic can fetch the discovery document; for `explicit_url` and `inline`
   * modes the issuer URL is only matched as the JWT's `iss` claim and is not
   * fetched.
   *
   * @example
   * ```ts
   * const betaFederationIssuer =
   *   await client.beta.organization.federation.issuers.create({
   *     issuer_url: 'x',
   *     name: 'x',
   *   });
   * ```
   */
  create(n, e) {
    const { betas: t, ...s } = n;
    return this._client.post("/v1/organizations/federation_issuers?beta=true", {
      body: s,
      ...e,
      headers: p([
        { ...t?.toString() != null ? { "anthropic-beta": t?.toString() } : void 0 },
        e?.headers
      ]),
      __span: u(this._client, "anthropic.organization.federation.issuers.create", e, {
        route: "/v1/organizations/federation_issuers",
        createdIDAttribute: "anthropic.organization.federation_issuer.id"
      })
    });
  }
  /**
   * **Requires an OAuth access token with the `org:admin` scope**, from
   * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
   * API keys are not accepted. See
   * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
   *
   * Retrieve a federation issuer by its ID (`fdis_...`).
   *
   * @example
   * ```ts
   * const betaFederationIssuer =
   *   await client.beta.organization.federation.issuers.retrieve(
   *     'federation_issuer_id',
   *   );
   * ```
   */
  retrieve(n, e = {}, t) {
    const { betas: s } = e ?? {};
    return this._client.get(f`/v1/organizations/federation_issuers/${n}?beta=true`, {
      ...t,
      headers: p([
        { ...s?.toString() != null ? { "anthropic-beta": s?.toString() } : void 0 },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.organization.federation.issuers.retrieve", t, {
        route: "/v1/organizations/federation_issuers/{federation_issuer_id}",
        attributes: { "anthropic.organization.federation_issuer.id": n }
      })
    });
  }
  /**
   * **Requires an OAuth access token with the `org:admin` scope**, from
   * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
   * API keys are not accepted. See
   * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
   *
   * Partially update a federation issuer.
   *
   * Setting `jwks` replaces the full JWKS shape at once. Archived issuers cannot be
   * updated; this returns 400. Create a new issuer instead.
   *
   * Updating an issuer that backs a rule with a scope outside `workspace:developer`
   * or `workspace:inference` requires a Console session.
   *
   * @example
   * ```ts
   * const betaFederationIssuer =
   *   await client.beta.organization.federation.issuers.update(
   *     'federation_issuer_id',
   *   );
   * ```
   */
  update(n, e, t) {
    const { betas: s, ...i } = e;
    return this._client.post(f`/v1/organizations/federation_issuers/${n}?beta=true`, {
      body: i,
      ...t,
      headers: p([
        { ...s?.toString() != null ? { "anthropic-beta": s?.toString() } : void 0 },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.organization.federation.issuers.update", t, {
        route: "/v1/organizations/federation_issuers/{federation_issuer_id}",
        attributes: { "anthropic.organization.federation_issuer.id": n }
      })
    });
  }
  /**
   * **Requires an OAuth access token with the `org:admin` scope**, from
   * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
   * API keys are not accepted. See
   * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
   *
   * List federation issuers in your organization.
   *
   * Archived issuers are excluded unless `include_archived=true`.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaFederationIssuer of client.beta.organization.federation.issuers.list()) {
   *   // ...
   * }
   * ```
   */
  list(n = {}, e) {
    const { betas: t, ...s } = n ?? {};
    return this._client.getAPIList("/v1/organizations/federation_issuers?beta=true", P, {
      query: s,
      ...e,
      headers: p([
        { ...t?.toString() != null ? { "anthropic-beta": t?.toString() } : void 0 },
        e?.headers
      ]),
      __span: u(this._client, "anthropic.organization.federation.issuers.list", e, {
        route: "/v1/organizations/federation_issuers",
        queryParams: ["include_archived", "limit", "page"]
      })
    });
  }
  /**
   * **Requires an OAuth access token with the `org:admin` scope**, from
   * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
   * API keys are not accepted. See
   * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
   *
   * Archive a federation issuer.
   *
   * Idempotent; re-archiving returns the issuer with its original `archived_at`.
   * Rejected with 400 if any live (non-archived) federation rule still references
   * the issuer; archive those rules first (a rule's issuer cannot be changed), or
   * recreate them against another issuer.
   *
   * @example
   * ```ts
   * const betaFederationIssuer =
   *   await client.beta.organization.federation.issuers.archive(
   *     'federation_issuer_id',
   *   );
   * ```
   */
  archive(n, e = {}, t) {
    const { betas: s } = e ?? {};
    return this._client.post(f`/v1/organizations/federation_issuers/${n}/archive?beta=true`, {
      ...t,
      headers: p([
        { ...s?.toString() != null ? { "anthropic-beta": s?.toString() } : void 0 },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.organization.federation.issuers.archive", t, {
        route: "/v1/organizations/federation_issuers/{federation_issuer_id}/archive",
        attributes: { "anthropic.organization.federation_issuer.id": n }
      })
    });
  }
}, ho = class extends T {
  /**
   * **Requires an OAuth access token with the `org:admin` scope**, from
   * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
   * API keys are not accepted. See
   * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
   *
   * List workspaces where this federation rule is enabled.
   *
   * Returns all workspace enablements in a single response; the `limit` and `page`
   * parameters are accepted but have no effect, and `next_page` is always `null`.
   * Returns explicit per-workspace enablements only; for rules with
   * `applies_to_all_workspaces` or a legacy single `workspace_id`, check those
   * fields on the rule itself.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaFederationRuleWorkspace of client.beta.organization.federation.rules.workspaces.list(
   *   'federation_rule_id',
   * )) {
   *   // ...
   * }
   * ```
   */
  list(n, e = {}, t) {
    const { betas: s, ...i } = e ?? {};
    return this._client.getAPIList(f`/v1/organizations/federation_rules/${n}/workspaces?beta=true`, P, {
      query: i,
      ...t,
      headers: p([
        { ...s?.toString() != null ? { "anthropic-beta": s?.toString() } : void 0 },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.organization.federation.rules.workspaces.list", t, {
        route: "/v1/organizations/federation_rules/{federation_rule_id}/workspaces",
        queryParams: ["limit", "page"],
        attributes: { "anthropic.organization.federation_rule.id": n }
      })
    });
  }
  /**
   * **Requires an OAuth access token with the `org:admin` scope**, from
   * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
   * API keys are not accepted. See
   * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
   *
   * Enable a federation rule for a workspace.
   *
   * Idempotent; re-enabling returns the existing enablement. The rule and workspace
   * must both belong to your organization. Membership of the rule's target service
   * account in this workspace is not checked at enablement: token exchange into this
   * workspace is rejected unless the target is a member (it is implicitly a member
   * of the default workspace). Archived rules are rejected with 400. OAuth callers
   * may only manage rules whose `oauth_scope` is `workspace:developer` or
   * `workspace:inference`; other scopes require a Console session.
   *
   * @example
   * ```ts
   * const betaFederationRuleWorkspace =
   *   await client.beta.organization.federation.rules.workspaces.add(
   *     'federation_rule_id',
   *     { workspace_id: 'workspace_id' },
   *   );
   * ```
   */
  add(n, e, t) {
    const { betas: s, ...i } = e;
    return this._client.post(f`/v1/organizations/federation_rules/${n}/workspaces?beta=true`, {
      body: i,
      ...t,
      headers: p([
        { ...s?.toString() != null ? { "anthropic-beta": s?.toString() } : void 0 },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.organization.federation.rules.workspaces.add", t, {
        route: "/v1/organizations/federation_rules/{federation_rule_id}/workspaces",
        attributes: { "anthropic.organization.federation_rule.id": n },
        createdIDAttribute: "anthropic.organization.federation_rule.workspace.id",
        createdIDField: "workspace_id"
      })
    });
  }
  /**
   * **Requires an OAuth access token with the `org:admin` scope**, from
   * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
   * API keys are not accepted. See
   * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
   *
   * Disable a federation rule for a workspace.
   *
   * Idempotent; succeeds even if the enablement was already removed. OAuth callers
   * may only manage rules whose `oauth_scope` is `workspace:developer` or
   * `workspace:inference`; other scopes require a Console session.
   *
   * @example
   * ```ts
   * const workspace =
   *   await client.beta.organization.federation.rules.workspaces.remove(
   *     'workspace_id',
   *     { federation_rule_id: 'federation_rule_id' },
   *   );
   * ```
   */
  remove(n, e, t) {
    const { federation_rule_id: s, betas: i } = e;
    return this._client.delete(f`/v1/organizations/federation_rules/${s}/workspaces/${n}?beta=true`, {
      ...t,
      headers: p([
        { ...i?.toString() != null ? { "anthropic-beta": i?.toString() } : void 0 },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.organization.federation.rules.workspaces.remove", t, {
        route: "/v1/organizations/federation_rules/{federation_rule_id}/workspaces/{workspace_id}",
        attributes: {
          "anthropic.organization.federation_rule.id": s,
          "anthropic.organization.federation_rule.workspace.id": n
        }
      })
    });
  }
};
var _o = /* @__PURE__ */ (() => {
  class r extends T {
    constructor() {
      super(...arguments), this.workspaces = new ho(this._client);
    }
    /**
     * **Requires an OAuth access token with the `org:admin` scope**, from
     * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
     * API keys are not accepted. See
     * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
     *
     * Create a federation rule owned by your organization.
     *
     * The referenced issuer and the target service account must already exist in the
     * same organization; invalid references are rejected with a 400 error. The
     * workspace reference is validated. Membership is not checked at rule creation:
     * token exchange resolves a single enabled workspace per call and is rejected
     * unless the target service account is a member of that workspace (it is
     * implicitly a member of the default workspace). Rules on well-known shared
     * issuers (GitHub Actions, GitLab, Buildkite, Terraform Cloud, Google) must
     * constrain tenant identity via an identity-bearing claim, a tenant-pinning
     * subject prefix (such as `repo:YOUR_ORG/...`), or a CEL condition referencing one
     * of those identity claims (e.g. `claims.repository_owner`). OAuth callers may
     * only manage rules whose `oauth_scope` is `workspace:developer` or
     * `workspace:inference`; other scopes require a Console session.
     *
     * @example
     * ```ts
     * const betaFederationRule =
     *   await client.beta.organization.federation.rules.create({
     *     issuer_id: 'issuer_id',
     *     match: {},
     *     name: 'x',
     *     oauth_scope: 'x',
     *     target: {
     *       service_account_id: 'svac_01SDCCSbTxrXDpWc1phhtcfK',
     *       type: 'service_account',
     *     },
     *   });
     * ```
     */
    create(e, t) {
      const { betas: s, ...i } = e;
      return this._client.post("/v1/organizations/federation_rules?beta=true", {
        body: i,
        ...t,
        headers: p([
          { ...s?.toString() != null ? { "anthropic-beta": s?.toString() } : void 0 },
          t?.headers
        ]),
        __span: u(this._client, "anthropic.organization.federation.rules.create", t, {
          route: "/v1/organizations/federation_rules",
          createdIDAttribute: "anthropic.organization.federation_rule.id"
        })
      });
    }
    /**
     * **Requires an OAuth access token with the `org:admin` scope**, from
     * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
     * API keys are not accepted. See
     * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
     *
     * Retrieve a federation rule by its ID (`fdrl_...`).
     *
     * @example
     * ```ts
     * const betaFederationRule =
     *   await client.beta.organization.federation.rules.retrieve(
     *     'federation_rule_id',
     *   );
     * ```
     */
    retrieve(e, t = {}, s) {
      const { betas: i } = t ?? {};
      return this._client.get(f`/v1/organizations/federation_rules/${e}?beta=true`, {
        ...s,
        headers: p([
          { ...i?.toString() != null ? { "anthropic-beta": i?.toString() } : void 0 },
          s?.headers
        ]),
        __span: u(this._client, "anthropic.organization.federation.rules.retrieve", s, {
          route: "/v1/organizations/federation_rules/{federation_rule_id}",
          attributes: { "anthropic.organization.federation_rule.id": e }
        })
      });
    }
    /**
     * **Requires an OAuth access token with the `org:admin` scope**, from
     * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
     * API keys are not accepted. See
     * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
     *
     * Partially update a federation rule.
     *
     * `issuer_id` is immutable. `match` and `target` are replaced as whole objects
     * when set. Referenced service accounts and workspaces must exist in your
     * organization; invalid references are rejected with a 400 error. Archived rules
     * cannot be updated; this returns 400. Create a new rule instead. Rules on
     * well-known shared issuers (GitHub Actions, GitLab, Buildkite, Terraform Cloud,
     * Google) must constrain tenant identity via an identity-bearing claim, a
     * tenant-pinning subject prefix (such as `repo:YOUR_ORG/...`), or a CEL condition
     * referencing one of those identity claims (e.g. `claims.repository_owner`). On
     * these issuers the requirement is re-checked on every update; if an existing
     * rule's stored match does not yet constrain tenant identity, any update (even a
     * rename or description change) must also supply a conforming `match` in the same
     * request. OAuth callers may only manage rules whose `oauth_scope` is
     * `workspace:developer` or `workspace:inference`; other scopes require a Console
     * session.
     *
     * @example
     * ```ts
     * const betaFederationRule =
     *   await client.beta.organization.federation.rules.update(
     *     'federation_rule_id',
     *   );
     * ```
     */
    update(e, t, s) {
      const { betas: i, ...a } = t;
      return this._client.post(f`/v1/organizations/federation_rules/${e}?beta=true`, {
        body: a,
        ...s,
        headers: p([
          { ...i?.toString() != null ? { "anthropic-beta": i?.toString() } : void 0 },
          s?.headers
        ]),
        __span: u(this._client, "anthropic.organization.federation.rules.update", s, {
          route: "/v1/organizations/federation_rules/{federation_rule_id}",
          attributes: { "anthropic.organization.federation_rule.id": e }
        })
      });
    }
    /**
     * **Requires an OAuth access token with the `org:admin` scope**, from
     * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
     * API keys are not accepted. See
     * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
     *
     * List federation rules in your organization.
     *
     * Optionally filter by issuer with `issuer_id`. Archived rules are excluded unless
     * `include_archived=true`.
     *
     * @example
     * ```ts
     * // Automatically fetches more pages as needed.
     * for await (const betaFederationRule of client.beta.organization.federation.rules.list()) {
     *   // ...
     * }
     * ```
     */
    list(e = {}, t) {
      const { betas: s, ...i } = e ?? {};
      return this._client.getAPIList("/v1/organizations/federation_rules?beta=true", P, {
        query: i,
        ...t,
        headers: p([
          { ...s?.toString() != null ? { "anthropic-beta": s?.toString() } : void 0 },
          t?.headers
        ]),
        __span: u(this._client, "anthropic.organization.federation.rules.list", t, {
          route: "/v1/organizations/federation_rules",
          queryParams: ["include_archived", "issuer_id", "limit", "page"]
        })
      });
    }
    /**
     * **Requires an OAuth access token with the `org:admin` scope**, from
     * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
     * API keys are not accepted. See
     * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
     *
     * Archive a federation rule.
     *
     * Token exchange through this rule stops immediately. Idempotent; re-archiving
     * returns the rule with its original `archived_at`. Archiving clears the rule's
     * workspace targeting (`workspace_id` and `workspace_ids` are emptied). Tokens
     * already minted before archive remain valid until they expire. OAuth callers may
     * only manage rules whose `oauth_scope` is `workspace:developer` or
     * `workspace:inference`; other scopes require a Console session.
     *
     * @example
     * ```ts
     * const betaFederationRule =
     *   await client.beta.organization.federation.rules.archive(
     *     'federation_rule_id',
     *   );
     * ```
     */
    archive(e, t = {}, s) {
      const { betas: i } = t ?? {};
      return this._client.post(f`/v1/organizations/federation_rules/${e}/archive?beta=true`, {
        ...s,
        headers: p([
          { ...i?.toString() != null ? { "anthropic-beta": i?.toString() } : void 0 },
          s?.headers
        ]),
        __span: u(this._client, "anthropic.organization.federation.rules.archive", s, {
          route: "/v1/organizations/federation_rules/{federation_rule_id}/archive",
          attributes: { "anthropic.organization.federation_rule.id": e }
        })
      });
    }
  }
  return r.Workspaces = ho, r;
})(), po = /* @__PURE__ */ (() => {
  class r extends T {
    constructor() {
      super(...arguments), this.issuers = new uo(this._client), this.rules = new _o(this._client);
    }
  }
  return r.Issuers = uo, r.Rules = _o, r;
})();
let fo = class extends T {
  /**
   * Invite a user to join the organization by email.
   *
   * On plans that draw members from a finite pool of purchased seats, the invite
   * automatically consumes a seat from the lowest tier with availability; there is
   * no seat-tier parameter. When no seat is free the request fails with a 400 error
   * rather than purchasing a seat.
   *
   * @example
   * ```ts
   * const betaOrganizationInvite =
   *   await client.beta.organization.invites.create({
   *     email: 'user@emaildomain.com',
   *     role: 'user',
   *   });
   * ```
   */
  create(n, e) {
    return this._client.post("/v1/organizations/invites?beta=true", {
      body: n,
      ...e,
      __span: u(this._client, "anthropic.organization.invites.create", e, {
        route: "/v1/organizations/invites",
        createdIDAttribute: "anthropic.organization.invite.id"
      })
    });
  }
  /**
   * Retrieve an invite by ID.
   *
   * @example
   * ```ts
   * const betaOrganizationInvite =
   *   await client.beta.organization.invites.retrieve(
   *     'invite_id',
   *   );
   * ```
   */
  retrieve(n, e) {
    return this._client.get(f`/v1/organizations/invites/${n}?beta=true`, {
      ...e,
      __span: u(this._client, "anthropic.organization.invites.retrieve", e, {
        route: "/v1/organizations/invites/{invite_id}",
        attributes: { "anthropic.organization.invite.id": n }
      })
    });
  }
  /**
   * List the organization's invites.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaOrganizationInvite of client.beta.organization.invites.list()) {
   *   // ...
   * }
   * ```
   */
  list(n = {}, e) {
    return this._client.getAPIList("/v1/organizations/invites?beta=true", Y, {
      query: n,
      ...e,
      __span: u(this._client, "anthropic.organization.invites.list", e, {
        route: "/v1/organizations/invites",
        queryParams: ["after_id", "before_id", "email", "limit", "roles", "statuses"]
      })
    });
  }
  /**
   * Delete a pending invite.
   *
   * @example
   * ```ts
   * const invite =
   *   await client.beta.organization.invites.delete(
   *     'invite_id',
   *   );
   * ```
   */
  delete(n, e) {
    return this._client.delete(f`/v1/organizations/invites/${n}?beta=true`, {
      ...e,
      __span: u(this._client, "anthropic.organization.invites.delete", e, {
        route: "/v1/organizations/invites/{invite_id}",
        attributes: { "anthropic.organization.invite.id": n }
      })
    });
  }
};
class go extends T {
  /**
   * Retrieve a plugin marketplace by ID.
   *
   * **Accepted credentials:** an Admin API key with the `read:plugins` or
   * `read:org_audit` scope, or a Compliance Access Key with the
   * `read:compliance_org_data` scope.
   *
   * Every request must include the beta header
   * `anthropic-beta: ce-plugins-2026-09-01`. A request without it returns `404`,
   * exactly as if the endpoint did not exist. The Plugins API is in beta and is
   * available to Claude Enterprise organizations only. It is not available to Claude
   * Platform (Claude Console) organizations, or to organizations with HIPAA
   * readiness enabled.
   *
   * @example
   * ```ts
   * const betaPluginMarketplace =
   *   await client.beta.organization.pluginMarketplaces.retrieve(
   *     'marketplace_id',
   *   );
   * ```
   */
  retrieve(n, e = {}, t) {
    const { betas: s, ...i } = e ?? {};
    return this._client.get(f`/v1/organizations/plugin_marketplaces/${n}?beta=true`, {
      query: i,
      ...t,
      headers: p([
        { "anthropic-beta": [...s ?? [], "ce-plugins-2026-09-01"].toString() },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.organization.plugin_marketplaces.retrieve", t, {
        route: "/v1/organizations/plugin_marketplaces/{marketplace_id}",
        queryParams: ["organization_id"],
        attributes: { "anthropic.organization.plugin_marketplace.id": n }
      })
    });
  }
  /**
   * Set the default installation setting of one of the organization's own plugin
   * marketplaces. Every Plugin in it without a setting of its own gets this default
   * as its organization-wide setting, including Plugins added later.
   *
   * Pass it as `default_installation_preference`. A member's personal marketplace
   * cannot be updated here (403).
   *
   * **Accepted credentials:** an Admin API key with the `write:plugins` scope.
   *
   * Every request must include the beta header
   * `anthropic-beta: ce-plugins-2026-09-01`. A request without it returns `404`,
   * exactly as if the endpoint did not exist. The Plugins API is in beta and is
   * available to Claude Enterprise organizations only. It is not available to Claude
   * Platform (Claude Console) organizations, or to organizations with HIPAA
   * readiness enabled.
   *
   * @example
   * ```ts
   * const betaPluginMarketplace =
   *   await client.beta.organization.pluginMarketplaces.update(
   *     'marketplace_id',
   *     { default_installation_preference: 'available' },
   *   );
   * ```
   */
  update(n, e, t) {
    const { betas: s, ...i } = e;
    return this._client.post(f`/v1/organizations/plugin_marketplaces/${n}?beta=true`, {
      body: i,
      ...t,
      headers: p([
        { "anthropic-beta": [...s ?? [], "ce-plugins-2026-09-01"].toString() },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.organization.plugin_marketplaces.update", t, {
        route: "/v1/organizations/plugin_marketplaces/{marketplace_id}",
        attributes: { "anthropic.organization.plugin_marketplace.id": n }
      })
    });
  }
  /**
   * List the plugin marketplaces Plugins live in, newest first: the organization's
   * own and its members' personal ones.
   *
   * Plugin marketplaces are created, connected to a repository and deleted in
   * claude.ai, not through this API. The organization's library marketplace, the
   * organization-owned `manual` marketplace that uploads go to when no marketplace
   * is named, is created the first time something is put in it and is listed from
   * then on.
   *
   * **Accepted credentials:** an Admin API key with the `read:plugins` or
   * `read:org_audit` scope, or a Compliance Access Key with the
   * `read:compliance_org_data` scope.
   *
   * Every request must include the beta header
   * `anthropic-beta: ce-plugins-2026-09-01`. A request without it returns `404`,
   * exactly as if the endpoint did not exist. The Plugins API is in beta and is
   * available to Claude Enterprise organizations only. It is not available to Claude
   * Platform (Claude Console) organizations, or to organizations with HIPAA
   * readiness enabled.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaPluginMarketplace of client.beta.organization.pluginMarketplaces.list()) {
   *   // ...
   * }
   * ```
   */
  list(n = {}, e) {
    const { betas: t, ...s } = n ?? {};
    return this._client.getAPIList("/v1/organizations/plugin_marketplaces?beta=true", P, {
      query: s,
      ...e,
      headers: p([
        { "anthropic-beta": [...t ?? [], "ce-plugins-2026-09-01"].toString() },
        e?.headers
      ]),
      __span: u(this._client, "anthropic.organization.plugin_marketplaces.list", e, {
        route: "/v1/organizations/plugin_marketplaces",
        queryParams: ["limit", "organization_id", "owner_type", "page", "source"]
      })
    });
  }
  /**
   * Check whether a plugin marketplace, uploaded as a `.zip` of the marketplace
   * directory, would synchronize into claude.ai, without connecting or storing it.
   *
   * To check a public GitHub repository instead, use Validate Plugin Marketplace
   * Repository.
   *
   * The report says whether `marketplace.json` is well-formed, which plugins a
   * synchronization would skip and why, and which plugins would synchronize only in
   * part, with some files left out. An archive that cannot be read as a marketplace
   * is reported, not refused: the response is a report with `valid: false`. Plugin
   * sources outside the marketplace are fetched anonymously from GitHub, so a
   * private one is reported as not found; a source on any other host is not fetched
   * here, and the report notes that it will be checked when the marketplace actually
   * synchronizes.
   *
   * Nothing is recorded on the Compliance API activity feed.
   *
   * For a worked example, see
   * [Validate marketplace content](/docs/en/manage-claude/plugins-api#validate-marketplace-content)
   * in the Plugins API guide.
   *
   * **Accepted credentials:** an Admin API key with the `read:plugins` or
   * `write:plugins` scope; `read:org_audit` and `read:compliance_org_data` do not
   * grant it.
   *
   * Every request must include the beta header
   * `anthropic-beta: ce-plugins-2026-09-01`. A request without it returns `404`,
   * exactly as if the endpoint did not exist. The Plugins API is in beta and is
   * available to Claude Enterprise organizations only. It is not available to Claude
   * Platform (Claude Console) organizations, or to organizations with HIPAA
   * readiness enabled.
   *
   * @example
   * ```ts
   * const betaPluginMarketplaceValidationReport =
   *   await client.beta.organization.pluginMarketplaces.validateArchive(
   *     { archive: fs.createReadStream('path/to/file') },
   *   );
   * ```
   */
  validateArchive(n, e) {
    const { betas: t, ...s } = n;
    return this._client.post("/v1/organizations/plugin_marketplaces/validate_archive?beta=true", Ce({
      body: s,
      ...e,
      headers: p([
        { "anthropic-beta": [...t ?? [], "ce-plugins-2026-09-01"].toString() },
        e?.headers
      ]),
      __span: u(this._client, "anthropic.organization.plugin_marketplaces.validate_archive", e, { route: "/v1/organizations/plugin_marketplaces/validate_archive" })
    }, this._client));
  }
  /**
   * Check whether a plugin marketplace held in a public GitHub repository would
   * synchronize into claude.ai, without connecting or storing it.
   *
   * To check a `.zip` of the marketplace directory instead, use Validate Plugin
   * Marketplace Archive.
   *
   * The report says whether `marketplace.json` is well-formed, which plugins a
   * synchronization would skip and why, and which plugins would synchronize only in
   * part, with some files left out. A repository that is missing, private, or has no
   * such branch or commit is reported, not refused: the response is a report with
   * `valid: false`. Plugin sources outside the marketplace are fetched anonymously
   * from GitHub, so a private one is reported as not found; a source on any other
   * host is not fetched here, and the report notes that it will be checked when the
   * marketplace actually synchronizes.
   *
   * Nothing is recorded on the Compliance API activity feed.
   *
   * For a worked example, see
   * [Validate marketplace content](/docs/en/manage-claude/plugins-api#validate-marketplace-content)
   * in the Plugins API guide.
   *
   * **Accepted credentials:** an Admin API key with the `read:plugins` or
   * `write:plugins` scope; `read:org_audit` and `read:compliance_org_data` do not
   * grant it.
   *
   * Every request must include the beta header
   * `anthropic-beta: ce-plugins-2026-09-01`. A request without it returns `404`,
   * exactly as if the endpoint did not exist. The Plugins API is in beta and is
   * available to Claude Enterprise organizations only. It is not available to Claude
   * Platform (Claude Console) organizations, or to organizations with HIPAA
   * readiness enabled.
   *
   * @example
   * ```ts
   * const betaPluginMarketplaceValidationReport =
   *   await client.beta.organization.pluginMarketplaces.validateRepository(
   *     {
   *       repository_url:
   *         'https://github.com/example-org/example-marketplace',
   *     },
   *   );
   * ```
   */
  validateRepository(n, e) {
    const { betas: t, ...s } = n;
    return this._client.post("/v1/organizations/plugin_marketplaces/validate_repository?beta=true", {
      body: s,
      ...e,
      headers: p([
        { "anthropic-beta": [...t ?? [], "ce-plugins-2026-09-01"].toString() },
        e?.headers
      ]),
      __span: u(this._client, "anthropic.organization.plugin_marketplaces.validate_repository", e, { route: "/v1/organizations/plugin_marketplaces/validate_repository" })
    });
  }
}
let mo = class extends T {
  /**
   * List Messages API rate limits for your organization.
   *
   * Each entry corresponds to one rate-limit group (either a model family or an
   * API-surface category such as the Message Batches API or the web search tool) and
   * contains the set of limiter values that apply to it.
   *
   * When `limit` is omitted, every matching entry is returned in a single page; when
   * `limit` truncates the result, follow `next_page` to fetch the remaining entries.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaOrganizationRateLimit of client.beta.organization.rateLimits.list()) {
   *   // ...
   * }
   * ```
   */
  list(n = {}, e) {
    return this._client.getAPIList("/v1/organizations/rate_limits?beta=true", P, {
      query: n,
      ...e,
      __span: u(this._client, "anthropic.organization.rate_limits.list", e, {
        route: "/v1/organizations/rate_limits",
        queryParams: ["group_type", "limit", "model", "page"]
      })
    });
  }
}, bo = class extends T {
  /**
   * Retrieve a member of the organization by user ID.
   *
   * @example
   * ```ts
   * const betaOrganizationUser =
   *   await client.beta.organization.users.retrieve('user_id');
   * ```
   */
  retrieve(n, e) {
    return this._client.get(f`/v1/organizations/users/${n}?beta=true`, {
      ...e,
      __span: u(this._client, "anthropic.organization.users.retrieve", e, {
        route: "/v1/organizations/users/{user_id}",
        attributes: { "anthropic.organization.user.id": n }
      })
    });
  }
  /**
   * Update a member's organization role.
   *
   * @example
   * ```ts
   * const betaOrganizationUser =
   *   await client.beta.organization.users.update('user_id', {
   *     role: 'user',
   *   });
   * ```
   */
  update(n, e, t) {
    return this._client.post(f`/v1/organizations/users/${n}?beta=true`, {
      body: e,
      ...t,
      __span: u(this._client, "anthropic.organization.users.update", t, {
        route: "/v1/organizations/users/{user_id}",
        attributes: { "anthropic.organization.user.id": n }
      })
    });
  }
  /**
   * List the organization's members.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaOrganizationUser of client.beta.organization.users.list()) {
   *   // ...
   * }
   * ```
   */
  list(n = {}, e) {
    return this._client.getAPIList("/v1/organizations/users?beta=true", Y, {
      query: n,
      ...e,
      __span: u(this._client, "anthropic.organization.users.list", e, {
        route: "/v1/organizations/users",
        queryParams: ["after_id", "before_id", "email", "limit", "roles"]
      })
    });
  }
  /**
   * Remove a member from the organization.
   *
   * @example
   * ```ts
   * const user = await client.beta.organization.users.remove(
   *   'user_id',
   * );
   * ```
   */
  remove(n, e) {
    return this._client.delete(f`/v1/organizations/users/${n}?beta=true`, {
      ...e,
      __span: u(this._client, "anthropic.organization.users.remove", e, {
        route: "/v1/organizations/users/{user_id}",
        attributes: { "anthropic.organization.user.id": n }
      })
    });
  }
};
class wo extends T {
  /**
   * Create an organization webhook endpoint.
   *
   * An organization webhook endpoint belongs to the organization rather than to one
   * of its workspaces. An organization can have at most 32 organization webhook
   * endpoints, enabled or disabled.
   *
   * The response includes the endpoint's signing secret. No read returns it, so
   * store it when you receive it.
   *
   * Every request must include the beta header
   * `anthropic-beta: webhooks-2026-10-07`. A request without it returns `404`,
   * exactly as if this API did not exist. Anthropic turns organization webhook
   * endpoints on for each organization; until yours is on, requests also return
   * `404`. Organization webhook endpoints are in beta and are not available to
   * organizations with HIPAA readiness enabled.
   *
   * @example
   * ```ts
   * const betaNewOrganizationWebhookEndpoint =
   *   await client.beta.organization.webhooks.create({
   *     enabled_events: [
   *       'user_profile.enforcement_action_opened',
   *     ],
   *     url: 'x',
   *   });
   * ```
   */
  create(n, e) {
    const { betas: t, ...s } = n;
    return this._client.post("/v1/organizations/webhooks?beta=true", {
      body: s,
      ...e,
      headers: p([
        { "anthropic-beta": [...t ?? [], "webhooks-2026-10-07"].toString() },
        e?.headers
      ]),
      __span: u(this._client, "anthropic.organization.webhooks.create", e, {
        route: "/v1/organizations/webhooks",
        createdIDAttribute: "anthropic.organization.webhook.id"
      })
    });
  }
  /**
   * Retrieve an organization webhook endpoint by ID.
   *
   * Every request must include the beta header
   * `anthropic-beta: webhooks-2026-10-07`. A request without it returns `404`,
   * exactly as if this API did not exist. Anthropic turns organization webhook
   * endpoints on for each organization; until yours is on, requests also return
   * `404`. Organization webhook endpoints are in beta and are not available to
   * organizations with HIPAA readiness enabled.
   *
   * @example
   * ```ts
   * const betaOrganizationWebhookEndpoint =
   *   await client.beta.organization.webhooks.retrieve(
   *     'webhook_endpoint_id',
   *   );
   * ```
   */
  retrieve(n, e = {}, t) {
    const { betas: s } = e ?? {};
    return this._client.get(f`/v1/organizations/webhooks/${n}?beta=true`, {
      ...t,
      headers: p([
        { "anthropic-beta": [...s ?? [], "webhooks-2026-10-07"].toString() },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.organization.webhooks.retrieve", t, {
        route: "/v1/organizations/webhooks/{webhook_endpoint_id}",
        attributes: { "anthropic.organization.webhook.id": n }
      })
    });
  }
  /**
   * Update an organization webhook endpoint. Only the fields you send are changed.
   *
   * Every request must include the beta header
   * `anthropic-beta: webhooks-2026-10-07`. A request without it returns `404`,
   * exactly as if this API did not exist. Anthropic turns organization webhook
   * endpoints on for each organization; until yours is on, requests also return
   * `404`. Organization webhook endpoints are in beta and are not available to
   * organizations with HIPAA readiness enabled.
   *
   * @example
   * ```ts
   * const betaOrganizationWebhookEndpoint =
   *   await client.beta.organization.webhooks.update(
   *     'webhook_endpoint_id',
   *   );
   * ```
   */
  update(n, e, t) {
    const { betas: s, ...i } = e;
    return this._client.post(f`/v1/organizations/webhooks/${n}?beta=true`, {
      body: i,
      ...t,
      headers: p([
        { "anthropic-beta": [...s ?? [], "webhooks-2026-10-07"].toString() },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.organization.webhooks.update", t, {
        route: "/v1/organizations/webhooks/{webhook_endpoint_id}",
        attributes: { "anthropic.organization.webhook.id": n }
      })
    });
  }
  /**
   * List the organization's webhook endpoints.
   *
   * An organization webhook endpoint belongs to the organization rather than to one
   * of its workspaces. The list does not include webhook endpoints that belong to a
   * workspace.
   *
   * Every request must include the beta header
   * `anthropic-beta: webhooks-2026-10-07`. A request without it returns `404`,
   * exactly as if this API did not exist. Anthropic turns organization webhook
   * endpoints on for each organization; until yours is on, requests also return
   * `404`. Organization webhook endpoints are in beta and are not available to
   * organizations with HIPAA readiness enabled.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaOrganizationWebhookEndpoint of client.beta.organization.webhooks.list()) {
   *   // ...
   * }
   * ```
   */
  list(n = {}, e) {
    const { betas: t, ...s } = n ?? {};
    return this._client.getAPIList("/v1/organizations/webhooks?beta=true", Y, {
      query: s,
      ...e,
      headers: p([
        { "anthropic-beta": [...t ?? [], "webhooks-2026-10-07"].toString() },
        e?.headers
      ]),
      __span: u(this._client, "anthropic.organization.webhooks.list", e, {
        route: "/v1/organizations/webhooks",
        queryParams: ["after_id", "before_id", "limit", "order"]
      })
    });
  }
  /**
   * Delete an organization webhook endpoint.
   *
   * Every request must include the beta header
   * `anthropic-beta: webhooks-2026-10-07`. A request without it returns `404`,
   * exactly as if this API did not exist. Anthropic turns organization webhook
   * endpoints on for each organization; until yours is on, requests also return
   * `404`. Organization webhook endpoints are in beta and are not available to
   * organizations with HIPAA readiness enabled.
   *
   * @example
   * ```ts
   * const betaDeletedOrganizationWebhookEndpoint =
   *   await client.beta.organization.webhooks.delete(
   *     'webhook_endpoint_id',
   *   );
   * ```
   */
  delete(n, e = {}, t) {
    const { betas: s } = e ?? {};
    return this._client.delete(f`/v1/organizations/webhooks/${n}?beta=true`, {
      ...t,
      headers: p([
        { "anthropic-beta": [...s ?? [], "webhooks-2026-10-07"].toString() },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.organization.webhooks.delete", t, {
        route: "/v1/organizations/webhooks/{webhook_endpoint_id}",
        attributes: { "anthropic.organization.webhook.id": n }
      })
    });
  }
  /**
   * Replace an organization webhook endpoint's signing secret. The old secret stops
   * working immediately. The new secret is returned only in this response.
   *
   * Every request must include the beta header
   * `anthropic-beta: webhooks-2026-10-07`. A request without it returns `404`,
   * exactly as if this API did not exist. Anthropic turns organization webhook
   * endpoints on for each organization; until yours is on, requests also return
   * `404`. Organization webhook endpoints are in beta and are not available to
   * organizations with HIPAA readiness enabled.
   *
   * @example
   * ```ts
   * const betaOrganizationWebhookEndpointSigningSecret =
   *   await client.beta.organization.webhooks.regenerateSigningSecret(
   *     'webhook_endpoint_id',
   *   );
   * ```
   */
  regenerateSigningSecret(n, e = {}, t) {
    const { betas: s } = e ?? {};
    return this._client.post(f`/v1/organizations/webhooks/${n}/regenerate_signing_secret?beta=true`, {
      ...t,
      headers: p([
        { "anthropic-beta": [...s ?? [], "webhooks-2026-10-07"].toString() },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.organization.webhooks.regenerate_signing_secret", t, {
        route: "/v1/organizations/webhooks/{webhook_endpoint_id}/regenerate_signing_secret",
        attributes: { "anthropic.organization.webhook.id": n }
      })
    });
  }
}
class yo extends T {
  /**
   * List an organization-owned Plugin's installation settings, which say which
   * members it is for, most recently created first.
   *
   * The list holds the Plugin's own organization-wide setting (absent while the
   * Plugin inherits its marketplace's default) and each RBAC Group's own setting. A
   * member-owned Plugin has shares instead, so this path returns 404 for one.
   *
   * **Accepted credentials:** an Admin API key with the `read:plugins` or
   * `read:org_audit` scope, or a Compliance Access Key with the
   * `read:compliance_org_data` scope.
   *
   * Every request must include the beta header
   * `anthropic-beta: ce-plugins-2026-09-01`. A request without it returns `404`,
   * exactly as if the endpoint did not exist. The Plugins API is in beta and is
   * available to Claude Enterprise organizations only. It is not available to Claude
   * Platform (Claude Console) organizations, or to organizations with HIPAA
   * readiness enabled.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaPluginInstallationSetting of client.beta.organization.plugins.installationSettings.list(
   *   'plugin_id',
   * )) {
   *   // ...
   * }
   * ```
   */
  list(n, e = {}, t) {
    const { betas: s, ...i } = e ?? {};
    return this._client.getAPIList(f`/v1/organizations/plugins/${n}/installation_settings?beta=true`, P, {
      query: i,
      ...t,
      headers: p([
        { "anthropic-beta": [...s ?? [], "ce-plugins-2026-09-01"].toString() },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.organization.plugins.installation_settings.list", t, {
        route: "/v1/organizations/plugins/{plugin_id}/installation_settings",
        queryParams: ["limit", "organization_id", "page", "target_type"],
        attributes: { "anthropic.organization.plugin.id": n }
      })
    });
  }
  /**
   * Remove an organization-owned Plugin's own installation setting for the whole
   * organization or for one RBAC Group.
   *
   * Removing the `organization` target returns the Plugin to its marketplace's
   * default installation setting and leaves the groups' settings in place. Removing
   * a group's setting makes the group's members fall back to the Plugin's
   * organization-wide setting or to the settings of their other groups.
   *
   * A target that holds no setting of its own returns 404 (a Plugin that already
   * inherits its marketplace's default holds no `organization` setting), and so does
   * a member-owned Plugin.
   *
   * A removal counts as one of the Plugin's installation-setting writes: send all of
   * those writes one at a time. If several arrive for the same Plugin at the same
   * time, the server handles them one after another and can answer some of them with
   * `503` and `x-should-retry: true` instead of applying them; wait a second or two
   * and send the removal again. A `404` on the repeat means the setting is already
   * gone.
   *
   * **Accepted credentials:** an Admin API key with the `write:plugins` scope.
   *
   * Every request must include the beta header
   * `anthropic-beta: ce-plugins-2026-09-01`. A request without it returns `404`,
   * exactly as if the endpoint did not exist. The Plugins API is in beta and is
   * available to Claude Enterprise organizations only. It is not available to Claude
   * Platform (Claude Console) organizations, or to organizations with HIPAA
   * readiness enabled.
   *
   * @example
   * ```ts
   * const betaDeletedPluginInstallationSetting =
   *   await client.beta.organization.plugins.installationSettings.remove(
   *     'target',
   *     { plugin_id: 'plugin_id' },
   *   );
   * ```
   */
  remove(n, e, t) {
    const { plugin_id: s, betas: i } = e;
    return this._client.delete(f`/v1/organizations/plugins/${s}/installation_settings/${n}?beta=true`, {
      ...t,
      headers: p([
        { "anthropic-beta": [...i ?? [], "ce-plugins-2026-09-01"].toString() },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.organization.plugins.installation_settings.remove", t, {
        route: "/v1/organizations/plugins/{plugin_id}/installation_settings/{target}",
        attributes: {
          "anthropic.organization.plugin.id": s,
          "anthropic.organization.plugin.installation_setting.id": n
        }
      })
    });
  }
  /**
   * Set or change an organization-owned Plugin's installation setting for the whole
   * organization or for one RBAC Group.
   *
   * Writing the value a target already holds of its own changes nothing.
   *
   * A member-owned Plugin has shares instead of installation settings, so this path
   * returns 404 for one.
   *
   * Send a Plugin's installation-setting writes one at a time. If several writes for
   * the same Plugin arrive at the same time, the server handles them one after
   * another and can answer some of them with `503` instead of applying them. That
   * `503` carries `x-should-retry: true`, and the write is safe to repeat: wait a
   * second or two, then send it again.
   *
   * **Accepted credentials:** an Admin API key with the `write:plugins` scope.
   *
   * Every request must include the beta header
   * `anthropic-beta: ce-plugins-2026-09-01`. A request without it returns `404`,
   * exactly as if the endpoint did not exist. The Plugins API is in beta and is
   * available to Claude Enterprise organizations only. It is not available to Claude
   * Platform (Claude Console) organizations, or to organizations with HIPAA
   * readiness enabled.
   *
   * @example
   * ```ts
   * const betaPluginInstallationSetting =
   *   await client.beta.organization.plugins.installationSettings.set(
   *     'target',
   *     {
   *       plugin_id: 'plugin_id',
   *       installation_preference: 'required',
   *     },
   *   );
   * ```
   */
  set(n, e, t) {
    const { plugin_id: s, betas: i, ...a } = e;
    return this._client.post(f`/v1/organizations/plugins/${s}/installation_settings/${n}?beta=true`, {
      body: a,
      ...t,
      headers: p([
        { "anthropic-beta": [...i ?? [], "ce-plugins-2026-09-01"].toString() },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.organization.plugins.installation_settings.set", t, {
        route: "/v1/organizations/plugins/{plugin_id}/installation_settings/{target}",
        attributes: {
          "anthropic.organization.plugin.id": s,
          "anthropic.organization.plugin.installation_setting.id": n
        }
      })
    });
  }
}
class vo extends T {
  /**
   * List the shares the owner of a member-owned Plugin has given — to every member
   * of the organization, to an RBAC Group, or to one member — most recently granted
   * first.
   *
   * Shares are read-only in this API: members give and withdraw them in claude.ai,
   * and who gave a share is recorded on the Compliance API activity feed rather than
   * on the share. An organization-owned Plugin has installation settings instead, so
   * this path returns 404 for one.
   *
   * **Accepted credentials:** an Admin API key with the `read:plugins` or
   * `read:org_audit` scope, or a Compliance Access Key with the
   * `read:compliance_org_data` scope.
   *
   * Every request must include the beta header
   * `anthropic-beta: ce-plugins-2026-09-01`. A request without it returns `404`,
   * exactly as if the endpoint did not exist. The Plugins API is in beta and is
   * available to Claude Enterprise organizations only. It is not available to Claude
   * Platform (Claude Console) organizations, or to organizations with HIPAA
   * readiness enabled.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaPluginShare of client.beta.organization.plugins.shares.list(
   *   'plugin_id',
   * )) {
   *   // ...
   * }
   * ```
   */
  list(n, e = {}, t) {
    const { betas: s, ...i } = e ?? {};
    return this._client.getAPIList(f`/v1/organizations/plugins/${n}/shares?beta=true`, P, {
      query: i,
      ...t,
      headers: p([
        { "anthropic-beta": [...s ?? [], "ce-plugins-2026-09-01"].toString() },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.organization.plugins.shares.list", t, {
        route: "/v1/organizations/plugins/{plugin_id}/shares",
        queryParams: ["limit", "organization_id", "page", "target_type"],
        attributes: { "anthropic.organization.plugin.id": n }
      })
    });
  }
}
let ko = class extends T {
  /**
   * Add a version to an organization-owned Plugin by uploading the new version's
   * files; it becomes the version served to members unless the Plugin's served
   * version has been pinned.
   *
   * The upload is the same `multipart/form-data` as creating a Plugin: the version's
   * files (`files`, each part sent as `files[]`) and optional `release_notes`. The
   * uploaded manifest's `name` must equal the Plugin's `name`. Returns the stored
   * version; read the Plugin back to see which version it serves.
   *
   * Only a Plugin in a `manual` marketplace takes uploads; a Plugin synchronized
   * from a repository gets its versions from the repository. When the Plugin is in
   * the organization's library marketplace, a version that adds a skill with the
   * name of an organization skill (a skill an administrator uploaded for the whole
   * organization in claude.ai) is refused with a 409: `error_code`
   * `skill_name_taken`, with that name in `details.skill_name`. A 503 with
   * `error_code` `registration_pending` means the version was stored but is not yet
   * usable; a later version create on the Plugin completes it.
   *
   * For a worked example, see
   * [Create a version](/docs/en/manage-claude/plugins-api#create-a-version) in the
   * Plugins API guide.
   *
   * **Accepted credentials:** an Admin API key with the `write:plugins` scope.
   *
   * Every request must include the beta header
   * `anthropic-beta: ce-plugins-2026-09-01`. A request without it returns `404`,
   * exactly as if the endpoint did not exist. The Plugins API is in beta and is
   * available to Claude Enterprise organizations only. It is not available to Claude
   * Platform (Claude Console) organizations, or to organizations with HIPAA
   * readiness enabled.
   *
   * @example
   * ```ts
   * const betaPluginVersion =
   *   await client.beta.organization.plugins.versions.create(
   *     'plugin_id',
   *     { files: [fs.createReadStream('path/to/file')] },
   *   );
   * ```
   */
  create(n, e, t) {
    const { betas: s, ...i } = e;
    return this._client.post(f`/v1/organizations/plugins/${n}/versions?beta=true`, Ce({
      body: i,
      ...t,
      headers: p([
        { "anthropic-beta": [...s ?? [], "ce-plugins-2026-09-01"].toString() },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.organization.plugins.versions.create", t, {
        route: "/v1/organizations/plugins/{plugin_id}/versions",
        attributes: { "anthropic.organization.plugin.id": n },
        createdIDAttribute: "anthropic.organization.plugin.version.id"
      })
    }, this._client));
  }
  /**
   * Retrieve one version of a Plugin by its ID, or the Plugin's newest version.
   *
   * **Accepted credentials:** an Admin API key with the `read:plugins` or
   * `read:org_audit` scope, or a Compliance Access Key with the
   * `read:compliance_org_data` scope.
   *
   * Every request must include the beta header
   * `anthropic-beta: ce-plugins-2026-09-01`. A request without it returns `404`,
   * exactly as if the endpoint did not exist. The Plugins API is in beta and is
   * available to Claude Enterprise organizations only. It is not available to Claude
   * Platform (Claude Console) organizations, or to organizations with HIPAA
   * readiness enabled.
   *
   * @example
   * ```ts
   * const betaPluginVersion =
   *   await client.beta.organization.plugins.versions.retrieve(
   *     'version',
   *     { plugin_id: 'plugin_id' },
   *   );
   * ```
   */
  retrieve(n, e, t) {
    const { plugin_id: s, betas: i, ...a } = e;
    return this._client.get(f`/v1/organizations/plugins/${s}/versions/${n}?beta=true`, {
      query: a,
      ...t,
      headers: p([
        { "anthropic-beta": [...i ?? [], "ce-plugins-2026-09-01"].toString() },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.organization.plugins.versions.retrieve", t, {
        route: "/v1/organizations/plugins/{plugin_id}/versions/{version}",
        queryParams: ["organization_id"],
        attributes: {
          "anthropic.organization.plugin.id": s,
          "anthropic.organization.plugin.version.id": n
        }
      })
    });
  }
  /**
   * List a Plugin's versions, newest first.
   *
   * The first item of the first page is the version the Plugin's `latest_version_id`
   * refers to.
   *
   * **Accepted credentials:** an Admin API key with the `read:plugins` or
   * `read:org_audit` scope, or a Compliance Access Key with the
   * `read:compliance_org_data` scope.
   *
   * Every request must include the beta header
   * `anthropic-beta: ce-plugins-2026-09-01`. A request without it returns `404`,
   * exactly as if the endpoint did not exist. The Plugins API is in beta and is
   * available to Claude Enterprise organizations only. It is not available to Claude
   * Platform (Claude Console) organizations, or to organizations with HIPAA
   * readiness enabled.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaPluginVersion of client.beta.organization.plugins.versions.list(
   *   'plugin_id',
   * )) {
   *   // ...
   * }
   * ```
   */
  list(n, e = {}, t) {
    const { betas: s, ...i } = e ?? {};
    return this._client.getAPIList(f`/v1/organizations/plugins/${n}/versions?beta=true`, P, {
      query: i,
      ...t,
      headers: p([
        { "anthropic-beta": [...s ?? [], "ce-plugins-2026-09-01"].toString() },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.organization.plugins.versions.list", t, {
        route: "/v1/organizations/plugins/{plugin_id}/versions",
        queryParams: ["limit", "organization_id", "page"],
        attributes: { "anthropic.organization.plugin.id": n }
      })
    });
  }
  /**
   * Download one version's `.zip` archive, exactly as stored. Each download of a
   * Plugin from a member's personal plugin marketplace is recorded on the Compliance
   * API activity feed.
   *
   * The response body is the archive (`Content-Type: application/zip`), sent as an
   * attachment whose filename is derived from the Plugin's name; name saved files
   * from the IDs in the request path, since that filename is not unique.
   *
   * **Accepted credentials:** an Admin API key with the `read:plugins` or
   * `read:org_audit` scope, or a Compliance Access Key with the
   * `read:compliance_org_data` scope.
   *
   * Every read scope above (`read:plugins`, `read:org_audit`, and
   * `read:compliance_org_data`) can download the files of plugins in members'
   * personal marketplaces, including files that claude.ai's admin settings do not
   * show, and a `read:org_audit` or `read:compliance_org_data` key created for all
   * of your parent organization's linked organizations can do this in any
   * organization under it that has access to this API, by passing `organization_id`.
   * Each such download records a `claude_plugin_archive_accessed` event on the
   * Compliance API activity feed, identifying the key, the plugin, the version, and
   * the member. Downloads of organization-owned plugins are not recorded.
   *
   * Every request must include the beta header
   * `anthropic-beta: ce-plugins-2026-09-01`. A request without it returns `404`,
   * exactly as if the endpoint did not exist. The Plugins API is in beta and is
   * available to Claude Enterprise organizations only. It is not available to Claude
   * Platform (Claude Console) organizations, or to organizations with HIPAA
   * readiness enabled.
   *
   * @example
   * ```ts
   * const response =
   *   await client.beta.organization.plugins.versions.download(
   *     'version',
   *     { plugin_id: 'plugin_id' },
   *   );
   *
   * const content = await response.blob();
   * console.log(content);
   * ```
   */
  download(n, e, t) {
    const { plugin_id: s, betas: i, ...a } = e;
    return this._client.get(f`/v1/organizations/plugins/${s}/versions/${n}/content?beta=true`, {
      query: a,
      ...t,
      headers: p([
        {
          "anthropic-beta": [...i ?? [], "ce-plugins-2026-09-01"].toString(),
          Accept: "application/binary"
        },
        t?.headers
      ]),
      __binaryResponse: !0,
      __span: u(this._client, "anthropic.organization.plugins.versions.download", t, {
        route: "/v1/organizations/plugins/{plugin_id}/versions/{version}/content",
        queryParams: ["organization_id"],
        attributes: {
          "anthropic.organization.plugin.id": s,
          "anthropic.organization.plugin.version.id": n
        }
      })
    });
  }
};
var So = /* @__PURE__ */ (() => {
  class r extends T {
    constructor() {
      super(...arguments), this.versions = new ko(this._client), this.installationSettings = new yo(this._client), this.shares = new vo(this._client);
    }
    /**
     * Create an organization-owned Plugin and its first version by uploading the
     * version's files.
     *
     * The upload is `multipart/form-data`: the version's files (`files`, each part
     * sent as `files[]`), with an optional `marketplace_id` and `release_notes`. The
     * manifest's `name` becomes the Plugin's `name`, and `display_name`, `description`
     * and `manifest_version` come from the manifest too.
     *
     * `name` may contain lowercase letters (from any alphabet), digits, and hyphens,
     * up to 64 characters. Uppercase letters, spaces, underscores, and other
     * punctuation are rejected.
     *
     * The `name` must be unique within the marketplace: a name already taken returns a
     * 409 with `error_code` `plugin_name_taken` and, when a Plugin holds it, that
     * Plugin's ID in `details.plugin_id`. A Plugin going into the organization's
     * library marketplace is also refused with a 409 when one of its skills has the
     * name of an organization skill (a skill an administrator uploaded for the whole
     * organization in claude.ai): `error_code` `skill_name_taken`, with that name in
     * `details.skill_name`; rename the skill, or remove the organization skill in
     * claude.ai. A 503 with `error_code` `registration_pending` means the Plugin and
     * its version were stored (their IDs are in `details`) but are not yet usable in
     * claude.ai: do not retry the create (the retry would return `plugin_name_taken`);
     * create a version on the stored Plugin instead, which completes it.
     *
     * For a worked example, see
     * [Create a plugin](/docs/en/manage-claude/plugins-api#create-a-plugin) in the
     * Plugins API guide.
     *
     * **Accepted credentials:** an Admin API key with the `write:plugins` scope.
     *
     * Every request must include the beta header
     * `anthropic-beta: ce-plugins-2026-09-01`. A request without it returns `404`,
     * exactly as if the endpoint did not exist. The Plugins API is in beta and is
     * available to Claude Enterprise organizations only. It is not available to Claude
     * Platform (Claude Console) organizations, or to organizations with HIPAA
     * readiness enabled.
     *
     * @example
     * ```ts
     * const betaPlugin =
     *   await client.beta.organization.plugins.create({
     *     files: [fs.createReadStream('path/to/file')],
     *   });
     * ```
     */
    create(e, t) {
      const { betas: s, ...i } = e;
      return this._client.post("/v1/organizations/plugins?beta=true", Ce({
        body: i,
        ...t,
        headers: p([
          { "anthropic-beta": [...s ?? [], "ce-plugins-2026-09-01"].toString() },
          t?.headers
        ]),
        __span: u(this._client, "anthropic.organization.plugins.create", t, {
          route: "/v1/organizations/plugins",
          createdIDAttribute: "anthropic.organization.plugin.id"
        })
      }, this._client));
    }
    /**
     * Retrieve a Plugin by ID.
     *
     * **Accepted credentials:** an Admin API key with the `read:plugins` or
     * `read:org_audit` scope, or a Compliance Access Key with the
     * `read:compliance_org_data` scope.
     *
     * Every request must include the beta header
     * `anthropic-beta: ce-plugins-2026-09-01`. A request without it returns `404`,
     * exactly as if the endpoint did not exist. The Plugins API is in beta and is
     * available to Claude Enterprise organizations only. It is not available to Claude
     * Platform (Claude Console) organizations, or to organizations with HIPAA
     * readiness enabled.
     *
     * @example
     * ```ts
     * const betaPlugin =
     *   await client.beta.organization.plugins.retrieve(
     *     'plugin_id',
     *   );
     * ```
     */
    retrieve(e, t = {}, s) {
      const { betas: i, ...a } = t ?? {};
      return this._client.get(f`/v1/organizations/plugins/${e}?beta=true`, {
        query: a,
        ...s,
        headers: p([
          { "anthropic-beta": [...i ?? [], "ce-plugins-2026-09-01"].toString() },
          s?.headers
        ]),
        __span: u(this._client, "anthropic.organization.plugins.retrieve", s, {
          route: "/v1/organizations/plugins/{plugin_id}",
          queryParams: ["organization_id"],
          attributes: { "anthropic.organization.plugin.id": e }
        })
      });
    }
    /**
     * Change which stored version of an organization-owned Plugin is served to
     * members, for example to roll back to an earlier one. This pins the served
     * version: later uploads are stored but no longer change what is served, and
     * pinning cannot currently be undone, here or in claude.ai.
     *
     * Pass the version as `served_version_id`: an earlier one to roll back, a later
     * one to start serving a version that was stored without being served, or the one
     * already served to pin it without changing what is served. No new version is
     * created.
     *
     * When the organization has content scanning enabled, a version whose scan is
     * still running is refused with a 409 (`error_code` `scan_pending`; retry once the
     * scan finishes) and one whose scan failed, errored or reached no verdict with a
     * 400 (`scan_failed`; a `warn` is accepted). When the Plugin is in the
     * organization's library marketplace, a version other than the one served is also
     * refused with a 409 when one of its skills has a name that an organization skill
     * (one an administrator uploaded for the whole organization in claude.ai) has
     * since taken: `error_code` `skill_name_taken`, with that name in
     * `details.skill_name`. A member-owned Plugin cannot be updated here (403).
     *
     * This endpoint does not write installation settings; they are written at
     * `/v1/organizations/plugins/{plugin_id}/installation_settings/{target}`.
     *
     * **Accepted credentials:** an Admin API key with the `write:plugins` scope.
     *
     * Every request must include the beta header
     * `anthropic-beta: ce-plugins-2026-09-01`. A request without it returns `404`,
     * exactly as if the endpoint did not exist. The Plugins API is in beta and is
     * available to Claude Enterprise organizations only. It is not available to Claude
     * Platform (Claude Console) organizations, or to organizations with HIPAA
     * readiness enabled.
     *
     * @example
     * ```ts
     * const betaPlugin =
     *   await client.beta.organization.plugins.update(
     *     'plugin_id',
     *     {
     *       served_version_id:
     *         'pluginver_01KaZmQpRsTuVwXyZ2b4c6d8',
     *     },
     *   );
     * ```
     */
    update(e, t, s) {
      const { betas: i, ...a } = t;
      return this._client.post(f`/v1/organizations/plugins/${e}?beta=true`, {
        body: a,
        ...s,
        headers: p([
          { "anthropic-beta": [...i ?? [], "ce-plugins-2026-09-01"].toString() },
          s?.headers
        ]),
        __span: u(this._client, "anthropic.organization.plugins.update", s, {
          route: "/v1/organizations/plugins/{plugin_id}",
          attributes: { "anthropic.organization.plugin.id": e }
        })
      });
    }
    /**
     * List the Plugins created under the organization, newest first: those in the
     * organization's own plugin marketplaces and those in members' personal plugin
     * marketplaces.
     *
     * Plugins in members' personal marketplaces are listed with the same detail as the
     * organization's own, and their files can be downloaded through the version
     * archive endpoint, which records each such download on the Compliance API
     * activity feed.
     *
     * **Accepted credentials:** an Admin API key with the `read:plugins` or
     * `read:org_audit` scope, or a Compliance Access Key with the
     * `read:compliance_org_data` scope.
     *
     * Every request must include the beta header
     * `anthropic-beta: ce-plugins-2026-09-01`. A request without it returns `404`,
     * exactly as if the endpoint did not exist. The Plugins API is in beta and is
     * available to Claude Enterprise organizations only. It is not available to Claude
     * Platform (Claude Console) organizations, or to organizations with HIPAA
     * readiness enabled.
     *
     * @example
     * ```ts
     * // Automatically fetches more pages as needed.
     * for await (const betaPlugin of client.beta.organization.plugins.list()) {
     *   // ...
     * }
     * ```
     */
    list(e = {}, t) {
      const { betas: s, ...i } = e ?? {};
      return this._client.getAPIList("/v1/organizations/plugins?beta=true", P, {
        query: i,
        ...t,
        headers: p([
          { "anthropic-beta": [...s ?? [], "ce-plugins-2026-09-01"].toString() },
          t?.headers
        ]),
        __span: u(this._client, "anthropic.organization.plugins.list", t, {
          route: "/v1/organizations/plugins",
          queryParams: [
            "created_at[gt]",
            "created_at[gte]",
            "created_at[lt]",
            "created_at[lte]",
            "limit",
            "marketplace_id",
            "organization_id",
            "owner_type",
            "owner_user_id",
            "page"
          ]
        })
      });
    }
    /**
     * Permanently delete a Plugin and every version it holds, exactly as when an
     * administrator deletes it in claude.ai. The Plugin may belong to the organization
     * or to a member, including a member who has since left the organization.
     *
     * An organization-owned Plugin's installation settings go with it; a member-owned
     * Plugin's shares are withdrawn and its owner no longer has it.
     *
     * To take an organization-owned Plugin out of use reversibly, set its
     * organization-wide installation setting to `not_available` instead (and remove or
     * change any group settings, which override it for their members). Only a Plugin
     * in a `manual` marketplace can be deleted here; one synchronized from a
     * repository is removed by removing it from the repository (400).
     *
     * **Accepted credentials:** an Admin API key with the `write:plugins` scope.
     *
     * Every request must include the beta header
     * `anthropic-beta: ce-plugins-2026-09-01`. A request without it returns `404`,
     * exactly as if the endpoint did not exist. The Plugins API is in beta and is
     * available to Claude Enterprise organizations only. It is not available to Claude
     * Platform (Claude Console) organizations, or to organizations with HIPAA
     * readiness enabled.
     *
     * @example
     * ```ts
     * const betaDeletedPlugin =
     *   await client.beta.organization.plugins.delete(
     *     'plugin_id',
     *   );
     * ```
     */
    delete(e, t = {}, s) {
      const { betas: i } = t ?? {};
      return this._client.delete(f`/v1/organizations/plugins/${e}?beta=true`, {
        ...s,
        headers: p([
          { "anthropic-beta": [...i ?? [], "ce-plugins-2026-09-01"].toString() },
          s?.headers
        ]),
        __span: u(this._client, "anthropic.organization.plugins.delete", s, {
          route: "/v1/organizations/plugins/{plugin_id}",
          attributes: { "anthropic.organization.plugin.id": e }
        })
      });
    }
  }
  return r.Versions = ko, r.InstallationSettings = yo, r.Shares = vo, r;
})();
let To = class extends T {
  /**
   * List members of an RBAC Group.
   *
   * The RBAC Groups API is available to Claude Enterprise organizations only.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaRBACGroupMember of client.beta.organization.rbacGroups.members.list(
   *   'rbac_group_id',
   * )) {
   *   // ...
   * }
   * ```
   */
  list(n, e = {}, t) {
    return this._client.getAPIList(f`/v1/organizations/rbac_groups/${n}/members?beta=true`, P, {
      query: e,
      ...t,
      __span: u(this._client, "anthropic.organization.rbac_groups.members.list", t, {
        route: "/v1/organizations/rbac_groups/{rbac_group_id}/members",
        queryParams: ["limit", "page"],
        attributes: { "anthropic.organization.rbac_group.id": n }
      })
    });
  }
  /**
   * Add a User to an RBAC Group. Membership of groups provisioned by an identity
   * provider (source type `"scim"`) cannot be modified via the API while an
   * organization in the tenant uses SCIM provisioning.
   *
   * The RBAC Groups API is available to Claude Enterprise organizations only.
   *
   * @example
   * ```ts
   * const betaRBACGroupMember =
   *   await client.beta.organization.rbacGroups.members.add(
   *     'rbac_group_id',
   *     { user_id: 'user_01WCz1FkmYMm4gnmykNKUu3Q' },
   *   );
   * ```
   */
  add(n, e, t) {
    return this._client.post(f`/v1/organizations/rbac_groups/${n}/members?beta=true`, {
      body: e,
      ...t,
      __span: u(this._client, "anthropic.organization.rbac_groups.members.add", t, {
        route: "/v1/organizations/rbac_groups/{rbac_group_id}/members",
        attributes: { "anthropic.organization.rbac_group.id": n },
        createdIDAttribute: "anthropic.organization.rbac_group.member.id",
        createdIDField: "user_id"
      })
    });
  }
  /**
   * Remove a User from an RBAC Group. Membership of groups provisioned by an
   * identity provider (source type `"scim"`) cannot be modified via the API while an
   * organization in the tenant uses SCIM provisioning.
   *
   * The RBAC Groups API is available to Claude Enterprise organizations only.
   *
   * @example
   * ```ts
   * const member =
   *   await client.beta.organization.rbacGroups.members.remove(
   *     'user_id',
   *     { rbac_group_id: 'rbac_group_id' },
   *   );
   * ```
   */
  remove(n, e, t) {
    const { rbac_group_id: s } = e;
    return this._client.delete(f`/v1/organizations/rbac_groups/${s}/members/${n}?beta=true`, {
      ...t,
      __span: u(this._client, "anthropic.organization.rbac_groups.members.remove", t, {
        route: "/v1/organizations/rbac_groups/{rbac_group_id}/members/{user_id}",
        attributes: {
          "anthropic.organization.rbac_group.id": s,
          "anthropic.organization.rbac_group.member.id": n
        }
      })
    });
  }
};
var Ao = /* @__PURE__ */ (() => {
  class r extends T {
    constructor() {
      super(...arguments), this.members = new To(this._client);
    }
    /**
     * Create an RBAC Group in the Claude Enterprise tenant. Groups created via the API
     * have source type `"direct"`.
     *
     * The RBAC Groups API is available to Claude Enterprise organizations only.
     *
     * @example
     * ```ts
     * const betaRBACGroup =
     *   await client.beta.organization.rbacGroups.create({
     *     name: 'Engineering',
     *   });
     * ```
     */
    create(e, t) {
      return this._client.post("/v1/organizations/rbac_groups?beta=true", {
        body: e,
        ...t,
        __span: u(this._client, "anthropic.organization.rbac_groups.create", t, {
          route: "/v1/organizations/rbac_groups",
          createdIDAttribute: "anthropic.organization.rbac_group.id"
        })
      });
    }
    /**
     * Retrieve an RBAC Group by ID.
     *
     * The RBAC Groups API is available to Claude Enterprise organizations only.
     *
     * @example
     * ```ts
     * const betaRBACGroup =
     *   await client.beta.organization.rbacGroups.retrieve(
     *     'rbac_group_id',
     *   );
     * ```
     */
    retrieve(e, t) {
      return this._client.get(f`/v1/organizations/rbac_groups/${e}?beta=true`, {
        ...t,
        __span: u(this._client, "anthropic.organization.rbac_groups.retrieve", t, {
          route: "/v1/organizations/rbac_groups/{rbac_group_id}",
          attributes: { "anthropic.organization.rbac_group.id": e }
        })
      });
    }
    /**
     * Update an RBAC Group's name. Groups provisioned by an identity provider (source
     * type `"scim"`) cannot be modified via the API while an organization in the
     * tenant uses SCIM provisioning.
     *
     * The RBAC Groups API is available to Claude Enterprise organizations only.
     *
     * @example
     * ```ts
     * const betaRBACGroup =
     *   await client.beta.organization.rbacGroups.update(
     *     'rbac_group_id',
     *   );
     * ```
     */
    update(e, t, s) {
      return this._client.post(f`/v1/organizations/rbac_groups/${e}?beta=true`, {
        body: t,
        ...s,
        __span: u(this._client, "anthropic.organization.rbac_groups.update", s, {
          route: "/v1/organizations/rbac_groups/{rbac_group_id}",
          attributes: { "anthropic.organization.rbac_group.id": e }
        })
      });
    }
    /**
     * List RBAC Groups in the Claude Enterprise tenant.
     *
     * The RBAC Groups API is available to Claude Enterprise organizations only.
     *
     * @example
     * ```ts
     * // Automatically fetches more pages as needed.
     * for await (const betaRBACGroup of client.beta.organization.rbacGroups.list()) {
     *   // ...
     * }
     * ```
     */
    list(e = {}, t) {
      return this._client.getAPIList("/v1/organizations/rbac_groups?beta=true", P, {
        query: e,
        ...t,
        __span: u(this._client, "anthropic.organization.rbac_groups.list", t, {
          route: "/v1/organizations/rbac_groups",
          queryParams: ["limit", "page"]
        })
      });
    }
    /**
     * Delete an RBAC Group. Groups provisioned by an identity provider (source type
     * `"scim"`) cannot be deleted via the API while an organization in the tenant uses
     * SCIM provisioning.
     *
     * The RBAC Groups API is available to Claude Enterprise organizations only.
     *
     * @example
     * ```ts
     * const rbacGroup =
     *   await client.beta.organization.rbacGroups.delete(
     *     'rbac_group_id',
     *   );
     * ```
     */
    delete(e, t) {
      return this._client.delete(f`/v1/organizations/rbac_groups/${e}?beta=true`, {
        ...t,
        __span: u(this._client, "anthropic.organization.rbac_groups.delete", t, {
          route: "/v1/organizations/rbac_groups/{rbac_group_id}",
          attributes: { "anthropic.organization.rbac_group.id": e }
        })
      });
    }
  }
  return r.Members = To, r;
})();
class xo extends T {
  /**
   * List the permissions an RBAC Role grants.
   *
   * The RBAC Roles API is available to Claude Enterprise organizations only.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaRBACRolePermission of client.beta.organization.rbacRoles.permissions.list(
   *   'rbac_role_id',
   * )) {
   *   // ...
   * }
   * ```
   */
  list(n, e = {}, t) {
    return this._client.getAPIList(f`/v1/organizations/rbac_roles/${n}/permissions?beta=true`, P, {
      query: e,
      ...t,
      __span: u(this._client, "anthropic.organization.rbac_roles.permissions.list", t, {
        route: "/v1/organizations/rbac_roles/{rbac_role_id}/permissions",
        queryParams: ["limit", "page"],
        attributes: { "anthropic.organization.rbac_role.id": n }
      })
    });
  }
}
var Eo = /* @__PURE__ */ (() => {
  class r extends T {
    constructor() {
      super(...arguments), this.permissions = new xo(this._client);
    }
    /**
     * Retrieve an RBAC Role by ID.
     *
     * The RBAC Roles API is available to Claude Enterprise organizations only.
     *
     * @example
     * ```ts
     * const betaRBACRole =
     *   await client.beta.organization.rbacRoles.retrieve(
     *     'rbac_role_id',
     *   );
     * ```
     */
    retrieve(e, t) {
      return this._client.get(f`/v1/organizations/rbac_roles/${e}?beta=true`, {
        ...t,
        __span: u(this._client, "anthropic.organization.rbac_roles.retrieve", t, {
          route: "/v1/organizations/rbac_roles/{rbac_role_id}",
          attributes: { "anthropic.organization.rbac_role.id": e }
        })
      });
    }
    /**
     * List RBAC Roles in the organization.
     *
     * The RBAC Roles API is available to Claude Enterprise organizations only.
     *
     * @example
     * ```ts
     * // Automatically fetches more pages as needed.
     * for await (const betaRBACRole of client.beta.organization.rbacRoles.list()) {
     *   // ...
     * }
     * ```
     */
    list(e = {}, t) {
      return this._client.getAPIList("/v1/organizations/rbac_roles?beta=true", P, {
        query: e,
        ...t,
        __span: u(this._client, "anthropic.organization.rbac_roles.list", t, {
          route: "/v1/organizations/rbac_roles",
          queryParams: ["limit", "page"]
        })
      });
    }
  }
  return r.Permissions = xo, r;
})();
let Ro = class extends T {
  /**
   * **Requires an OAuth access token with the `org:admin` scope**, from
   * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
   * API keys are not accepted. See
   * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
   *
   * List the workspaces a service account is a member of.
   *
   * Each entry includes the service account's `workspace_role` in that workspace.
   * Use `limit` and the `next_page` cursor to paginate. When the service account has
   * no explicit default-workspace membership, the implicit (`implicit: true`)
   * membership is returned as the first entry on the first page; with `limit=1` the
   * first page may return up to 2 entries (the implicit entry plus one explicit
   * membership) so a pagination cursor can be derived. Memberships are returned only
   * while the service account is active. Without a `page` cursor, an archived
   * service account returns an empty list. A `page` cursor that does not match an
   * active membership returns a 400 invalid-request error. A cursor stops matching
   * when the membership is removed, the workspace is deleted, or the service account
   * is archived. Restart pagination from the first page to recover.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaServiceAccountWorkspaceMember of client.beta.organization.serviceAccounts.workspaces.list(
   *   'service_account_id',
   * )) {
   *   // ...
   * }
   * ```
   */
  list(n, e = {}, t) {
    const { betas: s, ...i } = e ?? {};
    return this._client.getAPIList(f`/v1/organizations/service_accounts/${n}/workspaces?beta=true`, P, {
      query: i,
      ...t,
      headers: p([
        { ...s?.toString() != null ? { "anthropic-beta": s?.toString() } : void 0 },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.organization.service_accounts.workspaces.list", t, {
        route: "/v1/organizations/service_accounts/{service_account_id}/workspaces",
        queryParams: ["limit", "page"],
        attributes: { "anthropic.organization.service_account.id": n }
      })
    });
  }
  /**
   * **Requires an OAuth access token with the `org:admin` scope**, from
   * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
   * API keys are not accepted. See
   * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
   *
   * Add a service account to a workspace with the given `workspace_role`.
   *
   * Mirror of `POST /workspaces/{workspace_id}/service_accounts`, addressed from the
   * service-account side; both create the same membership. If the service account is
   * already an explicit member of the workspace, its `workspace_role` is replaced
   * with the value supplied here. Archived workspaces return 400. Archived service
   * accounts cannot be added and are rejected.
   *
   * @example
   * ```ts
   * const betaServiceAccountWorkspaceMember =
   *   await client.beta.organization.serviceAccounts.workspaces.add(
   *     'service_account_id',
   *     {
   *       workspace_id: 'workspace_id',
   *       workspace_role: 'workspace_admin',
   *     },
   *   );
   * ```
   */
  add(n, e, t) {
    const { betas: s, ...i } = e;
    return this._client.post(f`/v1/organizations/service_accounts/${n}/workspaces?beta=true`, {
      body: i,
      ...t,
      headers: p([
        { ...s?.toString() != null ? { "anthropic-beta": s?.toString() } : void 0 },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.organization.service_accounts.workspaces.add", t, {
        route: "/v1/organizations/service_accounts/{service_account_id}/workspaces",
        attributes: { "anthropic.organization.service_account.id": n },
        createdIDAttribute: "anthropic.organization.service_account.workspace.id",
        createdIDField: "workspace_id"
      })
    });
  }
  /**
   * **Requires an OAuth access token with the `org:admin` scope**, from
   * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
   * API keys are not accepted. See
   * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
   *
   * Remove a service account from a workspace.
   *
   * Mirror of
   * `DELETE /workspaces/{workspace_id}/service_accounts/{service_account_id}`,
   * addressed from the service-account side. Removal is idempotent (returns 200 even
   * if the membership was already removed). A DELETE against the implicit
   * default-workspace membership returns 200 but is a no-op and the membership
   * persists; deleting an explicit default-workspace row reverts to the implicit
   * `workspace_user` membership. Archived workspaces return 400.
   *
   * @example
   * ```ts
   * const workspace =
   *   await client.beta.organization.serviceAccounts.workspaces.remove(
   *     'workspace_id',
   *     { service_account_id: 'service_account_id' },
   *   );
   * ```
   */
  remove(n, e, t) {
    const { service_account_id: s, betas: i } = e;
    return this._client.delete(f`/v1/organizations/service_accounts/${s}/workspaces/${n}?beta=true`, {
      ...t,
      headers: p([
        { ...i?.toString() != null ? { "anthropic-beta": i?.toString() } : void 0 },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.organization.service_accounts.workspaces.remove", t, {
        route: "/v1/organizations/service_accounts/{service_account_id}/workspaces/{workspace_id}",
        attributes: {
          "anthropic.organization.service_account.id": s,
          "anthropic.organization.service_account.workspace.id": n
        }
      })
    });
  }
};
var Po = /* @__PURE__ */ (() => {
  class r extends T {
    constructor() {
      super(...arguments), this.workspaces = new Ro(this._client);
    }
    /**
     * **Requires an OAuth access token with the `org:admin` scope**, from
     * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
     * API keys are not accepted. See
     * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
     *
     * Create a service account.
     *
     * A service account is a named workload identity that federation rules target.
     * `organization_role` is `developer` (default) or `admin`; a rule may only be
     * created or retargeted to grant `org:admin` scope when the target's
     * `organization_role` is `admin`. Creating an `admin`-role service account
     * requires an interactive credential (a user OAuth token or a Console session) — a
     * workload may only create `developer`-role service accounts.
     *
     * @example
     * ```ts
     * const betaServiceAccount =
     *   await client.beta.organization.serviceAccounts.create({
     *     name: 'ci-deploy-bot',
     *   });
     * ```
     */
    create(e, t) {
      const { betas: s, ...i } = e;
      return this._client.post("/v1/organizations/service_accounts?beta=true", {
        body: i,
        ...t,
        headers: p([
          { ...s?.toString() != null ? { "anthropic-beta": s?.toString() } : void 0 },
          t?.headers
        ]),
        __span: u(this._client, "anthropic.organization.service_accounts.create", t, {
          route: "/v1/organizations/service_accounts",
          createdIDAttribute: "anthropic.organization.service_account.id"
        })
      });
    }
    /**
     * **Requires an OAuth access token with the `org:admin` scope**, from
     * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
     * API keys are not accepted. See
     * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
     *
     * Retrieve a service account by its ID (`svac_...`).
     *
     * @example
     * ```ts
     * const betaServiceAccount =
     *   await client.beta.organization.serviceAccounts.retrieve(
     *     'service_account_id',
     *   );
     * ```
     */
    retrieve(e, t = {}, s) {
      const { betas: i } = t ?? {};
      return this._client.get(f`/v1/organizations/service_accounts/${e}?beta=true`, {
        ...s,
        headers: p([
          { ...i?.toString() != null ? { "anthropic-beta": i?.toString() } : void 0 },
          s?.headers
        ]),
        __span: u(this._client, "anthropic.organization.service_accounts.retrieve", s, {
          route: "/v1/organizations/service_accounts/{service_account_id}",
          attributes: { "anthropic.organization.service_account.id": e }
        })
      });
    }
    /**
     * **Requires an OAuth access token with the `org:admin` scope**, from
     * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
     * API keys are not accepted. See
     * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
     *
     * Update a service account.
     *
     * Only `description` and `organization_role` are mutable; `name` cannot be
     * changed. Archived service accounts cannot be updated; this returns 400. Setting
     * `organization_role` to `admin` (even when unchanged) requires an interactive
     * credential (a user OAuth token or a Console session).
     *
     * @example
     * ```ts
     * const betaServiceAccount =
     *   await client.beta.organization.serviceAccounts.update(
     *     'service_account_id',
     *   );
     * ```
     */
    update(e, t, s) {
      const { betas: i, ...a } = t;
      return this._client.post(f`/v1/organizations/service_accounts/${e}?beta=true`, {
        body: a,
        ...s,
        headers: p([
          { ...i?.toString() != null ? { "anthropic-beta": i?.toString() } : void 0 },
          s?.headers
        ]),
        __span: u(this._client, "anthropic.organization.service_accounts.update", s, {
          route: "/v1/organizations/service_accounts/{service_account_id}",
          attributes: { "anthropic.organization.service_account.id": e }
        })
      });
    }
    /**
     * **Requires an OAuth access token with the `org:admin` scope**, from
     * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
     * API keys are not accepted. See
     * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
     *
     * List service accounts in the caller's organization.
     *
     * Results are ordered by creation time, newest first. Use `limit` and the
     * `next_page` cursor to paginate; set `include_archived=true` to include archived
     * service accounts.
     *
     * @example
     * ```ts
     * // Automatically fetches more pages as needed.
     * for await (const betaServiceAccount of client.beta.organization.serviceAccounts.list()) {
     *   // ...
     * }
     * ```
     */
    list(e = {}, t) {
      const { betas: s, ...i } = e ?? {};
      return this._client.getAPIList("/v1/organizations/service_accounts?beta=true", P, {
        query: i,
        ...t,
        headers: p([
          { ...s?.toString() != null ? { "anthropic-beta": s?.toString() } : void 0 },
          t?.headers
        ]),
        __span: u(this._client, "anthropic.organization.service_accounts.list", t, {
          route: "/v1/organizations/service_accounts",
          queryParams: ["include_archived", "limit", "page"]
        })
      });
    }
    /**
     * **Requires an OAuth access token with the `org:admin` scope**, from
     * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
     * API keys are not accepted. See
     * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
     *
     * Archive a service account.
     *
     * Idempotent; re-archiving returns the service account with its original
     * `archived_at`. Rejected with 400 if any live (non-archived) federation rule
     * still targets this service account, same as issuer archival; archive those rules
     * first or change their target to another service account.
     *
     * @example
     * ```ts
     * const betaServiceAccount =
     *   await client.beta.organization.serviceAccounts.archive(
     *     'service_account_id',
     *   );
     * ```
     */
    archive(e, t = {}, s) {
      const { betas: i } = t ?? {};
      return this._client.post(f`/v1/organizations/service_accounts/${e}/archive?beta=true`, {
        ...s,
        headers: p([
          { ...i?.toString() != null ? { "anthropic-beta": i?.toString() } : void 0 },
          s?.headers
        ]),
        __span: u(this._client, "anthropic.organization.service_accounts.archive", s, {
          route: "/v1/organizations/service_accounts/{service_account_id}/archive",
          attributes: { "anthropic.organization.service_account.id": e }
        })
      });
    }
  }
  return r.Workspaces = Ro, r;
})();
class zo extends T {
  /**
   * List each member's effective spend limit and period-to-date spend.
   *
   * Returns one row per (member, period) the member resolves a spend limit for, with
   * the `source` scope the spend limit was inherited from. Paginates by member, so a
   * member's periods never split across pages. Supported for Claude Enterprise
   * organizations only, not for Claude Console organizations.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaSpendSummary of client.beta.organization.spendLimits.effective.list()) {
   *   // ...
   * }
   * ```
   */
  list(n = {}, e) {
    return this._client.getAPIList("/v1/organizations/spend_limits/effective?beta=true", P, {
      query: n,
      ...e,
      __span: u(this._client, "anthropic.organization.spend_limits.effective.list", e, {
        route: "/v1/organizations/spend_limits/effective",
        queryParams: ["limit", "page", "period", "user_ids"]
      })
    });
  }
}
class Mo extends T {
  /**
   * Retrieve a spend limit increase request.
   *
   * While `pending`, the response includes a live `spend_summary` for the requester
   * at the request's period.
   *
   * @example
   * ```ts
   * const betaSpendLimitIncreaseRequest =
   *   await client.beta.organization.spendLimits.increaseRequests.retrieve(
   *     'spend_limit_increase_request_id',
   *   );
   * ```
   */
  retrieve(n, e) {
    return this._client.get(f`/v1/organizations/spend_limit_increase_requests/${n}?beta=true`, {
      ...e,
      __span: u(this._client, "anthropic.organization.spend_limits.increase_requests.retrieve", e, {
        route: "/v1/organizations/spend_limit_increase_requests/{spend_limit_increase_request_id}",
        attributes: {
          "anthropic.organization.spend_limit_increase_request.id": n
        }
      })
    });
  }
  /**
   * List spend limit increase requests, most recent first.
   *
   * Pending requests include a live `spend_summary` for the requester. Requests
   * whose requester is no longer a member are excluded.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaSpendLimitIncreaseRequest of client.beta.organization.spendLimits.increaseRequests.list()) {
   *   // ...
   * }
   * ```
   */
  list(n = {}, e) {
    return this._client.getAPIList("/v1/organizations/spend_limit_increase_requests?beta=true", P, {
      query: n,
      ...e,
      __span: u(this._client, "anthropic.organization.spend_limits.increase_requests.list", e, {
        route: "/v1/organizations/spend_limit_increase_requests",
        queryParams: ["actor_ids", "limit", "page", "status"]
      })
    });
  }
  /**
   * Approve a pending spend limit increase request.
   *
   * Writes a per-user spend limit at `amount` for the requester and transitions the
   * request to `approved`. `period` defaults to the period the member was blocked
   * on. Anthropic emails the requester unless `suppress_notification` is set.
   *
   * @example
   * ```ts
   * const response =
   *   await client.beta.organization.spendLimits.increaseRequests.approve(
   *     'spend_limit_increase_request_id',
   *     { amount: '50000' },
   *   );
   * ```
   */
  approve(n, e, t) {
    return this._client.post(f`/v1/organizations/spend_limit_increase_requests/${n}/approve?beta=true`, {
      body: e,
      ...t,
      __span: u(this._client, "anthropic.organization.spend_limits.increase_requests.approve", t, {
        route: "/v1/organizations/spend_limit_increase_requests/{spend_limit_increase_request_id}/approve",
        attributes: {
          "anthropic.organization.spend_limit_increase_request.id": n
        }
      })
    });
  }
  /**
   * Deny a pending spend limit increase request.
   *
   * Idempotent on `denied`; denying an already-`approved` request returns 400.
   * Anthropic emails the requester unless `suppress_notification` is set.
   *
   * @example
   * ```ts
   * const betaSpendLimitIncreaseRequest =
   *   await client.beta.organization.spendLimits.increaseRequests.deny(
   *     'spend_limit_increase_request_id',
   *   );
   * ```
   */
  deny(n, e, t) {
    return this._client.post(f`/v1/organizations/spend_limit_increase_requests/${n}/deny?beta=true`, {
      body: e,
      ...t,
      __span: u(this._client, "anthropic.organization.spend_limits.increase_requests.deny", t, {
        route: "/v1/organizations/spend_limit_increase_requests/{spend_limit_increase_request_id}/deny",
        attributes: {
          "anthropic.organization.spend_limit_increase_request.id": n
        }
      })
    });
  }
}
var Oo = /* @__PURE__ */ (() => {
  class r extends T {
    constructor() {
      super(...arguments), this.effective = new zo(this._client), this.increaseRequests = new Mo(this._client);
    }
    /**
     * Retrieve a spend limit by ID.
     *
     * @example
     * ```ts
     * const betaSpendLimit =
     *   await client.beta.organization.spendLimits.retrieve(
     *     'spend_limit_id',
     *   );
     * ```
     */
    retrieve(e, t) {
      return this._client.get(f`/v1/organizations/spend_limits/${e}?beta=true`, {
        ...t,
        __span: u(this._client, "anthropic.organization.spend_limits.retrieve", t, {
          route: "/v1/organizations/spend_limits/{spend_limit_id}",
          attributes: { "anthropic.organization.spend_limit.id": e }
        })
      });
    }
    /**
     * List the organization's spend limits.
     *
     * Limits are grouped by scope type, in the order `organization`, `seat_tier`,
     * `rbac_group`, `organization_service`, `user`; within a type they come in a fixed
     * order that is not creation order. Supported for Claude Enterprise organizations
     * only, not for Claude Console organizations.
     *
     * @example
     * ```ts
     * // Automatically fetches more pages as needed.
     * for await (const betaSpendLimit of client.beta.organization.spendLimits.list()) {
     *   // ...
     * }
     * ```
     */
    list(e = {}, t) {
      const { betas: s, ...i } = e ?? {};
      return this._client.getAPIList("/v1/organizations/spend_limits?beta=true", P, {
        query: i,
        ...t,
        headers: p([
          { "anthropic-beta": [...s ?? [], "spend-limit-reads-2026-09-26"].toString() },
          t?.headers
        ]),
        __span: u(this._client, "anthropic.organization.spend_limits.list", t, {
          route: "/v1/organizations/spend_limits",
          queryParams: ["limit", "page", "scope_type"]
        })
      });
    }
    /**
     * Delete a spend limit.
     *
     * For a Claude Enterprise organization, this deletes a per-user override, and the
     * member falls back to any inherited spend limit at that period. Its seat-tier,
     * group, and organization-level rows cannot be deleted via this endpoint. A Claude
     * Console organization deletes its organization and workspace limits, but not its
     * `usage_tier` limit. Deleting organization and workspace limits through the API
     * is in an early access preview.
     *
     * @example
     * ```ts
     * const spendLimit =
     *   await client.beta.organization.spendLimits.delete(
     *     'spend_limit_id',
     *   );
     * ```
     */
    delete(e, t) {
      return this._client.delete(f`/v1/organizations/spend_limits/${e}?beta=true`, {
        ...t,
        __span: u(this._client, "anthropic.organization.spend_limits.delete", t, {
          route: "/v1/organizations/spend_limits/{spend_limit_id}",
          attributes: { "anthropic.organization.spend_limit.id": e }
        })
      });
    }
    /**
     * Set a spend limit.
     *
     * Upsert keyed on (scope, period): setting a limit that already exists overwrites
     * it in place. A Claude Enterprise organization sets `user` limits. Its seat-tier,
     * group, and organization-level defaults are configured in claude.ai. A Claude
     * Console organization sets `organization` and `workspace` limits, which are
     * monthly and always carry an amount. Setting those limits is in an early access
     * preview. To request access, contact your Anthropic account team.
     *
     * @example
     * ```ts
     * const betaSpendLimit =
     *   await client.beta.organization.spendLimits.set({
     *     amount: '50000',
     *     scope: {
     *       type: 'user',
     *       user_id: 'user_01WCz1FkmYMm4gnmykNKUu3Q',
     *     },
     *   });
     * ```
     */
    set(e, t) {
      const { betas: s, ...i } = e;
      return this._client.post("/v1/organizations/spend_limits?beta=true", {
        body: i,
        ...t,
        headers: p([
          { ...s?.toString() != null ? { "anthropic-beta": s?.toString() } : void 0 },
          t?.headers
        ]),
        __span: u(this._client, "anthropic.organization.spend_limits.set", t, {
          route: "/v1/organizations/spend_limits",
          createdIDAttribute: "anthropic.organization.spend_limit.id"
        })
      });
    }
  }
  return r.Effective = zo, r.IncreaseRequests = Mo, r;
})();
let Co = class extends T {
  /**
   * List the workspaces on a destination's workspace list, newest entry first.
   *
   * A destination whose `workspaces.type` is `all` doesn't have a list, so its page
   * is empty. The list includes archived workspaces.
   *
   * See the
   * [OpenTelemetry export guide](https://platform.claude.com/docs/en/manage-claude/opentelemetry#choose-workspaces-for-a-destination)
   * to learn more about choosing the workspaces of a destination.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaTelemetryDestinationWorkspace of client.beta.organization.telemetryDestinations.workspaces.list(
   *   'destination_id',
   * )) {
   *   // ...
   * }
   * ```
   */
  list(n, e = {}, t) {
    const { betas: s, ...i } = e ?? {};
    return this._client.getAPIList(f`/v1/organizations/telemetry_destinations/${n}/workspaces?beta=true`, P, {
      query: i,
      ...t,
      headers: p([
        { "anthropic-beta": [...s ?? [], "telemetry-destinations-2026-08-11"].toString() },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.organization.telemetry_destinations.workspaces.list", t, {
        route: "/v1/organizations/telemetry_destinations/{destination_id}/workspaces",
        queryParams: ["limit", "page"],
        attributes: { "anthropic.organization.telemetry_destination.id": n }
      })
    });
  }
  /**
   * Add one workspace to a destination's workspace list.
   *
   * Under `include` the workspace's spans start going to the destination. Under
   * `exclude` they stop. A list holds at most 1,000 workspaces.
   *
   * Adding a workspace that is already on the list changes nothing and returns the
   * existing entry. An archived workspace that isn't on the list yet can't be added.
   * A destination whose `workspaces.type` is `all` doesn't have a list, so the API
   * returns 400. To change which workspaces such a destination covers, update its
   * `workspaces`.
   *
   * See the
   * [OpenTelemetry export guide](https://platform.claude.com/docs/en/manage-claude/opentelemetry#choose-workspaces-for-a-destination)
   * to learn more about choosing the workspaces of a destination.
   *
   * @example
   * ```ts
   * const betaTelemetryDestinationWorkspace =
   *   await client.beta.organization.telemetryDestinations.workspaces.add(
   *     'workspace_id',
   *     { destination_id: 'destination_id' },
   *   );
   * ```
   */
  add(n, e, t) {
    const { destination_id: s, betas: i } = e;
    return this._client.post(f`/v1/organizations/telemetry_destinations/${s}/workspaces/${n}?beta=true`, {
      ...t,
      headers: p([
        { "anthropic-beta": [...i ?? [], "telemetry-destinations-2026-08-11"].toString() },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.organization.telemetry_destinations.workspaces.add", t, {
        route: "/v1/organizations/telemetry_destinations/{destination_id}/workspaces/{workspace_id}",
        attributes: {
          "anthropic.organization.telemetry_destination.id": s,
          "anthropic.organization.telemetry_destination.workspace.id": n
        }
      })
    });
  }
  /**
   * Remove one workspace from a destination's workspace list.
   *
   * Under `include` the workspace's spans stop going to the destination. Under
   * `exclude` they start. An archived workspace can be removed too.
   *
   * The API returns 404 when the workspace isn't on the list. A destination whose
   * `workspaces.type` is `all` doesn't have a list, so the API returns 400.
   *
   * See the
   * [OpenTelemetry export guide](https://platform.claude.com/docs/en/manage-claude/opentelemetry#choose-workspaces-for-a-destination)
   * to learn more about choosing the workspaces of a destination.
   *
   * @example
   * ```ts
   * const betaDeletedTelemetryDestinationWorkspace =
   *   await client.beta.organization.telemetryDestinations.workspaces.remove(
   *     'workspace_id',
   *     { destination_id: 'destination_id' },
   *   );
   * ```
   */
  remove(n, e, t) {
    const { destination_id: s, betas: i } = e;
    return this._client.delete(f`/v1/organizations/telemetry_destinations/${s}/workspaces/${n}?beta=true`, {
      ...t,
      headers: p([
        { "anthropic-beta": [...i ?? [], "telemetry-destinations-2026-08-11"].toString() },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.organization.telemetry_destinations.workspaces.remove", t, {
        route: "/v1/organizations/telemetry_destinations/{destination_id}/workspaces/{workspace_id}",
        attributes: {
          "anthropic.organization.telemetry_destination.id": s,
          "anthropic.organization.telemetry_destination.workspace.id": n
        }
      })
    });
  }
};
var $o = /* @__PURE__ */ (() => {
  class r extends T {
    constructor() {
      super(...arguments), this.workspaces = new Co(this._client);
    }
    /**
     * Register an OpenTelemetry destination for the organization.
     *
     * The destination starts in state `enabled`. An organization can have at most 10
     * destinations, including disabled ones.
     *
     * See the
     * [OpenTelemetry export guide](https://platform.claude.com/docs/en/manage-claude/opentelemetry#add-a-destination)
     * to learn more about adding a destination.
     *
     * @example
     * ```ts
     * const betaTelemetryDestination =
     *   await client.beta.organization.telemetryDestinations.create(
     *     {
     *       endpoint_url: 'x',
     *       workspaces: { type: 'all' },
     *     },
     *   );
     * ```
     */
    create(e, t) {
      const { betas: s, ...i } = e;
      return this._client.post("/v1/organizations/telemetry_destinations?beta=true", {
        body: i,
        ...t,
        headers: p([
          { "anthropic-beta": [...s ?? [], "telemetry-destinations-2026-08-11"].toString() },
          t?.headers
        ]),
        __span: u(this._client, "anthropic.organization.telemetry_destinations.create", t, {
          route: "/v1/organizations/telemetry_destinations",
          createdIDAttribute: "anthropic.organization.telemetry_destination.id"
        })
      });
    }
    /**
     * Read a destination's configuration, state, and most recent delivery results.
     *
     * See the
     * [OpenTelemetry export guide](https://platform.claude.com/docs/en/manage-claude/opentelemetry#delivery-and-health)
     * to learn how the API delivers spans and when it disables a destination.
     *
     * @example
     * ```ts
     * const betaTelemetryDestination =
     *   await client.beta.organization.telemetryDestinations.retrieve(
     *     'destination_id',
     *   );
     * ```
     */
    retrieve(e, t = {}, s) {
      const { betas: i } = t ?? {};
      return this._client.get(f`/v1/organizations/telemetry_destinations/${e}?beta=true`, {
        ...s,
        headers: p([
          { "anthropic-beta": [...i ?? [], "telemetry-destinations-2026-08-11"].toString() },
          s?.headers
        ]),
        __span: u(this._client, "anthropic.organization.telemetry_destinations.retrieve", s, {
          route: "/v1/organizations/telemetry_destinations/{destination_id}",
          attributes: { "anthropic.organization.telemetry_destination.id": e }
        })
      });
    }
    /**
     * Change a telemetry destination's settings, its state, or which workspaces it
     * covers.
     *
     * Send at least one field. Omitted fields keep their stored values, except the
     * registered headers, which a change of the endpoint's hostname or port removes.
     * Only `display_name`, `traces`, `traces.endpoint_url`, `traces.content_mode`,
     * `traces.max_content_bytes`, and individual `headers` values accept `null`.
     *
     * If another request changes the destination while the update runs, the API
     * returns a 409 `conflict_error`. Read the destination again, then retry the
     * update.
     *
     * See the
     * [OpenTelemetry export guide](https://platform.claude.com/docs/en/manage-claude/opentelemetry#delivery-and-health)
     * to learn more about changing a destination.
     *
     * @example
     * ```ts
     * const betaTelemetryDestination =
     *   await client.beta.organization.telemetryDestinations.update(
     *     'destination_id',
     *   );
     * ```
     */
    update(e, t, s) {
      const { betas: i, ...a } = t;
      return this._client.post(f`/v1/organizations/telemetry_destinations/${e}?beta=true`, {
        body: a,
        ...s,
        headers: p([
          { "anthropic-beta": [...i ?? [], "telemetry-destinations-2026-08-11"].toString() },
          s?.headers
        ]),
        __span: u(this._client, "anthropic.organization.telemetry_destinations.update", s, {
          route: "/v1/organizations/telemetry_destinations/{destination_id}",
          attributes: { "anthropic.organization.telemetry_destination.id": e }
        })
      });
    }
    /**
     * List the organization's destinations, newest first, optionally only those that
     * cover given workspaces.
     *
     * See the
     * [OpenTelemetry export guide](https://platform.claude.com/docs/en/manage-claude/opentelemetry#set-up-api-tracing)
     * to learn more about destinations.
     *
     * @example
     * ```ts
     * // Automatically fetches more pages as needed.
     * for await (const betaTelemetryDestination of client.beta.organization.telemetryDestinations.list()) {
     *   // ...
     * }
     * ```
     */
    list(e = {}, t) {
      const { betas: s, ...i } = e ?? {};
      return this._client.getAPIList("/v1/organizations/telemetry_destinations?beta=true", P, {
        query: i,
        ...t,
        headers: p([
          { "anthropic-beta": [...s ?? [], "telemetry-destinations-2026-08-11"].toString() },
          t?.headers
        ]),
        __span: u(this._client, "anthropic.organization.telemetry_destinations.list", t, {
          route: "/v1/organizations/telemetry_destinations",
          queryParams: ["limit", "page", "workspace_ids"]
        })
      });
    }
    /**
     * Delete a destination and its workspace list.
     *
     * The API stops sending spans to the destination. The spans of the workspaces it
     * covered still go to the other destinations that cover them. A deleted
     * destination can't be read, listed, or restored.
     *
     * See the
     * [OpenTelemetry export guide](https://platform.claude.com/docs/en/manage-claude/opentelemetry#delivery-and-health)
     * to learn more about managing a destination.
     *
     * @example
     * ```ts
     * const betaDeletedTelemetryDestination =
     *   await client.beta.organization.telemetryDestinations.delete(
     *     'destination_id',
     *   );
     * ```
     */
    delete(e, t = {}, s) {
      const { betas: i } = t ?? {};
      return this._client.delete(f`/v1/organizations/telemetry_destinations/${e}?beta=true`, {
        ...s,
        headers: p([
          { "anthropic-beta": [...i ?? [], "telemetry-destinations-2026-08-11"].toString() },
          s?.headers
        ]),
        __span: u(this._client, "anthropic.organization.telemetry_destinations.delete", s, {
          route: "/v1/organizations/telemetry_destinations/{destination_id}",
          attributes: { "anthropic.organization.telemetry_destination.id": e }
        })
      });
    }
    /**
     * Send one test span, named `anthropic.test`, to the destination with its
     * registered headers, once and without retries, and report the destination's
     * answer. The response is 200 whether or not the destination answered with a 2xx
     * status: its `result` has the type `success`, or the type `failure` and the
     * reason in `error`. The destination's configuration, `state` and
     * `delivery_health` do not change. A disabled destination can be tested too. Wait
     * 10 seconds between tests of one destination; a request that comes sooner may be
     * answered with status 429.
     *
     * @example
     * ```ts
     * const betaTelemetryDestinationTestResponse =
     *   await client.beta.organization.telemetryDestinations.test(
     *     'destination_id',
     *   );
     * ```
     */
    test(e, t = {}, s) {
      const { betas: i } = t ?? {};
      return this._client.post(f`/v1/organizations/telemetry_destinations/${e}/test?beta=true`, {
        ...s,
        headers: p([
          { "anthropic-beta": [...i ?? [], "telemetry-destinations-2026-08-11"].toString() },
          s?.headers
        ]),
        __span: u(this._client, "anthropic.organization.telemetry_destinations.test", s, {
          route: "/v1/organizations/telemetry_destinations/{destination_id}/test",
          attributes: { "anthropic.organization.telemetry_destination.id": e }
        })
      });
    }
  }
  return r.Workspaces = Co, r;
})();
let Io = class extends T {
  /**
   * Get Workspace Member
   *
   * @example
   * ```ts
   * const betaWorkspaceMember =
   *   await client.beta.organization.workspaces.members.retrieve(
   *     'user_id',
   *     { workspace_id: 'workspace_id' },
   *   );
   * ```
   */
  retrieve(n, e, t) {
    const { workspace_id: s } = e;
    return this._client.get(f`/v1/organizations/workspaces/${s}/members/${n}?beta=true`, {
      ...t,
      __span: u(this._client, "anthropic.organization.workspaces.members.retrieve", t, {
        route: "/v1/organizations/workspaces/{workspace_id}/members/{user_id}",
        attributes: {
          "anthropic.organization.workspace.id": s,
          "anthropic.organization.workspace.member.id": n
        }
      })
    });
  }
  /**
   * Update Workspace Member
   *
   * @example
   * ```ts
   * const betaWorkspaceMember =
   *   await client.beta.organization.workspaces.members.update(
   *     'user_id',
   *     {
   *       workspace_id: 'workspace_id',
   *       workspace_role: 'workspace_admin',
   *     },
   *   );
   * ```
   */
  update(n, e, t) {
    const { workspace_id: s, ...i } = e;
    return this._client.post(f`/v1/organizations/workspaces/${s}/members/${n}?beta=true`, {
      body: i,
      ...t,
      __span: u(this._client, "anthropic.organization.workspaces.members.update", t, {
        route: "/v1/organizations/workspaces/{workspace_id}/members/{user_id}",
        attributes: {
          "anthropic.organization.workspace.id": s,
          "anthropic.organization.workspace.member.id": n
        }
      })
    });
  }
  /**
   * List Workspace Members
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaWorkspaceMember of client.beta.organization.workspaces.members.list(
   *   'workspace_id',
   * )) {
   *   // ...
   * }
   * ```
   */
  list(n, e = {}, t) {
    return this._client.getAPIList(f`/v1/organizations/workspaces/${n}/members?beta=true`, Y, {
      query: e,
      ...t,
      __span: u(this._client, "anthropic.organization.workspaces.members.list", t, {
        route: "/v1/organizations/workspaces/{workspace_id}/members",
        queryParams: ["after_id", "before_id", "limit"],
        attributes: { "anthropic.organization.workspace.id": n }
      })
    });
  }
  /**
   * Create Workspace Member
   *
   * @example
   * ```ts
   * const betaWorkspaceMember =
   *   await client.beta.organization.workspaces.members.add(
   *     'workspace_id',
   *     {
   *       user_id: 'user_01WCz1FkmYMm4gnmykNKUu3Q',
   *       workspace_role: 'workspace_admin',
   *     },
   *   );
   * ```
   */
  add(n, e, t) {
    return this._client.post(f`/v1/organizations/workspaces/${n}/members?beta=true`, {
      body: e,
      ...t,
      __span: u(this._client, "anthropic.organization.workspaces.members.add", t, {
        route: "/v1/organizations/workspaces/{workspace_id}/members",
        attributes: { "anthropic.organization.workspace.id": n },
        createdIDAttribute: "anthropic.organization.workspace.member.id",
        createdIDField: "user_id"
      })
    });
  }
  /**
   * Delete Workspace Member
   *
   * @example
   * ```ts
   * const member =
   *   await client.beta.organization.workspaces.members.remove(
   *     'user_id',
   *     { workspace_id: 'workspace_id' },
   *   );
   * ```
   */
  remove(n, e, t) {
    const { workspace_id: s } = e;
    return this._client.delete(f`/v1/organizations/workspaces/${s}/members/${n}?beta=true`, {
      ...t,
      __span: u(this._client, "anthropic.organization.workspaces.members.remove", t, {
        route: "/v1/organizations/workspaces/{workspace_id}/members/{user_id}",
        attributes: {
          "anthropic.organization.workspace.id": s,
          "anthropic.organization.workspace.member.id": n
        }
      })
    });
  }
}, No = class extends T {
  /**
   * Set or clear rate-limit overrides for one rate-limit group in a workspace.
   *
   * Only the limiter types named in `limits` change: an integer `value` sets that
   * type's override and `null` clears it. Types not named keep their current value.
   * A value above the organization's own limit is stored, but the organization limit
   * still applies, so the lower of the two is enforced.
   *
   * Returns the targeted group's entry with this request applied, in the shape
   * `GET /v1/organizations/workspaces/{workspace_id}/rate_limits` returns. Changes
   * take effect within about an hour.
   *
   * @example
   * ```ts
   * const betaWorkspaceRateLimit =
   *   await client.beta.organization.workspaces.rateLimits.update(
   *     'rate_limit_id',
   *     {
   *       workspace_id: 'workspace_id',
   *       limits: [{ type: 'fast_itpmca', value: 0 }],
   *     },
   *   );
   * ```
   */
  update(n, e, t) {
    const { workspace_id: s, ...i } = e;
    return this._client.post(f`/v1/organizations/workspaces/${s}/rate_limits/${n}?beta=true`, {
      body: i,
      ...t,
      __span: u(this._client, "anthropic.organization.workspaces.rate_limits.update", t, {
        route: "/v1/organizations/workspaces/{workspace_id}/rate_limits/{rate_limit_id}",
        attributes: {
          "anthropic.organization.workspace.id": s,
          "anthropic.organization.workspace.rate_limit.id": n
        }
      })
    });
  }
  /**
   * List a workspace's rate limits.
   *
   * By default, returns only the groups and limiter types that have a
   * workspace-level override. With `include_inherited=true`, returns every group
   * with organization-level limits the workspace can see, listing for each the
   * values it inherits from the organization as well as its own overrides. Each
   * value's `source` says which it is.
   *
   * When `limit` is omitted, every matching entry is returned in a single page; when
   * `limit` truncates the result, follow `next_page` to fetch the remaining entries.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaWorkspaceRateLimit of client.beta.organization.workspaces.rateLimits.list(
   *   'workspace_id',
   * )) {
   *   // ...
   * }
   * ```
   */
  list(n, e = {}, t) {
    return this._client.getAPIList(f`/v1/organizations/workspaces/${n}/rate_limits?beta=true`, P, {
      query: e,
      ...t,
      __span: u(this._client, "anthropic.organization.workspaces.rate_limits.list", t, {
        route: "/v1/organizations/workspaces/{workspace_id}/rate_limits",
        queryParams: ["group_type", "include_inherited", "limit", "page"],
        attributes: { "anthropic.organization.workspace.id": n }
      })
    });
  }
}, Lo = class extends T {
  /**
   * **Requires an OAuth access token with the `org:admin` scope**, from
   * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
   * API keys are not accepted. See
   * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
   *
   * Retrieve a service account's membership in a workspace.
   *
   * Returns the membership record, including the service account's `workspace_role`
   * in this workspace. Archived workspaces return 400. For the default workspace,
   * returns the implicit (`implicit: true`) membership when no explicit membership
   * exists; an explicitly added membership is returned with its assigned role. An
   * archived service account returns 404.
   *
   * @example
   * ```ts
   * const betaServiceAccountWorkspaceMember =
   *   await client.beta.organization.workspaces.serviceAccounts.retrieve(
   *     'service_account_id',
   *     { workspace_id: 'workspace_id' },
   *   );
   * ```
   */
  retrieve(n, e, t) {
    const { workspace_id: s, betas: i } = e;
    return this._client.get(f`/v1/organizations/workspaces/${s}/service_accounts/${n}?beta=true`, {
      ...t,
      headers: p([
        { ...i?.toString() != null ? { "anthropic-beta": i?.toString() } : void 0 },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.organization.workspaces.service_accounts.retrieve", t, {
        route: "/v1/organizations/workspaces/{workspace_id}/service_accounts/{service_account_id}",
        attributes: {
          "anthropic.organization.workspace.id": s,
          "anthropic.organization.workspace.service_account.id": n
        }
      })
    });
  }
  /**
   * **Requires an OAuth access token with the `org:admin` scope**, from
   * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
   * API keys are not accepted. See
   * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
   *
   * Change a service account's role in a workspace.
   *
   * The new `workspace_role` replaces the current one. Only explicit memberships can
   * be updated; to set a role on the implicit default-workspace membership, add the
   * service account explicitly with
   * `POST /workspaces/{workspace_id}/service_accounts`. Archived workspaces
   * return 400. Archived service accounts cannot be updated and are rejected.
   *
   * @example
   * ```ts
   * const betaServiceAccountWorkspaceMember =
   *   await client.beta.organization.workspaces.serviceAccounts.update(
   *     'service_account_id',
   *     {
   *       workspace_id: 'workspace_id',
   *       workspace_role: 'workspace_admin',
   *     },
   *   );
   * ```
   */
  update(n, e, t) {
    const { workspace_id: s, betas: i, ...a } = e;
    return this._client.post(f`/v1/organizations/workspaces/${s}/service_accounts/${n}?beta=true`, {
      body: a,
      ...t,
      headers: p([
        { ...i?.toString() != null ? { "anthropic-beta": i?.toString() } : void 0 },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.organization.workspaces.service_accounts.update", t, {
        route: "/v1/organizations/workspaces/{workspace_id}/service_accounts/{service_account_id}",
        attributes: {
          "anthropic.organization.workspace.id": s,
          "anthropic.organization.workspace.service_account.id": n
        }
      })
    });
  }
  /**
   * **Requires an OAuth access token with the `org:admin` scope**, from
   * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
   * API keys are not accepted. See
   * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
   *
   * List the service accounts that are members of a workspace.
   *
   * Each entry includes the service account's `workspace_role`. Use `limit` and the
   * `next_page` cursor to paginate. Archived workspaces return 400; use
   * `GET /service_accounts/{id}/workspaces` to audit memberships of an archived
   * workspace. The implicit default-workspace membership is not included in this
   * list. Memberships of archived service accounts are omitted from the results.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaServiceAccountWorkspaceMember of client.beta.organization.workspaces.serviceAccounts.list(
   *   'workspace_id',
   * )) {
   *   // ...
   * }
   * ```
   */
  list(n, e = {}, t) {
    const { betas: s, ...i } = e ?? {};
    return this._client.getAPIList(f`/v1/organizations/workspaces/${n}/service_accounts?beta=true`, P, {
      query: i,
      ...t,
      headers: p([
        { ...s?.toString() != null ? { "anthropic-beta": s?.toString() } : void 0 },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.organization.workspaces.service_accounts.list", t, {
        route: "/v1/organizations/workspaces/{workspace_id}/service_accounts",
        queryParams: ["limit", "page"],
        attributes: { "anthropic.organization.workspace.id": n }
      })
    });
  }
  /**
   * **Requires an OAuth access token with the `org:admin` scope**, from
   * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
   * API keys are not accepted. See
   * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
   *
   * Add a service account to a workspace with the given `workspace_role`.
   *
   * The role determines what the service account can do in the workspace and which
   * workspace-scoped permissions it can be granted when authenticating through
   * federation. Every service account is already an implicit `workspace_user` member
   * of the default workspace; adding it explicitly assigns a chosen role. If the
   * service account is already an explicit member of the workspace, its
   * `workspace_role` is replaced with the value supplied here. Archived workspaces
   * return 400. Archived service accounts cannot be added and are rejected.
   *
   * @example
   * ```ts
   * const betaServiceAccountWorkspaceMember =
   *   await client.beta.organization.workspaces.serviceAccounts.add(
   *     'workspace_id',
   *     {
   *       service_account_id: 'service_account_id',
   *       workspace_role: 'workspace_admin',
   *     },
   *   );
   * ```
   */
  add(n, e, t) {
    const { betas: s, ...i } = e;
    return this._client.post(f`/v1/organizations/workspaces/${n}/service_accounts?beta=true`, {
      body: i,
      ...t,
      headers: p([
        { ...s?.toString() != null ? { "anthropic-beta": s?.toString() } : void 0 },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.organization.workspaces.service_accounts.add", t, {
        route: "/v1/organizations/workspaces/{workspace_id}/service_accounts",
        attributes: { "anthropic.organization.workspace.id": n },
        createdIDAttribute: "anthropic.organization.workspace.service_account.id",
        createdIDField: "service_account_id"
      })
    });
  }
  /**
   * **Requires an OAuth access token with the `org:admin` scope**, from
   * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
   * API keys are not accepted. See
   * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
   *
   * Remove a service account from a workspace.
   *
   * Removal is idempotent (returns 200 even if the membership was already removed).
   * A DELETE against the implicit default-workspace membership returns 200 but is a
   * no-op and the membership persists; deleting an explicit default-workspace row
   * reverts to the implicit `workspace_user` membership. Archived workspaces
   * return 400.
   *
   * @example
   * ```ts
   * const serviceAccount =
   *   await client.beta.organization.workspaces.serviceAccounts.remove(
   *     'service_account_id',
   *     { workspace_id: 'workspace_id' },
   *   );
   * ```
   */
  remove(n, e, t) {
    const { workspace_id: s, betas: i } = e;
    return this._client.delete(f`/v1/organizations/workspaces/${s}/service_accounts/${n}?beta=true`, {
      ...t,
      headers: p([
        { ...i?.toString() != null ? { "anthropic-beta": i?.toString() } : void 0 },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.organization.workspaces.service_accounts.remove", t, {
        route: "/v1/organizations/workspaces/{workspace_id}/service_accounts/{service_account_id}",
        attributes: {
          "anthropic.organization.workspace.id": s,
          "anthropic.organization.workspace.service_account.id": n
        }
      })
    });
  }
};
var qo = /* @__PURE__ */ (() => {
  class r extends T {
    constructor() {
      super(...arguments), this.rateLimits = new No(this._client), this.members = new Io(this._client), this.serviceAccounts = new Lo(this._client);
    }
    /**
     * Create Workspace
     *
     * @example
     * ```ts
     * const betaWorkspace =
     *   await client.beta.organization.workspaces.create({
     *     name: 'x',
     *   });
     * ```
     */
    create(e, t) {
      const { betas: s, ...i } = e;
      return this._client.post("/v1/organizations/workspaces?beta=true", {
        body: i,
        ...t,
        headers: p([
          { ...s?.toString() != null ? { "anthropic-beta": s?.toString() } : void 0 },
          t?.headers
        ]),
        __span: u(this._client, "anthropic.organization.workspaces.create", t, {
          route: "/v1/organizations/workspaces",
          createdIDAttribute: "anthropic.organization.workspace.id"
        })
      });
    }
    /**
     * Get Workspace
     *
     * @example
     * ```ts
     * const betaWorkspace =
     *   await client.beta.organization.workspaces.retrieve(
     *     'workspace_id',
     *   );
     * ```
     */
    retrieve(e, t) {
      return this._client.get(f`/v1/organizations/workspaces/${e}?beta=true`, {
        ...t,
        __span: u(this._client, "anthropic.organization.workspaces.retrieve", t, {
          route: "/v1/organizations/workspaces/{workspace_id}",
          attributes: { "anthropic.organization.workspace.id": e }
        })
      });
    }
    /**
     * Update Workspace
     *
     * @example
     * ```ts
     * const betaWorkspace =
     *   await client.beta.organization.workspaces.update(
     *     'workspace_id',
     *   );
     * ```
     */
    update(e, t, s) {
      return this._client.post(f`/v1/organizations/workspaces/${e}?beta=true`, {
        body: t,
        ...s,
        __span: u(this._client, "anthropic.organization.workspaces.update", s, {
          route: "/v1/organizations/workspaces/{workspace_id}",
          attributes: { "anthropic.organization.workspace.id": e }
        })
      });
    }
    /**
     * List Workspaces
     *
     * @example
     * ```ts
     * // Automatically fetches more pages as needed.
     * for await (const betaWorkspace of client.beta.organization.workspaces.list()) {
     *   // ...
     * }
     * ```
     */
    list(e = {}, t) {
      return this._client.getAPIList("/v1/organizations/workspaces?beta=true", Y, {
        query: e,
        ...t,
        __span: u(this._client, "anthropic.organization.workspaces.list", t, {
          route: "/v1/organizations/workspaces",
          queryParams: ["after_id", "before_id", "include_archived", "include_default", "limit"]
        })
      });
    }
    /**
     * Archive Workspace
     *
     * @example
     * ```ts
     * const betaWorkspace =
     *   await client.beta.organization.workspaces.archive(
     *     'workspace_id',
     *   );
     * ```
     */
    archive(e, t) {
      return this._client.post(f`/v1/organizations/workspaces/${e}/archive?beta=true`, {
        ...t,
        __span: u(this._client, "anthropic.organization.workspaces.archive", t, {
          route: "/v1/organizations/workspaces/{workspace_id}/archive",
          attributes: { "anthropic.organization.workspace.id": e }
        })
      });
    }
  }
  return r.RateLimits = No, r.Members = Io, r.ServiceAccounts = Lo, r;
})(), Bo = /* @__PURE__ */ (() => {
  class r extends T {
    constructor() {
      super(...arguments), this.apiKeys = new Ga(this._client), this.externalKeys = new lo(this._client), this.federation = new po(this._client), this.invites = new fo(this._client), this.serviceAccounts = new Po(this._client), this.users = new bo(this._client), this.workspaces = new qo(this._client), this.rateLimits = new mo(this._client), this.complianceSettings = new co(this._client), this.analytics = new oo(this._client), this.spendLimits = new Oo(this._client), this.rbacGroups = new Ao(this._client), this.rbacRoles = new Eo(this._client), this.plugins = new So(this._client), this.pluginMarketplaces = new go(this._client), this.telemetryDestinations = new $o(this._client), this.webhooks = new wo(this._client);
    }
    /**
     * Retrieve information about the organization associated with the authenticated
     * API key.
     *
     * @example
     * ```ts
     * const betaOrganization =
     *   await client.beta.organization.retrieve();
     * ```
     */
    retrieve(e) {
      return this._client.get("/v1/organizations/me?beta=true", {
        ...e,
        __span: u(this._client, "anthropic.organization.retrieve", e, {
          route: "/v1/organizations/me"
        })
      });
    }
  }
  return r.APIKeys = Ga, r.ExternalKeys = lo, r.Federation = po, r.Invites = fo, r.ServiceAccounts = Po, r.Users = bo, r.Workspaces = qo, r.RateLimits = mo, r.ComplianceSettings = co, r.Analytics = oo, r.SpendLimits = Oo, r.RBACGroups = Ao, r.RBACRoles = Eo, r.Plugins = So, r.PluginMarketplaces = go, r.TelemetryDestinations = $o, r.Webhooks = wo, r;
})(), Uo = /* @__PURE__ */ (() => {
  class r extends T {
    /**
     * List Events
     *
     * @example
     * ```ts
     * // Automatically fetches more pages as needed.
     * for await (const betaManagedAgentsSessionEvent of client.beta.sessions.events.list(
     *   'sesn_011CZkZAtmR3yMPDzynEDxu7',
     * )) {
     *   // ...
     * }
     * ```
     */
    list(e, t = {}, s) {
      const { betas: i, workspace_id: a, ...o } = t ?? {};
      return this._client.getAPIList(f`/v1/sessions/${e}/events?beta=true`, P, {
        query: o,
        ...s,
        headers: p([
          {
            "anthropic-beta": [...i ?? [], "managed-agents-2026-04-01"].toString(),
            ...a != null ? { "anthropic-workspace-id": a } : void 0
          },
          s?.headers
        ]),
        __span: u(this._client, "anthropic.sessions.events.list", s, {
          route: "/v1/sessions/{session_id}/events",
          queryParams: [
            "created_at[gt]",
            "created_at[gte]",
            "created_at[lt]",
            "created_at[lte]",
            "limit",
            "order",
            "page",
            "types"
          ],
          attributes: { "anthropic.session.id": e }
        })
      });
    }
    /**
     * Send Events
     *
     * @example
     * ```ts
     * const betaManagedAgentsSendSessionEvents =
     *   await client.beta.sessions.events.send(
     *     'sesn_011CZkZAtmR3yMPDzynEDxu7',
     *     {
     *       events: [
     *         {
     *           content: [
     *             {
     *               text: 'Where is my order #1234?',
     *               type: 'text',
     *             },
     *           ],
     *           type: 'user.message',
     *         },
     *       ],
     *     },
     *   );
     * ```
     */
    send(e, t, s) {
      const { betas: i, workspace_id: a, ...o } = t;
      return this._client.post(f`/v1/sessions/${e}/events?beta=true`, {
        body: o,
        ...s,
        headers: p([
          {
            "anthropic-beta": [...i ?? [], "managed-agents-2026-04-01"].toString(),
            ...a != null ? { "anthropic-workspace-id": a } : void 0
          },
          s?.headers
        ]),
        __span: u(this._client, "anthropic.sessions.events.send", s, {
          route: "/v1/sessions/{session_id}/events",
          attributes: { "anthropic.session.id": e }
        })
      });
    }
    /**
     * Stream Events
     *
     * @example
     * ```ts
     * const stream = await client.beta.sessions.events.stream(
     *   'sesn_011CZkZAtmR3yMPDzynEDxu7',
     * );
     * for await (const betaManagedAgentsStreamSessionEvents of stream) {
     *   // ...
     * }
     * ```
     */
    stream(e, t = {}, s) {
      const { betas: i, workspace_id: a, ...o } = t ?? {};
      return this._client.get(f`/v1/sessions/${e}/events/stream?beta=true`, {
        query: o,
        ...s,
        headers: p([
          {
            "anthropic-beta": [...i ?? [], "managed-agents-2026-04-01"].toString(),
            ...a != null ? { "anthropic-workspace-id": a } : void 0
          },
          s?.headers
        ]),
        stream: !0,
        __span: u(this._client, "anthropic.sessions.events.stream", s, {
          route: "/v1/sessions/{session_id}/events/stream",
          queryParams: ["event_deltas"],
          attributes: { "anthropic.session.id": e }
        })
      });
    }
    /**
     * Attach to a session and dispatch every incoming `agent.tool_use` and
     * `agent.custom_tool_use` event to a local tool registry, sending the matching
     * result back (`user.tool_result` / `user.custom_tool_result`). The
     * sessions-side counterpart to `client.beta.messages.toolRunner`: yields one
     * entry per completed tool call so callers can observe each dispatch (and
     * `break` to abort cleanly).
     *
     * @example
     * ```ts
     * import { betaAgentToolset20260401 } from '@anthropic-ai/sdk/tools/agent-toolset/node';
     *
     * for await (const call of client.beta.sessions.events.toolRunner(work.data.id, {
     *   tools: [...betaAgentToolset20260401({ workdir }), myTool],
     * })) {
     *   console.log(`${call.name} -> ${call.isError ? 'error' : 'ok'}`);
     * }
     * ```
     */
    toolRunner(e, t) {
      return new Zs(e, { ...t, client: this._client });
    }
  }
  return r.SessionToolRunner = Zs, r;
})();
class Fo extends T {
  /**
   * Get Session Resource
   *
   * @example
   * ```ts
   * const resource =
   *   await client.beta.sessions.resources.retrieve(
   *     'sesrsc_011CZkZBJq5dWxk9fVLNcPht',
   *     { session_id: 'sesn_011CZkZAtmR3yMPDzynEDxu7' },
   *   );
   * ```
   */
  retrieve(n, e, t) {
    const { session_id: s, betas: i, workspace_id: a } = e;
    return this._client.get(f`/v1/sessions/${s}/resources/${n}?beta=true`, {
      ...t,
      headers: p([
        {
          "anthropic-beta": [...i ?? [], "managed-agents-2026-04-01"].toString(),
          ...a != null ? { "anthropic-workspace-id": a } : void 0
        },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.sessions.resources.retrieve", t, {
        route: "/v1/sessions/{session_id}/resources/{resource_id}",
        attributes: { "anthropic.session.id": s, "anthropic.session.resource.id": n }
      })
    });
  }
  /**
   * Update Session Resource
   *
   * @example
   * ```ts
   * const resource =
   *   await client.beta.sessions.resources.update(
   *     'sesrsc_011CZkZBJq5dWxk9fVLNcPht',
   *     {
   *       session_id: 'sesn_011CZkZAtmR3yMPDzynEDxu7',
   *       authorization_token: 'ghp_exampletoken',
   *     },
   *   );
   * ```
   */
  update(n, e, t) {
    const { session_id: s, betas: i, workspace_id: a, ...o } = e;
    return this._client.post(f`/v1/sessions/${s}/resources/${n}?beta=true`, {
      body: o,
      ...t,
      headers: p([
        {
          "anthropic-beta": [...i ?? [], "managed-agents-2026-04-01"].toString(),
          ...a != null ? { "anthropic-workspace-id": a } : void 0
        },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.sessions.resources.update", t, {
        route: "/v1/sessions/{session_id}/resources/{resource_id}",
        attributes: { "anthropic.session.id": s, "anthropic.session.resource.id": n }
      })
    });
  }
  /**
   * List Session Resources
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaManagedAgentsSessionResource of client.beta.sessions.resources.list(
   *   'sesn_011CZkZAtmR3yMPDzynEDxu7',
   * )) {
   *   // ...
   * }
   * ```
   */
  list(n, e = {}, t) {
    const { betas: s, workspace_id: i, ...a } = e ?? {};
    return this._client.getAPIList(f`/v1/sessions/${n}/resources?beta=true`, P, {
      query: a,
      ...t,
      headers: p([
        {
          "anthropic-beta": [...s ?? [], "managed-agents-2026-04-01"].toString(),
          ...i != null ? { "anthropic-workspace-id": i } : void 0
        },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.sessions.resources.list", t, {
        route: "/v1/sessions/{session_id}/resources",
        queryParams: ["limit", "page"],
        attributes: { "anthropic.session.id": n }
      })
    });
  }
  /**
   * Delete Session Resource
   *
   * @example
   * ```ts
   * const betaManagedAgentsDeleteSessionResource =
   *   await client.beta.sessions.resources.delete(
   *     'sesrsc_011CZkZBJq5dWxk9fVLNcPht',
   *     { session_id: 'sesn_011CZkZAtmR3yMPDzynEDxu7' },
   *   );
   * ```
   */
  delete(n, e, t) {
    const { session_id: s, betas: i, workspace_id: a } = e;
    return this._client.delete(f`/v1/sessions/${s}/resources/${n}?beta=true`, {
      ...t,
      headers: p([
        {
          "anthropic-beta": [...i ?? [], "managed-agents-2026-04-01"].toString(),
          ...a != null ? { "anthropic-workspace-id": a } : void 0
        },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.sessions.resources.delete", t, {
        route: "/v1/sessions/{session_id}/resources/{resource_id}",
        attributes: { "anthropic.session.id": s, "anthropic.session.resource.id": n }
      })
    });
  }
  /**
   * Add Session Resource
   *
   * @example
   * ```ts
   * const betaManagedAgentsFileResource =
   *   await client.beta.sessions.resources.add(
   *     'sesn_011CZkZAtmR3yMPDzynEDxu7',
   *     {
   *       file_id: 'file_011CNha8iCJcU1wXNR6q4V8w',
   *       type: 'file',
   *     },
   *   );
   * ```
   */
  add(n, e, t) {
    const { betas: s, workspace_id: i, ...a } = e;
    return this._client.post(f`/v1/sessions/${n}/resources?beta=true`, {
      body: a,
      ...t,
      headers: p([
        {
          "anthropic-beta": [...s ?? [], "managed-agents-2026-04-01"].toString(),
          ...i != null ? { "anthropic-workspace-id": i } : void 0
        },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.sessions.resources.add", t, {
        route: "/v1/sessions/{session_id}/resources",
        attributes: { "anthropic.session.id": n },
        createdIDAttribute: "anthropic.session.resource.id"
      })
    });
  }
}
class Wo extends T {
  /**
   * List Session Thread Events
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaManagedAgentsSessionEvent of client.beta.sessions.threads.events.list(
   *   'sthr_011CZkZVWa6oJjw1rgXZpnBt',
   *   { session_id: 'sesn_011CZkZAtmR3yMPDzynEDxu7' },
   * )) {
   *   // ...
   * }
   * ```
   */
  list(n, e, t) {
    const { session_id: s, betas: i, workspace_id: a, ...o } = e;
    return this._client.getAPIList(f`/v1/sessions/${s}/threads/${n}/events?beta=true`, P, {
      query: o,
      ...t,
      headers: p([
        {
          "anthropic-beta": [...i ?? [], "managed-agents-2026-04-01"].toString(),
          ...a != null ? { "anthropic-workspace-id": a } : void 0
        },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.sessions.threads.events.list", t, {
        route: "/v1/sessions/{session_id}/threads/{thread_id}/events",
        queryParams: ["limit", "page"],
        attributes: { "anthropic.session.id": s, "anthropic.session.thread.id": n }
      })
    });
  }
  /**
   * Stream Session Thread Events
   *
   * @example
   * ```ts
   * const stream =
   *   await client.beta.sessions.threads.events.stream(
   *     'sthr_011CZkZVWa6oJjw1rgXZpnBt',
   *     { session_id: 'sesn_011CZkZAtmR3yMPDzynEDxu7' },
   *   );
   * for await (const betaManagedAgentsStreamSessionThreadEvents of stream) {
   *   // ...
   * }
   * ```
   */
  stream(n, e, t) {
    const { session_id: s, betas: i, workspace_id: a, ...o } = e;
    return this._client.get(f`/v1/sessions/${s}/threads/${n}/stream?beta=true`, {
      query: o,
      ...t,
      headers: p([
        {
          "anthropic-beta": [...i ?? [], "managed-agents-2026-04-01"].toString(),
          ...a != null ? { "anthropic-workspace-id": a } : void 0
        },
        t?.headers
      ]),
      stream: !0,
      __span: u(this._client, "anthropic.sessions.threads.events.stream", t, {
        route: "/v1/sessions/{session_id}/threads/{thread_id}/stream",
        queryParams: ["event_deltas"],
        attributes: { "anthropic.session.id": s, "anthropic.session.thread.id": n }
      })
    });
  }
}
var jo = /* @__PURE__ */ (() => {
  class r extends T {
    constructor() {
      super(...arguments), this.events = new Wo(this._client);
    }
    /**
     * Get Session Thread
     *
     * @example
     * ```ts
     * const betaManagedAgentsSessionThread =
     *   await client.beta.sessions.threads.retrieve(
     *     'sthr_011CZkZVWa6oJjw1rgXZpnBt',
     *     { session_id: 'sesn_011CZkZAtmR3yMPDzynEDxu7' },
     *   );
     * ```
     */
    retrieve(e, t, s) {
      const { session_id: i, betas: a, workspace_id: o } = t;
      return this._client.get(f`/v1/sessions/${i}/threads/${e}?beta=true`, {
        ...s,
        headers: p([
          {
            "anthropic-beta": [...a ?? [], "managed-agents-2026-04-01"].toString(),
            ...o != null ? { "anthropic-workspace-id": o } : void 0
          },
          s?.headers
        ]),
        __span: u(this._client, "anthropic.sessions.threads.retrieve", s, {
          route: "/v1/sessions/{session_id}/threads/{thread_id}",
          attributes: { "anthropic.session.id": i, "anthropic.session.thread.id": e }
        })
      });
    }
    /**
     * List Session Threads
     *
     * @example
     * ```ts
     * // Automatically fetches more pages as needed.
     * for await (const betaManagedAgentsSessionThread of client.beta.sessions.threads.list(
     *   'sesn_011CZkZAtmR3yMPDzynEDxu7',
     * )) {
     *   // ...
     * }
     * ```
     */
    list(e, t = {}, s) {
      const { betas: i, workspace_id: a, ...o } = t ?? {};
      return this._client.getAPIList(f`/v1/sessions/${e}/threads?beta=true`, P, {
        query: o,
        ...s,
        headers: p([
          {
            "anthropic-beta": [...i ?? [], "managed-agents-2026-04-01"].toString(),
            ...a != null ? { "anthropic-workspace-id": a } : void 0
          },
          s?.headers
        ]),
        __span: u(this._client, "anthropic.sessions.threads.list", s, {
          route: "/v1/sessions/{session_id}/threads",
          queryParams: ["limit", "page", "statuses"],
          attributes: { "anthropic.session.id": e }
        })
      });
    }
    /**
     * Archive Session Thread
     *
     * @example
     * ```ts
     * const betaManagedAgentsSessionThread =
     *   await client.beta.sessions.threads.archive(
     *     'sthr_011CZkZVWa6oJjw1rgXZpnBt',
     *     { session_id: 'sesn_011CZkZAtmR3yMPDzynEDxu7' },
     *   );
     * ```
     */
    archive(e, t, s) {
      const { session_id: i, betas: a, workspace_id: o } = t;
      return this._client.post(f`/v1/sessions/${i}/threads/${e}/archive?beta=true`, {
        ...s,
        headers: p([
          {
            "anthropic-beta": [...a ?? [], "managed-agents-2026-04-01"].toString(),
            ...o != null ? { "anthropic-workspace-id": o } : void 0
          },
          s?.headers
        ]),
        __span: u(this._client, "anthropic.sessions.threads.archive", s, {
          route: "/v1/sessions/{session_id}/threads/{thread_id}/archive",
          attributes: { "anthropic.session.id": i, "anthropic.session.thread.id": e }
        })
      });
    }
  }
  return r.Events = Wo, r;
})(), Ho = /* @__PURE__ */ (() => {
  class r extends T {
    constructor() {
      super(...arguments), this.events = new Uo(this._client), this.resources = new Fo(this._client), this.threads = new jo(this._client);
    }
    /**
     * Create Session
     *
     * @example
     * ```ts
     * const betaManagedAgentsSession =
     *   await client.beta.sessions.create({
     *     agent: 'agent_011CZkYpogX7uDKUyvBTophP',
     *     environment_id: 'env_011CZkZ9X2dpNyB7HsEFoRfW',
     *     initial_events: [
     *       {
     *         type: 'user.message',
     *         content: [
     *           {
     *             type: 'text',
     *             text: 'Where is my order #1234?',
     *           },
     *         ],
     *       },
     *     ],
     *   });
     * ```
     */
    create(e, t) {
      const { betas: s, workspace_id: i, ...a } = e, o = p([
        {
          "anthropic-beta": [...s ?? [], "managed-agents-2026-04-01"].toString(),
          ...i != null ? { "anthropic-workspace-id": i } : void 0
        },
        t?.headers
      ]), l = u(this._client, "anthropic.sessions.create", t, {
        route: "/v1/sessions",
        attributes: {
          // An `agent` that is no agent is for the API to refuse, not for this line to throw on.
          "gen_ai.agent.id": typeof a.agent == "object" ? a.agent?.id : a.agent,
          "anthropic.session.environment.id": a.environment_id
        },
        createdIDAttribute: "anthropic.session.id"
      }), h = this._client.post("/v1/sessions?beta=true", {
        body: a,
        ...t,
        headers: o,
        __span: l
      });
      return l ? h._thenUnwrap((_) => (vp(this._client, l, _), _)) : h;
    }
    /**
     * Get Session
     *
     * @example
     * ```ts
     * const betaManagedAgentsSession =
     *   await client.beta.sessions.retrieve(
     *     'sesn_011CZkZAtmR3yMPDzynEDxu7',
     *   );
     * ```
     */
    retrieve(e, t = {}, s) {
      const { betas: i, workspace_id: a } = t ?? {};
      return this._client.get(f`/v1/sessions/${e}?beta=true`, {
        ...s,
        headers: p([
          {
            "anthropic-beta": [...i ?? [], "managed-agents-2026-04-01"].toString(),
            ...a != null ? { "anthropic-workspace-id": a } : void 0
          },
          s?.headers
        ]),
        __span: u(this._client, "anthropic.sessions.retrieve", s, {
          route: "/v1/sessions/{session_id}",
          attributes: { "anthropic.session.id": e }
        })
      });
    }
    /**
     * Update Session
     *
     * @example
     * ```ts
     * const betaManagedAgentsSession =
     *   await client.beta.sessions.update(
     *     'sesn_011CZkZAtmR3yMPDzynEDxu7',
     *   );
     * ```
     */
    update(e, t, s) {
      const { betas: i, workspace_id: a, ...o } = t;
      return this._client.post(f`/v1/sessions/${e}?beta=true`, {
        body: o,
        ...s,
        headers: p([
          {
            "anthropic-beta": [...i ?? [], "managed-agents-2026-04-01"].toString(),
            ...a != null ? { "anthropic-workspace-id": a } : void 0
          },
          s?.headers
        ]),
        __span: u(this._client, "anthropic.sessions.update", s, {
          route: "/v1/sessions/{session_id}",
          attributes: { "anthropic.session.id": e }
        })
      });
    }
    /**
     * List Sessions
     *
     * @example
     * ```ts
     * // Automatically fetches more pages as needed.
     * for await (const betaManagedAgentsSession of client.beta.sessions.list()) {
     *   // ...
     * }
     * ```
     */
    list(e = {}, t) {
      const { betas: s, workspace_id: i, ...a } = e ?? {};
      return this._client.getAPIList("/v1/sessions?beta=true", Kp, {
        query: a,
        ...t,
        headers: p([
          {
            "anthropic-beta": [...s ?? [], "managed-agents-2026-04-01"].toString(),
            ...i != null ? { "anthropic-workspace-id": i } : void 0
          },
          t?.headers
        ]),
        __span: u(this._client, "anthropic.sessions.list", t, {
          route: "/v1/sessions",
          queryParams: [
            "agent_id",
            "agent_version",
            "created_at[gt]",
            "created_at[gte]",
            "created_at[lt]",
            "created_at[lte]",
            "deployment_id",
            "include_archived",
            "limit",
            "memory_store_id",
            "order",
            "page",
            "statuses"
          ]
        })
      });
    }
    /**
     * Delete Session
     *
     * @example
     * ```ts
     * const betaManagedAgentsDeletedSession =
     *   await client.beta.sessions.delete(
     *     'sesn_011CZkZAtmR3yMPDzynEDxu7',
     *   );
     * ```
     */
    delete(e, t = {}, s) {
      const { betas: i, workspace_id: a } = t ?? {};
      return this._client.delete(f`/v1/sessions/${e}?beta=true`, {
        ...s,
        headers: p([
          {
            "anthropic-beta": [...i ?? [], "managed-agents-2026-04-01"].toString(),
            ...a != null ? { "anthropic-workspace-id": a } : void 0
          },
          s?.headers
        ]),
        __span: u(this._client, "anthropic.sessions.delete", s, {
          route: "/v1/sessions/{session_id}",
          attributes: { "anthropic.session.id": e }
        })
      });
    }
    /**
     * Archive Session
     *
     * @example
     * ```ts
     * const betaManagedAgentsSession =
     *   await client.beta.sessions.archive(
     *     'sesn_011CZkZAtmR3yMPDzynEDxu7',
     *   );
     * ```
     */
    archive(e, t = {}, s) {
      const { betas: i, workspace_id: a } = t ?? {};
      return this._client.post(f`/v1/sessions/${e}/archive?beta=true`, {
        ...s,
        headers: p([
          {
            "anthropic-beta": [...i ?? [], "managed-agents-2026-04-01"].toString(),
            ...a != null ? { "anthropic-workspace-id": a } : void 0
          },
          s?.headers
        ]),
        __span: u(this._client, "anthropic.sessions.archive", s, {
          route: "/v1/sessions/{session_id}/archive",
          attributes: { "anthropic.session.id": e }
        })
      });
    }
  }
  return r.Events = Uo, r.Resources = Fo, r.Threads = jo, r;
})();
let Do = class extends T {
  /**
   * Create Skill Version
   *
   * @example
   * ```ts
   * const betaSkillVersion =
   *   await client.beta.skills.versions.create('skill_id', {
   *     files: [fs.createReadStream('path/to/file')],
   *   });
   * ```
   */
  create(n, e, t) {
    const { betas: s, workspace_id: i, ...a } = e;
    return this._client.post(f`/v1/skills/${n}/versions?beta=true`, Ce({
      body: a,
      ...t,
      headers: p([
        {
          ...s?.toString() != null ? { "anthropic-beta": s?.toString() } : void 0,
          ...i != null ? { "anthropic-workspace-id": i } : void 0
        },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.skills.versions.create", t, {
        route: "/v1/skills/{skill_id}/versions",
        attributes: { "anthropic.skill.id": n },
        createdIDAttribute: "anthropic.skill.version.id"
      })
    }, this._client, !1));
  }
  /**
   * Get Skill Version
   *
   * @example
   * ```ts
   * const betaSkillVersion =
   *   await client.beta.skills.versions.retrieve('version', {
   *     skill_id: 'skill_id',
   *   });
   * ```
   */
  retrieve(n, e, t) {
    const { skill_id: s, betas: i, workspace_id: a } = e;
    return this._client.get(f`/v1/skills/${s}/versions/${n}?beta=true`, {
      ...t,
      headers: p([
        {
          ...i?.toString() != null ? { "anthropic-beta": i?.toString() } : void 0,
          ...a != null ? { "anthropic-workspace-id": a } : void 0
        },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.skills.versions.retrieve", t, {
        route: "/v1/skills/{skill_id}/versions/{version}",
        attributes: { "anthropic.skill.id": s, "anthropic.skill.version.id": n }
      })
    });
  }
  /**
   * List Skill Versions
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaSkillVersion of client.beta.skills.versions.list(
   *   'skill_id',
   * )) {
   *   // ...
   * }
   * ```
   */
  list(n, e = {}, t) {
    const { betas: s, workspace_id: i, ...a } = e ?? {};
    return this._client.getAPIList(f`/v1/skills/${n}/versions?beta=true`, P, {
      query: a,
      ...t,
      headers: p([
        {
          ...s?.toString() != null ? { "anthropic-beta": s?.toString() } : void 0,
          ...i != null ? { "anthropic-workspace-id": i } : void 0
        },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.skills.versions.list", t, {
        route: "/v1/skills/{skill_id}/versions",
        queryParams: ["limit", "page"],
        attributes: { "anthropic.skill.id": n }
      })
    });
  }
  /**
   * Delete Skill Version
   *
   * @example
   * ```ts
   * const betaDeletedSkillVersion =
   *   await client.beta.skills.versions.delete('version', {
   *     skill_id: 'skill_id',
   *   });
   * ```
   */
  delete(n, e, t) {
    const { skill_id: s, betas: i, workspace_id: a } = e;
    return this._client.delete(f`/v1/skills/${s}/versions/${n}?beta=true`, {
      ...t,
      headers: p([
        {
          ...i?.toString() != null ? { "anthropic-beta": i?.toString() } : void 0,
          ...a != null ? { "anthropic-workspace-id": a } : void 0
        },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.skills.versions.delete", t, {
        route: "/v1/skills/{skill_id}/versions/{version}",
        attributes: { "anthropic.skill.id": s, "anthropic.skill.version.id": n }
      })
    });
  }
  /**
   * Download a skill version's content as a zip archive.
   *
   * @example
   * ```ts
   * const response = await client.beta.skills.versions.download(
   *   'version',
   *   { skill_id: 'skill_id' },
   * );
   *
   * const content = await response.blob();
   * console.log(content);
   * ```
   */
  download(n, e, t) {
    const { skill_id: s, betas: i, workspace_id: a } = e;
    return this._client.get(f`/v1/skills/${s}/versions/${n}/content?beta=true`, {
      ...t,
      headers: p([
        {
          Accept: "application/binary",
          ...i?.toString() != null ? { "anthropic-beta": i?.toString() } : void 0,
          ...a != null ? { "anthropic-workspace-id": a } : void 0
        },
        t?.headers
      ]),
      __binaryResponse: !0,
      __span: u(this._client, "anthropic.skills.versions.download", t, {
        route: "/v1/skills/{skill_id}/versions/{version}/content",
        attributes: { "anthropic.skill.id": s, "anthropic.skill.version.id": n }
      })
    });
  }
};
var Ko = /* @__PURE__ */ (() => {
  class r extends T {
    constructor() {
      super(...arguments), this.versions = new Do(this._client);
    }
    /**
     * Create Skill
     *
     * @example
     * ```ts
     * const betaSkill = await client.beta.skills.create({
     *   files: [fs.createReadStream('path/to/file')],
     * });
     * ```
     */
    create(e, t) {
      const { betas: s, workspace_id: i, ...a } = e;
      return this._client.post("/v1/skills?beta=true", Ce({
        body: a,
        ...t,
        headers: p([
          {
            ...s?.toString() != null ? { "anthropic-beta": s?.toString() } : void 0,
            ...i != null ? { "anthropic-workspace-id": i } : void 0
          },
          t?.headers
        ]),
        __span: u(this._client, "anthropic.skills.create", t, {
          route: "/v1/skills",
          createdIDAttribute: "anthropic.skill.id"
        })
      }, this._client, !1));
    }
    /**
     * Get Skill
     *
     * @example
     * ```ts
     * const betaSkill = await client.beta.skills.retrieve(
     *   'skill_id',
     * );
     * ```
     */
    retrieve(e, t = {}, s) {
      const { betas: i, workspace_id: a } = t ?? {};
      return this._client.get(f`/v1/skills/${e}?beta=true`, {
        ...s,
        headers: p([
          {
            ...i?.toString() != null ? { "anthropic-beta": i?.toString() } : void 0,
            ...a != null ? { "anthropic-workspace-id": a } : void 0
          },
          s?.headers
        ]),
        __span: u(this._client, "anthropic.skills.retrieve", s, {
          route: "/v1/skills/{skill_id}",
          attributes: { "anthropic.skill.id": e }
        })
      });
    }
    /**
     * List Skills
     *
     * @example
     * ```ts
     * // Automatically fetches more pages as needed.
     * for await (const betaSkill of client.beta.skills.list()) {
     *   // ...
     * }
     * ```
     */
    list(e = {}, t) {
      const { betas: s, workspace_id: i, ...a } = e ?? {};
      return this._client.getAPIList("/v1/skills?beta=true", P, {
        query: a,
        ...t,
        headers: p([
          {
            ...s?.toString() != null ? { "anthropic-beta": s?.toString() } : void 0,
            ...i != null ? { "anthropic-workspace-id": i } : void 0
          },
          t?.headers
        ]),
        __span: u(this._client, "anthropic.skills.list", t, {
          route: "/v1/skills",
          queryParams: ["limit", "page", "source"]
        })
      });
    }
    /**
     * Delete Skill
     *
     * @example
     * ```ts
     * const betaDeletedSkill = await client.beta.skills.delete(
     *   'skill_id',
     * );
     * ```
     */
    delete(e, t = {}, s) {
      const { betas: i, workspace_id: a } = t ?? {};
      return this._client.delete(f`/v1/skills/${e}?beta=true`, {
        ...s,
        headers: p([
          {
            ...i?.toString() != null ? { "anthropic-beta": i?.toString() } : void 0,
            ...a != null ? { "anthropic-workspace-id": a } : void 0
          },
          s?.headers
        ]),
        __span: u(this._client, "anthropic.skills.delete", s, {
          route: "/v1/skills/{skill_id}",
          attributes: { "anthropic.skill.id": e }
        })
      });
    }
  }
  return r.Versions = Do, r;
})();
class Go extends T {
  /**
   * The Tunnels API is in research preview. It requires the
   * `anthropic-beta: mcp-tunnels-2026-06-22` header and may change without a
   * deprecation period. It supersedes the Admin API endpoints at
   * `/v1/organizations/tunnels`, which remain available during a migration window.
   *
   * Registers a public CA certificate on a tunnel. Anthropic verifies the gateway's
   * server certificate against this CA when it terminates the inner TLS session. A
   * tunnel holds at most two non-archived certificates.
   *
   * @example
   * ```ts
   * const betaTunnelCertificate =
   *   await client.beta.tunnels.certificates.create(
   *     'tunnel_id',
   *     { ca_certificate_pem: 'ca_certificate_pem' },
   *   );
   * ```
   */
  create(n, e, t) {
    const { betas: s, workspace_id: i, ...a } = e;
    return this._client.post(f`/v1/tunnels/${n}/certificates?beta=true`, {
      body: a,
      ...t,
      headers: p([
        {
          "anthropic-beta": [...s ?? [], "mcp-tunnels-2026-06-22"].toString(),
          ...i != null ? { "anthropic-workspace-id": i } : void 0
        },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.tunnels.certificates.create", t, {
        route: "/v1/tunnels/{tunnel_id}/certificates",
        attributes: { "anthropic.tunnel.id": n },
        createdIDAttribute: "anthropic.tunnel.certificate.id"
      })
    });
  }
  /**
   * The Tunnels API is in research preview. It requires the
   * `anthropic-beta: mcp-tunnels-2026-06-22` header and may change without a
   * deprecation period. It supersedes the Admin API endpoints at
   * `/v1/organizations/tunnels`, which remain available during a migration window.
   *
   * Fetches a tunnel certificate by ID.
   *
   * @example
   * ```ts
   * const betaTunnelCertificate =
   *   await client.beta.tunnels.certificates.retrieve(
   *     'certificate_id',
   *     { tunnel_id: 'tunnel_id' },
   *   );
   * ```
   */
  retrieve(n, e, t) {
    const { tunnel_id: s, betas: i, workspace_id: a } = e;
    return this._client.get(f`/v1/tunnels/${s}/certificates/${n}?beta=true`, {
      ...t,
      headers: p([
        {
          "anthropic-beta": [...i ?? [], "mcp-tunnels-2026-06-22"].toString(),
          ...a != null ? { "anthropic-workspace-id": a } : void 0
        },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.tunnels.certificates.retrieve", t, {
        route: "/v1/tunnels/{tunnel_id}/certificates/{certificate_id}",
        attributes: { "anthropic.tunnel.id": s, "anthropic.tunnel.certificate.id": n }
      })
    });
  }
  /**
   * The Tunnels API is in research preview. It requires the
   * `anthropic-beta: mcp-tunnels-2026-06-22` header and may change without a
   * deprecation period. It supersedes the Admin API endpoints at
   * `/v1/organizations/tunnels`, which remain available during a migration window.
   *
   * Lists the certificates registered on a tunnel. Archived certificates are
   * excluded unless include_archived is set.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaTunnelCertificate of client.beta.tunnels.certificates.list(
   *   'tunnel_id',
   * )) {
   *   // ...
   * }
   * ```
   */
  list(n, e = {}, t) {
    const { betas: s, workspace_id: i, ...a } = e ?? {};
    return this._client.getAPIList(f`/v1/tunnels/${n}/certificates?beta=true`, P, {
      query: a,
      ...t,
      headers: p([
        {
          "anthropic-beta": [...s ?? [], "mcp-tunnels-2026-06-22"].toString(),
          ...i != null ? { "anthropic-workspace-id": i } : void 0
        },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.tunnels.certificates.list", t, {
        route: "/v1/tunnels/{tunnel_id}/certificates",
        queryParams: ["include_archived", "limit", "page"],
        attributes: { "anthropic.tunnel.id": n }
      })
    });
  }
  /**
   * The Tunnels API is in research preview. It requires the
   * `anthropic-beta: mcp-tunnels-2026-06-22` header and may change without a
   * deprecation period. It supersedes the Admin API endpoints at
   * `/v1/organizations/tunnels`, which remain available during a migration window.
   *
   * Archives a tunnel certificate, removing it from the set Anthropic trusts for the
   * tunnel. The certificate record is retained. Archiving the last non-archived
   * certificate is permitted; the tunnel rejects MCP traffic until a new certificate
   * is added.
   *
   * @example
   * ```ts
   * const betaTunnelCertificate =
   *   await client.beta.tunnels.certificates.archive(
   *     'certificate_id',
   *     { tunnel_id: 'tunnel_id' },
   *   );
   * ```
   */
  archive(n, e, t) {
    const { tunnel_id: s, betas: i, workspace_id: a } = e;
    return this._client.post(f`/v1/tunnels/${s}/certificates/${n}/archive?beta=true`, {
      ...t,
      headers: p([
        {
          "anthropic-beta": [...i ?? [], "mcp-tunnels-2026-06-22"].toString(),
          ...a != null ? { "anthropic-workspace-id": a } : void 0
        },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.tunnels.certificates.archive", t, {
        route: "/v1/tunnels/{tunnel_id}/certificates/{certificate_id}/archive",
        attributes: { "anthropic.tunnel.id": s, "anthropic.tunnel.certificate.id": n }
      })
    });
  }
}
var Vo = /* @__PURE__ */ (() => {
  class r extends T {
    constructor() {
      super(...arguments), this.certificates = new Go(this._client);
    }
    /**
     * The Tunnels API is in research preview. It requires the
     * `anthropic-beta: mcp-tunnels-2026-06-22` header and may change without a
     * deprecation period. It supersedes the Admin API endpoints at
     * `/v1/organizations/tunnels`, which remain available during a migration window.
     *
     * Creates a tunnel. Creation allocates a fresh hostname and provisions the tunnel;
     * it is not idempotent. The new tunnel rejects MCP traffic until at least one CA
     * certificate is added.
     *
     * @example
     * ```ts
     * const betaTunnel = await client.beta.tunnels.create();
     * ```
     */
    create(e, t) {
      const { betas: s, workspace_id: i, ...a } = e;
      return this._client.post("/v1/tunnels?beta=true", {
        body: a,
        ...t,
        headers: p([
          {
            "anthropic-beta": [...s ?? [], "mcp-tunnels-2026-06-22"].toString(),
            ...i != null ? { "anthropic-workspace-id": i } : void 0
          },
          t?.headers
        ]),
        __span: u(this._client, "anthropic.tunnels.create", t, {
          route: "/v1/tunnels",
          createdIDAttribute: "anthropic.tunnel.id"
        })
      });
    }
    /**
     * The Tunnels API is in research preview. It requires the
     * `anthropic-beta: mcp-tunnels-2026-06-22` header and may change without a
     * deprecation period. It supersedes the Admin API endpoints at
     * `/v1/organizations/tunnels`, which remain available during a migration window.
     *
     * Fetches a tunnel by ID.
     *
     * @example
     * ```ts
     * const betaTunnel = await client.beta.tunnels.retrieve(
     *   'tunnel_id',
     * );
     * ```
     */
    retrieve(e, t = {}, s) {
      const { betas: i, workspace_id: a } = t ?? {};
      return this._client.get(f`/v1/tunnels/${e}?beta=true`, {
        ...s,
        headers: p([
          {
            "anthropic-beta": [...i ?? [], "mcp-tunnels-2026-06-22"].toString(),
            ...a != null ? { "anthropic-workspace-id": a } : void 0
          },
          s?.headers
        ]),
        __span: u(this._client, "anthropic.tunnels.retrieve", s, {
          route: "/v1/tunnels/{tunnel_id}",
          attributes: { "anthropic.tunnel.id": e }
        })
      });
    }
    /**
     * The Tunnels API is in research preview. It requires the
     * `anthropic-beta: mcp-tunnels-2026-06-22` header and may change without a
     * deprecation period. It supersedes the Admin API endpoints at
     * `/v1/organizations/tunnels`, which remain available during a migration window.
     *
     * Lists tunnels. Results are ordered by creation time, newest first; archived
     * tunnels are excluded unless include_archived is set.
     *
     * @example
     * ```ts
     * // Automatically fetches more pages as needed.
     * for await (const betaTunnel of client.beta.tunnels.list()) {
     *   // ...
     * }
     * ```
     */
    list(e = {}, t) {
      const { betas: s, workspace_id: i, ...a } = e ?? {};
      return this._client.getAPIList("/v1/tunnels?beta=true", P, {
        query: a,
        ...t,
        headers: p([
          {
            "anthropic-beta": [...s ?? [], "mcp-tunnels-2026-06-22"].toString(),
            ...i != null ? { "anthropic-workspace-id": i } : void 0
          },
          t?.headers
        ]),
        __span: u(this._client, "anthropic.tunnels.list", t, {
          route: "/v1/tunnels",
          queryParams: ["include_archived", "limit", "page"]
        })
      });
    }
    /**
     * The Tunnels API is in research preview. It requires the
     * `anthropic-beta: mcp-tunnels-2026-06-22` header and may change without a
     * deprecation period. It supersedes the Admin API endpoints at
     * `/v1/organizations/tunnels`, which remain available during a migration window.
     *
     * Archives a tunnel. Archival is irreversible: every non-archived certificate on
     * the tunnel is archived in the same operation, the hostname is retired and never
     * re-allocated, and the tunnel token is invalidated. Retrying against an
     * already-archived tunnel returns the existing record unchanged.
     *
     * @example
     * ```ts
     * const betaTunnel = await client.beta.tunnels.archive(
     *   'tunnel_id',
     * );
     * ```
     */
    archive(e, t = {}, s) {
      const { betas: i, workspace_id: a } = t ?? {};
      return this._client.post(f`/v1/tunnels/${e}/archive?beta=true`, {
        ...s,
        headers: p([
          {
            "anthropic-beta": [...i ?? [], "mcp-tunnels-2026-06-22"].toString(),
            ...a != null ? { "anthropic-workspace-id": a } : void 0
          },
          s?.headers
        ]),
        __span: u(this._client, "anthropic.tunnels.archive", s, {
          route: "/v1/tunnels/{tunnel_id}/archive",
          attributes: { "anthropic.tunnel.id": e }
        })
      });
    }
    /**
     * The Tunnels API is in research preview. It requires the
     * `anthropic-beta: mcp-tunnels-2026-06-22` header and may change without a
     * deprecation period. It supersedes the Admin API endpoints at
     * `/v1/organizations/tunnels`, which remain available during a migration window.
     *
     * Reveals a tunnel's connector token. The value is fetched live on each call;
     * Anthropic does not store it. Repeated calls return the same value until the
     * token is rotated. Exposed as POST so the token does not appear in intermediary
     * access logs.
     *
     * @example
     * ```ts
     * const betaTunnelToken =
     *   await client.beta.tunnels.revealToken('tunnel_id');
     * ```
     */
    revealToken(e, t = {}, s) {
      const { betas: i, workspace_id: a } = t ?? {};
      return this._client.post(f`/v1/tunnels/${e}/reveal_token?beta=true`, {
        ...s,
        headers: p([
          {
            "anthropic-beta": [...i ?? [], "mcp-tunnels-2026-06-22"].toString(),
            ...a != null ? { "anthropic-workspace-id": a } : void 0
          },
          s?.headers
        ]),
        __span: u(this._client, "anthropic.tunnels.reveal_token", s, {
          route: "/v1/tunnels/{tunnel_id}/reveal_token",
          attributes: { "anthropic.tunnel.id": e }
        })
      });
    }
    /**
     * The Tunnels API is in research preview. It requires the
     * `anthropic-beta: mcp-tunnels-2026-06-22` header and may change without a
     * deprecation period. It supersedes the Admin API endpoints at
     * `/v1/organizations/tunnels`, which remain available during a migration window.
     *
     * Rotates a tunnel's connector token. Rotation invalidates the current token for
     * new connections and returns a fresh value; established connections are not
     * severed. A connector restarted after rotation must use the new value.
     *
     * @example
     * ```ts
     * const betaTunnelToken =
     *   await client.beta.tunnels.rotateToken('tunnel_id');
     * ```
     */
    rotateToken(e, t, s) {
      const { betas: i, workspace_id: a, ...o } = t;
      return this._client.post(f`/v1/tunnels/${e}/rotate_token?beta=true`, {
        body: o,
        ...s,
        headers: p([
          {
            "anthropic-beta": [...i ?? [], "mcp-tunnels-2026-06-22"].toString(),
            ...a != null ? { "anthropic-workspace-id": a } : void 0
          },
          s?.headers
        ]),
        __span: u(this._client, "anthropic.tunnels.rotate_token", s, {
          route: "/v1/tunnels/{tunnel_id}/rotate_token",
          attributes: { "anthropic.tunnel.id": e }
        })
      });
    }
  }
  return r.Certificates = Go, r;
})();
let Jo = class extends T {
  /**
   * Create Action URL
   *
   * @example
   * ```ts
   * const betaUserProfileActionURL =
   *   await client.beta.userProfiles.actionURLs.create(
   *     'uprof_011CZkZCu8hGbp5mYRQgUmz9',
   *     { action: { type: 'enroll_end_user' } },
   *   );
   * ```
   */
  create(n, e, t) {
    const { betas: s, workspace_id: i, ...a } = e;
    return this._client.post(f`/v1/user_profiles/${n}/action_urls?beta=true`, {
      body: a,
      ...t,
      headers: p([
        {
          "anthropic-beta": [...s ?? [], "user-profiles-2026-08-18"].toString(),
          ...i != null ? { "anthropic-workspace-id": i } : void 0
        },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.user_profiles.action_urls.create", t, {
        route: "/v1/user_profiles/{user_profile_id}/action_urls",
        attributes: { "anthropic.user_profile.id": n }
      })
    });
  }
};
var Yo = /* @__PURE__ */ (() => {
  class r extends T {
    constructor() {
      super(...arguments), this.actionURLs = new Jo(this._client);
    }
    /**
     * Create User Profile
     *
     * @example
     * ```ts
     * const betaUserProfile =
     *   await client.beta.userProfiles.create();
     * ```
     */
    create(e, t) {
      const { betas: s, workspace_id: i, ...a } = e;
      return this._client.post("/v1/user_profiles?beta=true", {
        body: a,
        ...t,
        headers: p([
          {
            "anthropic-beta": [...s ?? [], "user-profiles-2026-08-18"].toString(),
            ...i != null ? { "anthropic-workspace-id": i } : void 0
          },
          t?.headers
        ]),
        __span: u(this._client, "anthropic.user_profiles.create", t, {
          route: "/v1/user_profiles",
          createdIDAttribute: "anthropic.user_profile.id"
        })
      });
    }
    /**
     * Get User Profile
     *
     * @example
     * ```ts
     * const betaUserProfile =
     *   await client.beta.userProfiles.retrieve(
     *     'uprof_011CZkZCu8hGbp5mYRQgUmz9',
     *   );
     * ```
     */
    retrieve(e, t = {}, s) {
      const { betas: i, workspace_id: a } = t ?? {};
      return this._client.get(f`/v1/user_profiles/${e}?beta=true`, {
        ...s,
        headers: p([
          {
            "anthropic-beta": [...i ?? [], "user-profiles-2026-08-18"].toString(),
            ...a != null ? { "anthropic-workspace-id": a } : void 0
          },
          s?.headers
        ]),
        __span: u(this._client, "anthropic.user_profiles.retrieve", s, {
          route: "/v1/user_profiles/{user_profile_id}",
          attributes: { "anthropic.user_profile.id": e }
        })
      });
    }
    /**
     * Update User Profile
     *
     * @example
     * ```ts
     * const betaUserProfile =
     *   await client.beta.userProfiles.update(
     *     'uprof_011CZkZCu8hGbp5mYRQgUmz9',
     *   );
     * ```
     */
    update(e, t, s) {
      const { betas: i, workspace_id: a, ...o } = t;
      return this._client.post(f`/v1/user_profiles/${e}?beta=true`, {
        body: o,
        ...s,
        headers: p([
          {
            "anthropic-beta": [...i ?? [], "user-profiles-2026-08-18"].toString(),
            ...a != null ? { "anthropic-workspace-id": a } : void 0
          },
          s?.headers
        ]),
        __span: u(this._client, "anthropic.user_profiles.update", s, {
          route: "/v1/user_profiles/{user_profile_id}",
          attributes: { "anthropic.user_profile.id": e }
        })
      });
    }
    /**
     * List User Profiles
     *
     * @example
     * ```ts
     * // Automatically fetches more pages as needed.
     * for await (const betaUserProfile of client.beta.userProfiles.list()) {
     *   // ...
     * }
     * ```
     */
    list(e = {}, t) {
      const { betas: s, workspace_id: i, ...a } = e ?? {};
      return this._client.getAPIList("/v1/user_profiles?beta=true", P, {
        query: a,
        ...t,
        headers: p([
          {
            "anthropic-beta": [...s ?? [], "user-profiles-2026-08-18"].toString(),
            ...i != null ? { "anthropic-workspace-id": i } : void 0
          },
          t?.headers
        ]),
        __span: u(this._client, "anthropic.user_profiles.list", t, {
          route: "/v1/user_profiles",
          queryParams: ["limit", "order", "order_by", "page"]
        })
      });
    }
    /**
     * Delete User Profile
     *
     * @example
     * ```ts
     * const betaDeletedUserProfile =
     *   await client.beta.userProfiles.delete(
     *     'uprof_011CZkZCu8hGbp5mYRQgUmz9',
     *   );
     * ```
     */
    delete(e, t = {}, s) {
      const { betas: i, workspace_id: a } = t ?? {};
      return this._client.delete(f`/v1/user_profiles/${e}?beta=true`, {
        ...s,
        headers: p([
          {
            "anthropic-beta": [...i ?? [], "user-profiles-2026-08-18"].toString(),
            ...a != null ? { "anthropic-workspace-id": a } : void 0
          },
          s?.headers
        ]),
        __span: u(this._client, "anthropic.user_profiles.delete", s, {
          route: "/v1/user_profiles/{user_profile_id}",
          attributes: { "anthropic.user_profile.id": e }
        })
      });
    }
    /**
     * Create Enrollment URL
     *
     * @example
     * ```ts
     * const betaUserProfileEnrollmentURL =
     *   await client.beta.userProfiles.createEnrollmentURL(
     *     'uprof_011CZkZCu8hGbp5mYRQgUmz9',
     *   );
     * ```
     */
    createEnrollmentURL(e, t = {}, s) {
      const { betas: i, workspace_id: a } = t ?? {};
      return this._client.post(f`/v1/user_profiles/${e}/enrollment_url?beta=true`, {
        ...s,
        headers: p([
          {
            "anthropic-beta": [...i ?? [], "user-profiles-2026-08-18"].toString(),
            ...a != null ? { "anthropic-workspace-id": a } : void 0
          },
          s?.headers
        ]),
        __span: u(this._client, "anthropic.user_profiles.create_enrollment_url", s, {
          route: "/v1/user_profiles/{user_profile_id}/enrollment_url",
          attributes: { "anthropic.user_profile.id": e }
        })
      });
    }
  }
  return r.ActionURLs = Jo, r;
})();
class Xo extends T {
  /**
   * Create a Credential
   *
   * @example
   * ```ts
   * const betaManagedAgentsCredential =
   *   await client.beta.vaults.credentials.create(
   *     'vlt_011CZkZDLs7fYzm1hXNPeRjv',
   *     {
   *       auth: {
   *         token: 'bearer_exampletoken',
   *         mcp_server_url:
   *           'https://example-server.modelcontextprotocol.io/sse',
   *         type: 'static_bearer',
   *       },
   *     },
   *   );
   * ```
   */
  create(n, e, t) {
    const { betas: s, workspace_id: i, ...a } = e;
    return this._client.post(f`/v1/vaults/${n}/credentials?beta=true`, {
      body: a,
      ...t,
      headers: p([
        {
          "anthropic-beta": [...s ?? [], "managed-agents-2026-04-01"].toString(),
          ...i != null ? { "anthropic-workspace-id": i } : void 0
        },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.vaults.credentials.create", t, {
        route: "/v1/vaults/{vault_id}/credentials",
        attributes: { "anthropic.vault.id": n },
        createdIDAttribute: "anthropic.vault.credential.id"
      })
    });
  }
  /**
   * Retrieve a Credential
   *
   * @example
   * ```ts
   * const betaManagedAgentsCredential =
   *   await client.beta.vaults.credentials.retrieve(
   *     'vcrd_011CZkZEMt8gZan2iYPQfSkw',
   *     { vault_id: 'vlt_011CZkZDLs7fYzm1hXNPeRjv' },
   *   );
   * ```
   */
  retrieve(n, e, t) {
    const { vault_id: s, betas: i, workspace_id: a } = e;
    return this._client.get(f`/v1/vaults/${s}/credentials/${n}?beta=true`, {
      ...t,
      headers: p([
        {
          "anthropic-beta": [...i ?? [], "managed-agents-2026-04-01"].toString(),
          ...a != null ? { "anthropic-workspace-id": a } : void 0
        },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.vaults.credentials.retrieve", t, {
        route: "/v1/vaults/{vault_id}/credentials/{credential_id}",
        attributes: { "anthropic.vault.id": s, "anthropic.vault.credential.id": n }
      })
    });
  }
  /**
   * Update a Credential
   *
   * @example
   * ```ts
   * const betaManagedAgentsCredential =
   *   await client.beta.vaults.credentials.update(
   *     'vcrd_011CZkZEMt8gZan2iYPQfSkw',
   *     { vault_id: 'vlt_011CZkZDLs7fYzm1hXNPeRjv' },
   *   );
   * ```
   */
  update(n, e, t) {
    const { vault_id: s, betas: i, workspace_id: a, ...o } = e;
    return this._client.post(f`/v1/vaults/${s}/credentials/${n}?beta=true`, {
      body: o,
      ...t,
      headers: p([
        {
          "anthropic-beta": [...i ?? [], "managed-agents-2026-04-01"].toString(),
          ...a != null ? { "anthropic-workspace-id": a } : void 0
        },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.vaults.credentials.update", t, {
        route: "/v1/vaults/{vault_id}/credentials/{credential_id}",
        attributes: { "anthropic.vault.id": s, "anthropic.vault.credential.id": n }
      })
    });
  }
  /**
   * List Credentials
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaManagedAgentsCredential of client.beta.vaults.credentials.list(
   *   'vlt_011CZkZDLs7fYzm1hXNPeRjv',
   * )) {
   *   // ...
   * }
   * ```
   */
  list(n, e = {}, t) {
    const { betas: s, workspace_id: i, ...a } = e ?? {};
    return this._client.getAPIList(f`/v1/vaults/${n}/credentials?beta=true`, P, {
      query: a,
      ...t,
      headers: p([
        {
          "anthropic-beta": [...s ?? [], "managed-agents-2026-04-01"].toString(),
          ...i != null ? { "anthropic-workspace-id": i } : void 0
        },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.vaults.credentials.list", t, {
        route: "/v1/vaults/{vault_id}/credentials",
        queryParams: ["include_archived", "limit", "page"],
        attributes: { "anthropic.vault.id": n }
      })
    });
  }
  /**
   * Delete a Credential
   *
   * @example
   * ```ts
   * const betaManagedAgentsDeletedCredential =
   *   await client.beta.vaults.credentials.delete(
   *     'vcrd_011CZkZEMt8gZan2iYPQfSkw',
   *     { vault_id: 'vlt_011CZkZDLs7fYzm1hXNPeRjv' },
   *   );
   * ```
   */
  delete(n, e, t) {
    const { vault_id: s, betas: i, workspace_id: a } = e;
    return this._client.delete(f`/v1/vaults/${s}/credentials/${n}?beta=true`, {
      ...t,
      headers: p([
        {
          "anthropic-beta": [...i ?? [], "managed-agents-2026-04-01"].toString(),
          ...a != null ? { "anthropic-workspace-id": a } : void 0
        },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.vaults.credentials.delete", t, {
        route: "/v1/vaults/{vault_id}/credentials/{credential_id}",
        attributes: { "anthropic.vault.id": s, "anthropic.vault.credential.id": n }
      })
    });
  }
  /**
   * Archive a Credential
   *
   * @example
   * ```ts
   * const betaManagedAgentsCredential =
   *   await client.beta.vaults.credentials.archive(
   *     'vcrd_011CZkZEMt8gZan2iYPQfSkw',
   *     { vault_id: 'vlt_011CZkZDLs7fYzm1hXNPeRjv' },
   *   );
   * ```
   */
  archive(n, e, t) {
    const { vault_id: s, betas: i, workspace_id: a } = e;
    return this._client.post(f`/v1/vaults/${s}/credentials/${n}/archive?beta=true`, {
      ...t,
      headers: p([
        {
          "anthropic-beta": [...i ?? [], "managed-agents-2026-04-01"].toString(),
          ...a != null ? { "anthropic-workspace-id": a } : void 0
        },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.vaults.credentials.archive", t, {
        route: "/v1/vaults/{vault_id}/credentials/{credential_id}/archive",
        attributes: { "anthropic.vault.id": s, "anthropic.vault.credential.id": n }
      })
    });
  }
  /**
   * Validate an MCP OAuth Credential
   *
   * @example
   * ```ts
   * const betaManagedAgentsCredentialValidation =
   *   await client.beta.vaults.credentials.mcpOAuthValidate(
   *     'vcrd_011CZkZEMt8gZan2iYPQfSkw',
   *     { vault_id: 'vlt_011CZkZDLs7fYzm1hXNPeRjv' },
   *   );
   * ```
   */
  mcpOAuthValidate(n, e, t) {
    const { vault_id: s, betas: i, workspace_id: a } = e;
    return this._client.post(f`/v1/vaults/${s}/credentials/${n}/mcp_oauth_validate?beta=true`, {
      ...t,
      headers: p([
        {
          "anthropic-beta": [...i ?? [], "managed-agents-2026-04-01"].toString(),
          ...a != null ? { "anthropic-workspace-id": a } : void 0
        },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.vaults.credentials.mcp_oauth_validate", t, {
        route: "/v1/vaults/{vault_id}/credentials/{credential_id}/mcp_oauth_validate",
        attributes: { "anthropic.vault.id": s, "anthropic.vault.credential.id": n }
      })
    });
  }
}
var Qo = /* @__PURE__ */ (() => {
  class r extends T {
    constructor() {
      super(...arguments), this.credentials = new Xo(this._client);
    }
    /**
     * Create a Vault
     *
     * @example
     * ```ts
     * const betaManagedAgentsVault =
     *   await client.beta.vaults.create({
     *     display_name: 'Example vault',
     *   });
     * ```
     */
    create(e, t) {
      const { betas: s, workspace_id: i, ...a } = e;
      return this._client.post("/v1/vaults?beta=true", {
        body: a,
        ...t,
        headers: p([
          {
            "anthropic-beta": [...s ?? [], "managed-agents-2026-04-01"].toString(),
            ...i != null ? { "anthropic-workspace-id": i } : void 0
          },
          t?.headers
        ]),
        __span: u(this._client, "anthropic.vaults.create", t, {
          route: "/v1/vaults",
          createdIDAttribute: "anthropic.vault.id"
        })
      });
    }
    /**
     * Retrieve a Vault
     *
     * @example
     * ```ts
     * const betaManagedAgentsVault =
     *   await client.beta.vaults.retrieve(
     *     'vlt_011CZkZDLs7fYzm1hXNPeRjv',
     *   );
     * ```
     */
    retrieve(e, t = {}, s) {
      const { betas: i, workspace_id: a } = t ?? {};
      return this._client.get(f`/v1/vaults/${e}?beta=true`, {
        ...s,
        headers: p([
          {
            "anthropic-beta": [...i ?? [], "managed-agents-2026-04-01"].toString(),
            ...a != null ? { "anthropic-workspace-id": a } : void 0
          },
          s?.headers
        ]),
        __span: u(this._client, "anthropic.vaults.retrieve", s, {
          route: "/v1/vaults/{vault_id}",
          attributes: { "anthropic.vault.id": e }
        })
      });
    }
    /**
     * Update a Vault
     *
     * @example
     * ```ts
     * const betaManagedAgentsVault =
     *   await client.beta.vaults.update(
     *     'vlt_011CZkZDLs7fYzm1hXNPeRjv',
     *   );
     * ```
     */
    update(e, t, s) {
      const { betas: i, workspace_id: a, ...o } = t;
      return this._client.post(f`/v1/vaults/${e}?beta=true`, {
        body: o,
        ...s,
        headers: p([
          {
            "anthropic-beta": [...i ?? [], "managed-agents-2026-04-01"].toString(),
            ...a != null ? { "anthropic-workspace-id": a } : void 0
          },
          s?.headers
        ]),
        __span: u(this._client, "anthropic.vaults.update", s, {
          route: "/v1/vaults/{vault_id}",
          attributes: { "anthropic.vault.id": e }
        })
      });
    }
    /**
     * List Vaults
     *
     * @example
     * ```ts
     * // Automatically fetches more pages as needed.
     * for await (const betaManagedAgentsVault of client.beta.vaults.list()) {
     *   // ...
     * }
     * ```
     */
    list(e = {}, t) {
      const { betas: s, workspace_id: i, ...a } = e ?? {};
      return this._client.getAPIList("/v1/vaults?beta=true", P, {
        query: a,
        ...t,
        headers: p([
          {
            "anthropic-beta": [...s ?? [], "managed-agents-2026-04-01"].toString(),
            ...i != null ? { "anthropic-workspace-id": i } : void 0
          },
          t?.headers
        ]),
        __span: u(this._client, "anthropic.vaults.list", t, {
          route: "/v1/vaults",
          queryParams: ["include_archived", "limit", "page"]
        })
      });
    }
    /**
     * Delete a Vault
     *
     * @example
     * ```ts
     * const betaManagedAgentsDeletedVault =
     *   await client.beta.vaults.delete(
     *     'vlt_011CZkZDLs7fYzm1hXNPeRjv',
     *   );
     * ```
     */
    delete(e, t = {}, s) {
      const { betas: i, workspace_id: a } = t ?? {};
      return this._client.delete(f`/v1/vaults/${e}?beta=true`, {
        ...s,
        headers: p([
          {
            "anthropic-beta": [...i ?? [], "managed-agents-2026-04-01"].toString(),
            ...a != null ? { "anthropic-workspace-id": a } : void 0
          },
          s?.headers
        ]),
        __span: u(this._client, "anthropic.vaults.delete", s, {
          route: "/v1/vaults/{vault_id}",
          attributes: { "anthropic.vault.id": e }
        })
      });
    }
    /**
     * Archive a Vault
     *
     * @example
     * ```ts
     * const betaManagedAgentsVault =
     *   await client.beta.vaults.archive(
     *     'vlt_011CZkZDLs7fYzm1hXNPeRjv',
     *   );
     * ```
     */
    archive(e, t = {}, s) {
      const { betas: i, workspace_id: a } = t ?? {};
      return this._client.post(f`/v1/vaults/${e}/archive?beta=true`, {
        ...s,
        headers: p([
          {
            "anthropic-beta": [...i ?? [], "managed-agents-2026-04-01"].toString(),
            ...a != null ? { "anthropic-workspace-id": a } : void 0
          },
          s?.headers
        ]),
        __span: u(this._client, "anthropic.vaults.archive", s, {
          route: "/v1/vaults/{vault_id}/archive",
          attributes: { "anthropic.vault.id": e }
        })
      });
    }
  }
  return r.Credentials = Xo, r;
})(), xe, gr, nt, At, mr, rt, xt, br, Zo, wr, yr, ec = /* @__PURE__ */ (() => {
  class r extends Nu {
    constructor(e, t, s) {
      super(e, { client: s }), xe.add(this), gr.set(this, void 0), nt.set(this, 0), At.set(this, []), mr.set(this, []), rt.set(this, void 0), xt.set(this, []), br.set(this, !1), y(this, gr, t);
    }
    /** The `tool_use` blocks that have finished streaming, in the model's order */
    get toolCalls() {
      return c(this, mr, "f");
    }
    /** Sends the request as `client.beta.messages.stream()` does. */
    static start(e, t, s, i) {
      const a = new r({ ...t, stream: !0 }, i, e);
      for (const o of t.messages)
        a._addMessageParam(o);
      return a._run(() => a._createMessage(e.beta.messages, { ...t, stream: !0 }, { ...s, headers: { ...s?.headers, [Ti]: "stream" } })), a;
    }
    _deliverEvent(e, t) {
      var s;
      y(this, nt, (s = c(this, nt, "f"), s++, s));
      const i = e.type === "content_block_stop" ? t?.content[e.index] : void 0, a = i?.type === "tool_use" ? i : void 0;
      a && c(this, mr, "f").push(a), super._deliverEvent(e, t), c(this, xe, "m", Zo).call(this, e, a), c(this, xe, "m", wr).call(this);
    }
    [(gr = /* @__PURE__ */ new WeakMap(), nt = /* @__PURE__ */ new WeakMap(), At = /* @__PURE__ */ new WeakMap(), mr = /* @__PURE__ */ new WeakMap(), rt = /* @__PURE__ */ new WeakMap(), xt = /* @__PURE__ */ new WeakMap(), br = /* @__PURE__ */ new WeakMap(), xe = /* @__PURE__ */ new WeakSet(), Symbol.asyncIterator)]() {
      const e = super[Symbol.asyncIterator](), t = { handled: c(this, nt, "f") };
      c(this, At, "f").push(t);
      let s = !1;
      return {
        next: async () => {
          s && (s = !1, t.handled++, c(this, xe, "m", wr).call(this));
          try {
            const i = await e.next();
            return s = !i.done, i.done && c(this, xe, "m", yr).call(this, t), i;
          } catch (i) {
            throw c(this, xe, "m", yr).call(this, t), i;
          }
        },
        return: async () => {
          const i = e.return?.();
          return c(this, xe, "m", yr).call(this, t), await i ?? { value: void 0, done: !0 };
        }
      };
    }
  }
  return Zo = function(e, t) {
    if (c(this, br, "f"))
      return;
    if (e.type === "content_block_start" && e.content_block.type === "fallback") {
      y(this, br, !0), y(this, rt, void 0);
      return;
    }
    const s = e.type === "content_block_start" || e.type === "message_delta" && e.delta.stop_reason === "tool_use";
    c(this, rt, "f") && s && (c(this, xt, "f").push({ toolUse: c(this, rt, "f"), event: c(this, nt, "f") }), y(this, rt, void 0)), t && y(this, rt, t);
  }, wr = function() {
    if (this.errored || this.controller.signal.aborted)
      return;
    const e = Math.min(c(this, nt, "f"), ...c(this, At, "f").map((t) => t.handled));
    for (; c(this, xt, "f")[0] && c(this, xt, "f")[0].event <= e; )
      c(this, gr, "f").call(this, c(this, xt, "f").shift().toolUse);
  }, yr = function(e) {
    const t = c(this, At, "f").indexOf(e);
    t >= 0 && (c(this, At, "f").splice(t, 1), c(this, xe, "m", wr).call(this));
  }, r;
})();
function tc() {
  let r, n;
  return { promise: new Promise((t, s) => {
    r = t, n = s;
  }), resolve: r, reject: n };
}
var N, Et, st, L, G, ne, Fe, Se, We, bn, Ee, le, Te, Rt, Pt, it, wn, Ps, nc, zs, Ms, yn, vr, rc, sc, Os, kr, ic, Cs;
const ac = "a tool runner's toolsets come only from its tools param; change them with setMessagesParams(), or build a new runner", ig = "a tool runner's toolsets come only from its tools param; remove it there with setMessagesParams(), or build a new runner without it";
var oc = /* @__PURE__ */ (() => {
  class r {
    constructor(e, t, s) {
      N.add(this), this.client = e, Et.set(this, !1), st.set(this, !1), L.set(this, void 0), G.set(this, void 0), ne.set(this, void 0), Fe.set(this, void 0), Se.set(this, void 0), We.set(this, void 0), bn.set(this, 0), Ee.set(this, void 0), le.set(this, { status: "idle" }), Te.set(this, void 0), Rt.set(this, null), Pt.set(this, /* @__PURE__ */ new Map()), it.set(this, []), cc(t), ag(t), lc(t), y(this, L, {
        params: {
          // You can't clone the entire params since there are functions as handlers.
          // You also don't really need to clone params.messages, but it probably will prevent a foot gun
          // somewhere.
          ...t,
          // Not structuredClone(): it throws on a function, and a runnable tool written by value into a
          // `tool_addition` block has `run`. A JSON copy is the messages as they are sent, which drops it.
          messages: JSON.parse(JSON.stringify(uc(t.messages)))
        }
      });
      const i = au(t.tools, t.messages);
      y(this, G, {
        ...s,
        headers: p([
          iu("BetaToolRunner"),
          i.length ? { [$n]: i.join(", ") } : void 0,
          s?.headers
        ])
      }), y(this, We, tc());
    }
    async *[(Et = /* @__PURE__ */ new WeakMap(), st = /* @__PURE__ */ new WeakMap(), L = /* @__PURE__ */ new WeakMap(), G = /* @__PURE__ */ new WeakMap(), ne = /* @__PURE__ */ new WeakMap(), Fe = /* @__PURE__ */ new WeakMap(), Se = /* @__PURE__ */ new WeakMap(), We = /* @__PURE__ */ new WeakMap(), bn = /* @__PURE__ */ new WeakMap(), Ee = /* @__PURE__ */ new WeakMap(), le = /* @__PURE__ */ new WeakMap(), Te = /* @__PURE__ */ new WeakMap(), Rt = /* @__PURE__ */ new WeakMap(), Pt = /* @__PURE__ */ new WeakMap(), it = /* @__PURE__ */ new WeakMap(), N = /* @__PURE__ */ new WeakSet(), wn = function(t) {
      return c(this, Ee, "f") ? he.with(c(this, Ee, "f"), t) : t();
    }, Symbol.asyncIterator)]() {
      var e;
      if (c(this, Et, "f"))
        throw new R("Cannot iterate over a consumed stream");
      y(this, Et, !0), y(this, st, !0), y(this, Se, void 0);
      const t = F(this.client, () => Rp(this.client, c(this, L, "f").params, c(this, G, "f").openTelemetry?.conversationId));
      y(this, Ee, t && _t.setSpan(he.active(), t));
      try {
        for (; ; )
          try {
            if (c(this, L, "f").params.max_iterations && c(this, bn, "f") >= c(this, L, "f").params.max_iterations)
              break;
            if (c(this, N, "m", ic).call(this), c(this, le, "f").status === "scheduled" && hc(c(this, Rt, "f")) !== "resume") {
              yield* c(this, N, "m", Ms).call(this, c(this, le, "f").config);
              continue;
            }
            y(this, st, !1, "f"), y(this, Se, void 0, "f"), y(this, bn, (e = c(this, bn, "f"), e++, e), "f"), y(this, ne, void 0, "f");
            const { max_iterations: s, runToolsEagerly: i, ...a } = c(this, L, "f").params;
            if (yield* c(this, N, "m", Ps).call(this, a), await c(this, N, "m", wn).call(this, async () => {
              if (c(this, st, "f"))
                y(this, Rt, null, "f");
              else {
                const h = await c(this, ne, "f"), _ = hc(h.stop_reason);
                y(this, Rt, h.stop_reason, "f"), c(this, L, "f").params.messages.push({
                  role: h.role,
                  content: h.content
                });
                const { container: d } = c(this, L, "f").params;
                if (h.container && (d == null ? c(this, L, "f").params.container = h.container.id : typeof d == "object" && d.id == null && (c(this, L, "f").params.container = { ...d, id: h.container.id })), _ === "stop")
                  return "stop";
                if (_ === "resume")
                  return "continue";
              }
              const l = await c(this, N, "m", Os).call(this, c(this, L, "f").params.messages.at(-1), c(this, G, "f").signal, c(this, Ee, "f"));
              if (l)
                c(this, L, "f").params.messages.push(l);
              else if (!c(this, st, "f"))
                return "stop";
              return "continue";
            }) === "stop") {
              yield* c(this, N, "m", sc).call(this);
              break;
            }
          } finally {
            c(this, Fe, "f")?.abort(), y(this, Fe, void 0, "f");
          }
        if (await c(this, N, "m", zs).call(this), !c(this, ne, "f"))
          throw new R("ToolRunner concluded without a message from the server");
        c(this, We, "f").resolve(await c(this, ne, "f")), F(this.client, () => t?.setStatus({ code: ht.OK }));
      } catch (s) {
        throw t && F(this.client, () => Ke(t, s)), y(this, Et, !1), c(this, We, "f").promise.catch(() => {
        }), c(this, We, "f").reject(s), y(this, We, tc()), s;
      } finally {
        F(this.client, () => t?.end()), y(this, Ee, void 0);
      }
    }
    setMessagesParams(e) {
      const t = typeof e == "function" ? e(c(this, L, "f").params) : e;
      if (cc(t), lc(t), c(this, le, "f").status !== "idle" && $s(t), c(this, le, "f").status === "in_flight" && t.messages !== c(this, L, "f").params.messages)
        throw new R("Message params can't be changed while the conversation is being compacted, because the compaction response is about to replace them. Change them after this iteration instead.");
      c(this, L, "f").params = t, y(this, st, !0), y(this, Se, void 0);
    }
    setRequestOptions(e) {
      typeof e == "function" ? y(this, G, e(c(this, G, "f"))) : y(this, G, { ...c(this, G, "f"), ...e });
    }
    /**
     * Get the tool response for the last message from the assistant.
     * Avoids redundant tool executions by caching results. With `runToolsEagerly`, it reuses the calls of
     * the reply that have started and runs the rest, including the ones `deferToolCall()` is holding, so that no
     * call runs twice.
     *
     * @returns A promise that resolves to a BetaMessageParam containing tool results, or null if no tools need to be executed
     *
     * @example
     * const toolResponse = await runner.generateToolResponse();
     * if (toolResponse) {
     *   console.log('Tool results:', toolResponse.content);
     * }
     */
    async generateToolResponse(e = c(this, G, "f").signal) {
      const t = this.client._tracer ? he.active() : void 0, s = await c(this, ne, "f") ?? this.params.messages.at(-1);
      return s ? c(this, N, "m", Os).call(this, s, e, t) : null;
    }
    /**
     * Hold a tool call of the current reply until you are done with the reply, which is when it runs without
     * streaming: at the end of the loop body, or when you call `generateToolResponse()`.
     *
     * With `runToolsEagerly` the runner otherwise starts each call while the reply streams, as soon as
     * the model has moved on from it: when the next block starts, or the reply stops with `tool_use`. A call
     * never starts before your stream listeners and any `for await` over the stream have handled that event, so
     * you can call this from either once you have seen the call. The other calls of the reply still start early,
     * except the later calls of the same toolset, which a toolset runs in order.
     * It does nothing for a call that has started, outside the loop body, and without `runToolsEagerly`.
     *
     * @param toolUse - The `tool_use` block of the call, or its id
     *
     * @example
     * for await (const stream of runner) {
     *   stream.on('contentBlock', (block) => {
     *     if (block.type === 'tool_use' && block.name === 'delete_file') {
     *       runner.deferToolCall(block);
     *     }
     *   });
     *   await stream.finalMessage();
     *   // No `delete_file` call has started yet.
     * }
     */
    deferToolCall(e) {
      const t = typeof e == "string" ? e : e.id;
      c(this, Te, "f") && !c(this, Te, "f").has(t) && c(this, Te, "f").set(t, { status: "held" });
    }
    /**
     * The tool calls of the current reply that `deferToolCall()` is holding, in the model's order, as their
     * `tool_use` blocks. A call is in the list once its block has finished streaming, so read the list when you
     * are done with the stream. A call that has started is not in it. It is empty without
     * `runToolsEagerly`.
     *
     * Held calls are listed whatever the reply's `stop_reason`, because `generateToolResponse()` runs them
     * whatever it is. After `max_tokens` the input of the last call can be cut off.
     *
     * @example
     * for await (const stream of runner) {
     *   stream.on('contentBlock', (block) => {
     *     if (block.type === 'tool_use' && block.name === 'delete_file') {
     *       runner.deferToolCall(block);
     *     }
     *   });
     *   await stream.finalMessage();
     *
     *   const held = runner.deferredToolCalls;
     *   if (held.length > 0 && !(await confirm(held))) break;
     * }
     */
    get deferredToolCalls() {
      const e = c(this, Fe, "f"), t = c(this, Te, "f");
      return !(e instanceof ec) || !t ? [] : e.toolCalls.filter((s) => t.get(s.id)?.status === "held");
    }
    /**
     * Wait for the async iterator to complete. This works even if the async iterator hasn't yet started, and
     * will wait for an instance to start and go to completion.
     *
     * @returns A promise that resolves to the final BetaMessage when the iterator completes
     *
     * @example
     * // Start consuming the iterator
     * for await (const message of runner) {
     *   console.log('Message:', message.content);
     * }
     *
     * // Meanwhile, wait for completion from another part of the code
     * const finalMessage = await runner.done();
     * console.log('Final response:', finalMessage.content);
     */
    done() {
      return c(this, We, "f").promise;
    }
    /**
     * Returns a promise indicating that the stream is done. Unlike .done(), this will eagerly read the stream:
     * * If the iterator has not been consumed, consume the entire iterator and return the final message from the
     * assistant.
     * * If the iterator has been consumed, waits for it to complete and returns the final message.
     *
     * @returns A promise that resolves to the final BetaMessage from the conversation
     * @throws {AnthropicError} If no messages were processed during the conversation
     *
     * @example
     * const finalMessage = await runner.runUntilDone();
     * console.log('Final response:', finalMessage.content);
     */
    async runUntilDone() {
      if (!c(this, Et, "f"))
        for await (const e of this)
          ;
      return this.done();
    }
    /**
     * Get the current parameters being used by the ToolRunner.
     *
     * @returns A readonly view of the current ToolRunnerParams
     *
     * @example
     * const currentParams = runner.params;
     * console.log('Current model:', currentParams.model);
     * console.log('Message count:', currentParams.messages.length);
     */
    get params() {
      return c(this, L, "f").params;
    }
    /**
     * Add one or more messages to the conversation history.
     *
     * @param messages - One or more BetaMessageParam objects to add to the conversation
     *
     * @example
     * runner.pushMessages(
     *   { role: 'user', content: 'Also, what about the weather in NYC?' }
     * );
     *
     * @example
     * // Adding multiple messages
     * runner.pushMessages(
     *   { role: 'user', content: 'What about NYC?' },
     *   { role: 'user', content: 'And Boston?' }
     * );
     */
    pushMessages(...e) {
      this.setMessagesParams((t) => ({
        ...t,
        messages: [...t.messages, ...e]
      }));
    }
    /**
     * Schedule a compaction of the conversation. Once the current turn has finished, including any tool
     * calls, the runner requests a summary and replaces the message history with the compaction response,
     * which is yielded like any other message. Requires the `compact-2026-09-04` beta.
     *
     * @param compaction - The config to send, as `messages.create()` takes it. Defaults to `{ type: 'summarize' }`
     *
     * @example
     * for await (const message of runner) {
     *   if (message.usage.input_tokens > 100_000) {
     *     runner.compactBeforeNextTurn();
     *   }
     * }
     */
    compactBeforeNextTurn(e) {
      c(this, le, "f").status !== "in_flight" && ($s(c(this, L, "f").params), y(this, le, { status: "scheduled", config: e ?? { type: "summarize" } }));
    }
    /**
     * Give the model more tools without changing `params.tools`, which would miss the prompt cache.
     *
     * Each tool's whole definition is sent in a `tool_addition` block with the next request, and a
     * runnable tool replaces a runnable tool of the same name straight away, even for a call already in
     * the message being handled. A call that started while the reply streamed keeps the old one. A raw definition
     * is only sent: the runner never runs it, and stops running a tool of the same name. Passing a runnable toolset,
     * or a raw definition of a toolset the runner has, throws `ToolsetContractError` and adds nothing: a runner's
     * toolsets come only from `params.tools`. A tool named like one of its toolsets is left to the API, which rejects
     * it with the next request. Requires the `inline-tools-2026-09-15` beta, which the runner does not add for you.
     *
     * @param tools - Runnable tools (for example from `betaZodTool()`) or raw tool definitions
     *
     * @example
     * runner.addTools(queryDatabaseTool);
     */
    addTools(...e) {
      const t = c(this, N, "m", kr).call(this);
      for (const s of e) {
        if (Mn(s))
          throw new Cr(`addTools() can't add the '${Ge(Ft(s))}' toolset: ${ac}`);
        const i = lg(s);
        if (t.has(i))
          throw new Cr(`addTools() can't replace the '${Ge(i)}' toolset: ${ac}`);
      }
      for (const s of e)
        "name" in s && c(this, Pt, "f").set(s.name, "run" in s ? s : null), c(this, it, "f").push({ type: "addition", tool: s });
    }
    /**
     * Take tools away from the model without changing `params.tools`, which would miss the prompt cache.
     *
     * The tools stop being run straight away: a call to one of them, even one in the message being
     * handled, gets the same "not found" error result as a call to an unknown tool. A call that started while the
     * reply streamed finishes as usual. The model is told in a `tool_removal` block with the next request. Use
     * {@link addTools} to bring a tool back. Passing the name of one of the runner's toolsets throws
     * `ToolsetContractError` and removes nothing. Requires the `inline-tools-2026-09-15` beta, which the runner does
     * not add for you.
     *
     * @param tools - The tools to remove, or their names
     *
     * @example
     * runner.removeTools('query_database');
     */
    removeTools(...e) {
      const t = c(this, N, "m", kr).call(this);
      for (const s of e) {
        const i = typeof s == "string" ? s : s.name;
        if (t.has(i))
          throw new Cr(`removeTools() can't remove the '${Ge(i)}' toolset: ${ig}`);
      }
      for (const s of e) {
        const i = typeof s == "string" ? s : s.name;
        c(this, Pt, "f").set(i, null), c(this, it, "f").push({ type: "removal", name: i });
      }
    }
    /**
     * Makes the ToolRunner directly awaitable, equivalent to calling .runUntilDone()
     * This allows using `await runner` instead of `await runner.runUntilDone()`
     */
    then(e, t) {
      return this.runUntilDone().then(e, t);
    }
  }
  return Ps = /**
   * Sends one request and yields its message, or its stream when streaming. `#message` and `#stream` are set
   * before the yield, so they are there while the caller handles the item; the loop aborts the stream at the
   * end of the iteration.
   */
  async function* (e) {
    await c(this, N, "m", zs).call(this), y(this, Te, void 0), e = c(this, N, "m", wn).call(this, () => ({
      ...e,
      ...e.tools && { tools: e.tools.map(ni) },
      messages: uc(e.messages)
    })), e.stream ? (y(this, Fe, c(this, N, "m", wn).call(this, () => c(this, L, "f").params.runToolsEagerly ? c(this, N, "m", nc).call(this, e) : this.client.beta.messages.stream({ ...e }, c(this, G, "f")))), y(this, ne, c(this, Fe, "f").finalMessage()), c(this, ne, "f").catch(() => {
    }), yield c(this, Fe, "f")) : (y(this, ne, c(this, N, "m", wn).call(this, () => this.client.beta.messages.create({ ...e, stream: !1 }, c(this, G, "f")))), yield c(this, ne, "f"));
  }, nc = function(e) {
    const t = /* @__PURE__ */ new Map();
    y(this, Te, t);
    const s = /* @__PURE__ */ new Map();
    return ec.start(this.client, e, c(this, G, "f"), (i) => {
      const a = t.has(i.id), o = !i.toolset_name && c(this, N, "m", kr).call(this).has(i.name), l = o ? i.name : i.toolset_name;
      if (l) {
        if (a || o || s.has(l)) {
          s.set(l, "waiting");
          return;
        }
        s.set(l, "running");
        const _ = Uu(c(this, L, "f").params, l, i, c(this, G, "f"), this.client, c(this, Ee, "f"));
        t.set(i.id, { status: "started", result: _ }), _.then(({ is_error: d }) => {
          d || s.get(l) === "waiting" ? s.set(l, "waiting") : s.delete(l);
        }, () => s.set(l, "waiting"));
        return;
      }
      if (a)
        return;
      const h = Fu(c(this, N, "m", yn).call(this), c(this, N, "m", vr).call(this), i, c(this, G, "f"), this.client, c(this, Ee, "f"));
      h.catch(() => {
      }), t.set(i.id, { status: "started", result: h });
    });
  }, zs = /** Waits for the calls of the last streamed reply that have started, whether or not their results were sent. */
  async function() {
    const e = [...c(this, Te, "f")?.values() ?? []].filter((t) => t.status === "started");
    await Promise.allSettled(e.map((t) => t.result));
  }, Ms = async function* (e) {
    $s(c(this, L, "f").params);
    const { max_iterations: t, runToolsEagerly: s, ...i } = c(this, L, "f").params, a = og(i);
    y(this, le, { status: "in_flight" }), y(this, Se, void 0);
    const o = c(this, ne, "f");
    try {
      yield* c(this, N, "m", Ps).call(this, { ...a, compaction: e });
      const l = await c(this, ne, "f");
      l.content.some((h) => h.type === "compaction" && h.content) ? (c(this, N, "m", rc).call(this), c(this, L, "f").params.messages = [{ role: l.role, content: l.content }]) : (M(this.client).warn("Compaction produced no summary; keeping the conversation as it is."), y(this, ne, o, "f"));
    } finally {
      y(this, le, { status: "idle" });
    }
  }, yn = function() {
    const e = /* @__PURE__ */ new Map();
    for (const t of c(this, L, "f").params.tools)
      "run" in t && "name" in t && e.set(t.name, t);
    for (const [t, s] of c(this, Pt, "f"))
      s ? e.set(t, s) : e.delete(t);
    return e;
  }, vr = function() {
    const e = new Set(c(this, N, "m", yn).call(this).keys());
    for (const t of [...c(this, L, "f").params.messages, c(this, N, "m", Cs).call(this)])
      if (typeof t.content != "string") {
        for (const s of t.content)
          if (t.role === "system")
            dc(s, e);
          else if (t.role === "assistant" && s.type === "compaction")
            for (const i of s.tool_changes ?? [])
              dc(i, e);
      }
    return e;
  }, rc = function() {
    const e = c(this, N, "m", vr).call(this);
    for (const t of c(this, N, "m", yn).call(this).keys())
      e.has(t) || c(this, Pt, "f").set(t, null);
  }, sc = async function* () {
    if (c(this, le, "f").status !== "scheduled")
      return;
    const e = c(this, L, "f").params.messages.at(-1)?.content;
    if (Array.isArray(e) && e.some((t) => t.type === "tool_use")) {
      M(this.client).warn("The pending compaction was skipped because the last turn ended with tool calls that were not run. Call `compactBeforeNextTurn()` again if you continue the conversation."), y(this, le, { status: "idle" });
      return;
    }
    yield* c(this, N, "m", Ms).call(this, c(this, le, "f").config);
  }, Os = async function(e, t, s) {
    return c(this, Se, "f") !== void 0 ? c(this, Se, "f") : (y(this, Se, cg(c(this, L, "f").params, c(this, N, "m", yn).call(this), c(this, N, "m", vr).call(this), e, { ...c(this, G, "f"), signal: t }, c(this, Te, "f"), this.client, s)), c(this, Se, "f"));
  }, kr = function() {
    return new Set(c(this, L, "f").params.tools.filter(Mn).map(Ft));
  }, ic = function() {
    c(this, Rt, "f") === "pause_turn" || c(this, it, "f").length === 0 || (c(this, L, "f").params.messages.push(c(this, N, "m", Cs).call(this)), y(this, it, []));
  }, Cs = function() {
    const e = [];
    for (const t of c(this, it, "f")) {
      if (t.type === "removal") {
        e.push({ type: "tool_removal", tool: { type: "tool_reference", name: t.name } });
        continue;
      }
      const s = ni(t.tool);
      e.push({ type: "tool_addition", tool: { type: "tool_definition", definition: s } });
    }
    return { role: "system", content: e };
  }, r;
})();
function cc(r) {
  if ("compaction" in r && r.compaction != null)
    throw new R("`compaction` cannot be set on a tool runner: every request in the loop would compact again. Call `runner.compactBeforeNextTurn()` when the conversation should be compacted instead.");
}
function ag(r) {
  if ("compactionControl" in r && r.compactionControl != null)
    throw new R("`compactionControl` has been removed from the tool runner. Use server-side compaction instead: call `runner.compactBeforeNextTurn()` when the conversation should be compacted.");
}
function lc(r) {
  if (r.runToolsEagerly && !r.stream)
    throw new TypeError("`runToolsEagerly: true` needs `stream: true` in the tool runner's params, because a reply that isn't streamed arrives whole.");
}
function $s(r) {
  if (r.context_management?.edits?.some((n) => n.type.startsWith("compact_")))
    throw new R("`compactBeforeNextTurn()` can't be used while `context_management` has a compaction edit, because the API doesn't accept a compaction block together with one. Remove the edit first.");
}
function og(r) {
  const { context_management: n, stop_sequences: e, output_format: t, ...s } = r, i = ({ format: a, ...o }) => o;
  return (s.tool_choice?.type === "any" || s.tool_choice?.type === "tool") && delete s.tool_choice, s.output_config && (s.output_config = i(s.output_config)), Array.isArray(s.fallbacks) && (s.fallbacks = s.fallbacks.map((a) => a.output_config ? { ...a, output_config: i(a.output_config) } : a)), s;
}
function ni(r) {
  if (!("run" in r))
    return r;
  const n = gg, e = "toJSON" in r && typeof r.toJSON == "function" ? r.toJSON() : r;
  return {
    ...Object.fromEntries(Object.entries(e).filter(([t]) => n.includes(t))),
    ...ot(r) && { [ze]: r[ze] }
  };
}
function uc(r) {
  return r.map((n) => {
    if (n.role !== "system" || typeof n.content == "string")
      return n;
    const e = n.content.map((t) => t.type === "tool_addition" && t.tool.type === "tool_definition" ? { ...t, tool: { ...t.tool, definition: ni(t.tool.definition) } } : t);
    return { ...n, content: e };
  });
}
async function cg(r, n, e, t, s, i, a, o) {
  if (!t || t.role !== "assistant" || !t.content || typeof t.content == "string")
    return null;
  const l = t.content.filter((d) => d.type === "tool_use");
  if (l.length === 0)
    return null;
  const h = /* @__PURE__ */ new Map();
  return {
    role: "user",
    content: await Promise.all(l.map(async (d) => {
      const m = i?.get(d.id), g = m?.status === "started" ? m.result : void 0;
      if (d.toolset_name) {
        const S = d.toolset_name, x = h.get(S) ?? { tail: Promise.resolve(), failed: !1 };
        h.set(S, x);
        const v = r.tools.some((A) => Mn(A) && Ft(A) === S), k = g ?? x.tail.then(() => x.failed ? Hr(d, tg(S), !0) : Uu(r, S, d, s, a, o));
        return x.tail = k.then(({ is_error: A }) => {
          A && v && (x.failed = !0);
        }, () => {
          x.failed = !0;
        }), i?.set(d.id, { status: "started", result: k }), k;
      }
      if (g)
        return g;
      if (!(e.has(d.name) ? n.get(d.name) : void 0) && r.tools.some((S) => Mn(S) && Ft(S) === d.name)) {
        const S = h.get(d.name) ?? { tail: Promise.resolve(), failed: !1 };
        return h.set(d.name, S), S.tail = S.tail.then(() => {
          S.failed = !0;
        }), dg(d);
      }
      const w = Fu(n, e, d, s, a, o);
      return i?.set(d.id, { status: "started", result: w }), w;
    }))
  };
}
async function Uu(r, n, e, t, s, i) {
  const a = r.tools.find((h) => Mn(h) && Ft(h) === n);
  if (!a)
    return Hr(e, `Error: Toolset '${Ge(n)}' member '${Ge(e.name)}' not found`, !0);
  const o = {
    signal: t?.signal,
    conversationId: t?.openTelemetry?.conversationId,
    parentContext: i
  };
  return (await Ai(s, a, e, o, async () => {
    const h = await sg(a, e, { signal: t?.signal });
    return { block: h, content: h.content ?? [], isError: h.is_error === !0 };
  })).block;
}
async function Fu(r, n, e, t, s, i) {
  const a = n.has(e.name) ? r.get(e.name) : void 0;
  if (!a)
    return ug(e);
  const o = {
    signal: t?.signal,
    conversationId: t?.openTelemetry?.conversationId,
    parentContext: i
  }, l = await Ai(s, a, e, o, () => Mu(a, e.input, {
    toolUse: e,
    toolUseBlock: e,
    signal: t?.signal
  }));
  return {
    type: "tool_result",
    tool_use_id: e.id,
    content: l.content,
    ...l.isError ? { is_error: !0 } : void 0
  };
}
function lg(r) {
  return (r.type ?? "custom").replace(/_\d{8}$/, "").replace(/_toolset$/, "");
}
function ug(r) {
  return {
    type: "tool_result",
    tool_use_id: r.id,
    content: `Error: Tool '${r.name}' not found`,
    is_error: !0
  };
}
function dg(r) {
  return {
    type: "tool_result",
    tool_use_id: r.id,
    content: `Error: the '${Ge(r.name)}' toolset could not run this call${hg(r.input)}; nothing in the batch was executed`,
    is_error: !0
  };
}
function hg(r) {
  const n = typeof r == "object" && r !== null ? r : {};
  if (!("actions" in n)) {
    const i = "action" in n ? n.action : void 0;
    return typeof i == "string" ? `: the call has no 'actions' list (action: '${Ge(i)}')` : ": the call has no 'actions' list";
  }
  const { actions: e } = n;
  if (typeof e == "string")
    return ": 'actions' is text, not a list of actions";
  if (!Array.isArray(e))
    return ": 'actions' is not a list of actions";
  if (e.length === 0)
    return ": the 'actions' list is empty";
  const t = [];
  for (const [i, a] of e.entries()) {
    const o = typeof a == "object" && a !== null && "action" in a ? a.action : void 0;
    if (typeof o != "string")
      return `: action ${i} must be an object with a string 'action' field`;
    t.push(`'${Ge(o)}'`);
  }
  const s = t.length > 10 ? `, and ${t.length - 10} more` : "";
  return `: its actions could not be run as sent (actions: ${t.slice(0, 10).join(", ")}${s})`;
}
function dc(r, n) {
  switch (r.type) {
    case "tool_removal":
    case "tool_addition":
      _g(r, n);
      break;
  }
}
function _g(r, n) {
  const e = pg(r.tool);
  e !== void 0 && (r.type === "tool_removal" ? n.delete(e) : n.add(e));
}
function pg(r) {
  switch (r.type) {
    case "tool_reference":
      return r.name;
    case "tool_definition":
      return "name" in r.definition ? r.definition.name : void 0;
    default:
      return;
  }
}
function hc(r) {
  if (r === null)
    return "stop";
  switch (r) {
    case "tool_use":
      return "run_tools";
    case "pause_turn":
    // pause_after_compaction hands the turn back before the model answers; sending it back
    // unchanged continues it.
    case "compaction":
      return "resume";
    case "end_turn":
    case "stop_sequence":
    case "max_tokens":
    case "model_context_window_exceeded":
    case "refusal":
      return "stop";
    default:
      return "stop";
  }
}
const _c = {
  "claude-sonnet-4-5": "November 30th, 2026",
  "claude-sonnet-4-5-20250929": "November 30th, 2026"
}, fg = ["claude-mythos-preview", "claude-opus-4-6"];
var pc = /* @__PURE__ */ (() => {
  class r extends T {
    constructor() {
      super(...arguments), this.batches = new Wa(this._client);
    }
    create(e, t) {
      const s = ti(e), { betas: i, user_profile_id: a, workspace_id: o, ...l } = s;
      l.model in _c && console.warn(`The model '${l.model}' is deprecated and will reach end-of-life on ${_c[l.model]}
Please migrate to a newer model. Visit https://docs.anthropic.com/en/docs/resources/model-deprecations for more information.`), fg.includes(l.model) && l.thinking && l.thinking.type === "enabled" && console.warn(`Using Claude with ${l.model} and 'thinking.type=enabled' is deprecated. Use 'thinking.type=adaptive' instead which results in better model performance in our testing: https://platform.claude.com/docs/en/build-with-claude/adaptive-thinking`);
      let h = t?.timeout ?? this._client._options.timeout;
      if (!l.stream && h == null) {
        const g = Tu[l.model] ?? void 0;
        h = this._client.calculateNonstreamingTimeout(l.max_tokens, g);
      }
      const _ = Iu(s, t), d = this._client._tracer && u(this._client, "anthropic.messages.create", t, Xr(this._client, l, _));
      Zl(this._client, d, l);
      const m = this._client.post("/v1/messages?beta=true", {
        body: l,
        timeout: h ?? 6e5,
        ...t,
        __span: d,
        headers: _,
        stream: s.stream ?? !1
      });
      return d ? m._thenUnwrap((g) => (eu(this._client, d, l, g), g)) : m;
    }
    /**
     * Send a structured list of input messages with text and/or image content, along with an expected `output_format` and
     * the response will be automatically parsed and available in the `parsed_output` property of the message.
     *
     * @example
     * ```ts
     * const message = await client.beta.messages.parse({
     *   model: 'claude-3-5-sonnet-20241022',
     *   max_tokens: 1024,
     *   messages: [{ role: 'user', content: 'What is 2+2?' }],
     *   output_format: zodOutputFormat(z.object({ answer: z.number() }), 'math'),
     * });
     *
     * console.log(message.parsed_output?.answer); // 4
     * ```
     */
    parse(e, t) {
      return t = {
        ...t,
        headers: p([
          { "anthropic-beta": [...e.betas ?? [], "structured-outputs-2025-12-15"].toString() },
          t?.headers
        ])
      }, this.create(e, t).then((s) => $u(s, e, { logger: this._client.logger ?? console }));
    }
    /**
     * Create a Message stream
     */
    stream(e, t) {
      return Nu.createMessage(this, e, t, { client: this._client });
    }
    /**
     * Count the number of tokens in a Message.
     *
     * The Token Count API can be used to count the number of tokens in a Message,
     * including tools, images, and documents, without creating it.
     *
     * Learn more about token counting in our
     * [user guide](https://platform.claude.com/docs/en/build-with-claude/token-counting)
     *
     * @example
     * ```ts
     * const betaMessageTokensCount =
     *   await client.beta.messages.countTokens({
     *     messages: [{ content: 'Hello, world', role: 'user' }],
     *     model: 'claude-opus-5-5',
     *   });
     * ```
     */
    countTokens(e, t) {
      const s = ti(e), { betas: i, user_profile_id: a, workspace_id: o, ...l } = s, h = p([
        {
          "anthropic-beta": [...i ?? [], "token-counting-2024-11-01"].toString(),
          ...a != null ? { "anthropic-user-profile-id": a } : void 0,
          ...o != null ? { "anthropic-workspace-id": o } : void 0
        },
        t?.headers
      ]), _ = u(this._client, "anthropic.messages.count_tokens", t, {
        route: "/v1/messages/count_tokens",
        attributes: { [Cn]: l.model }
      }), d = this._client.post("/v1/messages/count_tokens?beta=true", {
        body: l,
        ...t,
        __span: _,
        headers: h
      });
      return _ ? d._thenUnwrap((m) => (tu(this._client, _, m), m)) : d;
    }
    toolRunner(e, t) {
      return new oc(this._client, e, t);
    }
  }
  return r.Batches = Wa, r.BetaToolRunner = oc, r.ToolError = Pi, r;
})();
const gg = [
  "input_schema",
  "name",
  "allowed_callers",
  "cache_control",
  "defer_loading",
  "description",
  "eager_input_streaming",
  "input_examples",
  "strict",
  "type",
  "configs",
  "display_height_px",
  "display_width_px",
  "display_number",
  "enable_zoom",
  "max_characters"
];
var fc = /* @__PURE__ */ (() => {
  class r extends T {
    constructor() {
      super(...arguments), this.models = new ma(this._client), this.messages = new pc(this._client), this.agents = new Ta(this._client), this.environments = new qa(this._client), this.sessions = new Ho(this._client), this.deployments = new pa(this._client), this.deploymentRuns = new _a(this._client), this.vaults = new Qo(this._client), this.memoryStores = new Fa(this._client), this.files = new ga(this._client), this.skills = new Ko(this._client), this.webhooks = new ka(this._client), this.userProfiles = new Yo(this._client), this.dreams = new fa(this._client), this.tunnels = new Vo(this._client), this.organization = new Bo(this._client);
    }
  }
  return r.Models = ma, r.Messages = pc, r.Agents = Ta, r.Environments = qa, r.Sessions = Ho, r.Deployments = pa, r.DeploymentRuns = _a, r.Vaults = Qo, r.MemoryStores = Fa, r.Files = ga, r.Skills = Ko, r.Webhooks = ka, r.UserProfiles = Yo, r.Dreams = fa, r.Tunnels = Vo, r.Organization = Bo, r;
})();
class gc extends T {
  create(n, e) {
    const { betas: t, workspace_id: s, ...i } = n;
    return this._client.post("/v1/complete", {
      body: i,
      timeout: this._client._options.timeout ?? 6e5,
      ...e,
      headers: p([
        {
          ...t?.toString() != null ? { "anthropic-beta": t?.toString() } : void 0,
          ...s != null ? { "anthropic-workspace-id": s } : void 0
        },
        e?.headers
      ]),
      stream: n.stream ?? !1,
      __span: u(this._client, "anthropic.completions.create", e, {
        route: "/v1/complete"
      })
    });
  }
}
class mc extends T {
  /**
   * List Files
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const fileMetadata of client.files.list()) {
   *   // ...
   * }
   * ```
   */
  list(n = {}, e) {
    const { workspace_id: t, ...s } = n ?? {};
    return this._client.getAPIList("/v1/files", P, {
      query: s,
      ...e,
      headers: p([
        { ...t != null ? { "anthropic-workspace-id": t } : void 0 },
        e?.headers
      ]),
      __span: u(this._client, "anthropic.files.list", e, {
        route: "/v1/files",
        queryParams: ["ids", "limit", "page"]
      })
    });
  }
  /**
   * Delete File
   *
   * @example
   * ```ts
   * const deletedFile = await client.files.delete('file_id');
   * ```
   */
  delete(n, e = {}, t) {
    const { workspace_id: s } = e ?? {};
    return this._client.delete(f`/v1/files/${n}`, {
      ...t,
      headers: p([
        { ...s != null ? { "anthropic-workspace-id": s } : void 0 },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.files.delete", t, {
        route: "/v1/files/{file_id}",
        attributes: { "anthropic.file.id": n }
      })
    });
  }
  /**
   * Download File
   *
   * @example
   * ```ts
   * const response = await client.files.download('file_id');
   *
   * const content = await response.blob();
   * console.log(content);
   * ```
   */
  download(n, e = {}, t) {
    const { workspace_id: s } = e ?? {};
    return this._client.get(f`/v1/files/${n}/content`, {
      ...t,
      headers: p([
        {
          Accept: "application/binary",
          ...s != null ? { "anthropic-workspace-id": s } : void 0
        },
        t?.headers
      ]),
      __binaryResponse: !0,
      __span: u(this._client, "anthropic.files.download", t, {
        route: "/v1/files/{file_id}/content",
        attributes: { "anthropic.file.id": n }
      })
    });
  }
  /**
   * Get File Metadata
   *
   * @example
   * ```ts
   * const fileMetadata = await client.files.retrieveMetadata(
   *   'file_id',
   * );
   * ```
   */
  retrieveMetadata(n, e = {}, t) {
    const { workspace_id: s } = e ?? {};
    return this._client.get(f`/v1/files/${n}`, {
      ...t,
      headers: p([
        { ...s != null ? { "anthropic-workspace-id": s } : void 0 },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.files.retrieve_metadata", t, {
        route: "/v1/files/{file_id}",
        attributes: { "anthropic.file.id": n }
      })
    });
  }
  /**
   * Upload File
   *
   * @example
   * ```ts
   * const fileMetadata = await client.files.upload({
   *   file: fs.createReadStream('path/to/file'),
   * });
   * ```
   */
  upload(n, e) {
    const { workspace_id: t, ...s } = n;
    return this._client.post("/v1/files", Ce({
      body: s,
      ...e,
      headers: p([
        { ...t != null ? { "anthropic-workspace-id": t } : void 0 },
        cu(s.file),
        e?.headers
      ]),
      __span: u(this._client, "anthropic.files.upload", e, {
        route: "/v1/files",
        createdIDAttribute: "anthropic.file.id"
      })
    }, this._client));
  }
}
class bc extends T {
  /**
   * Get a specific model.
   *
   * The Models API response can be used to determine information about a specific
   * model or resolve a model alias to a model ID.
   *
   * @example
   * ```ts
   * const modelInfo = await client.models.retrieve('model_id');
   * ```
   */
  retrieve(n, e = {}, t) {
    const { betas: s, workspace_id: i } = e ?? {};
    return this._client.get(f`/v1/models/${n}`, {
      ...t,
      headers: p([
        {
          ...s?.toString() != null ? { "anthropic-beta": s?.toString() } : void 0,
          ...i != null ? { "anthropic-workspace-id": i } : void 0
        },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.models.retrieve", t, {
        route: "/v1/models/{model_id}",
        attributes: { "anthropic.model.id": n }
      })
    });
  }
  /**
   * List available models.
   *
   * The Models API response can be used to determine which models are available for
   * use in the API. More recently released models are listed first.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const modelInfo of client.models.list()) {
   *   // ...
   * }
   * ```
   */
  list(n = {}, e) {
    const { betas: t, workspace_id: s, ...i } = n ?? {};
    return this._client.getAPIList("/v1/models", Y, {
      query: i,
      ...e,
      headers: p([
        {
          ...t?.toString() != null ? { "anthropic-beta": t?.toString() } : void 0,
          ...s != null ? { "anthropic-workspace-id": s } : void 0
        },
        e?.headers
      ]),
      __span: u(this._client, "anthropic.models.list", e, {
        route: "/v1/models",
        queryParams: ["after_id", "before_id", "lifecycle", "limit"]
      })
    });
  }
}
class wc extends T {
  /**
   * Get API Key
   *
   * @example
   * ```ts
   * const apiKey = await client.organization.apiKeys.retrieve(
   *   'api_key_id',
   * );
   * ```
   */
  retrieve(n, e) {
    return this._client.get(f`/v1/organizations/api_keys/${n}`, {
      ...e,
      __span: u(this._client, "anthropic.organization.api_keys.retrieve", e, {
        route: "/v1/organizations/api_keys/{api_key_id}",
        attributes: { "anthropic.organization.api_key.id": n }
      })
    });
  }
  /**
   * Update API Key
   *
   * @example
   * ```ts
   * const apiKey = await client.organization.apiKeys.update(
   *   'api_key_id',
   * );
   * ```
   */
  update(n, e, t) {
    return this._client.post(f`/v1/organizations/api_keys/${n}`, {
      body: e,
      ...t,
      __span: u(this._client, "anthropic.organization.api_keys.update", t, {
        route: "/v1/organizations/api_keys/{api_key_id}",
        attributes: { "anthropic.organization.api_key.id": n }
      })
    });
  }
  /**
   * List API Keys
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const apiKey of client.organization.apiKeys.list()) {
   *   // ...
   * }
   * ```
   */
  list(n = {}, e) {
    return this._client.getAPIList("/v1/organizations/api_keys", Y, {
      query: n,
      ...e,
      __span: u(this._client, "anthropic.organization.api_keys.list", e, {
        route: "/v1/organizations/api_keys",
        queryParams: ["after_id", "before_id", "created_by_user_id", "limit", "status", "workspace_id"]
      })
    });
  }
}
class yc extends T {
  /**
   * Retrieve your organization's Compliance Settings.
   *
   * Compliance Settings is a singleton resource: there is exactly one per
   * organization, addressed without an identifier. The `state` field reflects
   * whether the Compliance API is enabled. An organization with a parent
   * organization reads the state inherited from the parent's configuration.
   *
   * @example
   * ```ts
   * const organizationComplianceSettings =
   *   await client.organization.complianceSettings.retrieve();
   * ```
   */
  retrieve(n) {
    return this._client.get("/v1/organizations/compliance_settings", {
      ...n,
      __span: u(this._client, "anthropic.organization.compliance_settings.retrieve", n, {
        route: "/v1/organizations/compliance_settings"
      })
    });
  }
  /**
   * Update your organization's Compliance Settings.
   *
   * Setting `state` to `enabled` turns on the Compliance API and begins capturing
   * organization activity events. Setting it to `disabled` turns both off. `state`
   * reflects whether the Compliance API is enabled.
   *
   * A request that sets `state` to its current value succeeds and leaves the
   * resource unchanged. A `disabled` request stays in effect until a later `enabled`
   * request or the organization's next provisioning action that enables Access
   * Transparency: enabling Access Transparency also enables the Compliance API,
   * which serves its activity events, so such provisioning (including re-runs)
   * re-enables the Compliance API even after a `disabled` request. Automated
   * provisioning never disables compliance settings.
   *
   * @example
   * ```ts
   * const organizationComplianceSettings =
   *   await client.organization.complianceSettings.update({
   *     state: { type: 'enabled' },
   *   });
   * ```
   */
  update(n, e) {
    return this._client.post("/v1/organizations/compliance_settings", {
      body: n,
      ...e,
      __span: u(this._client, "anthropic.organization.compliance_settings.update", e, {
        route: "/v1/organizations/compliance_settings"
      })
    });
  }
}
class vc extends T {
  /**
   * Create an external key config owned by the caller's organization.
   *
   * @example
   * ```ts
   * const externalKey =
   *   await client.organization.externalKeys.create({
   *     provider_config: {
   *       kms_arn:
   *         'arn:aws:kms:us-east-1:111122223333:key/abcd1234-5678-90ab-cdef-000011112222',
   *       type: 'aws',
   *     },
   *   });
   * ```
   */
  create(n, e) {
    return this._client.post("/v1/organizations/external_keys", {
      body: n,
      ...e,
      __span: u(this._client, "anthropic.organization.external_keys.create", e, {
        route: "/v1/organizations/external_keys",
        createdIDAttribute: "anthropic.organization.external_key.id"
      })
    });
  }
  /**
   * Retrieve a single external key config in the caller's organization by ID.
   *
   * @example
   * ```ts
   * const externalKey =
   *   await client.organization.externalKeys.retrieve(
   *     'external_key_id',
   *   );
   * ```
   */
  retrieve(n, e) {
    return this._client.get(f`/v1/organizations/external_keys/${n}`, {
      ...e,
      __span: u(this._client, "anthropic.organization.external_keys.retrieve", e, {
        route: "/v1/organizations/external_keys/{external_key_id}",
        attributes: { "anthropic.organization.external_key.id": n }
      })
    });
  }
  /**
   * Partially update an external key config. Omitted fields are left unchanged.
   *
   * `display_name` is always editable. `geo` and `provider_config` cannot be changed
   * once any workspace references this config, because previously encrypted data
   * requires the original key identity to decrypt.
   *
   * @example
   * ```ts
   * const externalKey =
   *   await client.organization.externalKeys.update(
   *     'external_key_id',
   *   );
   * ```
   */
  update(n, e, t) {
    return this._client.post(f`/v1/organizations/external_keys/${n}`, {
      body: e,
      ...t,
      __span: u(this._client, "anthropic.organization.external_keys.update", t, {
        route: "/v1/organizations/external_keys/{external_key_id}",
        attributes: { "anthropic.organization.external_key.id": n }
      })
    });
  }
  /**
   * List external key configs in the caller's organization.
   *
   * Results are ordered by creation time (newest first). Use the `next_page` cursor
   * from the response to fetch subsequent pages.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const externalKey of client.organization.externalKeys.list()) {
   *   // ...
   * }
   * ```
   */
  list(n = {}, e) {
    return this._client.getAPIList("/v1/organizations/external_keys", P, {
      query: n,
      ...e,
      __span: u(this._client, "anthropic.organization.external_keys.list", e, {
        route: "/v1/organizations/external_keys",
        queryParams: ["limit", "page"]
      })
    });
  }
  /**
   * Delete an external key config.
   *
   * The request is rejected if any workspace still references this config.
   *
   * @example
   * ```ts
   * const externalKey =
   *   await client.organization.externalKeys.delete(
   *     'external_key_id',
   *   );
   * ```
   */
  delete(n, e) {
    return this._client.delete(f`/v1/organizations/external_keys/${n}`, {
      ...e,
      __span: u(this._client, "anthropic.organization.external_keys.delete", e, {
        route: "/v1/organizations/external_keys/{external_key_id}",
        attributes: { "anthropic.organization.external_key.id": n }
      })
    });
  }
  /**
   * Validate an external key config against the customer's KMS.
   *
   * Anthropic performs an encrypt/decrypt roundtrip against the configured KMS key
   * and waits up to 30 seconds for the result. The response status is `success` if
   * the roundtrip succeeded, or `failure` with an error message if it failed or
   * timed out.
   *
   * @example
   * ```ts
   * const response =
   *   await client.organization.externalKeys.validate(
   *     'external_key_id',
   *   );
   * ```
   */
  validate(n, e) {
    return this._client.post(f`/v1/organizations/external_keys/${n}/validate`, {
      ...e,
      __span: u(this._client, "anthropic.organization.external_keys.validate", e, {
        route: "/v1/organizations/external_keys/{external_key_id}/validate",
        attributes: { "anthropic.organization.external_key.id": n }
      })
    });
  }
}
class kc extends T {
  /**
   * Invite a user to join the organization by email.
   *
   * On plans that draw members from a finite pool of purchased seats, the invite
   * automatically consumes a seat from the lowest tier with availability; there is
   * no seat-tier parameter. When no seat is free the request fails with a 400 error
   * rather than purchasing a seat.
   *
   * @example
   * ```ts
   * const organizationInvite =
   *   await client.organization.invites.create({
   *     email: 'user@emaildomain.com',
   *     role: 'user',
   *   });
   * ```
   */
  create(n, e) {
    return this._client.post("/v1/organizations/invites", {
      body: n,
      ...e,
      __span: u(this._client, "anthropic.organization.invites.create", e, {
        route: "/v1/organizations/invites",
        createdIDAttribute: "anthropic.organization.invite.id"
      })
    });
  }
  /**
   * Retrieve an invite by ID.
   *
   * @example
   * ```ts
   * const organizationInvite =
   *   await client.organization.invites.retrieve('invite_id');
   * ```
   */
  retrieve(n, e) {
    return this._client.get(f`/v1/organizations/invites/${n}`, {
      ...e,
      __span: u(this._client, "anthropic.organization.invites.retrieve", e, {
        route: "/v1/organizations/invites/{invite_id}",
        attributes: { "anthropic.organization.invite.id": n }
      })
    });
  }
  /**
   * List the organization's invites.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const organizationInvite of client.organization.invites.list()) {
   *   // ...
   * }
   * ```
   */
  list(n = {}, e) {
    return this._client.getAPIList("/v1/organizations/invites", Y, {
      query: n,
      ...e,
      __span: u(this._client, "anthropic.organization.invites.list", e, {
        route: "/v1/organizations/invites",
        queryParams: ["after_id", "before_id", "email", "limit", "roles", "statuses"]
      })
    });
  }
  /**
   * Delete a pending invite.
   *
   * @example
   * ```ts
   * const invite = await client.organization.invites.delete(
   *   'invite_id',
   * );
   * ```
   */
  delete(n, e) {
    return this._client.delete(f`/v1/organizations/invites/${n}`, {
      ...e,
      __span: u(this._client, "anthropic.organization.invites.delete", e, {
        route: "/v1/organizations/invites/{invite_id}",
        attributes: { "anthropic.organization.invite.id": n }
      })
    });
  }
}
let Sc = class extends T {
  /**
   * List Messages API rate limits for your organization.
   *
   * Each entry corresponds to one rate-limit group (either a model family or an
   * API-surface category such as the Message Batches API or the web search tool) and
   * contains the set of limiter values that apply to it.
   *
   * When `limit` is omitted, every matching entry is returned in a single page; when
   * `limit` truncates the result, follow `next_page` to fetch the remaining entries.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const organizationRateLimit of client.organization.rateLimits.list()) {
   *   // ...
   * }
   * ```
   */
  list(n = {}, e) {
    return this._client.getAPIList("/v1/organizations/rate_limits", P, {
      query: n,
      ...e,
      __span: u(this._client, "anthropic.organization.rate_limits.list", e, {
        route: "/v1/organizations/rate_limits",
        queryParams: ["group_type", "limit", "model", "page"]
      })
    });
  }
};
class Tc extends T {
  /**
   * Retrieve a member of the organization by user ID.
   *
   * @example
   * ```ts
   * const organizationUser =
   *   await client.organization.users.retrieve('user_id');
   * ```
   */
  retrieve(n, e) {
    return this._client.get(f`/v1/organizations/users/${n}`, {
      ...e,
      __span: u(this._client, "anthropic.organization.users.retrieve", e, {
        route: "/v1/organizations/users/{user_id}",
        attributes: { "anthropic.organization.user.id": n }
      })
    });
  }
  /**
   * Update a member's organization role.
   *
   * @example
   * ```ts
   * const organizationUser =
   *   await client.organization.users.update('user_id', {
   *     role: 'user',
   *   });
   * ```
   */
  update(n, e, t) {
    return this._client.post(f`/v1/organizations/users/${n}`, {
      body: e,
      ...t,
      __span: u(this._client, "anthropic.organization.users.update", t, {
        route: "/v1/organizations/users/{user_id}",
        attributes: { "anthropic.organization.user.id": n }
      })
    });
  }
  /**
   * List the organization's members.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const organizationUser of client.organization.users.list()) {
   *   // ...
   * }
   * ```
   */
  list(n = {}, e) {
    return this._client.getAPIList("/v1/organizations/users", Y, {
      query: n,
      ...e,
      __span: u(this._client, "anthropic.organization.users.list", e, {
        route: "/v1/organizations/users",
        queryParams: ["after_id", "before_id", "email", "limit", "roles"]
      })
    });
  }
  /**
   * Remove a member from the organization.
   *
   * @example
   * ```ts
   * const user = await client.organization.users.remove(
   *   'user_id',
   * );
   * ```
   */
  remove(n, e) {
    return this._client.delete(f`/v1/organizations/users/${n}`, {
      ...e,
      __span: u(this._client, "anthropic.organization.users.remove", e, {
        route: "/v1/organizations/users/{user_id}",
        attributes: { "anthropic.organization.user.id": n }
      })
    });
  }
}
class Ac extends T {
  /**
   * **Requires an OAuth access token with the `org:admin` scope**, from
   * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
   * API keys are not accepted. See
   * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
   *
   * Register an OIDC issuer that Anthropic will trust for workload identity
   * federation in your organization.
   *
   * The `jwks` field controls how the issuer's signing keys are obtained and takes
   * one of three shapes selected by `type`: `discovery` (resolve keys through OIDC
   * discovery), `explicit_url` (fetch keys from a fixed JWKS URL), or `inline`
   * (provide a static key set). When `jwks.type` is `discovery` and no
   * `discovery_base` is set, the issuer URL must be publicly reachable over HTTPS so
   * Anthropic can fetch the discovery document; for `explicit_url` and `inline`
   * modes the issuer URL is only matched as the JWT's `iss` claim and is not
   * fetched.
   *
   * @example
   * ```ts
   * const federationIssuer =
   *   await client.organization.federation.issuers.create({
   *     issuer_url: 'x',
   *     name: 'x',
   *   });
   * ```
   */
  create(n, e) {
    return this._client.post("/v1/organizations/federation_issuers", {
      body: n,
      ...e,
      __span: u(this._client, "anthropic.organization.federation.issuers.create", e, {
        route: "/v1/organizations/federation_issuers",
        createdIDAttribute: "anthropic.organization.federation_issuer.id"
      })
    });
  }
  /**
   * **Requires an OAuth access token with the `org:admin` scope**, from
   * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
   * API keys are not accepted. See
   * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
   *
   * Retrieve a federation issuer by its ID (`fdis_...`).
   *
   * @example
   * ```ts
   * const federationIssuer =
   *   await client.organization.federation.issuers.retrieve(
   *     'federation_issuer_id',
   *   );
   * ```
   */
  retrieve(n, e) {
    return this._client.get(f`/v1/organizations/federation_issuers/${n}`, {
      ...e,
      __span: u(this._client, "anthropic.organization.federation.issuers.retrieve", e, {
        route: "/v1/organizations/federation_issuers/{federation_issuer_id}",
        attributes: { "anthropic.organization.federation_issuer.id": n }
      })
    });
  }
  /**
   * **Requires an OAuth access token with the `org:admin` scope**, from
   * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
   * API keys are not accepted. See
   * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
   *
   * Partially update a federation issuer.
   *
   * Setting `jwks` replaces the full JWKS shape at once. Archived issuers cannot be
   * updated; this returns 400. Create a new issuer instead.
   *
   * Updating an issuer that backs a rule with a scope outside `workspace:developer`
   * or `workspace:inference` requires a Console session.
   *
   * @example
   * ```ts
   * const federationIssuer =
   *   await client.organization.federation.issuers.update(
   *     'federation_issuer_id',
   *   );
   * ```
   */
  update(n, e, t) {
    return this._client.post(f`/v1/organizations/federation_issuers/${n}`, {
      body: e,
      ...t,
      __span: u(this._client, "anthropic.organization.federation.issuers.update", t, {
        route: "/v1/organizations/federation_issuers/{federation_issuer_id}",
        attributes: { "anthropic.organization.federation_issuer.id": n }
      })
    });
  }
  /**
   * **Requires an OAuth access token with the `org:admin` scope**, from
   * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
   * API keys are not accepted. See
   * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
   *
   * List federation issuers in your organization.
   *
   * Archived issuers are excluded unless `include_archived=true`.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const federationIssuer of client.organization.federation.issuers.list()) {
   *   // ...
   * }
   * ```
   */
  list(n = {}, e) {
    return this._client.getAPIList("/v1/organizations/federation_issuers", P, {
      query: n,
      ...e,
      __span: u(this._client, "anthropic.organization.federation.issuers.list", e, {
        route: "/v1/organizations/federation_issuers",
        queryParams: ["include_archived", "limit", "page"]
      })
    });
  }
  /**
   * **Requires an OAuth access token with the `org:admin` scope**, from
   * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
   * API keys are not accepted. See
   * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
   *
   * Archive a federation issuer.
   *
   * Idempotent; re-archiving returns the issuer with its original `archived_at`.
   * Rejected with 400 if any live (non-archived) federation rule still references
   * the issuer; archive those rules first (a rule's issuer cannot be changed), or
   * recreate them against another issuer.
   *
   * @example
   * ```ts
   * const federationIssuer =
   *   await client.organization.federation.issuers.archive(
   *     'federation_issuer_id',
   *   );
   * ```
   */
  archive(n, e) {
    return this._client.post(f`/v1/organizations/federation_issuers/${n}/archive`, {
      ...e,
      __span: u(this._client, "anthropic.organization.federation.issuers.archive", e, {
        route: "/v1/organizations/federation_issuers/{federation_issuer_id}/archive",
        attributes: { "anthropic.organization.federation_issuer.id": n }
      })
    });
  }
}
let xc = class extends T {
  /**
   * **Requires an OAuth access token with the `org:admin` scope**, from
   * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
   * API keys are not accepted. See
   * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
   *
   * List workspaces where this federation rule is enabled.
   *
   * Returns all workspace enablements in a single response; the `limit` and `page`
   * parameters are accepted but have no effect, and `next_page` is always `null`.
   * Returns explicit per-workspace enablements only; for rules with
   * `applies_to_all_workspaces` or a legacy single `workspace_id`, check those
   * fields on the rule itself.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const federationRuleWorkspace of client.organization.federation.rules.workspaces.list(
   *   'federation_rule_id',
   * )) {
   *   // ...
   * }
   * ```
   */
  list(n, e = {}, t) {
    return this._client.getAPIList(f`/v1/organizations/federation_rules/${n}/workspaces`, P, {
      query: e,
      ...t,
      __span: u(this._client, "anthropic.organization.federation.rules.workspaces.list", t, {
        route: "/v1/organizations/federation_rules/{federation_rule_id}/workspaces",
        queryParams: ["limit", "page"],
        attributes: { "anthropic.organization.federation_rule.id": n }
      })
    });
  }
  /**
   * **Requires an OAuth access token with the `org:admin` scope**, from
   * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
   * API keys are not accepted. See
   * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
   *
   * Enable a federation rule for a workspace.
   *
   * Idempotent; re-enabling returns the existing enablement. The rule and workspace
   * must both belong to your organization. Membership of the rule's target service
   * account in this workspace is not checked at enablement: token exchange into this
   * workspace is rejected unless the target is a member (it is implicitly a member
   * of the default workspace). Archived rules are rejected with 400. OAuth callers
   * may only manage rules whose `oauth_scope` is `workspace:developer` or
   * `workspace:inference`; other scopes require a Console session.
   *
   * @example
   * ```ts
   * const federationRuleWorkspace =
   *   await client.organization.federation.rules.workspaces.add(
   *     'federation_rule_id',
   *     { workspace_id: 'workspace_id' },
   *   );
   * ```
   */
  add(n, e, t) {
    return this._client.post(f`/v1/organizations/federation_rules/${n}/workspaces`, {
      body: e,
      ...t,
      __span: u(this._client, "anthropic.organization.federation.rules.workspaces.add", t, {
        route: "/v1/organizations/federation_rules/{federation_rule_id}/workspaces",
        attributes: { "anthropic.organization.federation_rule.id": n },
        createdIDAttribute: "anthropic.organization.federation_rule.workspace.id",
        createdIDField: "workspace_id"
      })
    });
  }
  /**
   * **Requires an OAuth access token with the `org:admin` scope**, from
   * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
   * API keys are not accepted. See
   * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
   *
   * Disable a federation rule for a workspace.
   *
   * Idempotent; succeeds even if the enablement was already removed. OAuth callers
   * may only manage rules whose `oauth_scope` is `workspace:developer` or
   * `workspace:inference`; other scopes require a Console session.
   *
   * @example
   * ```ts
   * const workspace =
   *   await client.organization.federation.rules.workspaces.remove(
   *     'workspace_id',
   *     { federation_rule_id: 'federation_rule_id' },
   *   );
   * ```
   */
  remove(n, e, t) {
    const { federation_rule_id: s } = e;
    return this._client.delete(f`/v1/organizations/federation_rules/${s}/workspaces/${n}`, {
      ...t,
      __span: u(this._client, "anthropic.organization.federation.rules.workspaces.remove", t, {
        route: "/v1/organizations/federation_rules/{federation_rule_id}/workspaces/{workspace_id}",
        attributes: {
          "anthropic.organization.federation_rule.id": s,
          "anthropic.organization.federation_rule.workspace.id": n
        }
      })
    });
  }
};
var Ec = /* @__PURE__ */ (() => {
  class r extends T {
    constructor() {
      super(...arguments), this.workspaces = new xc(this._client);
    }
    /**
     * **Requires an OAuth access token with the `org:admin` scope**, from
     * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
     * API keys are not accepted. See
     * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
     *
     * Create a federation rule owned by your organization.
     *
     * The referenced issuer and the target service account must already exist in the
     * same organization; invalid references are rejected with a 400 error. The
     * workspace reference is validated. Membership is not checked at rule creation:
     * token exchange resolves a single enabled workspace per call and is rejected
     * unless the target service account is a member of that workspace (it is
     * implicitly a member of the default workspace). Rules on well-known shared
     * issuers (GitHub Actions, GitLab, Buildkite, Terraform Cloud, Google) must
     * constrain tenant identity via an identity-bearing claim, a tenant-pinning
     * subject prefix (such as `repo:YOUR_ORG/...`), or a CEL condition referencing one
     * of those identity claims (e.g. `claims.repository_owner`). OAuth callers may
     * only manage rules whose `oauth_scope` is `workspace:developer` or
     * `workspace:inference`; other scopes require a Console session.
     *
     * @example
     * ```ts
     * const federationRule =
     *   await client.organization.federation.rules.create({
     *     issuer_id: 'issuer_id',
     *     match: {},
     *     name: 'x',
     *     oauth_scope: 'x',
     *     target: {
     *       service_account_id: 'svac_01SDCCSbTxrXDpWc1phhtcfK',
     *       type: 'service_account',
     *     },
     *   });
     * ```
     */
    create(e, t) {
      return this._client.post("/v1/organizations/federation_rules", {
        body: e,
        ...t,
        __span: u(this._client, "anthropic.organization.federation.rules.create", t, {
          route: "/v1/organizations/federation_rules",
          createdIDAttribute: "anthropic.organization.federation_rule.id"
        })
      });
    }
    /**
     * **Requires an OAuth access token with the `org:admin` scope**, from
     * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
     * API keys are not accepted. See
     * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
     *
     * Retrieve a federation rule by its ID (`fdrl_...`).
     *
     * @example
     * ```ts
     * const federationRule =
     *   await client.organization.federation.rules.retrieve(
     *     'federation_rule_id',
     *   );
     * ```
     */
    retrieve(e, t) {
      return this._client.get(f`/v1/organizations/federation_rules/${e}`, {
        ...t,
        __span: u(this._client, "anthropic.organization.federation.rules.retrieve", t, {
          route: "/v1/organizations/federation_rules/{federation_rule_id}",
          attributes: { "anthropic.organization.federation_rule.id": e }
        })
      });
    }
    /**
     * **Requires an OAuth access token with the `org:admin` scope**, from
     * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
     * API keys are not accepted. See
     * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
     *
     * Partially update a federation rule.
     *
     * `issuer_id` is immutable. `match` and `target` are replaced as whole objects
     * when set. Referenced service accounts and workspaces must exist in your
     * organization; invalid references are rejected with a 400 error. Archived rules
     * cannot be updated; this returns 400. Create a new rule instead. Rules on
     * well-known shared issuers (GitHub Actions, GitLab, Buildkite, Terraform Cloud,
     * Google) must constrain tenant identity via an identity-bearing claim, a
     * tenant-pinning subject prefix (such as `repo:YOUR_ORG/...`), or a CEL condition
     * referencing one of those identity claims (e.g. `claims.repository_owner`). On
     * these issuers the requirement is re-checked on every update; if an existing
     * rule's stored match does not yet constrain tenant identity, any update (even a
     * rename or description change) must also supply a conforming `match` in the same
     * request. OAuth callers may only manage rules whose `oauth_scope` is
     * `workspace:developer` or `workspace:inference`; other scopes require a Console
     * session.
     *
     * @example
     * ```ts
     * const federationRule =
     *   await client.organization.federation.rules.update(
     *     'federation_rule_id',
     *   );
     * ```
     */
    update(e, t, s) {
      return this._client.post(f`/v1/organizations/federation_rules/${e}`, {
        body: t,
        ...s,
        __span: u(this._client, "anthropic.organization.federation.rules.update", s, {
          route: "/v1/organizations/federation_rules/{federation_rule_id}",
          attributes: { "anthropic.organization.federation_rule.id": e }
        })
      });
    }
    /**
     * **Requires an OAuth access token with the `org:admin` scope**, from
     * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
     * API keys are not accepted. See
     * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
     *
     * List federation rules in your organization.
     *
     * Optionally filter by issuer with `issuer_id`. Archived rules are excluded unless
     * `include_archived=true`.
     *
     * @example
     * ```ts
     * // Automatically fetches more pages as needed.
     * for await (const federationRule of client.organization.federation.rules.list()) {
     *   // ...
     * }
     * ```
     */
    list(e = {}, t) {
      return this._client.getAPIList("/v1/organizations/federation_rules", P, {
        query: e,
        ...t,
        __span: u(this._client, "anthropic.organization.federation.rules.list", t, {
          route: "/v1/organizations/federation_rules",
          queryParams: ["include_archived", "issuer_id", "limit", "page"]
        })
      });
    }
    /**
     * **Requires an OAuth access token with the `org:admin` scope**, from
     * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
     * API keys are not accepted. See
     * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
     *
     * Archive a federation rule.
     *
     * Token exchange through this rule stops immediately. Idempotent; re-archiving
     * returns the rule with its original `archived_at`. Archiving clears the rule's
     * workspace targeting (`workspace_id` and `workspace_ids` are emptied). Tokens
     * already minted before archive remain valid until they expire. OAuth callers may
     * only manage rules whose `oauth_scope` is `workspace:developer` or
     * `workspace:inference`; other scopes require a Console session.
     *
     * @example
     * ```ts
     * const federationRule =
     *   await client.organization.federation.rules.archive(
     *     'federation_rule_id',
     *   );
     * ```
     */
    archive(e, t) {
      return this._client.post(f`/v1/organizations/federation_rules/${e}/archive`, {
        ...t,
        __span: u(this._client, "anthropic.organization.federation.rules.archive", t, {
          route: "/v1/organizations/federation_rules/{federation_rule_id}/archive",
          attributes: { "anthropic.organization.federation_rule.id": e }
        })
      });
    }
  }
  return r.Workspaces = xc, r;
})(), Rc = /* @__PURE__ */ (() => {
  class r extends T {
    constructor() {
      super(...arguments), this.issuers = new Ac(this._client), this.rules = new Ec(this._client);
    }
  }
  return r.Issuers = Ac, r.Rules = Ec, r;
})();
let Pc = class extends T {
  /**
   * **Requires an OAuth access token with the `org:admin` scope**, from
   * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
   * API keys are not accepted. See
   * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
   *
   * List the workspaces a service account is a member of.
   *
   * Each entry includes the service account's `workspace_role` in that workspace.
   * Use `limit` and the `next_page` cursor to paginate. When the service account has
   * no explicit default-workspace membership, the implicit (`implicit: true`)
   * membership is returned as the first entry on the first page; with `limit=1` the
   * first page may return up to 2 entries (the implicit entry plus one explicit
   * membership) so a pagination cursor can be derived. Memberships are returned only
   * while the service account is active. Without a `page` cursor, an archived
   * service account returns an empty list. A `page` cursor that does not match an
   * active membership returns a 400 invalid-request error. A cursor stops matching
   * when the membership is removed, the workspace is deleted, or the service account
   * is archived. Restart pagination from the first page to recover.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const serviceAccountWorkspaceMember of client.organization.serviceAccounts.workspaces.list(
   *   'service_account_id',
   * )) {
   *   // ...
   * }
   * ```
   */
  list(n, e = {}, t) {
    return this._client.getAPIList(f`/v1/organizations/service_accounts/${n}/workspaces`, P, {
      query: e,
      ...t,
      __span: u(this._client, "anthropic.organization.service_accounts.workspaces.list", t, {
        route: "/v1/organizations/service_accounts/{service_account_id}/workspaces",
        queryParams: ["limit", "page"],
        attributes: { "anthropic.organization.service_account.id": n }
      })
    });
  }
  /**
   * **Requires an OAuth access token with the `org:admin` scope**, from
   * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
   * API keys are not accepted. See
   * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
   *
   * Add a service account to a workspace with the given `workspace_role`.
   *
   * Mirror of `POST /workspaces/{workspace_id}/service_accounts`, addressed from the
   * service-account side; both create the same membership. If the service account is
   * already an explicit member of the workspace, its `workspace_role` is replaced
   * with the value supplied here. Archived workspaces return 400. Archived service
   * accounts cannot be added and are rejected.
   *
   * @example
   * ```ts
   * const serviceAccountWorkspaceMember =
   *   await client.organization.serviceAccounts.workspaces.add(
   *     'service_account_id',
   *     {
   *       workspace_id: 'workspace_id',
   *       workspace_role: 'workspace_admin',
   *     },
   *   );
   * ```
   */
  add(n, e, t) {
    return this._client.post(f`/v1/organizations/service_accounts/${n}/workspaces`, {
      body: e,
      ...t,
      __span: u(this._client, "anthropic.organization.service_accounts.workspaces.add", t, {
        route: "/v1/organizations/service_accounts/{service_account_id}/workspaces",
        attributes: { "anthropic.organization.service_account.id": n },
        createdIDAttribute: "anthropic.organization.service_account.workspace.id",
        createdIDField: "workspace_id"
      })
    });
  }
  /**
   * **Requires an OAuth access token with the `org:admin` scope**, from
   * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
   * API keys are not accepted. See
   * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
   *
   * Remove a service account from a workspace.
   *
   * Mirror of
   * `DELETE /workspaces/{workspace_id}/service_accounts/{service_account_id}`,
   * addressed from the service-account side. Removal is idempotent (returns 200 even
   * if the membership was already removed). A DELETE against the implicit
   * default-workspace membership returns 200 but is a no-op and the membership
   * persists; deleting an explicit default-workspace row reverts to the implicit
   * `workspace_user` membership. Archived workspaces return 400.
   *
   * @example
   * ```ts
   * const workspace =
   *   await client.organization.serviceAccounts.workspaces.remove(
   *     'workspace_id',
   *     { service_account_id: 'service_account_id' },
   *   );
   * ```
   */
  remove(n, e, t) {
    const { service_account_id: s } = e;
    return this._client.delete(f`/v1/organizations/service_accounts/${s}/workspaces/${n}`, {
      ...t,
      __span: u(this._client, "anthropic.organization.service_accounts.workspaces.remove", t, {
        route: "/v1/organizations/service_accounts/{service_account_id}/workspaces/{workspace_id}",
        attributes: {
          "anthropic.organization.service_account.id": s,
          "anthropic.organization.service_account.workspace.id": n
        }
      })
    });
  }
};
var zc = /* @__PURE__ */ (() => {
  class r extends T {
    constructor() {
      super(...arguments), this.workspaces = new Pc(this._client);
    }
    /**
     * **Requires an OAuth access token with the `org:admin` scope**, from
     * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
     * API keys are not accepted. See
     * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
     *
     * Create a service account.
     *
     * A service account is a named workload identity that federation rules target.
     * `organization_role` is `developer` (default) or `admin`; a rule may only be
     * created or retargeted to grant `org:admin` scope when the target's
     * `organization_role` is `admin`. Creating an `admin`-role service account
     * requires an interactive credential (a user OAuth token or a Console session) — a
     * workload may only create `developer`-role service accounts.
     *
     * @example
     * ```ts
     * const serviceAccount =
     *   await client.organization.serviceAccounts.create({
     *     name: 'ci-deploy-bot',
     *   });
     * ```
     */
    create(e, t) {
      return this._client.post("/v1/organizations/service_accounts", {
        body: e,
        ...t,
        __span: u(this._client, "anthropic.organization.service_accounts.create", t, {
          route: "/v1/organizations/service_accounts",
          createdIDAttribute: "anthropic.organization.service_account.id"
        })
      });
    }
    /**
     * **Requires an OAuth access token with the `org:admin` scope**, from
     * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
     * API keys are not accepted. See
     * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
     *
     * Retrieve a service account by its ID (`svac_...`).
     *
     * @example
     * ```ts
     * const serviceAccount =
     *   await client.organization.serviceAccounts.retrieve(
     *     'service_account_id',
     *   );
     * ```
     */
    retrieve(e, t) {
      return this._client.get(f`/v1/organizations/service_accounts/${e}`, {
        ...t,
        __span: u(this._client, "anthropic.organization.service_accounts.retrieve", t, {
          route: "/v1/organizations/service_accounts/{service_account_id}",
          attributes: { "anthropic.organization.service_account.id": e }
        })
      });
    }
    /**
     * **Requires an OAuth access token with the `org:admin` scope**, from
     * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
     * API keys are not accepted. See
     * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
     *
     * Update a service account.
     *
     * Only `description` and `organization_role` are mutable; `name` cannot be
     * changed. Archived service accounts cannot be updated; this returns 400. Setting
     * `organization_role` to `admin` (even when unchanged) requires an interactive
     * credential (a user OAuth token or a Console session).
     *
     * @example
     * ```ts
     * const serviceAccount =
     *   await client.organization.serviceAccounts.update(
     *     'service_account_id',
     *   );
     * ```
     */
    update(e, t, s) {
      return this._client.post(f`/v1/organizations/service_accounts/${e}`, {
        body: t,
        ...s,
        __span: u(this._client, "anthropic.organization.service_accounts.update", s, {
          route: "/v1/organizations/service_accounts/{service_account_id}",
          attributes: { "anthropic.organization.service_account.id": e }
        })
      });
    }
    /**
     * **Requires an OAuth access token with the `org:admin` scope**, from
     * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
     * API keys are not accepted. See
     * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
     *
     * List service accounts in the caller's organization.
     *
     * Results are ordered by creation time, newest first. Use `limit` and the
     * `next_page` cursor to paginate; set `include_archived=true` to include archived
     * service accounts.
     *
     * @example
     * ```ts
     * // Automatically fetches more pages as needed.
     * for await (const serviceAccount of client.organization.serviceAccounts.list()) {
     *   // ...
     * }
     * ```
     */
    list(e = {}, t) {
      return this._client.getAPIList("/v1/organizations/service_accounts", P, {
        query: e,
        ...t,
        __span: u(this._client, "anthropic.organization.service_accounts.list", t, {
          route: "/v1/organizations/service_accounts",
          queryParams: ["include_archived", "limit", "page"]
        })
      });
    }
    /**
     * **Requires an OAuth access token with the `org:admin` scope**, from
     * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
     * API keys are not accepted. See
     * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
     *
     * Archive a service account.
     *
     * Idempotent; re-archiving returns the service account with its original
     * `archived_at`. Rejected with 400 if any live (non-archived) federation rule
     * still targets this service account, same as issuer archival; archive those rules
     * first or change their target to another service account.
     *
     * @example
     * ```ts
     * const serviceAccount =
     *   await client.organization.serviceAccounts.archive(
     *     'service_account_id',
     *   );
     * ```
     */
    archive(e, t) {
      return this._client.post(f`/v1/organizations/service_accounts/${e}/archive`, {
        ...t,
        __span: u(this._client, "anthropic.organization.service_accounts.archive", t, {
          route: "/v1/organizations/service_accounts/{service_account_id}/archive",
          attributes: { "anthropic.organization.service_account.id": e }
        })
      });
    }
  }
  return r.Workspaces = Pc, r;
})();
class Mc extends T {
  /**
   * Get Workspace Member
   *
   * @example
   * ```ts
   * const workspaceMember =
   *   await client.organization.workspaces.members.retrieve(
   *     'user_id',
   *     { workspace_id: 'workspace_id' },
   *   );
   * ```
   */
  retrieve(n, e, t) {
    const { workspace_id: s } = e;
    return this._client.get(f`/v1/organizations/workspaces/${s}/members/${n}`, {
      ...t,
      __span: u(this._client, "anthropic.organization.workspaces.members.retrieve", t, {
        route: "/v1/organizations/workspaces/{workspace_id}/members/{user_id}",
        attributes: {
          "anthropic.organization.workspace.id": s,
          "anthropic.organization.workspace.member.id": n
        }
      })
    });
  }
  /**
   * Update Workspace Member
   *
   * @example
   * ```ts
   * const workspaceMember =
   *   await client.organization.workspaces.members.update(
   *     'user_id',
   *     {
   *       workspace_id: 'workspace_id',
   *       workspace_role: 'workspace_admin',
   *     },
   *   );
   * ```
   */
  update(n, e, t) {
    const { workspace_id: s, ...i } = e;
    return this._client.post(f`/v1/organizations/workspaces/${s}/members/${n}`, {
      body: i,
      ...t,
      __span: u(this._client, "anthropic.organization.workspaces.members.update", t, {
        route: "/v1/organizations/workspaces/{workspace_id}/members/{user_id}",
        attributes: {
          "anthropic.organization.workspace.id": s,
          "anthropic.organization.workspace.member.id": n
        }
      })
    });
  }
  /**
   * List Workspace Members
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const workspaceMember of client.organization.workspaces.members.list(
   *   'workspace_id',
   * )) {
   *   // ...
   * }
   * ```
   */
  list(n, e = {}, t) {
    return this._client.getAPIList(f`/v1/organizations/workspaces/${n}/members`, Y, {
      query: e,
      ...t,
      __span: u(this._client, "anthropic.organization.workspaces.members.list", t, {
        route: "/v1/organizations/workspaces/{workspace_id}/members",
        queryParams: ["after_id", "before_id", "limit"],
        attributes: { "anthropic.organization.workspace.id": n }
      })
    });
  }
  /**
   * Create Workspace Member
   *
   * @example
   * ```ts
   * const workspaceMember =
   *   await client.organization.workspaces.members.add(
   *     'workspace_id',
   *     {
   *       user_id: 'user_01WCz1FkmYMm4gnmykNKUu3Q',
   *       workspace_role: 'workspace_admin',
   *     },
   *   );
   * ```
   */
  add(n, e, t) {
    return this._client.post(f`/v1/organizations/workspaces/${n}/members`, {
      body: e,
      ...t,
      __span: u(this._client, "anthropic.organization.workspaces.members.add", t, {
        route: "/v1/organizations/workspaces/{workspace_id}/members",
        attributes: { "anthropic.organization.workspace.id": n },
        createdIDAttribute: "anthropic.organization.workspace.member.id",
        createdIDField: "user_id"
      })
    });
  }
  /**
   * Delete Workspace Member
   *
   * @example
   * ```ts
   * const member =
   *   await client.organization.workspaces.members.remove(
   *     'user_id',
   *     { workspace_id: 'workspace_id' },
   *   );
   * ```
   */
  remove(n, e, t) {
    const { workspace_id: s } = e;
    return this._client.delete(f`/v1/organizations/workspaces/${s}/members/${n}`, {
      ...t,
      __span: u(this._client, "anthropic.organization.workspaces.members.remove", t, {
        route: "/v1/organizations/workspaces/{workspace_id}/members/{user_id}",
        attributes: {
          "anthropic.organization.workspace.id": s,
          "anthropic.organization.workspace.member.id": n
        }
      })
    });
  }
}
class Oc extends T {
  /**
   * Set or clear rate-limit overrides for one rate-limit group in a workspace.
   *
   * Only the limiter types named in `limits` change: an integer `value` sets that
   * type's override and `null` clears it. Types not named keep their current value.
   * A value above the organization's own limit is stored, but the organization limit
   * still applies, so the lower of the two is enforced.
   *
   * Returns the targeted group's entry with this request applied, in the shape
   * `GET /v1/organizations/workspaces/{workspace_id}/rate_limits` returns. Changes
   * take effect within about an hour.
   *
   * @example
   * ```ts
   * const workspaceRateLimit =
   *   await client.organization.workspaces.rateLimits.update(
   *     'rate_limit_id',
   *     {
   *       workspace_id: 'workspace_id',
   *       limits: [{ type: 'fast_itpmca', value: 0 }],
   *     },
   *   );
   * ```
   */
  update(n, e, t) {
    const { workspace_id: s, ...i } = e;
    return this._client.post(f`/v1/organizations/workspaces/${s}/rate_limits/${n}`, {
      body: i,
      ...t,
      __span: u(this._client, "anthropic.organization.workspaces.rate_limits.update", t, {
        route: "/v1/organizations/workspaces/{workspace_id}/rate_limits/{rate_limit_id}",
        attributes: {
          "anthropic.organization.workspace.id": s,
          "anthropic.organization.workspace.rate_limit.id": n
        }
      })
    });
  }
  /**
   * List a workspace's rate limits.
   *
   * By default, returns only the groups and limiter types that have a
   * workspace-level override. With `include_inherited=true`, returns every group
   * with organization-level limits the workspace can see, listing for each the
   * values it inherits from the organization as well as its own overrides. Each
   * value's `source` says which it is.
   *
   * When `limit` is omitted, every matching entry is returned in a single page; when
   * `limit` truncates the result, follow `next_page` to fetch the remaining entries.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const workspaceRateLimit of client.organization.workspaces.rateLimits.list(
   *   'workspace_id',
   * )) {
   *   // ...
   * }
   * ```
   */
  list(n, e = {}, t) {
    return this._client.getAPIList(f`/v1/organizations/workspaces/${n}/rate_limits`, P, {
      query: e,
      ...t,
      __span: u(this._client, "anthropic.organization.workspaces.rate_limits.list", t, {
        route: "/v1/organizations/workspaces/{workspace_id}/rate_limits",
        queryParams: ["group_type", "include_inherited", "limit", "page"],
        attributes: { "anthropic.organization.workspace.id": n }
      })
    });
  }
}
class Cc extends T {
  /**
   * **Requires an OAuth access token with the `org:admin` scope**, from
   * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
   * API keys are not accepted. See
   * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
   *
   * Retrieve a service account's membership in a workspace.
   *
   * Returns the membership record, including the service account's `workspace_role`
   * in this workspace. Archived workspaces return 400. For the default workspace,
   * returns the implicit (`implicit: true`) membership when no explicit membership
   * exists; an explicitly added membership is returned with its assigned role. An
   * archived service account returns 404.
   *
   * @example
   * ```ts
   * const serviceAccountWorkspaceMember =
   *   await client.organization.workspaces.serviceAccounts.retrieve(
   *     'service_account_id',
   *     { workspace_id: 'workspace_id' },
   *   );
   * ```
   */
  retrieve(n, e, t) {
    const { workspace_id: s } = e;
    return this._client.get(f`/v1/organizations/workspaces/${s}/service_accounts/${n}`, {
      ...t,
      __span: u(this._client, "anthropic.organization.workspaces.service_accounts.retrieve", t, {
        route: "/v1/organizations/workspaces/{workspace_id}/service_accounts/{service_account_id}",
        attributes: {
          "anthropic.organization.workspace.id": s,
          "anthropic.organization.workspace.service_account.id": n
        }
      })
    });
  }
  /**
   * **Requires an OAuth access token with the `org:admin` scope**, from
   * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
   * API keys are not accepted. See
   * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
   *
   * Change a service account's role in a workspace.
   *
   * The new `workspace_role` replaces the current one. Only explicit memberships can
   * be updated; to set a role on the implicit default-workspace membership, add the
   * service account explicitly with
   * `POST /workspaces/{workspace_id}/service_accounts`. Archived workspaces
   * return 400. Archived service accounts cannot be updated and are rejected.
   *
   * @example
   * ```ts
   * const serviceAccountWorkspaceMember =
   *   await client.organization.workspaces.serviceAccounts.update(
   *     'service_account_id',
   *     {
   *       workspace_id: 'workspace_id',
   *       workspace_role: 'workspace_admin',
   *     },
   *   );
   * ```
   */
  update(n, e, t) {
    const { workspace_id: s, ...i } = e;
    return this._client.post(f`/v1/organizations/workspaces/${s}/service_accounts/${n}`, {
      body: i,
      ...t,
      __span: u(this._client, "anthropic.organization.workspaces.service_accounts.update", t, {
        route: "/v1/organizations/workspaces/{workspace_id}/service_accounts/{service_account_id}",
        attributes: {
          "anthropic.organization.workspace.id": s,
          "anthropic.organization.workspace.service_account.id": n
        }
      })
    });
  }
  /**
   * **Requires an OAuth access token with the `org:admin` scope**, from
   * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
   * API keys are not accepted. See
   * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
   *
   * List the service accounts that are members of a workspace.
   *
   * Each entry includes the service account's `workspace_role`. Use `limit` and the
   * `next_page` cursor to paginate. Archived workspaces return 400; use
   * `GET /service_accounts/{id}/workspaces` to audit memberships of an archived
   * workspace. The implicit default-workspace membership is not included in this
   * list. Memberships of archived service accounts are omitted from the results.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const serviceAccountWorkspaceMember of client.organization.workspaces.serviceAccounts.list(
   *   'workspace_id',
   * )) {
   *   // ...
   * }
   * ```
   */
  list(n, e = {}, t) {
    return this._client.getAPIList(f`/v1/organizations/workspaces/${n}/service_accounts`, P, {
      query: e,
      ...t,
      __span: u(this._client, "anthropic.organization.workspaces.service_accounts.list", t, {
        route: "/v1/organizations/workspaces/{workspace_id}/service_accounts",
        queryParams: ["limit", "page"],
        attributes: { "anthropic.organization.workspace.id": n }
      })
    });
  }
  /**
   * **Requires an OAuth access token with the `org:admin` scope**, from
   * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
   * API keys are not accepted. See
   * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
   *
   * Add a service account to a workspace with the given `workspace_role`.
   *
   * The role determines what the service account can do in the workspace and which
   * workspace-scoped permissions it can be granted when authenticating through
   * federation. Every service account is already an implicit `workspace_user` member
   * of the default workspace; adding it explicitly assigns a chosen role. If the
   * service account is already an explicit member of the workspace, its
   * `workspace_role` is replaced with the value supplied here. Archived workspaces
   * return 400. Archived service accounts cannot be added and are rejected.
   *
   * @example
   * ```ts
   * const serviceAccountWorkspaceMember =
   *   await client.organization.workspaces.serviceAccounts.add(
   *     'workspace_id',
   *     {
   *       service_account_id: 'service_account_id',
   *       workspace_role: 'workspace_admin',
   *     },
   *   );
   * ```
   */
  add(n, e, t) {
    return this._client.post(f`/v1/organizations/workspaces/${n}/service_accounts`, {
      body: e,
      ...t,
      __span: u(this._client, "anthropic.organization.workspaces.service_accounts.add", t, {
        route: "/v1/organizations/workspaces/{workspace_id}/service_accounts",
        attributes: { "anthropic.organization.workspace.id": n },
        createdIDAttribute: "anthropic.organization.workspace.service_account.id",
        createdIDField: "service_account_id"
      })
    });
  }
  /**
   * **Requires an OAuth access token with the `org:admin` scope**, from
   * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
   * API keys are not accepted. See
   * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
   *
   * Remove a service account from a workspace.
   *
   * Removal is idempotent (returns 200 even if the membership was already removed).
   * A DELETE against the implicit default-workspace membership returns 200 but is a
   * no-op and the membership persists; deleting an explicit default-workspace row
   * reverts to the implicit `workspace_user` membership. Archived workspaces
   * return 400.
   *
   * @example
   * ```ts
   * const serviceAccount =
   *   await client.organization.workspaces.serviceAccounts.remove(
   *     'service_account_id',
   *     { workspace_id: 'workspace_id' },
   *   );
   * ```
   */
  remove(n, e, t) {
    const { workspace_id: s } = e;
    return this._client.delete(f`/v1/organizations/workspaces/${s}/service_accounts/${n}`, {
      ...t,
      __span: u(this._client, "anthropic.organization.workspaces.service_accounts.remove", t, {
        route: "/v1/organizations/workspaces/{workspace_id}/service_accounts/{service_account_id}",
        attributes: {
          "anthropic.organization.workspace.id": s,
          "anthropic.organization.workspace.service_account.id": n
        }
      })
    });
  }
}
var $c = /* @__PURE__ */ (() => {
  class r extends T {
    constructor() {
      super(...arguments), this.rateLimits = new Oc(this._client), this.members = new Mc(this._client), this.serviceAccounts = new Cc(this._client);
    }
    /**
     * Create Workspace
     *
     * @example
     * ```ts
     * const workspace =
     *   await client.organization.workspaces.create({
     *     name: 'x',
     *   });
     * ```
     */
    create(e, t) {
      return this._client.post("/v1/organizations/workspaces", {
        body: e,
        ...t,
        __span: u(this._client, "anthropic.organization.workspaces.create", t, {
          route: "/v1/organizations/workspaces",
          createdIDAttribute: "anthropic.organization.workspace.id"
        })
      });
    }
    /**
     * Get Workspace
     *
     * @example
     * ```ts
     * const workspace =
     *   await client.organization.workspaces.retrieve(
     *     'workspace_id',
     *   );
     * ```
     */
    retrieve(e, t) {
      return this._client.get(f`/v1/organizations/workspaces/${e}`, {
        ...t,
        __span: u(this._client, "anthropic.organization.workspaces.retrieve", t, {
          route: "/v1/organizations/workspaces/{workspace_id}",
          attributes: { "anthropic.organization.workspace.id": e }
        })
      });
    }
    /**
     * Update Workspace
     *
     * @example
     * ```ts
     * const workspace =
     *   await client.organization.workspaces.update(
     *     'workspace_id',
     *   );
     * ```
     */
    update(e, t, s) {
      return this._client.post(f`/v1/organizations/workspaces/${e}`, {
        body: t,
        ...s,
        __span: u(this._client, "anthropic.organization.workspaces.update", s, {
          route: "/v1/organizations/workspaces/{workspace_id}",
          attributes: { "anthropic.organization.workspace.id": e }
        })
      });
    }
    /**
     * List Workspaces
     *
     * @example
     * ```ts
     * // Automatically fetches more pages as needed.
     * for await (const workspace of client.organization.workspaces.list()) {
     *   // ...
     * }
     * ```
     */
    list(e = {}, t) {
      return this._client.getAPIList("/v1/organizations/workspaces", Y, {
        query: e,
        ...t,
        __span: u(this._client, "anthropic.organization.workspaces.list", t, {
          route: "/v1/organizations/workspaces",
          queryParams: ["after_id", "before_id", "include_archived", "include_default", "limit"]
        })
      });
    }
    /**
     * Archive Workspace
     *
     * @example
     * ```ts
     * const workspace =
     *   await client.organization.workspaces.archive(
     *     'workspace_id',
     *   );
     * ```
     */
    archive(e, t) {
      return this._client.post(f`/v1/organizations/workspaces/${e}/archive`, {
        ...t,
        __span: u(this._client, "anthropic.organization.workspaces.archive", t, {
          route: "/v1/organizations/workspaces/{workspace_id}/archive",
          attributes: { "anthropic.organization.workspace.id": e }
        })
      });
    }
  }
  return r.RateLimits = Oc, r.Members = Mc, r.ServiceAccounts = Cc, r;
})(), Ic = /* @__PURE__ */ (() => {
  class r extends T {
    constructor() {
      super(...arguments), this.apiKeys = new wc(this._client), this.externalKeys = new vc(this._client), this.federation = new Rc(this._client), this.invites = new kc(this._client), this.serviceAccounts = new zc(this._client), this.users = new Tc(this._client), this.workspaces = new $c(this._client), this.rateLimits = new Sc(this._client), this.complianceSettings = new yc(this._client);
    }
    /**
     * Retrieve information about the organization associated with the authenticated
     * API key.
     *
     * @example
     * ```ts
     * const organizationInfo =
     *   await client.organization.retrieve();
     * ```
     */
    retrieve(e) {
      return this._client.get("/v1/organizations/me", {
        ...e,
        __span: u(this._client, "anthropic.organization.retrieve", e, {
          route: "/v1/organizations/me"
        })
      });
    }
  }
  return r.APIKeys = wc, r.ExternalKeys = vc, r.Federation = Rc, r.Invites = kc, r.ServiceAccounts = zc, r.Users = Tc, r.Workspaces = $c, r.RateLimits = Sc, r.ComplianceSettings = yc, r;
})();
class Nc extends T {
  /**
   * Create Skill Version
   *
   * @example
   * ```ts
   * const skillVersion = await client.skills.versions.create(
   *   'skill_id',
   *   { files: [fs.createReadStream('path/to/file')] },
   * );
   * ```
   */
  create(n, e, t) {
    const { workspace_id: s, ...i } = e;
    return this._client.post(f`/v1/skills/${n}/versions`, Ce({
      body: i,
      ...t,
      headers: p([
        { ...s != null ? { "anthropic-workspace-id": s } : void 0 },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.skills.versions.create", t, {
        route: "/v1/skills/{skill_id}/versions",
        attributes: { "anthropic.skill.id": n },
        createdIDAttribute: "anthropic.skill.version.id"
      })
    }, this._client, !1));
  }
  /**
   * Get Skill Version
   *
   * @example
   * ```ts
   * const skillVersion = await client.skills.versions.retrieve(
   *   'version',
   *   { skill_id: 'skill_id' },
   * );
   * ```
   */
  retrieve(n, e, t) {
    const { skill_id: s, workspace_id: i } = e;
    return this._client.get(f`/v1/skills/${s}/versions/${n}`, {
      ...t,
      headers: p([
        { ...i != null ? { "anthropic-workspace-id": i } : void 0 },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.skills.versions.retrieve", t, {
        route: "/v1/skills/{skill_id}/versions/{version}",
        attributes: { "anthropic.skill.id": s, "anthropic.skill.version.id": n }
      })
    });
  }
  /**
   * List Skill Versions
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const skillVersion of client.skills.versions.list(
   *   'skill_id',
   * )) {
   *   // ...
   * }
   * ```
   */
  list(n, e = {}, t) {
    const { workspace_id: s, ...i } = e ?? {};
    return this._client.getAPIList(f`/v1/skills/${n}/versions`, P, {
      query: i,
      ...t,
      headers: p([
        { ...s != null ? { "anthropic-workspace-id": s } : void 0 },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.skills.versions.list", t, {
        route: "/v1/skills/{skill_id}/versions",
        queryParams: ["limit", "page"],
        attributes: { "anthropic.skill.id": n }
      })
    });
  }
  /**
   * Delete Skill Version
   *
   * @example
   * ```ts
   * const deletedSkillVersion =
   *   await client.skills.versions.delete('version', {
   *     skill_id: 'skill_id',
   *   });
   * ```
   */
  delete(n, e, t) {
    const { skill_id: s, workspace_id: i } = e;
    return this._client.delete(f`/v1/skills/${s}/versions/${n}`, {
      ...t,
      headers: p([
        { ...i != null ? { "anthropic-workspace-id": i } : void 0 },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.skills.versions.delete", t, {
        route: "/v1/skills/{skill_id}/versions/{version}",
        attributes: { "anthropic.skill.id": s, "anthropic.skill.version.id": n }
      })
    });
  }
}
var Lc = /* @__PURE__ */ (() => {
  class r extends T {
    constructor() {
      super(...arguments), this.versions = new Nc(this._client);
    }
    /**
     * Create Skill
     *
     * @example
     * ```ts
     * const skill = await client.skills.create({
     *   files: [fs.createReadStream('path/to/file')],
     * });
     * ```
     */
    create(e, t) {
      const { workspace_id: s, ...i } = e;
      return this._client.post("/v1/skills", Ce({
        body: i,
        ...t,
        headers: p([
          { ...s != null ? { "anthropic-workspace-id": s } : void 0 },
          t?.headers
        ]),
        __span: u(this._client, "anthropic.skills.create", t, {
          route: "/v1/skills",
          createdIDAttribute: "anthropic.skill.id"
        })
      }, this._client, !1));
    }
    /**
     * Get Skill
     *
     * @example
     * ```ts
     * const skill = await client.skills.retrieve('skill_id');
     * ```
     */
    retrieve(e, t = {}, s) {
      const { workspace_id: i } = t ?? {};
      return this._client.get(f`/v1/skills/${e}`, {
        ...s,
        headers: p([
          { ...i != null ? { "anthropic-workspace-id": i } : void 0 },
          s?.headers
        ]),
        __span: u(this._client, "anthropic.skills.retrieve", s, {
          route: "/v1/skills/{skill_id}",
          attributes: { "anthropic.skill.id": e }
        })
      });
    }
    /**
     * List Skills
     *
     * @example
     * ```ts
     * // Automatically fetches more pages as needed.
     * for await (const skill of client.skills.list()) {
     *   // ...
     * }
     * ```
     */
    list(e = {}, t) {
      const { workspace_id: s, ...i } = e ?? {};
      return this._client.getAPIList("/v1/skills", P, {
        query: i,
        ...t,
        headers: p([
          { ...s != null ? { "anthropic-workspace-id": s } : void 0 },
          t?.headers
        ]),
        __span: u(this._client, "anthropic.skills.list", t, {
          route: "/v1/skills",
          queryParams: ["limit", "page", "source"]
        })
      });
    }
    /**
     * Delete Skill
     *
     * @example
     * ```ts
     * const deletedSkill = await client.skills.delete('skill_id');
     * ```
     */
    delete(e, t = {}, s) {
      const { workspace_id: i } = t ?? {};
      return this._client.delete(f`/v1/skills/${e}`, {
        ...s,
        headers: p([
          { ...i != null ? { "anthropic-workspace-id": i } : void 0 },
          s?.headers
        ]),
        __span: u(this._client, "anthropic.skills.delete", s, {
          route: "/v1/skills/{skill_id}",
          attributes: { "anthropic.skill.id": e }
        })
      });
    }
  }
  return r.Versions = Nc, r;
})();
class qc extends T {
  /**
   * Create Action URL
   *
   * @example
   * ```ts
   * const userProfileActionURL =
   *   await client.userProfiles.actionURLs.create(
   *     'uprof_011CZkZCu8hGbp5mYRQgUmz9',
   *     { action: { type: 'enroll_end_user' } },
   *   );
   * ```
   */
  create(n, e, t) {
    const { workspace_id: s, ...i } = e;
    return this._client.post(f`/v1/user_profiles/${n}/action_urls`, {
      body: i,
      ...t,
      headers: p([
        { ...s != null ? { "anthropic-workspace-id": s } : void 0 },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.user_profiles.action_urls.create", t, {
        route: "/v1/user_profiles/{user_profile_id}/action_urls",
        attributes: { "anthropic.user_profile.id": n }
      })
    });
  }
}
var Bc = /* @__PURE__ */ (() => {
  class r extends T {
    constructor() {
      super(...arguments), this.actionURLs = new qc(this._client);
    }
    /**
     * Create User Profile
     *
     * @example
     * ```ts
     * const userProfile = await client.userProfiles.create();
     * ```
     */
    create(e, t) {
      const { workspace_id: s, ...i } = e;
      return this._client.post("/v1/user_profiles", {
        body: i,
        ...t,
        headers: p([
          { ...s != null ? { "anthropic-workspace-id": s } : void 0 },
          t?.headers
        ]),
        __span: u(this._client, "anthropic.user_profiles.create", t, {
          route: "/v1/user_profiles",
          createdIDAttribute: "anthropic.user_profile.id"
        })
      });
    }
    /**
     * Get User Profile
     *
     * @example
     * ```ts
     * const userProfile = await client.userProfiles.retrieve(
     *   'uprof_011CZkZCu8hGbp5mYRQgUmz9',
     * );
     * ```
     */
    retrieve(e, t = {}, s) {
      const { workspace_id: i } = t ?? {};
      return this._client.get(f`/v1/user_profiles/${e}`, {
        ...s,
        headers: p([
          { ...i != null ? { "anthropic-workspace-id": i } : void 0 },
          s?.headers
        ]),
        __span: u(this._client, "anthropic.user_profiles.retrieve", s, {
          route: "/v1/user_profiles/{user_profile_id}",
          attributes: { "anthropic.user_profile.id": e }
        })
      });
    }
    /**
     * Update User Profile
     *
     * @example
     * ```ts
     * const userProfile = await client.userProfiles.update(
     *   'uprof_011CZkZCu8hGbp5mYRQgUmz9',
     * );
     * ```
     */
    update(e, t, s) {
      const { workspace_id: i, ...a } = t;
      return this._client.post(f`/v1/user_profiles/${e}`, {
        body: a,
        ...s,
        headers: p([
          { ...i != null ? { "anthropic-workspace-id": i } : void 0 },
          s?.headers
        ]),
        __span: u(this._client, "anthropic.user_profiles.update", s, {
          route: "/v1/user_profiles/{user_profile_id}",
          attributes: { "anthropic.user_profile.id": e }
        })
      });
    }
    /**
     * List User Profiles
     *
     * @example
     * ```ts
     * // Automatically fetches more pages as needed.
     * for await (const userProfile of client.userProfiles.list()) {
     *   // ...
     * }
     * ```
     */
    list(e = {}, t) {
      const { workspace_id: s, ...i } = e ?? {};
      return this._client.getAPIList("/v1/user_profiles", P, {
        query: i,
        ...t,
        headers: p([
          { ...s != null ? { "anthropic-workspace-id": s } : void 0 },
          t?.headers
        ]),
        __span: u(this._client, "anthropic.user_profiles.list", t, {
          route: "/v1/user_profiles",
          queryParams: ["limit", "order", "order_by", "page"]
        })
      });
    }
    /**
     * Delete User Profile
     *
     * @example
     * ```ts
     * const deletedUserProfile = await client.userProfiles.delete(
     *   'uprof_011CZkZCu8hGbp5mYRQgUmz9',
     * );
     * ```
     */
    delete(e, t = {}, s) {
      const { workspace_id: i } = t ?? {};
      return this._client.delete(f`/v1/user_profiles/${e}`, {
        ...s,
        headers: p([
          { ...i != null ? { "anthropic-workspace-id": i } : void 0 },
          s?.headers
        ]),
        __span: u(this._client, "anthropic.user_profiles.delete", s, {
          route: "/v1/user_profiles/{user_profile_id}",
          attributes: { "anthropic.user_profile.id": e }
        })
      });
    }
  }
  return r.ActionURLs = qc, r;
})(), Is, Ns, Sr, at, Uc;
const mg = "\\n\\nHuman:", bg = "\\n\\nAssistant:";
var wg = /* @__PURE__ */ (() => {
  class r {
    /**
     * The active credential provider. Default credential resolution runs once
     * at construction time. If it fails, the error is surfaced on every
     * request and the client must be reconstructed — there is no retry path.
     *
     * Clones returned by {@link withOptions} share the parent's auth state
     * (provider, token cache, pending resolution, and any resolution error)
     * unless the caller passes an explicit `apiKey`, `authToken`,
     * `credentials`, `config`, or `profile` override.
     */
    get credentials() {
      return this._authState.provider;
    }
    /**
     * The `openTelemetry` option as this client settled it when it was constructed: `propagation` and
     * each field of `traces` from the option, or else its default. A client constructed without the
     * option has what the environment variables said. One constructed with `openTelemetry: false` has
     * `traces.enabled: false` here.
     *
     * The value is frozen. It is a valid `openTelemetry` option, so a copy of this client can change
     * one setting and keep the others:
     *
     * ```ts
     * const { openTelemetry } = client;
     * client.withOptions({
     *   openTelemetry: { ...openTelemetry, traces: { ...openTelemetry.traces, contentMode: 'content' } },
     * });
     * ```
     */
    get openTelemetry() {
      return c(this, at, "f");
    }
    /**
     * The instrumentation scope of this client's spans: the version of the package that the client
     * is from, and for the client of another platform the platform's name, which the scope's name
     * ends with. The clients for other platforms override it. The constructor calls it.
     * @internal
     */
    _instrumentationScope() {
      return { version: Pe };
    }
    /**
     * API Client for interfacing with the Anthropic API.
     *
     * @param {string | null | undefined} [opts.apiKey=process.env['ANTHROPIC_API_KEY'] ?? null]
     * @param {string | null | undefined} [opts.authToken=process.env['ANTHROPIC_AUTH_TOKEN'] ?? null]
     * @param {string | null | undefined} [opts.webhookKey=process.env['ANTHROPIC_WEBHOOK_SIGNING_KEY'] ?? null]
     * @param {string} [opts.baseURL=process.env['ANTHROPIC_BASE_URL'] ?? https://api.anthropic.com] - Override the default base URL for the API.
     * @param {number} [opts.timeout=10 minutes] - The maximum amount of time (in milliseconds) the client will wait for a response before timing out.
     * @param {MergedRequestInit} [opts.fetchOptions] - Additional `RequestInit` options to be passed to `fetch` calls.
     * @param {Fetch} [opts.fetch] - Specify a custom `fetch` function implementation.
     * @param {number} [opts.maxRetries=2] - The maximum number of times the client will retry a request.
     * @param {HeadersLike} opts.defaultHeaders - Default headers to include with every request to the API.
     * @param {Record<string, string | undefined>} opts.defaultQuery - Default query parameters to include with every request to the API.
     * @param {boolean} [opts.dangerouslyAllowBrowser=false] - By default, client-side use of this library is not allowed, as it risks exposing your secret API credentials to attackers.
     */
    constructor({ baseURL: e = O("ANTHROPIC_BASE_URL"), apiKey: t, authToken: s, webhookKey: i = O("ANTHROPIC_WEBHOOK_SIGNING_KEY") ?? null, ...a } = {}) {
      if (Is.add(this), this._requestAuthFlags = /* @__PURE__ */ new WeakMap(), Sr.set(this, void 0), at.set(this, void 0), this._genAIProviderName = "anthropic", t === void 0 && (t = a.profile != null ? null : O("ANTHROPIC_API_KEY") ?? null), s === void 0 && (s = a.profile != null ? null : O("ANTHROPIC_AUTH_TOKEN") ?? null), a.profile != null && (a.credentials != null || a.config != null))
        throw new TypeError("Pass at most one of `profile`, `credentials`, or `config`.");
      const o = {
        apiKey: t,
        authToken: s,
        webhookKey: i,
        ...a,
        baseURL: e || "https://api.anthropic.com"
      };
      if (!o.dangerouslyAllowBrowser && bd())
        throw new R(`It looks like you're running in a browser-like environment.

This is disabled by default, as it risks exposing your secret API credentials to attackers.
If you understand the risks and have appropriate mitigations in place,
you can set the \`dangerouslyAllowBrowser\` option to \`true\`, e.g.,

new Anthropic({ apiKey, dangerouslyAllowBrowser: true });
`);
      this.baseURL = o.baseURL, this._baseURLIsExplicit = a.__baseURLIsExplicit ?? !!e, this.timeout = o.timeout ?? Ns.DEFAULT_TIMEOUT, this.logger = o.logger ?? console, this.logLevel = Br, this.logLevel = js(o.logLevel, "ClientOptions.logLevel", M(this)) ?? js(O("ANTHROPIC_LOG"), "process.env['ANTHROPIC_LOG']", M(this)) ?? Br, this.fetchOptions = o.fetchOptions, this.maxRetries = ts("maxRetries", o.maxRetries ?? 2);
      const l = this._instrumentationScope();
      y(this, at, n_(o.openTelemetry)), o.openTelemetry = c(this, at, "f"), this._tracer = F(this, () => s_(c(this, at, "f"), l.version, l.platform)), this.fetch = o.fetch ?? Ad(), y(this, Sr, Rd), this.middleware = [...o.middleware ?? []];
      const h = O("ANTHROPIC_CUSTOM_HEADERS");
      if (h) {
        const d = {};
        for (const m of h.split(`
`)) {
          const g = m.indexOf(":");
          g >= 0 && (d[m.substring(0, g).trim()] = m.substring(g + 1).trim());
        }
        o.defaultHeaders = { ...d, ...o.defaultHeaders };
      }
      const _ = a.__auth;
      if (delete o.__auth, delete o.__baseURLIsExplicit, this._options = o, this.apiKey = typeof t == "string" ? t : null, this.authToken = s, this.webhookKey = i, _)
        this._authState = _, !this._baseURLIsExplicit && _.baseURL && (this.baseURL = _.baseURL);
      else if (this._authState = { provider: null, tokenCache: null, resolution: null, error: null, extraHeaders: {} }, this.apiKey == null && this.authToken == null) {
        const d = o.credentials ?? null;
        if (d)
          this._authState.provider = d, this._authState.tokenCache = this._makeTokenCache(d);
        else if (o.config != null) {
          const m = hu(o.config, this._credentialResolverOptions());
          this._authState.provider = m.provider, this._authState.tokenCache = this._makeTokenCache(m.provider), this._authState.extraHeaders = m.extraHeaders, this._applyCredentialBaseURL(m.baseURL);
        } else o.profile != null ? this._authState.resolution = this._resolveDefaultCredentials(o.profile) : this._shouldResolveDefaultCredentials() && (this._authState.resolution = this._resolveDefaultCredentials());
      }
    }
    /**
     * Whether to lazily resolve auth from the default credential chain when no
     * explicit auth is configured. Called once from the constructor, so
     * overrides must not depend on subclass instance state. Subclasses that
     * bring their own auth scheme return false so unrelated local credentials
     * are never resolved or allowed to supply a base URL.
     */
    _shouldResolveDefaultCredentials() {
      return !0;
    }
    /**
     * Stores a profile/config-supplied base URL on the shared auth state and, if
     * the caller did not pin `baseURL` via constructor option or env, adopts it
     * as this client's outbound API host. Precedence: ctor opt > env > profile >
     * hardcoded default.
     */
    _applyCredentialBaseURL(e) {
      if (!e)
        return;
      const t = e.replace(/\/+$/, "");
      this._authState.baseURL = t, this._baseURLIsExplicit || (this.baseURL = t);
    }
    /**
     * Options bag passed into the credential chain. `baseURL` here is only the
     * fallback host for the token-exchange POST when the config itself omits
     * `base_url`; the chain returns the config's own `base_url` (if any) on
     * {@link CredentialResult.baseURL}, which {@link _applyCredentialBaseURL}
     * then adopts for outbound API requests. The two are deliberately decoupled
     * so this fallback never round-trips into precedence.
     */
    _credentialResolverOptions() {
      return {
        baseURL: this.baseURL,
        fetch: this._credentialsFetch(),
        userAgent: this.getUserAgent(),
        onCacheWriteError: (e) => {
          M(this).debug("credential cache write failed (best-effort)", e);
        },
        onSafetyWarning: (e) => {
          M(this).warn(e);
        }
      };
    }
    /**
     * A `Fetch` for first-party credential token-exchange requests (OIDC
     * federation jwt-bearer grants, user-OAuth refresh grants) that routes
     * through this client's middleware chain, so middleware observes token
     * traffic like any other request. Only client-level middleware applies:
     * a minted token is shared across requests, so attributing the exchange
     * to any one request's per-request middleware would be arbitrary. For the
     * same reason, `ctx.options` is undefined for these requests.
     */
    _credentialsFetch() {
      return na(this.fetch, this.middleware, void 0, this);
    }
    _makeTokenCache(e) {
      return new R_(e, (t) => {
        M(this).debug("advisory token refresh failed; serving cached token", t);
      });
    }
    /**
     * Create a new client instance re-using the same options given to the
     * current client with optional overriding.
     */
    withOptions(e) {
      const t = "credentials" in e || "config" in e || "profile" in e, s = "apiKey" in e || "authToken" in e || t, i = {
        ...this._options,
        // Only forward baseURL when the caller (or env) explicitly chose it.
        // For a non-explicit parent, this.baseURL may have been mutated to the
        // profile-resolved host; pinning that as the clone's options.baseURL
        // would make _options on the clone misreport caller intent and would
        // leave the clone stuck on the parent's host across an auth override.
        // The clone instead receives the construction-time value via
        // ...this._options above and re-adopts the profile host through the
        // shared _authState.baseURL + __baseURLIsExplicit=false path.
        ...this._baseURLIsExplicit ? { baseURL: this.baseURL } : {},
        maxRetries: this.maxRetries,
        timeout: this.timeout,
        logger: this.logger,
        logLevel: this.logLevel,
        fetch: this.fetch,
        fetchOptions: this.fetchOptions,
        middleware: this.middleware,
        apiKey: this.apiKey,
        authToken: this.authToken,
        webhookKey: this.webhookKey,
        // credentials: this.credentials is a no-op when __auth is shared (the
        // ctor takes the inherited path and ignores options.credentials); when
        // overridesAuth is true via apiKey/authToken only, it lets the clone
        // build a fresh TokenCache around the parent's provider.
        credentials: this.credentials,
        // When the caller passes a structured-credential override, drop inherited
        // structured-credential options so only `...options` supplies them —
        // otherwise an inherited `credentials`/`config`/`profile` would trip the
        // mutual-exclusion check or precedence over the override.
        ...t ? { credentials: void 0, config: void 0, profile: void 0 } : {},
        ...e,
        openTelemetry: e.openTelemetry ?? c(this, at, "f"),
        // Always set __auth so any stale value from ...this._options is
        // overwritten. undefined means "build fresh auth from these options".
        __auth: s ? void 0 : this._authState,
        __baseURLIsExplicit: "baseURL" in e ? !0 : this._baseURLIsExplicit
      };
      return new this.constructor(i);
    }
    /**
     * Lazily resolves credentials from config files or environment variables.
     * Called once from the constructor when no explicit auth is provided, or
     * when an explicit `profile` was passed (in which case a missing/unresolved
     * profile is surfaced as an error instead of falling through to "no auth").
     * The returned promise is stored and awaited on the first request.
     */
    async _resolveDefaultCredentials(e) {
      try {
        const t = await Lp(this._credentialResolverOptions(), e);
        if (t)
          this._authState.provider = t.provider, this._authState.tokenCache = this._makeTokenCache(t.provider), this._authState.extraHeaders = t.extraHeaders, this._applyCredentialBaseURL(t.baseURL);
        else if (e != null)
          throw new R(`Profile "${e}" could not be resolved (no <config_dir>/configs/${e}.json found).`);
      } catch (t) {
        this._authState.error = t;
      } finally {
        this._authState.resolution = null;
      }
    }
    defaultQuery() {
      return this._options.defaultQuery;
    }
    validateHeaders({ values: e, nulls: t }) {
      if (!(e.get("x-api-key") || e.get("authorization"))) {
        if (this._authState.error)
          throw this._authState.error;
        if (!(this._authState.tokenCache || this._authState.resolution) && !(this.apiKey && e.get("x-api-key")) && !t.has("x-api-key") && !(this.authToken && e.get("authorization")) && !t.has("authorization"))
          throw new Error('Could not resolve authentication method. Expected one of apiKey, authToken, credentials, config, or profile to be set. Or for one of the "X-Api-Key" or "Authorization" headers to be explicitly omitted');
      }
    }
    _authFlags(e) {
      let t = this._requestAuthFlags.get(e);
      return t || (t = { usedTokenCache: !1, didRefreshFor401: !1 }, this._requestAuthFlags.set(e, t)), t;
    }
    async authHeaders(e) {
      if (this._authState.resolution && await this._authState.resolution, !this._authState.error) {
        if (this._authState.tokenCache && this.apiKey == null) {
          const t = await this._authState.tokenCache.getToken();
          return this._authFlags(e).usedTokenCache = !0, p([{ Authorization: `Bearer ${t}` }]);
        }
        return p([await this.apiKeyAuth(e), await this.bearerAuth(e)]);
      }
    }
    async apiKeyAuth(e) {
      if (this.apiKey != null)
        return p([{ "X-Api-Key": this.apiKey }]);
    }
    async bearerAuth(e) {
      if (this.authToken != null)
        return p([{ Authorization: `Bearer ${this.authToken}` }]);
    }
    stringifyQuery(e) {
      return y_(e);
    }
    getUserAgent() {
      return `Anthropic/JS ${Pe}`;
    }
    makeStatusError(e, t, s, i) {
      return j.generate(e, t, s, i);
    }
    buildURL(e, t, s) {
      const i = !c(this, Is, "m", Uc).call(this) && s || this.baseURL, a = gd(e) ? new URL(e) : new URL(i + (i.endsWith("/") && e.startsWith("/") ? e.slice(1) : e)), o = this.defaultQuery(), l = Object.fromEntries(a.searchParams);
      return (!Ii(o) || !Ii(l)) && (t = { ...l, ...o, ...t }), typeof t == "object" && t && !Array.isArray(t) && (a.search = this.stringifyQuery(t)), a.toString();
    }
    _calculateNonstreamingTimeout(e) {
      if (3600 * e / 128e3 > 600)
        throw new R("Streaming is required for operations that may take longer than 10 minutes. See https://github.com/anthropics/anthropic-sdk-typescript#streaming-responses for more details");
      return 600 * 1e3;
    }
    /**
     * Used as a callback for mutating the given `FinalRequestOptions` object.
     */
    async prepareOptions(e) {
    }
    /**
     * Used as a callback for mutating the given `RequestInit` object.
     *
     * This is useful for cases where you want to add certain headers based off of
     * the request properties, e.g. `method` or `url`.
     *
     * Runs after all middleware (including {@link backendMiddleware}),
     * immediately before each underlying fetch call, so it sees exactly what
     * goes over the wire, except the trace-context headers of a traced call
     * (`traceparent`, `tracestate`, `baggage`, and any other that the registered
     * propagator writes): the client sets them again after this hook, so that a
     * signature does not cover them. Middleware may replay a request by calling
     * `next()` more than once, so this hook can run multiple times per attempt:
     * overrides must be idempotent and overwrite headers from a previous
     * invocation rather than append to them.
     */
    async prepareRequest(e, { url: t, options: s }) {
      if (this._authState.tokenCache && this.apiKey == null) {
        const i = e.headers instanceof Headers ? e.headers : new Headers(e.headers);
        for (const [o, l] of Object.entries(this._authState.extraHeaders))
          i.has(o) || i.set(o, l);
        const a = i.get("anthropic-beta")?.split(",").map((o) => o.trim());
        a?.includes(Fr) || i.set("anthropic-beta", [...a ?? [], Fr].join(",")), e.headers = i;
      }
    }
    /**
     * Internal {@link Middleware} composed innermost in the chain — inside both
     * client-level and per-request middleware, immediately around the underlying
     * `fetch`. Subclasses for third-party backends override this to adapt the
     * canonical Anthropic-shaped request to the backend's wire shape (URL/body
     * rewriting, request signing) and to normalize the wire response back to the
     * canonical shape (e.g. AWS EventStream to SSE).
     *
     * Running inside the user's middleware means user middleware always observes
     * canonical Anthropic-shaped traffic, and the adaptation re-runs (e.g.
     * re-signs) on every `next()` invocation, covering whatever the middleware
     * mutated. It does not see the trace-context headers of a traced call: see
     * {@link prepareRequest}.
     *
     * Errors thrown here follow the middleware error policy: they propagate to
     * the caller as-is — no retries, no `APIConnectionError` wrapping — unless
     * retryable (see {@link Middleware}); throw a `RetryableError` to opt into
     * the retry path.
     */
    backendMiddleware() {
      return [];
    }
    get(e, t) {
      return this.methodRequest("get", e, t);
    }
    post(e, t) {
      return this.methodRequest("post", e, t);
    }
    patch(e, t) {
      return this.methodRequest("patch", e, t);
    }
    put(e, t) {
      return this.methodRequest("put", e, t);
    }
    delete(e, t) {
      return this.methodRequest("delete", e, t);
    }
    methodRequest(e, t, s) {
      return this.request(Promise.resolve(s).then((i) => ({ method: e, path: t, ...i })));
    }
    request(e, t = null) {
      return this._tracer ? new Ys(this, this.makeTracedRequest(e, t)) : new Ys(this, this.makeRequest(e, t, void 0));
    }
    /**
     * Makes the request inside the call span that the SDK method started and passed in the options
     * (`__span`). The span ends here when the call fails, and otherwise when the application has
     * read the response body: see `APIPromise`.
     */
    async makeTracedRequest(e, t) {
      const s = await e, i = s.__span?.span;
      if (!i)
        return this.makeRequest(s, t, void 0);
      try {
        return await he.with(_t.setSpan(he.active(), i), () => this.makeRequest(s, t, void 0, i));
      } catch (a) {
        const o = { status: "error", options: s, error: a };
        throw zr(this, i, o), F(this, () => Tn(i, o)), a;
      }
    }
    async makeRequest(e, t, s, i) {
      const a = await e;
      let o = ts("maxRetries", a.maxRetries ?? this.maxRetries);
      this.isStreamBody(a.body) && (o = 0), t == null && (t = o, this._requestAuthFlags.delete(a)), await this.prepareOptions(a);
      const { req: l, url: h, timeout: _ } = await this.buildRequest(a, {
        retryCount: o - t
      }), d = "log_" + (Math.random() * (1 << 24) | 0).toString(16).padStart(6, "0"), m = s === void 0 ? "" : `, retryOf: ${s}`;
      i && this.openTelemetry.propagation && (l.headers = F(this, () => u_(i, l.headers)) ?? l.headers);
      const g = Date.now();
      if (a.signal?.aborted)
        throw new ue();
      const b = new AbortController(), w = await this.fetchWithTimeout(h, l, _, b, a, {
        requestLogID: d,
        retryOfRequestLogID: s
      }).catch(Ir), S = Date.now();
      if (w instanceof globalThis.Error) {
        lt(b);
        const k = `retrying, ${t} attempts remaining`;
        if (a.signal?.aborted)
          throw new ue();
        const A = dt(w) || /timed? ?out/i.test(String(w) + ("cause" in w ? String(w.cause) : "")), E = this.middleware.length > 0 || !!a.middleware?.length || this.backendMiddleware().length > 0;
        if (E && !A && !Fp(w))
          throw M(this).info(`[${d}] middleware error (not retryable)`), He(M(this), `[${d}] middleware error (not retryable)`, {
            retryOfRequestLogID: s,
            url: h,
            durationMs: S - g,
            message: w.message
          }), w;
        if (t)
          return M(this).info(`[${d}] connection ${A ? "timed out" : "failed"} - ${k}`), He(M(this), `[${d}] connection ${A ? "timed out" : "failed"} (${k})`, {
            retryOfRequestLogID: s,
            url: h,
            durationMs: S - g,
            message: w.message
          }), this.retryRequest(a, t, s ?? d, i);
        throw M(this).info(`[${d}] connection ${A ? "timed out" : "failed"} - error; no more retries left`), He(M(this), `[${d}] connection ${A ? "timed out" : "failed"} (error; no more retries left)`, {
          retryOfRequestLogID: s,
          url: h,
          durationMs: S - g,
          message: w.message
        }), A ? new Us() : E && !fu(w) ? w : new qt({ cause: w });
      }
      const x = [...w.headers.entries()].filter(([k]) => k === "request-id" || k === "anthropic-workspace-id").map(([k, A]) => ", " + k + ": " + JSON.stringify(A)).join(""), v = `[${d}${m}${x}] ${l.method} ${h} ${w.ok ? "succeeded" : "failed"} with status ${w.status} in ${S - g}ms`;
      if (!w.ok) {
        const k = await this.shouldRetry(w, a);
        if (t && k) {
          const I = `retrying, ${t} attempts remaining`;
          return await Ed(w.body), lt(b), M(this).info(`${v} - ${I}`), He(M(this), `[${d}] response error (${I})`, {
            retryOfRequestLogID: s,
            url: w.url,
            status: w.status,
            headers: w.headers,
            durationMs: S - g
          }), this.retryRequest(a, t, s ?? d, i, w.headers);
        }
        const A = k ? "error; no more retries left" : "error; not retryable";
        M(this).info(`${v} - ${A}`);
        const E = await w.text().catch((I) => Ir(I).message), z = fl(E), q = z ? void 0 : E;
        throw He(M(this), `[${d}] response error (${A})`, {
          retryOfRequestLogID: s,
          url: w.url,
          status: w.status,
          headers: w.headers,
          message: q,
          durationMs: Date.now() - g
        }), lt(b), this.makeStatusError(w.status, z, q, w.headers);
      }
      return M(this).info(v), He(M(this), `[${d}] response start`, {
        retryOfRequestLogID: s,
        url: w.url,
        status: w.status,
        headers: w.headers,
        durationMs: S - g
      }), Td(w.body ?? w, b), { response: w, options: a, controller: b, requestLogID: d, retryOfRequestLogID: s, startTime: g };
    }
    getAPIList(e, t, s) {
      return this.requestAPIList(t, s && "then" in s ? s.then((i) => ({ method: "get", path: e, ...i })) : { method: "get", path: e, ...s });
    }
    requestAPIList(e, t) {
      if (!this._tracer) {
        const i = this.makeRequest(t, null, void 0);
        return new ia(this, i, e);
      }
      const s = this.makeTracedRequest(t, null);
      return new ia(this, s, e);
    }
    async fetchWithTimeout(e, t, s, i, a, o) {
      const { signal: l, method: h, ..._ } = t || {}, d = this._makeAbort(i);
      l && (l.addEventListener("abort", d, { once: !0 }), Sd(i, l, d));
      const m = globalThis.ReadableStream && _.body instanceof globalThis.ReadableStream || typeof _.body == "object" && _.body !== null && Symbol.asyncIterator in _.body, g = {
        signal: i.signal,
        ...m ? { duplex: "half" } : {},
        method: "GET",
        ..._
      };
      h && (g.method = h.toUpperCase());
      const b = this.fetch, w = async (A, E) => {
        const z = setTimeout(d, s);
        try {
          return await b.call(void 0, A, E);
        } finally {
          clearTimeout(z);
        }
      }, S = a === void 0 ? w : (async (A, E = {}) => {
        const z = typeof A == "string" ? A : A instanceof URL ? A.href : A.url;
        E.headers = E.headers instanceof Headers ? E.headers : new Headers(E.headers);
        let q = [];
        a.__span && (E.headers = new Headers(E.headers), q = nu(E.headers)), await this.prepareRequest(E, { url: z, options: a }), q.length && (E.headers = p([E.headers, q]).values);
        const $ = a.__span;
        return $ && F(this, () => o_($, E.method ?? "GET", z, this.openTelemetry.traces.contentMode === "content")), o && He(M(this), `[${o.requestLogID}] sending request`, {
          retryOfRequestLogID: o.retryOfRequestLogID,
          method: E.method,
          url: z,
          options: a,
          headers: E.headers
        }), w(A, E);
      }), x = a?.middleware, v = a?.__span ? this.backendMiddleware().map(Sp) : this.backendMiddleware(), k = x?.length || v.length ? [...this.middleware, ...x ?? [], ...v] : this.middleware;
      return await na(S, k, a, this)(e, g);
    }
    async shouldRetry(e, t) {
      const s = this._authFlags(t);
      if (e.status === 401 && this._authState.tokenCache && s.usedTokenCache && !s.didRefreshFor401)
        return s.didRefreshFor401 = !0, this._authState.tokenCache.invalidate(), !0;
      const i = e.headers.get("x-should-retry");
      return i === "true" ? !0 : i === "false" ? !1 : e.status === 408 || e.status === 409 || e.status === 429 || e.status >= 500;
    }
    async retryRequest(e, t, s, i, a) {
      let o;
      const l = a?.get("retry-after-ms");
      if (l) {
        const _ = parseFloat(l);
        Number.isNaN(_) || (o = _);
      }
      const h = a?.get("retry-after");
      if (h && !o) {
        const _ = parseFloat(h);
        Number.isNaN(_) ? o = Date.parse(h) - Date.now() : o = _ * 1e3;
      }
      if (o === void 0 || !(o > 0 && o <= 2 ** 31 - 1)) {
        const _ = e.maxRetries ?? this.maxRetries;
        o = this.calculateDefaultRetryTimeoutMillis(t, _);
      }
      return await ct(o, e.signal ?? void 0), this.makeRequest(e, t - 1, s, i);
    }
    calculateDefaultRetryTimeoutMillis(e, t) {
      const a = t - e, o = Math.min(0.5 * Math.pow(2, a), 8), l = 1 - Math.random() * 0.25;
      return o * l * 1e3;
    }
    calculateNonstreamingTimeout(e, t) {
      if (36e5 * e / 128e3 > 6e5 || t != null && e > t)
        throw new R("Streaming is required for operations that may take longer than 10 minutes. See https://github.com/anthropics/anthropic-sdk-typescript#long-requests for more details");
      return 6e5;
    }
    async buildRequest(e, { retryCount: t = 0 } = {}) {
      const s = { ...e }, { method: i, path: a, query: o, defaultBaseURL: l } = s;
      this._authState.resolution && await this._authState.resolution, !this._baseURLIsExplicit && this._authState.baseURL && this.baseURL !== this._authState.baseURL && (this.baseURL = this._authState.baseURL);
      const h = this.buildURL(a, o, l);
      "timeout" in s && ts("timeout", s.timeout), s.timeout = s.timeout ?? this.timeout;
      const { bodyHeaders: _, body: d } = this.buildBody({ options: s }), m = await this.buildHeaders({
        options: e,
        method: i,
        bodyHeaders: _,
        retryCount: t,
        timeout: s.timeout
      });
      return { req: {
        method: i,
        headers: m,
        ...s.signal && { signal: s.signal },
        ...globalThis.ReadableStream && d instanceof globalThis.ReadableStream && { duplex: "half" },
        ...d && { body: d },
        ...this.fetchOptions ?? {},
        ...s.fetchOptions ?? {}
      }, url: h, timeout: s.timeout };
    }
    async buildHeaders({ options: e, method: t, bodyHeaders: s, retryCount: i, timeout: a }) {
      const o = p([
        {
          Accept: "application/json",
          "User-Agent": this.getUserAgent(),
          "X-Stainless-Retry-Count": String(i),
          "X-Stainless-Timeout": String(Math.trunc(a / 1e3)),
          ...ui(),
          ...this._options.dangerouslyAllowBrowser ? { "anthropic-dangerous-direct-browser-access": "true" } : void 0,
          "anthropic-version": "2023-06-01"
        },
        await this.authHeaders(e),
        this._options.defaultHeaders,
        s,
        e.headers
      ]);
      return this.validateHeaders(o), o.values;
    }
    _makeAbort(e) {
      return () => e.abort();
    }
    buildBody({ options: { body: e, headers: t } }) {
      if (!e)
        return { bodyHeaders: void 0, body: void 0 };
      const s = p([t]);
      return (
        // Pass raw type verbatim
        ArrayBuffer.isView(e) || e instanceof ArrayBuffer || e instanceof DataView || typeof e == "string" && // Preserve legacy string encoding behavior for now
        s.values.has("content-type") || // `Blob` is superset of `File`
        globalThis.Blob && e instanceof globalThis.Blob || // `FormData` -> `multipart/form-data`
        e instanceof FormData || // `URLSearchParams` -> `application/x-www-form-urlencoded`
        e instanceof URLSearchParams || // Send chunked stream (each chunk has own `length`)
        globalThis.ReadableStream && e instanceof globalThis.ReadableStream ? { bodyHeaders: void 0, body: e } : this.isStreamBody(e) ? { bodyHeaders: void 0, body: bl(e) } : typeof e == "object" && s.values.get("content-type") === "application/x-www-form-urlencoded" ? {
          bodyHeaders: { "content-type": "application/x-www-form-urlencoded" },
          body: this.stringifyQuery(e)
        } : c(this, Sr, "f").call(this, { body: e, headers: s })
      );
    }
    /**
     * Whether `body` is sent as a stream, which can be read only once:
     * a `ReadableStream`, an async iterable or an iterator.
     */
    isStreamBody(e) {
      return globalThis.ReadableStream && e instanceof globalThis.ReadableStream ? !0 : typeof e == "object" && e !== null && (Symbol.asyncIterator in e || Symbol.iterator in e && "next" in e && typeof e.next == "function");
    }
  }
  return Ns = r, Sr = /* @__PURE__ */ new WeakMap(), at = /* @__PURE__ */ new WeakMap(), Is = /* @__PURE__ */ new WeakSet(), Uc = function() {
    return this.baseURL !== "https://api.anthropic.com";
  }, r.Anthropic = Ns, r.DEFAULT_TIMEOUT = 6e5, r.AnthropicError = R, r.APIError = j, r.APIConnectionError = qt, r.APIConnectionTimeoutError = Us, r.APIUserAbortError = ue, r.NotFoundError = ul, r.ConflictError = dl, r.RateLimitError = _l, r.BadRequestError = ol, r.AuthenticationError = cl, r.InternalServerError = pl, r.PermissionDeniedError = ll, r.UnprocessableEntityError = hl, r.toFile = Jp, r.HUMAN_PROMPT = mg, r.AI_PROMPT = bg, r;
})(), Fc = /* @__PURE__ */ (() => {
  class r extends wg {
    constructor() {
      super(...arguments), this.completions = new gc(this), this.messages = new da(this), this.models = new bc(this), this.files = new mc(this), this.skills = new Lc(this), this.userProfiles = new Bc(this), this.organization = new Ic(this), this.beta = new fc(this);
    }
  }
  return r.Completions = gc, r.Messages = da, r.Models = bc, r.Files = mc, r.Skills = Lc, r.UserProfiles = Bc, r.Organization = Ic, r.Beta = fc, r;
})();
const yg = {
  type: "object",
  properties: {
    translations: {
      type: "array",
      items: {
        type: "object",
        properties: { subtitle_id: { type: "string" }, translated_text: { type: "string" } },
        required: ["subtitle_id", "translated_text"],
        additionalProperties: !1
      }
    }
  },
  required: ["translations"],
  additionalProperties: !1
}, vg = (r) => /^claude-(opus|sonnet|haiku|fable|mythos)-5/.test(r), kg = (r) => /^claude-(opus-5|sonnet-5-5|fable-5)/.test(r);
class Sg {
  constructor(n) {
    if (this.o = n, !n.apiKey) throw new me("Thiếu API key Anthropic (Cài đặt → Anthropic Claude).");
    this.client = new Fc({
      apiKey: n.apiKey,
      baseURL: n.endpoint.replace(/\/+$/, "") || void 0,
      dangerouslyAllowBrowser: !0,
      maxRetries: 0,
      ...n.fetchImpl ? { fetch: n.fetchImpl } : {}
    });
  }
  id = "anthropic";
  client;
  async translateBatch(n) {
    const e = this.o.model;
    let t;
    try {
      t = await this.client.beta.messages.create(
        {
          model: e,
          max_tokens: 16e3,
          system: oi,
          messages: [{ role: "user", content: ci(n) }],
          output_config: {
            ...vg(e) ? { effort: "low" } : {},
            // speed-first
            format: { type: "json_schema", schema: yg }
          },
          ...kg(e) ? { betas: ["server-side-fallback-2026-07-01"], fallbacks: "default" } : {}
        },
        { signal: n.signal }
      );
    } catch (o) {
      if (o instanceof Fc.APIError && typeof o.status == "number") {
        const l = o.headers, h = o.status === 401 || o.status === 403 ? " (check the API key / permissions)" : o.status === 429 ? " (rate limited)" : "";
        throw new Me(o.status, `Anthropic HTTP ${o.status}${h}: ${o.message.slice(0, 300)}`, nl(l?.get?.("retry-after") ?? null));
      }
      throw o;
    }
    const s = t.usage.cache_read_input_tokens ?? 0, i = t.usage.cache_creation_input_tokens ?? 0;
    if (n.onUsage?.({
      inputTokens: (t.usage.input_tokens ?? 0) + s + i,
      outputTokens: t.usage.output_tokens ?? 0,
      cachedInputTokens: s || void 0,
      cacheWriteTokens: i || void 0
    }), t.stop_reason === "refusal") throw new De("Claude declined this batch");
    const a = t.content.map((o) => o.type === "text" ? o.text : "").join("");
    return Dr(li(a), n.segments.map((o) => o.id));
  }
}
function Tg(r, n, e) {
  const t = Zc(n, r.kind, r.kind);
  switch (r.kind) {
    case "anthropic":
      return new Sg({ endpoint: r.endpoint, model: r.model, apiKey: t, fetchImpl: e });
    case "openai":
      return new _d({ endpoint: r.endpoint, model: r.model, apiKey: t, temperature: r.temperature, fetchImpl: e });
    case "gemini":
      return new od({ endpoint: r.endpoint, model: r.model, apiKey: t, temperature: r.temperature, fetchImpl: e });
    case "local":
      return new dd({ endpoint: r.endpoint, model: r.model, apiKey: t, fetchImpl: e });
    case "mock":
    default:
      return new hd(150);
  }
}
const Wc = {
  fast: { firstBatchSize: 3, batchSize: 8, backgroundBatchSize: 12, lookAheadSec: 45, contextSize: 1 },
  balanced: { firstBatchSize: 4, batchSize: 10, backgroundBatchSize: 16, lookAheadSec: 90, contextSize: 3 },
  quality: { firstBatchSize: 4, batchSize: 12, backgroundBatchSize: 20, lookAheadSec: 120, contextSize: 6 }
};
function Ag(r) {
  return Wc[r ?? "balanced"] ?? Wc.balanced;
}
function xg(r) {
  return An(
    [
      r.provider.kind,
      r.provider.endpoint,
      r.provider.model,
      r.provider.temperature,
      r.provider.kind === "gemini" && sl(r.provider.model) ? "think:minimal" : "",
      id,
      Zu(r.glossary),
      "en",
      "vi",
      r.mergeFragments ? "merge" : "nomerge"
    ].join("|")
  );
}
function Eg(r, n, e) {
  return `${r}|${An(n)}|${An(e.trim().toLowerCase())}:${e.length}`;
}
class Rg {
  requests = 0;
  failedRequests = 0;
  retries = 0;
  rateLimited = 0;
  segmentsTranslated = 0;
  cacheHits = 0;
  cacheMisses = 0;
  inputTokens = 0;
  outputTokens = 0;
  /** Cost of tokens with a known model price (USD). */
  estimatedCostUsd = 0;
  pricedModel = !0;
  latencies = [];
  recordUsage(n, e, t) {
    this.inputTokens += e, this.outputTokens += t;
    const s = ld(n, e, t);
    s === null ? this.pricedModel = !1 : this.estimatedCostUsd += s;
  }
  recordLatency(n) {
    this.latencies.push(n), this.latencies.length > 200 && this.latencies.shift();
  }
  snapshot() {
    const n = this.latencies.length ? this.latencies.reduce((e, t) => e + t, 0) / this.latencies.length : 0;
    return {
      requests: this.requests,
      failedRequests: this.failedRequests,
      retries: this.retries,
      rateLimited: this.rateLimited,
      segmentsTranslated: this.segmentsTranslated,
      cacheHits: this.cacheHits,
      cacheMisses: this.cacheMisses,
      avgLatencyMs: Math.round(n),
      medianLatencyMs: Math.round(Bs(this.latencies, 50)),
      p95LatencyMs: Math.round(Bs(this.latencies, 95)),
      inputTokens: this.inputTokens,
      outputTokens: this.outputTokens,
      estimatedCostUsd: this.pricedModel ? Math.round(this.estimatedCostUsd * 1e6) / 1e6 : null
    };
  }
}
class Pg {
  constructor(n) {
    this.deps = n, this.queue = new rd({
      ...n.queueOptions,
      onEvent: (e, t) => {
        t && n.onAccounting?.(e, t), e.type === "request" ? this.metrics.requests++ : e.type === "success" ? (this.metrics.segmentsTranslated += e.size, this.metrics.recordLatency(e.latencyMs)) : e.type === "retry" ? this.metrics.retries++ : e.type === "rate-limited" ? this.metrics.rateLimited++ : e.type === "failure" ? this.metrics.failedRequests++ : e.type === "usage" && this.metrics.recordUsage(t?.model ?? this.currentModel, e.usage.inputTokens, e.usage.outputTokens), n.queueOptions?.onEvent?.(e);
      }
    });
  }
  metrics = new Rg();
  queue;
  currentModel = "";
  writesSincePrune = 0;
  async checkConfig(n) {
    if (Xc(n) && !n.consent.remoteTranslation)
      throw new me(
        'Chưa cho phép gửi phụ đề tới dịch vụ dịch từ xa. Mở Cài đặt → bật "Cho phép gửi phụ đề" (remote translation consent required).'
      );
    if (n.provider.kind !== "mock" && this.deps.hasEndpointPermission && !await this.deps.hasEndpointPermission(n.provider.endpoint))
      throw new me('Chưa cấp quyền truy cập endpoint dịch. Mở Cài đặt và bấm "Lưu" để cấp quyền (host permission missing).');
  }
  async translateUnits(n, e, t, s = 2) {
    const i = await this.deps.getSettings(), a = this.deps.getGlossaryText ? await this.deps.getGlossaryText(i).catch(() => i.glossary) : i.glossary, o = { ...i, glossary: a, provider: Ju(i) };
    this.currentModel = o.provider.kind === "mock" ? "mock" : o.provider.model;
    try {
      await this.checkConfig(o);
    } catch (b) {
      return e.map((w) => ({ id: w.id, error: b.message, fatal: !0 }));
    }
    const l = xg(o), h = e.map((b) => ({ ...b, key: Eg(l, n, b.text) }));
    let _ = /* @__PURE__ */ new Map();
    try {
      _ = await this.deps.cache.getMany(h.map((b) => b.key));
    } catch {
    }
    const d = /* @__PURE__ */ new Map(), m = h.filter((b) => {
      const w = _.get(b.key);
      return w !== void 0 ? (d.set(b.id, { id: b.id, vi: w, cached: !0 }), !1) : !0;
    });
    this.metrics.cacheHits += h.length - m.length, this.metrics.cacheMisses += m.length;
    const g = { provider: o.provider.kind, model: this.currentModel, lesson: An(n) };
    if (this.deps.onAccounting?.({ type: "cache", hits: h.length - m.length, misses: m.length }, g), m.length) {
      const b = await this.deps.getSecrets();
      let w;
      try {
        w = this.deps.providerFactory ? this.deps.providerFactory(o, b) : Tg(o.provider, b);
      } catch (v) {
        for (const k of m) d.set(k.id, { id: k.id, error: v.message, fatal: !0 });
        return e.map((k) => d.get(k.id));
      }
      const S = await this.queue.translate(
        m.map((v) => ({ key: v.key, text: v.text })),
        {
          provider: w,
          context: t.slice(-Math.max(0, Ag(o.translationMode).contextSize)),
          glossary: rl(o.glossary),
          group: n,
          priority: s,
          meta: g
        }
      ), x = [];
      for (const v of m) {
        const k = S.get(v.key);
        if (k?.vi !== void 0)
          d.set(v.id, { id: v.id, vi: k.vi }), x.push({ key: v.key, videoKey: n, vi: k.vi });
        else {
          const A = k?.error, E = A instanceof me || A instanceof Me && (A.status === 401 || A.status === 403 || A.status === 404 || A.status === 400);
          d.set(v.id, { id: v.id, error: A?.message ?? "Translation failed", fatal: E });
        }
      }
      this.deps.cache.putMany(x).catch(() => {
      }), this.writesSincePrune += x.length, this.writesSincePrune >= 500 && (this.writesSincePrune = 0, this.deps.cache.prune().catch(() => {
      }));
    }
    return e.map((b) => d.get(b.id));
  }
  cancel(n) {
    this.queue.cancelGroup(n);
  }
}
const Tr = "tabRegistry", jc = () => ({ active: !1, chunks: 0, droppedChunks: 0 });
class zg {
  constructor(n) {
    this.store = n, this.loaded = this.load();
  }
  tabs = /* @__PURE__ */ new Map();
  loaded;
  saveTimer;
  async load() {
    try {
      const e = (await this.store.get(Tr))[Tr] ?? {};
      for (const [t, s] of Object.entries(e)) this.tabs.set(Number(t), s);
    } catch {
    }
  }
  ready() {
    return this.loaded;
  }
  persist() {
    clearTimeout(this.saveTimer), this.saveTimer = setTimeout(() => {
      const n = {};
      for (const [e, t] of this.tabs) n[e] = t;
      this.store.set({ [Tr]: n }).catch(() => {
      });
    }, 100);
  }
  /** Flush pending writes immediately (tests / shutdown). */
  async flush() {
    clearTimeout(this.saveTimer);
    const n = {};
    for (const [e, t] of this.tabs) n[e] = t;
    await this.store.set({ [Tr]: n });
  }
  rec(n) {
    let e = this.tabs.get(n);
    return e || (e = { isSkool: !1, frames: {}, audio: jc() }, this.tabs.set(n, e)), e;
  }
  setSkool(n, e) {
    this.rec(n).isSkool = e, this.persist();
  }
  updateFrame(n, e, t) {
    this.rec(n).frames[e] = { ...t, frameId: e }, this.persist();
  }
  removeFrame(n, e) {
    const t = this.tabs.get(n);
    t && (delete t.frames[e], e === 0 && (t.frames = {}), this.persist());
  }
  setAudio(n, e) {
    const t = this.rec(n);
    return t.audio = { ...t.audio, ...e }, this.persist(), t.audio;
  }
  removeTab(n) {
    this.tabs.delete(n), this.persist();
  }
  tabIds() {
    return [...this.tabs.keys()];
  }
  /** Frame that should display subtitles: largest real <video>, else the top frame. */
  primaryFrame(n) {
    const e = this.tabs.get(n);
    if (!e) return null;
    const t = Object.values(e.frames), s = t.filter((o) => o.targetKind === "video").sort((o, l) => l.targetArea - o.targetArea);
    if (s.length) return s[0].frameId;
    const i = t.find((o) => o.targetKind === "media");
    if (i) return i.frameId;
    const a = t.find((o) => o.targetKind === "iframe");
    return a ? a.frameId : t.length ? 0 : null;
  }
  get(n) {
    const e = this.tabs.get(n) ?? { isSkool: !1, frames: {}, audio: jc() };
    return {
      tabId: n,
      isSkool: e.isSkool,
      frames: Object.values(e.frames).sort((t, s) => t.frameId - s.frameId),
      primaryFrameId: this.primaryFrame(n),
      audio: e.audio
    };
  }
}
class Mg {
  constructor(n, e, t, s = fetch) {
    if (this.endpoint = n, this.model = e, this.apiKey = t, this.fetchImpl = s, !n) throw new me("STT endpoint is not configured");
  }
  id = "openai-stt";
  async transcribe(n) {
    const e = new FormData();
    e.append("file", new Blob([n.wav], { type: "audio/wav" }), "chunk.wav"), e.append("model", this.model), e.append("language", n.language), e.append("response_format", "json"), e.append("temperature", "0"), n.prompt && e.append("prompt", n.prompt.slice(-200));
    const t = {};
    this.apiKey && (t.Authorization = `Bearer ${this.apiKey}`);
    const s = await this.fetchImpl(this.endpoint.replace(/\/+$/, "") + "/audio/transcriptions", {
      method: "POST",
      headers: t,
      body: e,
      signal: n.signal
    });
    await On(s, "STT");
    const i = await s.json();
    return { text: (i.text ?? "").trim(), segments: i.segments };
  }
}
class Og {
  constructor(n, e, t = fetch) {
    if (this.endpoint = n, this.apiKey = e, this.fetchImpl = t, !n) throw new me("Local STT endpoint is not configured");
  }
  id = "local-stt";
  async transcribe(n) {
    const e = { "Content-Type": "audio/wav", "X-Language": n.language };
    n.prompt && (e["X-Prompt"] = encodeURIComponent(n.prompt.slice(-200))), this.apiKey && (e.Authorization = `Bearer ${this.apiKey}`);
    const t = await this.fetchImpl(this.endpoint.replace(/\/+$/, "") + "/transcribe", {
      method: "POST",
      headers: e,
      body: n.wav,
      signal: n.signal
    });
    return await On(t, "Local STT"), { text: ((await t.json()).text ?? "").trim() };
  }
}
class Cg {
  id = "mock-stt";
  n = 0;
  async transcribe() {
    return this.n++, { text: `This is mock speech segment number ${this.n}.` };
  }
}
function $g(r, n, e) {
  switch (r.kind) {
    case "openai":
      return new Mg(r.endpoint, r.model, n.sttApiKey, e);
    case "local":
      return new Og(r.endpoint, n.sttApiKey, e);
    default:
      return new Cg();
  }
}
const Ig = [
  /^thanks? (you )?for watching[.!]*$/i,
  /^thank you[.!]*$/i,
  /^please subscribe.*$/i,
  /^subtitles? by .*$/i,
  /^\[?(music|applause|silence|blank_audio)\]?$/i,
  /^you$/i,
  /^\.+$/
];
function Ng(r, n) {
  const e = r.trim();
  return e ? n < 0.02 && Ig.some((t) => t.test(e)) : !0;
}
class Lg {
  constructor(n = 4, e = 3) {
    this.minWords = n, this.maxHoldSec = e;
  }
  seq = 0;
  pending = null;
  lastWords = [];
  push(n, e, t, s = 1) {
    let i = n.replace(/\s+/g, " ").trim();
    if (Ng(i, s)) return this.pending && t - this.pending.startSec > this.maxHoldSec ? this.flush() : [];
    if (i = this.dropOverlap(i), !i) return [];
    const a = [];
    let o;
    this.pending ? (o = { ...this.pending, text: `${this.pending.text} ${i}`, endSec: t }, this.pending = null) : o = { id: "", text: i, startSec: e, endSec: t };
    const l = o.text.split(" ").length;
    return !/[.!?…]["')\]]?$/.test(o.text) && l < this.minWords && t - o.startSec < this.maxHoldSec ? (this.pending = o, a) : (o.id = `live-${++this.seq}`, this.remember(o.text), a.push(o), a);
  }
  /** Emit any held fragment (on timeout or stop). */
  flush() {
    if (!this.pending) return [];
    const n = { ...this.pending, id: `live-${++this.seq}` };
    return this.pending = null, this.remember(n.text), [n];
  }
  get hasPending() {
    return !!this.pending;
  }
  remember(n) {
    this.lastWords = n.split(" ").slice(-8);
  }
  dropOverlap(n) {
    const e = n.split(" "), t = (s) => s.toLowerCase().replace(/[^\p{L}\p{N}']/gu, "");
    for (let s = Math.min(6, this.lastWords.length, e.length - 1); s >= 2; s--) {
      const i = this.lastWords.slice(-s).map(t).join(" "), a = e.slice(0, s).map(t).join(" ");
      if (i === a) return e.slice(s).join(" ");
    }
    return n;
  }
}
const qg = 2, Bg = 3, Ar = "audioSession";
class Ug {
  constructor(n) {
    this.d = n, this.restored = this.restore();
  }
  session = null;
  restored;
  now() {
    return (this.d.now ?? Date.now)();
  }
  /** After a service-worker restart, re-attach to a session the offscreen doc still runs. */
  async restore() {
    const e = (await this.d.sessionStore?.get(Ar).catch(() => ({})))?.[Ar];
    e && (this.session = this.newSession(e.id, e.tabId, e.startedAt));
  }
  newSession(n, e, t) {
    return {
      id: n,
      tabId: e,
      startedAt: t,
      assembler: new Lg(),
      context: [],
      sttInFlight: 0,
      consecutiveFailures: 0,
      abort: new AbortController(),
      sttLatencies: [],
      totalLatencies: [],
      nextSeqToEmit: 0,
      readyBySeq: /* @__PURE__ */ new Map(),
      seenAny: !1
    };
  }
  get active() {
    return this.session ? { id: this.session.id, tabId: this.session.tabId } : null;
  }
  async start(n, e) {
    await this.restored;
    const t = await this.d.getSettings();
    if (Qc(t) && !t.consent.remoteAudio)
      throw new Error("Chưa cho phép gửi âm thanh tới dịch vụ STT từ xa. Bật trong Cài đặt → Quyền riêng tư (remote audio consent required).");
    if (t.stt.kind !== "mock" && this.d.hasEndpointPermission && !await this.d.hasEndpointPermission(t.stt.endpoint))
      throw new Error('Chưa cấp quyền truy cập endpoint STT. Mở Cài đặt và bấm "Lưu".');
    this.session && await this.stop(this.session.tabId, "replaced");
    const s = `a${this.now().toString(36)}${Math.random().toString(36).slice(2, 6)}`;
    this.session = this.newSession(s, n, this.now()), await this.d.sessionStore?.set({ [Ar]: { id: s, tabId: n, startedAt: this.session.startedAt } }), this.d.registry.setAudio(n, { active: !0, sessionId: s, startedAt: this.session.startedAt, error: void 0, chunks: 0, droppedChunks: 0 }), this.d.setBadge(n, "REC"), await this.d.ensureOffscreen(), await this.d.sendOffscreen({ type: "start", streamId: e, sessionId: s }), await this.notifyState(n, !0);
  }
  async stop(n, e = "user", t) {
    await this.restored;
    const s = this.session;
    !s || n !== void 0 && s.tabId !== n || (this.session = null, s.abort.abort(), clearTimeout(s.holdTimer), await this.d.sessionStore?.set({ [Ar]: null }).catch(() => {
    }), await this.d.sendOffscreen({ type: "stop" }).catch(() => {
    }), await this.d.closeOffscreen().catch(() => {
    }), this.d.setBadge(s.tabId, ""), this.d.registry.setAudio(s.tabId, { active: !1, error: t }), await this.notifyState(s.tabId, !1, t));
  }
  async notifyState(n, e, t) {
    const s = this.d.registry.primaryFrame(n), i = this.d.registry.get(n);
    await Promise.all(
      (i.frames.length ? i.frames : [{ frameId: 0 }]).map(
        (a) => this.d.sendToFrame(n, a.frameId, { type: "audio:state", active: e, primary: a.frameId === (s ?? 0), error: t })
      )
    );
  }
  async onOffscreenError(n, e) {
    await this.restored, this.session?.id === n && await this.stop(this.session.tabId, "error", e);
  }
  async onOffscreenStopped(n, e) {
    await this.restored, this.session?.id === n && await this.stop(this.session.tabId, e, e === "ended" ? "Âm thanh tab đã dừng (tab đóng hoặc điều hướng)." : void 0);
  }
  async onChunk(n) {
    await this.restored;
    const e = this.session;
    if (!e || e.id !== n.sessionId) return;
    const t = this.d.registry.setAudio(e.tabId, {});
    if (this.d.registry.setAudio(e.tabId, { chunks: t.chunks + 1 }), !e.seenAny && n.seq > e.nextSeqToEmit && (e.nextSeqToEmit = n.seq), e.seenAny = !0, e.sttInFlight >= qg + 1) {
      this.d.registry.setAudio(e.tabId, { droppedChunks: t.droppedChunks + 1 }), e.readyBySeq.set(n.seq, null), this.drain(e);
      return;
    }
    e.sttInFlight++;
    const s = await this.d.getSettings(), i = await this.d.getSecrets();
    let a = "";
    try {
      const o = (this.d.sttFactory ?? ((h, _) => $g(h.stt, _)))(s, i);
      a = await this.transcribeWithRetry(o, Ku(n.wavBase64), e), e.consecutiveFailures = 0;
      const l = this.now() - n.endedAt;
      e.sttLatencies.push(l), e.sttLatencies.length > 30 && e.sttLatencies.shift(), this.d.registry.setAudio(e.tabId, { sttLatencyMs: Hc(e.sttLatencies), error: void 0 });
    } catch (o) {
      if (e.abort.signal.aborted) return;
      e.consecutiveFailures++;
      const l = `Lỗi nhận dạng giọng nói (STT): ${o.message}`;
      if (this.d.registry.setAudio(e.tabId, { error: l }), e.consecutiveFailures >= Bg || o instanceof Me && (o.status === 401 || o.status === 403)) {
        await this.stop(e.tabId, "error", l + " — Audio Mode đã dừng. Kiểm tra backend STT trong Cài đặt.");
        return;
      }
    } finally {
      e.sttInFlight--;
    }
    e.readyBySeq.set(n.seq, a ? { text: a, startSec: n.startSec, endSec: n.endSec, rms: n.rms, endedAt: n.endedAt } : null), this.drain(e);
  }
  async transcribeWithRetry(n, e, t) {
    let s;
    for (let i = 0; i < 2; i++)
      try {
        return (await n.transcribe({ wav: e, language: "en", prompt: t.context.slice(-2).join(" "), signal: t.abort.signal })).text;
      } catch (a) {
        if (s = a, t.abort.signal.aborted || a instanceof Me && !a.retryable) throw a;
        await new Promise((o) => setTimeout(o, a instanceof Me && a.retryAfterMs ? Math.min(a.retryAfterMs, 3e3) : 600));
      }
    throw s;
  }
  /** Emit transcripts strictly in capture order. */
  drain(n) {
    for (; n.readyBySeq.has(n.nextSeqToEmit); ) {
      const e = n.readyBySeq.get(n.nextSeqToEmit);
      if (n.readyBySeq.delete(n.nextSeqToEmit), n.nextSeqToEmit++, !e) continue;
      const t = n.assembler.push(e.text, e.startSec, e.endSec, e.rms);
      for (const s of t) this.emitSegment(n, s, e.endedAt);
      clearTimeout(n.holdTimer), n.assembler.hasPending && (n.holdTimer = setTimeout(() => {
        for (const s of n.assembler.flush()) this.emitSegment(n, s, e.endedAt);
      }, 2500));
    }
  }
  async emitSegment(n, e, t) {
    const s = this.d.registry.primaryFrame(n.tabId);
    await this.d.sendToFrame(n.tabId, s, { type: "live:segment", id: e.id, en: e.text, final: !1 });
    const i = n.context.slice(-3);
    n.context.push(e.text), n.context.length > 10 && n.context.shift();
    const a = await this.d.translate(`audio:${n.id}`, e.text, e.id, i);
    this.session === n && (a.vi ? (n.totalLatencies.push(this.now() - t), n.totalLatencies.length > 30 && n.totalLatencies.shift(), this.d.registry.setAudio(n.tabId, { totalLatencyMs: Hc(n.totalLatencies) }), await this.d.sendToFrame(n.tabId, s, { type: "live:segment", id: e.id, en: e.text, vi: a.vi, final: !0 })) : a.error && this.d.registry.setAudio(n.tabId, { error: `Lỗi dịch: ${a.error}` }));
  }
}
const Hc = (r) => r.length ? Math.round(r.reduce((n, e) => n + e, 0) / r.length) : void 0;
async function Dc(r, n) {
  const e = new AbortController(), t = setTimeout(() => e.abort(), n.timeoutMs ?? 2500);
  try {
    return (await (n.fetchImpl ?? fetch)(r, { signal: e.signal })).ok;
  } catch {
    return !1;
  } finally {
    clearTimeout(t);
  }
}
async function Kc(r, n, e, t, s, i) {
  if (r === "mock") return { state: "mock" };
  if (e && !t) return { state: "no-consent" };
  if (!await i.hasPermission(n)) return { state: "no-permission" };
  const a = n.replace(/\/+$/, "");
  return r === "local" ? await Dc(a + "/health", i) ? { state: "ready" } : { state: "unreachable", detail: a } : si(n) ? await Dc(a + "/models", i) ? { state: "ready" } : { state: "unreachable", detail: a } : s ? { state: "configured" } : { state: "no-key" };
}
async function Fg(r, n, e) {
  const [t, s] = await Promise.all([
    Kc(r.provider.kind, r.provider.endpoint, Xc(r), r.consent.remoteTranslation, !!Zc(n, r.provider.kind, r.provider.kind), e),
    Kc(r.stt.kind, r.stt.endpoint, Qc(r), r.consent.remoteAudio, !!n.sttApiKey, e)
  ]);
  return { translation: t, stt: s };
}
const Ls = "glossaryCompiled";
async function Wg(r) {
  try {
    const n = await chrome.storage.local.get(Ls);
    return typeof n[Ls] == "string" ? n[Ls] : r;
  } catch {
    return r;
  }
}
const je = () => ({
  requests: 0,
  failed: 0,
  retries: 0,
  rateLimited: 0,
  segments: 0,
  inputTokens: 0,
  outputTokens: 0,
  cachedInputTokens: 0,
  cacheWriteTokens: 0,
  reasoningTokens: 0,
  estimatedInputTokens: 0,
  estimatedOutputTokens: 0,
  unpricedTokens: 0,
  costUsd: 0,
  estimatedCostUsd: 0,
  cacheHits: 0,
  cacheMisses: 0,
  latencyMsTotal: 0,
  latencyCount: 0
}), xr = "usageLedger", Er = "usageSession", Gc = 300, jg = 120;
class Hg {
  constructor(n, e, t, s = Date.now) {
    this.local = n, this.sessionArea = e, this.getPricing = t, this.now = s, this.loaded = this.load();
  }
  data = { version: 1, total: je(), days: {}, models: {}, lessons: {} };
  session = { bucket: je(), latencies: [], lastError: null, lastErrorAt: null };
  loaded;
  timer;
  async load() {
    try {
      const [n, e] = await Promise.all([this.local.get(xr), this.sessionArea.get(Er)]);
      n[xr] && (this.data = n[xr]), e[Er] && (this.session = e[Er]);
    } catch {
    }
  }
  ready() {
    return this.loaded;
  }
  day() {
    return new Date(this.now()).toISOString().slice(0, 10);
  }
  buckets(n = {}) {
    const e = this.day(), t = [this.data.total, this.data.days[e] ??= je(), this.session.bucket];
    if (n.provider && n.model && t.push(this.data.models[`${n.provider}:${n.model}`] ??= je()), n.lesson) {
      const s = this.data.lessons[n.lesson] ??= { ...je(), lastSeen: 0 };
      s.lastSeen = this.now(), t.push(s);
    }
    return t;
  }
  async record(n, e = {}) {
    await this.loaded;
    const t = n.type === "usage" ? await this.getPricing() : [], s = this.buckets(e);
    for (const i of s)
      switch (n.type) {
        case "request":
          i.requests++;
          break;
        case "success":
          i.segments += n.size, i.latencyMsTotal += n.latencyMs, i.latencyCount++;
          break;
        case "retry":
          i.retries++;
          break;
        case "rate-limited":
          i.rateLimited++;
          break;
        case "failure":
          i.failed++;
          break;
        case "cache":
          i.cacheHits += n.hits, i.cacheMisses += n.misses;
          break;
        case "usage": {
          const a = n.usage, o = il(e.model ?? "", a, t);
          a.estimated ? (i.estimatedInputTokens += a.inputTokens, i.estimatedOutputTokens += a.outputTokens, o !== null && (i.estimatedCostUsd += o)) : (i.inputTokens += a.inputTokens, i.outputTokens += a.outputTokens, i.cachedInputTokens += a.cachedInputTokens ?? 0, i.cacheWriteTokens += a.cacheWriteTokens ?? 0, i.reasoningTokens += a.reasoningTokens ?? 0, o !== null && (i.costUsd += o)), o === null && (i.unpricedTokens += a.inputTokens + a.outputTokens);
          break;
        }
      }
    n.type === "success" && (this.session.latencies.push(n.latencyMs), this.session.latencies.length > 200 && this.session.latencies.shift()), n.type === "failure" && (this.session.lastError = n.reason.slice(0, 200), this.session.lastErrorAt = this.now()), this.persistSoon();
  }
  prune() {
    const n = Object.entries(this.data.lessons);
    if (n.length > Gc) {
      n.sort((t, s) => t[1].lastSeen - s[1].lastSeen);
      for (const [t] of n.slice(0, n.length - Gc)) delete this.data.lessons[t];
    }
    const e = Object.keys(this.data.days).sort();
    for (const t of e.slice(0, Math.max(0, e.length - jg))) delete this.data.days[t];
  }
  persistSoon() {
    clearTimeout(this.timer), this.timer = setTimeout(() => void this.flush(), 1e3);
  }
  async flush() {
    clearTimeout(this.timer), this.prune(), await Promise.all([this.local.set({ [xr]: this.data }), this.sessionArea.set({ [Er]: this.session })]).catch(() => {
    });
  }
  async snapshot() {
    await this.loaded;
    const n = this.session.latencies;
    return {
      total: this.data.total,
      today: this.data.days[this.day()] ?? je(),
      session: this.session.bucket,
      models: this.data.models,
      lessons: this.data.lessons,
      sessionP95LatencyMs: Math.round(Bs(n, 95)),
      sessionAvgLatencyMs: n.length ? Math.round(n.reduce((e, t) => e + t, 0) / n.length) : 0,
      lastError: this.session.lastError
    };
  }
  async reset() {
    await this.loaded, this.data = { version: 1, total: je(), days: {}, models: {}, lessons: {} }, this.session = { bucket: je(), latencies: [], lastError: null, lastErrorAt: null }, await this.flush();
  }
}
const Vc = "audio/offscreen.html", Nt = new Qu(), ri = new Hg(chrome.storage.local, chrome.storage.session, al), J = new zg(chrome.storage.session);
async function zi(r) {
  const n = Du(r);
  if (!n) return !1;
  try {
    return await chrome.permissions.contains({ origins: [n] });
  } catch {
    return !1;
  }
}
const Mt = new Pg({
  cache: Nt,
  getSettings: ii,
  getSecrets: ai,
  getGlossaryText: (r) => Wg(r.glossary),
  onAccounting: (r, n) => void ri.record(r, n),
  hasEndpointPermission: zi
});
async function Wt(r, n, e) {
  try {
    await chrome.tabs.sendMessage(r, e, { frameId: n ?? 0 });
  } catch {
  }
}
let Rr = null;
async function Dg() {
  (await chrome.runtime.getContexts({
    contextTypes: [chrome.runtime.ContextType.OFFSCREEN_DOCUMENT],
    documentUrls: [chrome.runtime.getURL(Vc)]
  })).length || (Rr || (Rr = chrome.offscreen.createDocument({
    url: Vc,
    reasons: [chrome.offscreen.Reason.USER_MEDIA],
    justification: "Process user-approved tab audio for live speech-to-text subtitles."
  }).then(() => new Promise((n) => setTimeout(n, 50))).finally(() => Rr = null)), await Rr);
}
async function Kg() {
  (await chrome.runtime.getContexts({ contextTypes: [chrome.runtime.ContextType.OFFSCREEN_DOCUMENT] })).length && await chrome.offscreen.closeDocument();
}
const Re = new Ug({
  registry: J,
  getSettings: ii,
  getSecrets: ai,
  ensureOffscreen: Dg,
  closeOffscreen: Kg,
  sendOffscreen: async (r) => {
    await chrome.runtime.sendMessage({ target: "offscreen", ...r });
  },
  sendToFrame: Wt,
  broadcast: (r, n) => Wt(r, 0, n),
  translate: async (r, n, e, t) => {
    const [s] = await Mt.translateUnits(r, [{ id: e, text: n }], t);
    return s;
  },
  setBadge: (r, n) => {
    chrome.action.setBadgeText({ tabId: r, text: n }), n && chrome.action.setBadgeBackgroundColor({ tabId: r, color: "#d1242f" });
  },
  hasEndpointPermission: zi,
  sessionStore: chrome.storage.session
}), qs = /* @__PURE__ */ new Map();
function zt(r) {
  clearTimeout(qs.get(r)), qs.set(
    r,
    setTimeout(() => {
      qs.delete(r), Wt(r, 0, { type: "tab:status:changed", status: J.get(r) });
    }, 200)
  );
}
async function Jc(r) {
  const n = J.get(r);
  await Promise.all(
    n.frames.map(async (e) => {
      try {
        await Promise.race([
          chrome.tabs.sendMessage(r, { type: "frame:ping" }, { frameId: e.frameId }),
          new Promise((t, s) => setTimeout(() => s(new Error("timeout")), 400))
        ]);
      } catch {
        J.removeFrame(r, e.frameId);
      }
    })
  );
}
async function Gg(r, n) {
  await J.ready();
  const e = n.tab?.id, t = n.frameId ?? 0;
  switch (r.type) {
    case "frame:hello": {
      if (e === void 0) return { active: !1, frameId: t };
      const s = tl(n.tab?.url ?? (t === 0 ? n.url : void 0)), i = !!s && el(s);
      return t === 0 && J.setSkool(e, i), { active: i, frameId: t };
    }
    case "frame:status":
      return e === void 0 ? null : (J.updateFrame(e, t, r.status), zt(e), { ok: !0 });
    case "frame:gone":
      return e !== void 0 && (J.removeFrame(e, t), zt(e)), { ok: !0 };
    case "translate:units":
      return { results: await Mt.translateUnits(r.videoKey, r.units, r.context, r.priority) };
    case "translate:cancel":
      return Mt.cancel(r.videoKey), { ok: !0 };
    case "translate:test": {
      const [s] = await Mt.translateUnits(`test:${Date.now()}`, [{ id: "t", text: "Welcome back! Today we will set up our first Facebook Ads campaign with a $50 daily budget." }], []);
      return s;
    }
    case "tab:status":
      return await Jc(r.tabId), {
        status: J.get(r.tabId),
        metrics: Mt.metrics.snapshot(),
        cache: await Nt.stats().catch(() => ({ entries: 0, approxBytes: 0 }))
      };
    case "backend:check":
      return Fg(await ii(), await ai(), { hasPermission: zi });
    case "diag:run": {
      await Jc(r.tabId);
      const s = /* @__PURE__ */ new Set([0, ...J.get(r.tabId).frames.map((a) => a.frameId)]), i = await Promise.all(
        [...s].map(async (a) => {
          try {
            return { frameId: a, report: await chrome.tabs.sendMessage(r.tabId, { type: "diag:collect" }, { frameId: a }) };
          } catch (o) {
            return { frameId: a, error: o.message };
          }
        })
      );
      return { collectedAt: (/* @__PURE__ */ new Date()).toISOString(), extensionVersion: chrome.runtime.getManifest().version, frames: i };
    }
    case "usage:get":
      return { usage: await ri.snapshot(), pricing: await al(), defaultPricing: Lt };
    case "usage:reset":
      return await ri.reset(), { ok: !0 };
    case "pricing:set":
      return await ud(r.rows), { ok: !0 };
    case "metrics:get":
      return Mt.metrics.snapshot();
    case "cache:stats":
      return Nt.stats();
    case "cache:clear":
      return await Nt.clear(), { ok: !0 };
    case "audio:start":
      try {
        return await Re.start(r.tabId, r.streamId), zt(r.tabId), { ok: !0 };
      } catch (s) {
        return J.setAudio(r.tabId, { active: !1, error: s.message }), { ok: !1, error: s.message };
      }
    case "audio:stop": {
      const s = r.tabId ?? e;
      return await Re.stop(s), s !== void 0 && zt(s), { ok: !0 };
    }
    case "manual:cues": {
      const s = J.primaryFrame(r.tabId);
      return await Wt(r.tabId, s, { type: "manual:cues", cues: r.cues, label: r.label }), { ok: !0, frameId: s };
    }
    case "session:start": {
      if (e === void 0) return { ok: !1 };
      const s = J.get(e);
      return await Promise.all([0, ...s.frames.map((i) => i.frameId)].map((i) => Wt(e, i, { type: "session:start" }))), { ok: !0 };
    }
    case "offscreen:ready":
      return { ok: !0 };
    case "offscreen:started": {
      const s = Re.active;
      return s && zt(s.tabId), { ok: !0 };
    }
    case "offscreen:chunk":
      return Re.onChunk(r).then(() => {
        const s = Re.active;
        s && zt(s.tabId);
      }), { ok: !0 };
    case "offscreen:error":
      return await Re.onOffscreenError(r.sessionId, r.error), { ok: !0 };
    case "offscreen:stopped":
      return await Re.onOffscreenStopped(r.sessionId, r.reason), { ok: !0 };
  }
  return null;
}
chrome.runtime.onMessage.addListener((r, n, e) => !r || typeof r != "object" || r.target === "offscreen" || n.id !== chrome.runtime.id ? !1 : (Gg(r, n).then(e, (t) => e({ __error: t.message })), !0));
chrome.tabs.onRemoved.addListener((r) => {
  Re.stop(r, "tab-closed"), J.removeTab(r);
});
chrome.tabs.onUpdated.addListener((r, n) => {
  n.url && (el(tl(n.url) ?? new URL("about:blank")) ? Wt(r, 0, { type: "nav:check" }) : (Re.stop(r, "navigated"), J.removeTab(r)));
});
chrome.runtime.onInstalled.addListener((r) => {
  Nt.prune().catch(() => {
  }), r.reason === "install" && chrome.runtime.openOptionsPage();
});
chrome.runtime.onStartup.addListener(() => {
  Nt.prune().catch(() => {
  });
});
function Wu(r) {
  return new Proxy({}, {
    get(n, e) {
      if (typeof e != "symbol")
        throw new R(`\`${r}.${e}\` is not available in this environment; it needs a Node.js-compatible runtime`);
    }
  });
}
const Vg = /* @__PURE__ */ Wu("fs"), Jg = /* @__PURE__ */ Wu("path"), $e = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  fs: Vg,
  path: Jg
}, Symbol.toStringTag, { value: "Module" }));
function W(r) {
  throw new R(`${r} requires Node.js or a Node-compatible runtime`);
}
const Yg = 3e4, Xg = ".anthropic-memory-store";
class Qg extends R {
  constructor(n, e) {
    super(n), this.name = "SessionMemoryError", e !== void 0 && (this.cause = e);
  }
}
class Zg {
  constructor(n, e) {
    W("SessionMemoryStores");
  }
  get roots() {
    return W("SessionMemoryStores");
  }
  get readOnlyRoots() {
    return W("SessionMemoryStores");
  }
  download(n) {
    return W("SessionMemoryStores");
  }
  finish() {
    return W("SessionMemoryStores");
  }
  /** @internal */
  syncAll(n) {
    return W("SessionMemoryStores");
  }
  syncIfDue() {
    return W("SessionMemoryStores");
  }
  flushWrites(n) {
    return W("SessionMemoryStores");
  }
  dispose() {
    return W("SessionMemoryStores");
  }
}
function em(r) {
  return W("setupSkills");
}
function tm(r, n) {
  return W("extractSkillArchive");
}
function nm(r) {
  return W("betaAgentToolset20260401");
}
function rm(r, n) {
  return W("resolvePath");
}
class sm extends R {
  constructor(n) {
    super(`bash command timed out after ${n}ms`), this.name = "BashTimeoutError", this.timeoutMs = n;
  }
}
class im {
  constructor(n, e) {
    W("BashSession");
  }
  get closed() {
    return W("BashSession");
  }
  exec(n, e = {}) {
    return W("BashSession");
  }
  close() {
    W("BashSession");
  }
}
function am(r) {
  return W("betaBashTool");
}
function om(r) {
  return W("betaReadTool");
}
function cm(r) {
  return W("betaWriteTool");
}
function lm(r) {
  return W("betaEditTool");
}
function um(r) {
  return W("betaGlobTool");
}
function dm(r) {
  return W("betaGrepTool");
}
const hm = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  BashSession: im,
  BashTimeoutError: sm,
  DEFAULT_MEMORY_SYNC_INTERVAL_MS: jf,
  MARKER_PATH: Xg,
  MEMORY_FLUSH_TIMEOUT_MS: Yg,
  MIN_MEMORY_SYNC_INTERVAL_MS: ei,
  SessionMemoryError: Qg,
  SessionMemoryStores: Zg,
  betaAgentToolset20260401: nm,
  betaBashTool: am,
  betaEditTool: lm,
  betaGlobTool: um,
  betaGrepTool: dm,
  betaReadTool: om,
  betaWriteTool: cm,
  extractSkillArchive: tm,
  resolvePath: rm,
  setupSkills: em
}, Symbol.toStringTag, { value: "Module" }));
