import{i as p}from"./util-B8mpwbVq.js";const m=["Receiving end does not exist","message port closed","Could not establish connection","The message port closed before a response was received"];function g(e){const t=e instanceof Error?e.message:String(e);return m.some(o=>t.includes(o))}function h(e){try{if(!chrome?.runtime?.id)return!0}catch{return!0}return(e instanceof Error?e.message:String(e??"")).includes("Extension context invalidated")}async function w(e,t={}){const o=t.retries??4,s=t.baseDelayMs??150;let d;for(let i=0;i<=o;i++)try{const n=await chrome.runtime.sendMessage(e);if(n&&typeof n=="object"&&"__error"in n&&n.__error)throw new Error(n.__error);return n}catch(n){if(d=n,h(n)||!g(n)||i===o)throw n;await new Promise(u=>setTimeout(u,s*2**i))}throw d}const f=`# One entry per line. "English => Vietnamese" forces a translation,
# a bare term is kept exactly as written. Lines starting with # are ignored.
Skool
dropshipping
Shopify
Facebook Ads
Google Ads
TikTok Ads
ROAS
CTR
CPC
CPM
CPA
KPI
SEO
API
SaaS
AI
ChatGPT
prompt
landing page => landing page (trang đích)
funnel => phễu bán hàng (funnel)
sales funnel => phễu bán hàng
conversion rate => tỷ lệ chuyển đổi
ad set => nhóm quảng cáo (ad set)
ad account => tài khoản quảng cáo
lead => khách hàng tiềm năng (lead)
retargeting => tiếp thị lại (retargeting)
upsell => bán thêm (upsell)
cross-sell => bán chéo
niche => thị trường ngách
supplier => nhà cung cấp
fulfillment => xử lý đơn hàng (fulfillment)
workflow => quy trình (workflow)
automation => tự động hóa
deploy => triển khai (deploy)
repository => repository (kho mã)
`,c={enabled:!0,modePreference:"auto",displayMode:"vi",fontScale:1,bottomOffsetPct:14,background:!0,backgroundOpacity:.55,outline:!1,shadow:!0,showPanel:!0,provider:{kind:"local",endpoint:"http://localhost:8787",model:"default",temperature:.2},providerProfiles:{},stt:{kind:"local",endpoint:"http://localhost:8787",model:"whisper-1"},consent:{remoteTranslation:!1,remoteAudio:!1},glossary:f,contextWindow:3,translationMode:"balanced",modeModels:{},pretranslateAll:!0,autoStart:!0,autoEnableCaptions:!1,autoEnableCaptionsAsked:!1,autoInitOnNavigation:!0,sourceLanguage:"en",targetLanguage:"vi",mergeFragments:!0,customCaptionSelectors:"",costWarningUsd:0},a="settings",r="secrets";function l(e){const t=e??{};return{...c,...t,provider:{...c.provider,...t.provider??{}},providerProfiles:{...t.providerProfiles??{}},modeModels:{...t.modeModels??{}},stt:{...c.stt,...t.stt??{}},consent:{...c.consent,...t.consent??{}}}}async function v(){const e=await chrome.storage.sync.get(a);return l(e[a])}async function k(e){const t=await v(),o=l({...t,...e});return await chrome.storage.sync.set({[a]:o}),o}function P(e){const t=(o,s)=>{s==="sync"&&o[a]&&e(l(o[a].newValue))};return chrome.storage.onChanged.addListener(t),()=>{try{chrome.storage?.onChanged?.removeListener(t)}catch{}}}async function E(){const[e,t]=await Promise.all([chrome.storage.local.get(r),chrome.storage.session.get(r)]);return{...e[r]??{},...t[r]??{}}}async function T(e,t){const o=t?chrome.storage.session:chrome.storage.local;await(t?chrome.storage.local:chrome.storage.session).remove(r),await o.set({[r]:e})}async function A(){await Promise.all([chrome.storage.local.remove(r),chrome.storage.session.remove(r)])}function C(e){return e.provider.kind!=="mock"&&!p(e.provider.endpoint)}function I(e){return e.stt.kind!=="mock"&&!p(e.stt.endpoint)}const S={gemini:{endpoint:"https://generativelanguage.googleapis.com/v1beta",model:"gemini-3.5-flash-lite",label:"Google Gemini"},openai:{endpoint:"https://api.openai.com/v1",model:"gpt-4o-mini",label:"OpenAI GPT"},anthropic:{endpoint:"https://api.anthropic.com",model:"claude-opus-5-5",label:"Anthropic Claude"},local:{endpoint:"http://localhost:8787",model:"default",label:"Backend cục bộ"},mock:{endpoint:"mock://",model:"mock",label:"Mock (thử nghiệm)"}},R=["gemini","openai","anthropic","local","mock"];function y(e,t){if(e.provider.kind===t)return e.provider;const o=S[t];return e.providerProfiles[t]??{kind:t,endpoint:o.endpoint,model:o.model,temperature:.2}}function _(e){const t=e.modeModels?.[e.translationMode]?.[e.provider.kind]?.trim();return t?{...e.provider,model:t}:e.provider}function M(e,t){const o={...e.providerProfiles,[e.provider.kind]:e.provider};return{...e,providerProfiles:o,provider:{...y({...e,providerProfiles:o},t),kind:t}}}function x(e,t,o){return e.translationApiKeys?.[t]??(t===o?e.translationApiKey:void 0)}export{S as P,k as a,M as b,E as c,R as d,_ as e,x as f,A as g,T as h,I as i,v as l,P as o,y as p,w as s,C as t};
