import{i as l}from"./util-DRO3HpUb.js";const c=`# One entry per line. "English => Vietnamese" forces a translation,
# a bare term is kept exactly as written. Lines starting with # are ignored.
Skool
dropshipping
Shopify
Facebook Ads
Google Ads
TikTok Ads
ROAS
CTR
CPC
CPM
CPA
KPI
SEO
API
SaaS
AI
ChatGPT
prompt
landing page => landing page (trang đích)
funnel => phễu bán hàng (funnel)
sales funnel => phễu bán hàng
conversion rate => tỷ lệ chuyển đổi
ad set => nhóm quảng cáo (ad set)
ad account => tài khoản quảng cáo
lead => khách hàng tiềm năng (lead)
retargeting => tiếp thị lại (retargeting)
upsell => bán thêm (upsell)
cross-sell => bán chéo
niche => thị trường ngách
supplier => nhà cung cấp
fulfillment => xử lý đơn hàng (fulfillment)
workflow => quy trình (workflow)
automation => tự động hóa
deploy => triển khai (deploy)
repository => repository (kho mã)
`,r={enabled:!0,modePreference:"auto",displayMode:"vi",fontScale:1,bottomOffsetPct:14,background:!0,backgroundOpacity:.55,outline:!1,shadow:!0,showPanel:!0,provider:{kind:"local",endpoint:"http://localhost:8787",model:"default",temperature:.2},providerProfiles:{},stt:{kind:"local",endpoint:"http://localhost:8787",model:"whisper-1"},consent:{remoteTranslation:!1,remoteAudio:!1},glossary:c,contextWindow:3,translationMode:"balanced",modeModels:{},pretranslateAll:!0,autoStart:!0,autoEnableCaptions:!1,autoEnableCaptionsAsked:!1,autoInitOnNavigation:!0,autoTranslateTextLessons:!1,autoFullTranscript:!0,dubbing:{enabled:!1,provider:"chrome",voice:"",gender:"female",rate:1,volume:1,originalVolume:.15,listenMode:"vi",lookaheadSec:60,latePolicy:"skip",maxDelaySec:2.5,maxSpeedup:1.35,restoreOnFailure:!0,showSubtitles:!0,googleEndpoint:"https://texttospeech.googleapis.com/v1",geminiModel:"gemini-3.8-flash-lite-tts",geminiVoice:"",geminiStyle:!0},textDisplayMode:"vi",sourceLanguage:"en",targetLanguage:"vi",mergeFragments:!0,customCaptionSelectors:"",costWarningUsd:0},a="settings",n="secrets";function i(e){const o=e??{};return{...r,...o,provider:{...r.provider,...o.provider??{}},providerProfiles:{...o.providerProfiles??{}},modeModels:{...o.modeModels??{}},stt:{...r.stt,...o.stt??{}},consent:{...r.consent,...o.consent??{}},dubbing:{...r.dubbing,...o.dubbing??{}}}}async function d(){const e=await chrome.storage.sync.get(a);return i(e[a])}async function m(e){const o=await d(),t=i({...o,...e});return await chrome.storage.sync.set({[a]:t}),t}function h(e){const o=(t,s)=>{s==="sync"&&t[a]&&e(i(t[a].newValue))};return chrome.storage.onChanged.addListener(o),()=>{try{chrome.storage?.onChanged?.removeListener(o)}catch{}}}async function f(){const[e,o]=await Promise.all([chrome.storage.local.get(n),chrome.storage.session.get(n)]);return{...e[n]??{},...o[n]??{}}}async function v(e,o){const t=o?chrome.storage.session:chrome.storage.local;await(o?chrome.storage.local:chrome.storage.session).remove(n),await t.set({[n]:e})}async function b(){await Promise.all([chrome.storage.local.remove(n),chrome.storage.session.remove(n)])}function S(e){return e.provider.kind!=="mock"&&!l(e.provider.endpoint)}function k(e){return e.stt.kind!=="mock"&&!l(e.stt.endpoint)}const p={gemini:{endpoint:"https://generativelanguage.googleapis.com/v1beta",model:"gemini-3.5-flash-lite",label:"Google Gemini"},openai:{endpoint:"https://api.openai.com/v1",model:"gpt-4o-mini",label:"OpenAI GPT"},anthropic:{endpoint:"https://api.anthropic.com",model:"claude-opus-5-5",label:"Anthropic Claude"},local:{endpoint:"http://localhost:8787",model:"default",label:"Backend cục bộ"},mock:{endpoint:"mock://",model:"mock",label:"Mock (thử nghiệm)"}},y=["gemini","openai","anthropic","local","mock"];function u(e,o){if(e.provider.kind===o)return e.provider;const t=p[o];return e.providerProfiles[o]??{kind:o,endpoint:t.endpoint,model:t.model,temperature:.2}}function P(e){const o=e.modeModels?.[e.translationMode]?.[e.provider.kind]?.trim();return o?{...e.provider,model:o}:e.provider}function w(e,o){const t={...e.providerProfiles,[e.provider.kind]:e.provider};return{...e,providerProfiles:t,provider:{...u({...e,providerProfiles:t},o),kind:o}}}function A(e,o,t){return e.translationApiKeys?.[o]??(o===t?e.translationApiKey:void 0)}export{p as P,w as a,f as b,y as c,A as d,P as e,b as f,v as g,k as h,d as l,h as o,u as p,m as s,S as t};
