class n extends AudioWorkletProcessor {
  buf = new Float32Array(4096);
  n = 0;
  process(o) {
    const s = o[0];
    if (!s || !s.length) return !0;
    const r = s[0], e = s[1];
    for (let t = 0; t < r.length; t++)
      this.buf[this.n++] = e ? (r[t] + e[t]) * 0.5 : r[t], this.n === this.buf.length && (this.port.postMessage(this.buf, [this.buf.buffer]), this.buf = new Float32Array(4096), this.n = 0);
    return !0;
  }
}
registerProcessor("sst-capture", n);
