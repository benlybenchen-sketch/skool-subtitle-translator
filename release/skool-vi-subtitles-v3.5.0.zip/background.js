const Xr = (s, n) => new Promise((e, t) => {
  if (n?.aborted) return t(ht());
  const r = setTimeout(() => {
    n?.removeEventListener("abort", i), e();
  }, s), i = () => {
    clearTimeout(r), t(ht());
  };
  n?.addEventListener("abort", i, { once: !0 });
});
function ht(s = "Aborted") {
  const n = new Error(s);
  return n.name = "AbortError", n;
}
const ud = (s) => s instanceof Error && (s.name === "AbortError" || s.name === "TimeoutError");
function wi(s) {
  try {
    const n = new URL(s);
    return ["localhost", "127.0.0.1", "[::1]", "::1"].includes(n.hostname);
  } catch {
    return !1;
  }
}
function dd(s) {
  try {
    const n = new URL(s);
    return n.protocol !== "https:" && n.protocol !== "http:" ? null : `${n.protocol}//${n.hostname}/*`;
  } catch {
    return null;
  }
}
function hd(s) {
  const n = atob(s), e = new Uint8Array(n.length);
  for (let t = 0; t < n.length; t++) e[t] = n.charCodeAt(t);
  return e;
}
function Qr(s, n) {
  if (!s.length) return 0;
  const e = [...s].sort((r, i) => r - i), t = Math.min(e.length - 1, Math.ceil(n / 100 * e.length) - 1);
  return e[Math.max(0, t)];
}
const pd = `# One entry per line. "English => Vietnamese" forces a translation,
# a bare term is kept exactly as written. Lines starting with # are ignored.
Skool
dropshipping
Shopify
Facebook Ads
Google Ads
TikTok Ads
ROAS
CTR
CPC
CPM
CPA
KPI
SEO
API
SaaS
AI
ChatGPT
prompt
landing page => landing page (trang đích)
funnel => phễu bán hàng (funnel)
sales funnel => phễu bán hàng
conversion rate => tỷ lệ chuyển đổi
ad set => nhóm quảng cáo (ad set)
ad account => tài khoản quảng cáo
lead => khách hàng tiềm năng (lead)
retargeting => tiếp thị lại (retargeting)
upsell => bán thêm (upsell)
cross-sell => bán chéo
niche => thị trường ngách
supplier => nhà cung cấp
fulfillment => xử lý đơn hàng (fulfillment)
workflow => quy trình (workflow)
automation => tự động hóa
deploy => triển khai (deploy)
repository => repository (kho mã)
`, Bn = {
  enabled: !0,
  modePreference: "auto",
  displayMode: "vi",
  fontScale: 1,
  bottomOffsetPct: 14,
  background: !0,
  backgroundOpacity: 0.55,
  outline: !1,
  shadow: !0,
  showPanel: !0,
  provider: {
    kind: "local",
    endpoint: "http://localhost:8787",
    model: "default",
    temperature: 0.2
  },
  providerProfiles: {},
  stt: {
    kind: "local",
    endpoint: "http://localhost:8787",
    model: "whisper-1"
  },
  consent: { remoteTranslation: !1, remoteAudio: !1 },
  glossary: pd,
  contextWindow: 3,
  translationMode: "balanced",
  modeModels: {},
  pretranslateAll: !0,
  autoStart: !0,
  autoEnableCaptions: !1,
  autoEnableCaptionsAsked: !1,
  autoInitOnNavigation: !0,
  autoTranslateTextLessons: !1,
  textDisplayMode: "vi",
  sourceLanguage: "en",
  targetLanguage: "vi",
  mergeFragments: !0,
  customCaptionSelectors: "",
  costWarningUsd: 0
}, Ki = "settings", Un = "secrets";
function _d(s) {
  const n = s ?? {};
  return {
    ...Bn,
    ...n,
    provider: { ...Bn.provider, ...n.provider ?? {} },
    providerProfiles: { ...n.providerProfiles ?? {} },
    modeModels: { ...n.modeModels ?? {} },
    stt: { ...Bn.stt, ...n.stt ?? {} },
    consent: { ...Bn.consent, ...n.consent ?? {} }
  };
}
async function Zs() {
  const s = await chrome.storage.sync.get(Ki);
  return _d(s[Ki]);
}
async function vi() {
  const [s, n] = await Promise.all([
    chrome.storage.local.get(Un),
    chrome.storage.session.get(Un)
  ]);
  return { ...s[Un] ?? {}, ...n[Un] ?? {} };
}
function gl(s) {
  return s.provider.kind !== "mock" && !wi(s.provider.endpoint);
}
function ml(s) {
  return s.stt.kind !== "mock" && !wi(s.stt.endpoint);
}
function ur(s) {
  const n = s.modeModels?.[s.translationMode]?.[s.provider.kind]?.trim();
  return n ? { ...s.provider, model: n } : s.provider;
}
function yl(s, n, e) {
  return s.translationApiKeys?.[n] ?? (n === e ? s.translationApiKey : void 0);
}
const Gi = (s) => s.hostname.toLowerCase(), fd = (s, ...n) => n.some((e) => Gi(s) === e || Gi(s).endsWith("." + e)), gd = ["skool.com"], bl = (s) => fd(s, ...gd);
function wl(s, n) {
  if (!s) return null;
  try {
    return new URL(s, n);
  } catch {
    return null;
  }
}
const ie = "translations";
function dr(s) {
  return new Promise((n, e) => {
    s.onsuccess = () => n(s.result), s.onerror = () => e(s.error);
  });
}
function Yt(s) {
  return new Promise((n, e) => {
    s.oncomplete = () => n(), s.onerror = () => e(s.error), s.onabort = () => e(s.error);
  });
}
class md {
  dbp = null;
  o;
  constructor(n = {}) {
    this.o = {
      dbName: n.dbName ?? "sst-cache",
      maxAgeMs: n.maxAgeMs ?? 1080 * 3600 * 1e3,
      maxEntries: n.maxEntries ?? 6e4,
      now: n.now ?? Date.now,
      indexedDB: n.indexedDB
    };
  }
  db() {
    if (!this.dbp) {
      const n = this.o.indexedDB ?? indexedDB;
      this.dbp = new Promise((e, t) => {
        const r = n.open(this.o.dbName, 1);
        r.onupgradeneeded = () => {
          const a = r.result.createObjectStore(ie, { keyPath: "key" });
          a.createIndex("videoKey", "videoKey"), a.createIndex("lastUsedAt", "lastUsedAt");
        }, r.onsuccess = () => e(r.result), r.onerror = () => t(r.error);
      }), this.dbp.catch(() => this.dbp = null);
    }
    return this.dbp;
  }
  async getMany(n) {
    const e = /* @__PURE__ */ new Map();
    if (!n.length) return e;
    const r = (await this.db()).transaction(ie, "readwrite"), i = r.objectStore(ie), a = this.o.now();
    return await Promise.all(
      n.map(async (o) => {
        const l = await dr(i.get(o));
        if (l) {
          if (a - l.lastUsedAt > this.o.maxAgeMs) {
            i.delete(o);
            return;
          }
          e.set(o, l.vi), a - l.lastUsedAt > 36e5 && i.put({ ...l, lastUsedAt: a });
        }
      })
    ), await Yt(r), e;
  }
  async putMany(n) {
    if (!n.length) return;
    const t = (await this.db()).transaction(ie, "readwrite"), r = t.objectStore(ie), i = this.o.now();
    for (const a of n)
      r.put({ ...a, createdAt: i, lastUsedAt: i, size: a.key.length + a.vi.length * 2 });
    await Yt(t);
  }
  async stats() {
    const t = (await this.db()).transaction(ie, "readonly").objectStore(ie), r = await dr(t.count());
    let i = 0;
    return await new Promise((a, o) => {
      const l = t.openCursor();
      l.onsuccess = () => {
        const d = l.result;
        if (!d) return a();
        i += d.value.size ?? 0, d.continue();
      }, l.onerror = () => o(l.error);
    }), { entries: r, approxBytes: i };
  }
  async clear() {
    const e = (await this.db()).transaction(ie, "readwrite");
    e.objectStore(ie).clear(), await Yt(e);
  }
  /** Invalidate all cached translations of one video. */
  async deleteVideo(n) {
    const t = (await this.db()).transaction(ie, "readwrite"), r = t.objectStore(ie).index("videoKey");
    let i = 0;
    return await new Promise((a, o) => {
      const l = r.openCursor(IDBKeyRange.only(n));
      l.onsuccess = () => {
        const d = l.result;
        if (!d) return a();
        d.delete(), i++, d.continue();
      }, l.onerror = () => o(l.error);
    }), await Yt(t), i;
  }
  /** Remove expired entries and enforce the LRU cap. */
  async prune() {
    const e = (await this.db()).transaction(ie, "readwrite"), t = e.objectStore(ie), r = await dr(t.count()), i = this.o.now() - this.o.maxAgeMs;
    let a = Math.max(0, r - this.o.maxEntries), o = 0;
    return await new Promise((l, d) => {
      const p = t.index("lastUsedAt").openCursor();
      p.onsuccess = () => {
        const h = p.result;
        if (!h) return l();
        h.value.lastUsedAt < i || a > 0 ? (h.delete(), o++, a > 0 && a--, h.continue()) : l();
      }, p.onerror = () => d(p.error);
    }), await Yt(e), o;
  }
}
function mt(s, n = 0) {
  let e = 3735928559 ^ n, t = 1103547991 ^ n;
  for (let r = 0; r < s.length; r++) {
    const i = s.charCodeAt(r);
    e = Math.imul(e ^ i, 2654435761), t = Math.imul(t ^ i, 1597334677);
  }
  return e = Math.imul(e ^ e >>> 16, 2246822507) ^ Math.imul(t ^ t >>> 13, 3266489909), t = Math.imul(t ^ t >>> 16, 2246822507) ^ Math.imul(e ^ e >>> 13, 3266489909), (4294967296 * (2097151 & t) + (e >>> 0)).toString(36);
}
class de extends Error {
  constructor(n, e, t) {
    super(e), this.status = n, this.retryAfterMs = t, this.name = "HttpError";
  }
  get retryable() {
    return this.status === 408 || this.status === 409 || this.status === 425 || this.status === 429 || this.status >= 500;
  }
}
class re extends Error {
  constructor(n) {
    super(n), this.name = "ConfigError";
  }
}
class xe extends Error {
  constructor(n) {
    super(n), this.name = "ParseError";
  }
}
function Zr(s) {
  if (!s) return;
  const n = Number(s);
  if (Number.isFinite(n)) return Math.max(0, n * 1e3);
  const e = Date.parse(s);
  return Number.isFinite(e) ? Math.max(0, e - Date.now()) : void 0;
}
async function Qe(s, n) {
  if (s.ok) return s;
  let e = "";
  try {
    e = await s.text();
  } catch {
  }
  const t = e.slice(0, 300), r = e.match(/"retryDelay"\s*:\s*"(\d+(?:\.\d+)?)s"/), i = Zr(s.headers.get("retry-after")) ?? (r ? Math.round(Number(r[1]) * 1e3) : void 0), a = s.status === 401 || s.status === 403 ? " (check the API key / permissions)" : s.status === 429 ? " (rate limited)" : "";
  throw new de(s.status, `${n} HTTP ${s.status}${a}${t ? ": " + t : ""}`, i);
}
function vl(s) {
  const n = [], e = /* @__PURE__ */ new Set();
  for (const t of s.split(/\r?\n/)) {
    const r = t.trim();
    if (!r || r.startsWith("#")) continue;
    const [i, a] = r.split(/\s*(?:=>|→)\s*/, 2), o = i.trim().toLowerCase();
    !o || e.has(o) || (e.add(o), n.push({ term: i.trim(), translation: a?.trim() || void 0 }));
  }
  return n;
}
function yd(s) {
  return mt(vl(s).map((n) => `${n.term}=${n.translation ?? ""}`).join(`
`));
}
const bd = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
function wd(s, n) {
  const e = n.join(`
`);
  return s.filter((t) => new RegExp(`(^|[^\\p{L}\\p{N}])${bd(t.term)}(?=$|[^\\p{L}\\p{N}])`, "iu").test(e));
}
const vd = {
  concurrency: 2,
  maxBatchItems: 24,
  maxBatchChars: 2600,
  minBatchChars: 200,
  maxRetries: 4,
  baseDelayMs: 800,
  maxDelayMs: 2e4,
  timeoutMs: 45e3,
  sleep: Xr,
  random: Math.random,
  now: () => Date.now()
};
class kd {
  opts;
  inflight = /* @__PURE__ */ new Map();
  groups = /* @__PURE__ */ new Map();
  active = 0;
  waiters = [];
  waiterSeq = 0;
  /** After an HTTP 429, NO request is sent until this time (shared by all batches/tabs). */
  cooldownUntil = 0;
  get rateLimitedForMs() {
    return Math.max(0, this.cooldownUntil - this.opts.now());
  }
  budget;
  constructor(n = {}) {
    this.opts = { ...vd, ...n }, this.budget = this.opts.maxBatchChars;
  }
  get batchBudget() {
    return this.budget;
  }
  get inflightCount() {
    return this.inflight.size;
  }
  cancelGroup(n) {
    this.groups.get(n)?.abort(), this.groups.delete(n);
  }
  groupSignal(n) {
    let e = this.groups.get(n);
    return (!e || e.signal.aborted) && (e = new AbortController(), this.groups.set(n, e)), e.signal;
  }
  async translate(n, e) {
    const t = this.groupSignal(e.group), r = /* @__PURE__ */ new Map(), i = [];
    for (const o of n) {
      if (r.has(o.key)) continue;
      const l = this.inflight.get(o.key);
      l ? r.set(o.key, l) : (i.push(o), r.set(o.key, null));
    }
    for (const o of this.makeBatches(i)) {
      const l = /* @__PURE__ */ new Map();
      for (const d of o) {
        const p = new Promise((h, m) => l.set(d.key, { resolve: h, reject: m }));
        p.catch(() => {
        }), this.inflight.set(d.key, p), r.set(d.key, p), p.finally(() => {
          this.inflight.get(d.key) === p && this.inflight.delete(d.key);
        }).catch(() => {
        });
      }
      this.runBatch(o, e, t, 0).then((d) => {
        for (const p of o) {
          const h = l.get(p.key), m = d.get(p.key);
          m?.vi !== void 0 ? h.resolve(m.vi) : h.reject(m?.error ?? new Error("Translation missing"));
        }
      }).catch((d) => {
        for (const p of l.values()) p.reject(d);
      });
    }
    const a = /* @__PURE__ */ new Map();
    return await Promise.all(
      [...r.entries()].map(async ([o, l]) => {
        try {
          a.set(o, { vi: await l });
        } catch (d) {
          a.set(o, { error: d });
        }
      })
    ), a;
  }
  makeBatches(n) {
    const e = [];
    let t = [], r = 0;
    for (const i of n)
      t.length && (t.length >= this.opts.maxBatchItems || r + i.text.length > this.budget) && (e.push(t), t = [], r = 0), t.push(i), r += i.text.length;
    return t.length && e.push(t), e;
  }
  /**
   * Run one non-translation request (AI Study Notes) through the same slots, cooldown and
   * accounting as subtitle batches. Use a large priority number so subtitles always win
   * free slots. Retries transient failures (429 honours the shared cooldown).
   */
  async runTask(n, e) {
    const t = e.maxRetries ?? 3;
    for (let r = 0; ; r++) {
      if (e.signal.aborted) throw ht();
      await this.acquire(e.signal, e.priority);
      const i = new AbortController(), a = setTimeout(() => i.abort(), e.timeoutMs ?? 12e4), o = Vi([e.signal, i.signal]);
      let l = !1, d, p, h = !1;
      try {
        this.opts.onEvent?.({ type: "request", size: 0 }, e.meta), p = await n(o, (y) => {
          l = !0, this.opts.onEvent?.({ type: "usage", usage: y }, e.meta);
        }), h = !0;
      } catch (y) {
        d = i.signal.aborted && !e.signal.aborted ? Object.assign(new Error("Request timed out"), { name: "TimeoutError" }) : y;
      } finally {
        clearTimeout(a), this.release();
      }
      if (h)
        return !l && e.estimate && this.opts.onEvent?.({ type: "usage", usage: e.estimate(p) }, e.meta), p;
      if (e.signal.aborted) throw ht();
      const m = d;
      if (!(m instanceof de && m.retryable || m instanceof xe || m.name === "TimeoutError" || m instanceof TypeError) || m instanceof re || r >= t)
        throw this.opts.onEvent?.({ type: "failure", size: 0, reason: m.message }, e.meta), m;
      let b = Math.min(this.opts.maxDelayMs, this.opts.baseDelayMs * 2 ** r) * (0.75 + this.opts.random() * 0.5);
      m instanceof de && m.status === 429 && (m.retryAfterMs !== void 0 && (b = Math.min(this.opts.maxDelayMs * 3, m.retryAfterMs)), this.cooldownUntil = Math.max(this.cooldownUntil, this.opts.now() + b), this.opts.onEvent?.({ type: "rate-limited", delayMs: b }, e.meta)), this.opts.onEvent?.({ type: "retry", attempt: r + 1, delayMs: Math.round(b), reason: m.message }, e.meta), m instanceof de && m.status === 429 || await this.opts.sleep(Math.round(b), e.signal);
    }
  }
  async acquire(n, e) {
    const t = this.rateLimitedForMs;
    for (t > 0 && await this.opts.sleep(t, n); this.active >= this.opts.concurrency; )
      if (await new Promise((r) => this.waiters.push({ priority: e, seq: this.waiterSeq++, wake: r })), n.aborted) throw ht();
    this.active++;
  }
  /** Wake the most urgent waiter (lowest priority number, then FIFO). */
  release() {
    if (this.active--, !this.waiters.length) return;
    let n = 0;
    for (let e = 1; e < this.waiters.length; e++) {
      const t = this.waiters[e], r = this.waiters[n];
      (t.priority < r.priority || t.priority === r.priority && t.seq < r.seq) && (n = e);
    }
    this.waiters.splice(n, 1)[0].wake();
  }
  async runBatch(n, e, t, r) {
    if (t.aborted) throw ht();
    await this.acquire(t, e.priority ?? 2);
    const i = Date.now(), a = new AbortController(), o = setTimeout(() => a.abort(), this.opts.timeoutMs), l = Vi([t, a.signal]), d = n.map((y, k) => ({ id: "s" + k, text: y.text }));
    let p, h, m = !1;
    try {
      this.opts.onEvent?.({ type: "request", size: n.length }, e.meta), h = await e.provider.translateBatch({
        segments: d,
        context: e.context,
        glossary: wd(e.glossary, n.map((y) => y.text)),
        sourceLang: e.sourceLang ?? "en",
        targetLang: e.targetLang ?? "vi",
        signal: l,
        format: e.format,
        onUsage: (y) => {
          m = !0, this.opts.onEvent?.({ type: "usage", usage: y }, e.meta);
        }
      });
    } catch (y) {
      p = a.signal.aborted && !t.aborted ? Object.assign(new Error("Translation request timed out"), { name: "TimeoutError" }) : y;
    } finally {
      clearTimeout(o), this.release();
    }
    if (h) {
      if (!m) {
        const E = 1600 + n.reduce((T, v) => T + v.text.length, 0) + e.context.join(" ").length, A = Object.values(h).reduce((T, v) => T + v.length, 0);
        this.opts.onEvent?.({ type: "usage", usage: { inputTokens: Math.ceil(E / 4), outputTokens: Math.ceil(A / 3), estimated: !0 } }, e.meta);
      }
      const y = /* @__PURE__ */ new Map(), k = [];
      if (n.forEach((E, A) => {
        const T = h[d[A].id];
        typeof T == "string" && T.trim() ? y.set(E.key, { vi: T.trim() }) : k.push(E);
      }), this.opts.onEvent?.({ type: "success", size: n.length - k.length, latencyMs: Date.now() - i }, e.meta), !k.length)
        return this.budget = Math.min(this.opts.maxBatchChars, Math.round(this.budget * 1.25)), y;
      if (r < this.opts.maxRetries) {
        const E = await this.retryLater(k, e, t, r, new xe("Model omitted segments"));
        for (const [A, T] of E) y.set(A, T);
      } else for (const E of k) y.set(E.key, { error: new xe("Model omitted this segment") });
      return y;
    }
    if (t.aborted || ud(p) && p.name === "AbortError") throw ht();
    const _ = p;
    if (!(_ instanceof de && _.retryable || _ instanceof xe || _.name === "TimeoutError" || _ instanceof TypeError) || _ instanceof re || r >= this.opts.maxRetries) {
      this.opts.onEvent?.({ type: "failure", size: n.length, reason: _.message }, e.meta);
      const y = /* @__PURE__ */ new Map();
      for (const k of n) y.set(k.key, { error: _ });
      return y;
    }
    return (_ instanceof xe || _.name === "TimeoutError") && (this.budget = Math.max(this.opts.minBatchChars, Math.round(this.budget / 2))), this.retryLater(n, e, t, r, _);
  }
  async retryLater(n, e, t, r, i) {
    let a = Math.min(this.opts.maxDelayMs, this.opts.baseDelayMs * 2 ** r) * (0.75 + this.opts.random() * 0.5);
    if (i instanceof de && i.status === 429 && (i.retryAfterMs !== void 0 && (a = Math.min(this.opts.maxDelayMs * 3, i.retryAfterMs)), this.cooldownUntil = Math.max(this.cooldownUntil, this.opts.now() + a), this.opts.onEvent?.({ type: "rate-limited", delayMs: a }, e.meta)), a = Math.round(a), this.opts.onEvent?.({ type: "retry", attempt: r + 1, delayMs: a, reason: i.message }, e.meta), i instanceof de && i.status === 429 || await this.opts.sleep(a, t), (i instanceof xe || i.name === "TimeoutError") && n.length > 1) {
      const o = Math.ceil(n.length / 2), [l, d] = await Promise.all([
        this.runBatch(n.slice(0, o), e, t, r + 1),
        this.runBatch(n.slice(o), e, t, r + 1)
      ]);
      return new Map([...l, ...d]);
    }
    return this.runBatch(n, e, t, r + 1);
  }
}
function Vi(s) {
  const n = AbortSignal.any;
  if (n) return n(s);
  const e = new AbortController();
  for (const t of s) {
    if (t.aborted) {
      e.abort();
      break;
    }
    t.addEventListener("abort", () => e.abort(), { once: !0 });
  }
  return e.signal;
}
const Sd = "p4", ki = `You are a professional English→Vietnamese subtitle translator for online courses (marketing, digital advertising, e-commerce, dropshipping, software engineering, business strategy, AI and automation, technical tutorials).

Rules:
- Translate each segment into natural, fluent, spoken Vietnamese that a Vietnamese learner would understand immediately. Avoid stiff word-for-word translation, but never change the instructor's meaning.
- Keep technical terms, product names, brand names, people's names, code, commands, URLs and acronyms (ROAS, CTR, API, SEO…) unchanged unless the glossary says otherwise.
- Preserve all numbers, percentages, currencies, units and dates exactly (e.g. "$1,500" stays "$1,500", "30%" stays "30%").
- Follow the glossary strictly.
- Segments may be incomplete spoken sentences; translate them as natural incomplete Vietnamese, consistent with neighbouring segments. Use the context only for understanding — do NOT translate the context.
- Subtitles must be short and easy to read: keep each translation about as long as the original (or shorter). No explanations, notes or quotation marks.
- Return ONLY JSON: {"translations":[{"subtitle_id":"<id>","translated_text":"<vietnamese>"}]} with exactly one item per input id, same ids, no extra items.`, Td = {
  type: "OBJECT",
  properties: {
    translations: {
      type: "ARRAY",
      items: {
        type: "OBJECT",
        properties: { subtitle_id: { type: "STRING" }, translated_text: { type: "STRING" } },
        required: ["subtitle_id", "translated_text"]
      }
    }
  },
  required: ["translations"]
}, Ad = `These segments are headings, paragraphs and list items of a WRITTEN lesson, not subtitles: translate each one completely and faithfully (the length rule does not apply).
Segments may contain lightweight markup: <b>…</b>, <i>…</i>, <u>…</u>, <s>…</s>, link tags <a1>…</a1>, <a2>…</a2>…, line breaks <br> and placeholders such as ⟦C0⟧ (code) or ⟦I0⟧ (image). Keep every tag and placeholder exactly as written (same names, same count), wrapped around the corresponding Vietnamese words; never translate, add or remove them.`;
function Si(s) {
  const n = [];
  return s.glossary.length && n.push(
    `Glossary:
` + s.glossary.map((e) => e.translation ? `- ${e.term} => ${e.translation}` : `- ${e.term} => (keep as "${e.term}")`).join(`
`)
  ), s.context.length && n.push(`Context (previous lines, do not translate):
` + s.context.map((e) => `> ${e}`).join(`
`)), s.format === "markup" && n.push(Ad), n.push(
    `Segments:
` + JSON.stringify(s.segments.map((e) => ({ subtitle_id: e.id, text: e.text })))
  ), n.join(`

`);
}
function er(s) {
  const n = s.trim().replace(/^```(?:json)?\s*/i, "").replace(/```\s*$/, "");
  try {
    return JSON.parse(n);
  } catch {
    const e = n.indexOf("{"), t = n.lastIndexOf("}");
    if (e >= 0 && t > e)
      try {
        return JSON.parse(n.slice(e, t + 1));
      } catch {
      }
    throw new xe("Model reply is not valid JSON");
  }
}
function tr(s, n) {
  let e = s;
  if (e && typeof e == "object" && !Array.isArray(e)) {
    const i = e;
    e = i.translations ?? i.t ?? i.items ?? i.segments;
  }
  if (!Array.isArray(e)) throw new xe("Model reply has no translation list");
  const t = {}, r = new Set(n);
  return e.forEach((i, a) => {
    if (typeof i == "string") {
      n[a] && (t[n[a]] = i);
      return;
    }
    if (!i || typeof i != "object") return;
    const o = i, l = String(o.subtitle_id ?? o.i ?? o.id ?? n[a] ?? ""), d = o.translated_text ?? o.v ?? o.vi ?? o.text ?? o.translation;
    r.has(l) && !(l in t) && typeof d == "string" && d.trim() && (t[l] = d.trim());
  }), t;
}
const ei = (s) => /^(models\/)?gemini-3/i.test(s);
class xd {
  constructor(n) {
    if (this.o = n, !n.endpoint) throw new re("Gemini endpoint is not configured");
  }
  id = "gemini";
  async translateBatch(n) {
    const e = this.o.fetchImpl ?? fetch, t = this.o.model.replace(/^models\//, ""), r = `${this.o.endpoint.replace(/\/+$/, "")}/models/${encodeURIComponent(t)}:generateContent`, i = { "Content-Type": "application/json" };
    this.o.apiKey && (i["x-goog-api-key"] = this.o.apiKey);
    const a = await e(r, {
      method: "POST",
      headers: i,
      signal: n.signal,
      body: JSON.stringify({
        systemInstruction: { parts: [{ text: ki }] },
        contents: [{ role: "user", parts: [{ text: Si(n) }] }],
        generationConfig: {
          temperature: this.o.temperature,
          responseMimeType: "application/json",
          responseSchema: Td,
          // Speed-first: minimal thinking (default for 3.5 Flash-Lite; sent explicitly).
          ...ei(t) ? { thinkingConfig: { thinkingLevel: "minimal" } } : {}
        }
      })
    });
    await Qe(a, "Gemini");
    const o = await a.json(), l = o.usageMetadata;
    if (l && n.onUsage?.({
      inputTokens: l.promptTokenCount ?? 0,
      outputTokens: (l.candidatesTokenCount ?? 0) + (l.thoughtsTokenCount ?? 0),
      cachedInputTokens: l.cachedContentTokenCount || void 0,
      reasoningTokens: l.thoughtsTokenCount || void 0
    }), o.promptFeedback?.blockReason) throw new re(`Gemini blocked the request: ${o.promptFeedback.blockReason}`);
    const d = o.candidates?.[0]?.content?.parts?.map((p) => p.text ?? "").join("") ?? "";
    return tr(er(d), n.segments.map((p) => p.id));
  }
  /** Structured generation (AI Study Notes): same model, JSON reply, bounded output. */
  async complete(n) {
    const e = this.o.fetchImpl ?? fetch, t = this.o.model.replace(/^models\//, ""), r = `${this.o.endpoint.replace(/\/+$/, "")}/models/${encodeURIComponent(t)}:generateContent`, i = { "Content-Type": "application/json" };
    this.o.apiKey && (i["x-goog-api-key"] = this.o.apiKey);
    const a = await e(r, {
      method: "POST",
      headers: i,
      signal: n.signal,
      body: JSON.stringify({
        systemInstruction: { parts: [{ text: n.system }] },
        contents: [{ role: "user", parts: [{ text: n.user }] }],
        generationConfig: {
          temperature: Math.min(this.o.temperature, 0.4),
          maxOutputTokens: n.maxTokens,
          responseMimeType: "application/json",
          ...ei(t) ? { thinkingConfig: { thinkingLevel: "low" } } : {}
        }
      })
    });
    await Qe(a, "Gemini");
    const o = await a.json(), l = o.usageMetadata;
    if (l && n.onUsage?.({
      inputTokens: l.promptTokenCount ?? 0,
      outputTokens: (l.candidatesTokenCount ?? 0) + (l.thoughtsTokenCount ?? 0),
      cachedInputTokens: l.cachedContentTokenCount || void 0,
      reasoningTokens: l.thoughtsTokenCount || void 0
    }), o.promptFeedback?.blockReason) throw new re(`Gemini blocked the request: ${o.promptFeedback.blockReason}`);
    return o.candidates?.[0]?.content?.parts?.map((d) => d.text ?? "").join("") ?? "";
  }
}
const Wt = [
  { match: "gemini-3.5-flash-lite", input: 0.3, output: 2.5, cachedInput: 0.03, note: "public pricing pages (web search), Nov 2026" },
  { match: "gpt-4o-mini", input: 0.15, output: 0.6, cachedInput: 0.075, note: "OpenAI list price (training data) — verify" },
  { match: "claude-opus-5-5", input: 4, output: 20, cachedInput: 0.2, cacheWrite: 5, note: "Claude API reference cached 2026-10-06; cache write = 1.25× input" },
  { match: "claude-sonnet-5-5", input: 2, output: 10, cachedInput: 0.2, cacheWrite: 2.5, note: "Claude API reference cached 2026-10-06; cache write = 1.25× input" },
  { match: "claude-haiku-5-5", input: 0.1, output: 0.5, cachedInput: 0.01, cacheWrite: 0.125, note: "Claude API reference cached 2026-10-06 (≤100K-token prompts)" }
];
function Ed(s, n = Wt) {
  const e = s.replace(/^models\//, "").toLowerCase();
  let t = null;
  for (const r of n) r.match && e.startsWith(r.match.toLowerCase()) && (!t || r.match.length > t.match.length) && (t = r);
  return t;
}
function kl(s, n, e = Wt) {
  if (s === "mock") return 0;
  const t = Ed(s, e);
  if (!t) return null;
  const r = n.cachedInputTokens ?? 0, i = n.cacheWriteTokens ?? 0;
  return (Math.max(0, n.inputTokens - r - i) * t.input + r * (t.cachedInput ?? t.input) + i * (t.cacheWrite ?? t.input) + n.outputTokens * t.output) / 1e6;
}
function Rd(s, n, e, t = Wt) {
  return kl(s, { inputTokens: n, outputTokens: e }, t);
}
const Fs = "pricingTable";
async function Sl() {
  try {
    const n = (await chrome.storage.local.get(Fs))[Fs];
    return Array.isArray(n) && n.length ? n : Wt;
  } catch {
    return Wt;
  }
}
async function Pd(s) {
  s ? await chrome.storage.local.set({ [Fs]: s.filter((n) => n.match.trim()) }) : await chrome.storage.local.remove(Fs);
}
class zd {
  constructor(n) {
    if (this.o = n, !n.endpoint) throw new re("Local backend endpoint is not configured");
  }
  id = "local";
  async translateBatch(n) {
    const e = this.o.fetchImpl ?? fetch, t = { "Content-Type": "application/json" };
    this.o.apiKey && (t.Authorization = `Bearer ${this.o.apiKey}`);
    const r = await e(this.o.endpoint.replace(/\/+$/, "") + "/translate", {
      method: "POST",
      headers: t,
      signal: n.signal,
      body: JSON.stringify({
        source: n.sourceLang,
        target: n.targetLang,
        model: this.o.model,
        segments: n.segments,
        context: n.context,
        glossary: n.glossary,
        ...n.format === "markup" ? { format: "markup" } : {}
      })
    });
    await Qe(r, "Local backend");
    const i = await r.json();
    return i.usage && (i.usage.inputTokens || i.usage.outputTokens) && n.onUsage?.({ ...i.usage }), tr(i, n.segments.map((a) => a.id));
  }
  /** POST {endpoint}/complete { system, user, schema, maxTokens, model } → { text, usage? } */
  async complete(n) {
    const e = this.o.fetchImpl ?? fetch, t = { "Content-Type": "application/json" };
    this.o.apiKey && (t.Authorization = `Bearer ${this.o.apiKey}`);
    const r = await e(this.o.endpoint.replace(/\/+$/, "") + "/complete", {
      method: "POST",
      headers: t,
      signal: n.signal,
      body: JSON.stringify({ system: n.system, user: n.user, schema: n.schema, maxTokens: n.maxTokens, model: this.o.model })
    });
    await Qe(r, "Local backend");
    const i = await r.json();
    return i.usage && (i.usage.inputTokens || i.usage.outputTokens) && n.onUsage?.({ ...i.usage }), i.text ?? "";
  }
}
const Ji = "<<PARTIAL_NOTES_JSON>>";
class Md {
  constructor(n = 0) {
    this.latencyMs = n;
  }
  id = "mock";
  calls = 0;
  completeCalls = 0;
  async translateBatch(n) {
    this.calls++, this.latencyMs && await Xr(this.latencyMs, n.signal);
    const e = {};
    for (const t of n.segments) e[t.id] = `[VI] ${t.text}`;
    return e;
  }
  /** Deterministic "study notes" built only from the lines it was given (refs = their labels). */
  async complete(n) {
    this.completeCalls++, this.latencyMs && await Xr(this.latencyMs, n.signal);
    const t = { title: /^Lesson title: (.*)$/m.exec(n.user)?.[1] ?? "", summary: "", objectives: [], concepts: [], insights: [], steps: [], terminology: [], takeaways: [], checklist: [], moments: [] }, r = n.user.indexOf(Ji);
    if (r >= 0) {
      const a = JSON.parse(n.user.slice(r + Ji.length)), o = { ...t };
      for (const l of Object.keys(t))
        if (l !== "title")
          if (l === "summary") o.summary = a.map((d) => d.summary).filter(Boolean).join(" ");
          else {
            const d = /* @__PURE__ */ new Set();
            o[l] = a.flatMap((p) => p[l] ?? []).filter((p) => {
              const h = JSON.stringify(typeof p == "object" && p ? p.text ?? p.term : p);
              return d.has(h) ? !1 : (d.add(h), !0);
            });
          }
      return JSON.stringify(o);
    }
    const i = [...n.user.matchAll(/^\[([SP]\d+)(?: [\d:]+)?\] (.*)$/gm)].map((a) => ({ label: a[1], text: a[2] }));
    return n.onUsage?.({ inputTokens: Math.ceil(n.user.length / 4), outputTokens: 200, estimated: !0 }), JSON.stringify({
      ...t,
      summary: i.length ? `[VI] ${i.slice(0, 2).map((a) => a.text).join(" ")}` : "",
      objectives: i.length ? [`[VI] Hiểu: ${i[0].text}`] : [],
      takeaways: i.slice(0, 5).map((a) => ({ text: `[VI] ${a.text}`, refs: [a.label] })),
      moments: i.filter((a, o) => o % 5 === 0).map((a) => ({ text: `[VI] ${a.text}`, refs: [a.label] }))
    });
  }
}
class Od {
  constructor(n) {
    if (this.o = n, !n.endpoint) throw new re("OpenAI-compatible endpoint is not configured");
  }
  id = "openai";
  async translateBatch(n) {
    const e = this.o.fetchImpl ?? fetch, t = this.o.endpoint.replace(/\/+$/, "") + "/chat/completions", r = { "Content-Type": "application/json" };
    this.o.apiKey && (r.Authorization = `Bearer ${this.o.apiKey}`);
    const i = await e(t, {
      method: "POST",
      headers: r,
      signal: n.signal,
      body: JSON.stringify({
        model: this.o.model,
        temperature: this.o.temperature,
        response_format: { type: "json_object" },
        messages: [
          { role: "system", content: ki },
          { role: "user", content: Si(n) }
        ]
      })
    });
    await Qe(i, "OpenAI-compatible");
    const a = await i.json(), o = a.usage;
    o && n.onUsage?.({
      inputTokens: o.prompt_tokens ?? 0,
      outputTokens: o.completion_tokens ?? 0,
      cachedInputTokens: o.prompt_tokens_details?.cached_tokens || void 0,
      reasoningTokens: o.completion_tokens_details?.reasoning_tokens || void 0
    });
    const l = a.choices?.[0]?.message?.content ?? "";
    return tr(er(l), n.segments.map((d) => d.id));
  }
  /** Structured generation (AI Study Notes): same model, JSON object reply, bounded output. */
  async complete(n) {
    const e = this.o.fetchImpl ?? fetch, t = { "Content-Type": "application/json" };
    this.o.apiKey && (t.Authorization = `Bearer ${this.o.apiKey}`);
    const r = await e(this.o.endpoint.replace(/\/+$/, "") + "/chat/completions", {
      method: "POST",
      headers: t,
      signal: n.signal,
      body: JSON.stringify({
        model: this.o.model,
        temperature: Math.min(this.o.temperature, 0.4),
        max_tokens: n.maxTokens,
        response_format: { type: "json_object" },
        messages: [
          { role: "system", content: n.system },
          { role: "user", content: n.user }
        ]
      })
    });
    await Qe(r, "OpenAI-compatible");
    const i = await r.json();
    if (i.usage) {
      const a = {
        inputTokens: i.usage.prompt_tokens ?? 0,
        outputTokens: i.usage.completion_tokens ?? 0,
        cachedInputTokens: i.usage.prompt_tokens_details?.cached_tokens || void 0
      };
      n.onUsage?.(a);
    }
    return i.choices?.[0]?.message?.content ?? "";
  }
}
function w(s, n, e, t, r) {
  if (typeof n == "function" ? s !== n || !0 : !n.has(s))
    throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return n.set(s, e), e;
}
function c(s, n, e, t) {
  if (e === "a" && !t)
    throw new TypeError("Private accessor was defined without a getter");
  if (typeof n == "function" ? s !== n || !t : !n.has(s))
    throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return e === "m" ? t : e === "a" ? t.call(s) : t ? t.value : n.get(s);
}
function yt(s) {
  return typeof s == "object" && s !== null && // Spec-compliant fetch implementations
  ("name" in s && s.name === "AbortError" || // Expo fetch
  "message" in s && String(s.message).includes("FetchRequestCanceledException"));
}
const Ws = (s) => {
  if (s instanceof Error)
    return s;
  if (typeof s == "object" && s !== null) {
    try {
      const n = Object.prototype.toString.call(s);
      if (n === "[object Error]" || n === "[object DOMException]") {
        const e = new Error(s.message, s.cause ? { cause: s.cause } : {});
        return s.stack && (e.stack = s.stack), s.cause && !e.cause && (e.cause = s.cause), s.name && (e.name = s.name), e;
      }
    } catch {
    }
    try {
      return new Error(JSON.stringify(s));
    } catch {
    }
  }
  return new Error(s);
};
var R = /* @__PURE__ */ (() => {
  class s extends Error {
  }
  return s;
})();
class W extends R {
  constructor(n, e, t, r, i) {
    super(`${W.makeMessage(n, e, t)}`), this.status = n, this.headers = r, this.requestID = r?.get("request-id"), this.workspaceID = r?.get("anthropic-workspace-id"), this.error = e, this.type = i ?? null;
  }
  static makeMessage(n, e, t) {
    const r = e?.message ? typeof e.message == "string" ? e.message : JSON.stringify(e.message) : e ? JSON.stringify(e) : t;
    return n && r ? `${n} ${r}` : n ? `${n} status code (no body)` : r || "(no status code or body)";
  }
  static generate(n, e, t, r) {
    if (!n || !r)
      return new Ht({ message: t, cause: Ws(e) });
    const i = e, a = i?.error?.type;
    return n === 400 ? new Tl(n, i, t, r, a) : n === 401 ? new Al(n, i, t, r, a) : n === 403 ? new xl(n, i, t, r, a) : n === 404 ? new El(n, i, t, r, a) : n === 409 ? new Rl(n, i, t, r, a) : n === 422 ? new Pl(n, i, t, r, a) : n === 429 ? new zl(n, i, t, r, a) : n >= 500 ? new Ml(n, i, t, r, a) : new W(n, i, t, r, a);
  }
}
class he extends W {
  constructor({ message: n } = {}) {
    super(void 0, void 0, n || "Request was aborted.", void 0);
  }
}
class Ht extends W {
  constructor({ message: n, cause: e }) {
    super(void 0, void 0, n || "Connection error.", void 0), e && (this.cause = e);
  }
}
class ti extends Ht {
  constructor({ message: n } = {}) {
    super({ message: n ?? "Request timed out." });
  }
}
class Cd extends R {
  constructor(n, { cause: e } = {}) {
    super(n ?? "Retryable error."), e !== void 0 && (this.cause = e);
  }
}
class Tl extends W {
}
class Al extends W {
}
class xl extends W {
}
class El extends W {
}
class Rl extends W {
}
class Pl extends W {
}
class zl extends W {
}
class Ml extends W {
}
const Id = /^[a-z][a-z0-9+.-]*:/i, $d = (s) => Id.test(s);
let se = (s) => (se = Array.isArray, se(s)), Yi = se;
function Mn(s) {
  return typeof s != "object" ? {} : s ?? {};
}
function Xi(s) {
  if (!s)
    return !0;
  for (const n in s)
    return !1;
  return !0;
}
function Nd(s, n) {
  return Object.prototype.hasOwnProperty.call(s, n);
}
function Qi(s) {
  return s != null && typeof s == "object" && !Array.isArray(s);
}
const hr = (s, n) => {
  if (typeof n != "number" || !Number.isInteger(n))
    throw new R(`${s} must be an integer`);
  if (n < 0)
    throw new R(`${s} must be a positive integer`);
  return n;
}, Ol = (s) => {
  try {
    return JSON.parse(s);
  } catch {
    return;
  }
};
const _t = (s, n) => new Promise((e) => {
  if (n?.aborted)
    return e();
  const t = () => {
    clearTimeout(r), e();
  }, r = setTimeout(() => {
    n?.removeEventListener("abort", t), e();
  }, s);
  n?.addEventListener("abort", t, { once: !0 });
}), Ie = "0.137.0", Ld = () => (
  // @ts-ignore
  typeof window < "u" && // @ts-ignore
  typeof window.document < "u" && // @ts-ignore
  typeof navigator < "u"
);
function qd() {
  return typeof Deno < "u" && Deno.build != null ? "deno" : typeof EdgeRuntime < "u" ? "edge" : Object.prototype.toString.call(typeof globalThis.process < "u" ? globalThis.process : 0) === "[object process]" ? "node" : "unknown";
}
const Bd = () => {
  const s = qd();
  if (s === "deno")
    return {
      "X-Stainless-Lang": "js",
      "X-Stainless-Package-Version": Ie,
      "X-Stainless-OS": ea(Deno.build.os),
      "X-Stainless-Arch": Zi(Deno.build.arch),
      "X-Stainless-Runtime": "deno",
      "X-Stainless-Runtime-Version": typeof Deno.version == "string" ? Deno.version : Deno.version?.deno ?? "unknown"
    };
  if (typeof EdgeRuntime < "u")
    return {
      "X-Stainless-Lang": "js",
      "X-Stainless-Package-Version": Ie,
      "X-Stainless-OS": "Unknown",
      "X-Stainless-Arch": `other:${EdgeRuntime}`,
      "X-Stainless-Runtime": "edge",
      "X-Stainless-Runtime-Version": globalThis.process?.version ?? "unknown"
    };
  if (s === "node")
    return {
      "X-Stainless-Lang": "js",
      "X-Stainless-Package-Version": Ie,
      "X-Stainless-OS": ea(globalThis.process.platform ?? "unknown"),
      "X-Stainless-Arch": Zi(globalThis.process.arch ?? "unknown"),
      "X-Stainless-Runtime": "node",
      "X-Stainless-Runtime-Version": globalThis.process.version ?? "unknown"
    };
  const n = Ud();
  return n ? {
    "X-Stainless-Lang": "js",
    "X-Stainless-Package-Version": Ie,
    "X-Stainless-OS": "Unknown",
    "X-Stainless-Arch": "unknown",
    "X-Stainless-Runtime": `browser:${n.browser}`,
    "X-Stainless-Runtime-Version": n.version
  } : {
    "X-Stainless-Lang": "js",
    "X-Stainless-Package-Version": Ie,
    "X-Stainless-OS": "Unknown",
    "X-Stainless-Arch": "unknown",
    "X-Stainless-Runtime": "unknown",
    "X-Stainless-Runtime-Version": "unknown"
  };
};
function Ud() {
  if (typeof navigator > "u" || !navigator)
    return null;
  const s = [
    { key: "edge", pattern: /Edge(?:\W+(\d+)\.(\d+)(?:\.(\d+))?)?/ },
    { key: "ie", pattern: /MSIE(?:\W+(\d+)\.(\d+)(?:\.(\d+))?)?/ },
    { key: "ie", pattern: /Trident(?:.*rv\:(\d+)\.(\d+)(?:\.(\d+))?)?/ },
    { key: "chrome", pattern: /Chrome(?:\W+(\d+)\.(\d+)(?:\.(\d+))?)?/ },
    { key: "firefox", pattern: /Firefox(?:\W+(\d+)\.(\d+)(?:\.(\d+))?)?/ },
    { key: "safari", pattern: /(?:Version\W+(\d+)\.(\d+)(?:\.(\d+))?)?(?:\W+Mobile\S*)?\W+Safari/ }
  ];
  for (const { key: n, pattern: e } of s) {
    const t = e.exec(navigator.userAgent);
    if (t) {
      const r = t[1] || 0, i = t[2] || 0, a = t[3] || 0;
      return { browser: n, version: `${r}.${i}.${a}` };
    }
  }
  return null;
}
const Zi = (s) => s === "x32" ? "x32" : s === "x86_64" || s === "x64" ? "x64" : s === "arm" ? "arm" : s === "aarch64" || s === "arm64" ? "arm64" : s ? `other:${s}` : "unknown", ea = (s) => (s = s.toLowerCase(), s.includes("ios") ? "iOS" : s === "android" ? "Android" : s === "darwin" ? "MacOS" : s === "win32" ? "Windows" : s === "freebsd" ? "FreeBSD" : s === "openbsd" ? "OpenBSD" : s === "linux" ? "Linux" : s ? `Other:${s}` : "Unknown");
let ta;
const Ti = () => ta ?? (ta = Bd()), Hs = /* @__PURE__ */ new WeakMap(), Cl = typeof globalThis.FinalizationRegistry == "function" ? new globalThis.FinalizationRegistry((s) => ft(s)) : null;
function jd(s, n) {
  return () => s.removeEventListener("abort", n);
}
function Fd(s, n, e) {
  Hs.set(s, jd(n, e));
}
function Wd(s, n) {
  Hs.has(n) && Cl?.register(s, n, n);
}
function ft(s) {
  const n = Hs.get(s);
  n && (Hs.delete(s), Cl?.unregister(s), n());
}
function Hd() {
  if (typeof fetch < "u")
    return fetch;
  throw new Error("`fetch` is not defined as a global; Either pass `fetch` to the client, `new Anthropic({ fetch })` or polyfill the global, `globalThis.fetch = fetch`");
}
function Il(...s) {
  const n = globalThis.ReadableStream;
  if (typeof n > "u")
    throw new Error("`ReadableStream` is not defined as a global; You will need to polyfill it, `globalThis.ReadableStream = ReadableStream`");
  return new n(...s);
}
function $l(s) {
  let n = Symbol.asyncIterator in s ? s[Symbol.asyncIterator]() : s[Symbol.iterator]();
  return Il({
    start() {
    },
    async pull(e) {
      const { done: t, value: r } = await n.next();
      t ? e.close() : e.enqueue(r);
    },
    async cancel() {
      await n.return?.();
    }
  });
}
function Dd(s) {
  if (s[Symbol.asyncIterator])
    return s[Symbol.asyncIterator]();
  const n = s.getReader();
  return {
    async next() {
      try {
        const e = await n.read();
        return e?.done && n.releaseLock(), e;
      } catch (e) {
        throw n.releaseLock(), e;
      }
    },
    async return() {
      const e = n.cancel();
      return n.releaseLock(), await e, { done: !0, value: void 0 };
    }
  };
}
const na = typeof FinalizationRegistry > "u" ? void 0 : /* @__PURE__ */ new FinalizationRegistry(async (s) => {
  try {
    await s.return?.();
  } catch {
  }
});
async function* Ai(s) {
  const n = Dd(s), e = {};
  na?.register(e, n, e);
  try {
    for await (const t of { [Symbol.asyncIterator]: () => n })
      yield t;
  } finally {
    na?.unregister(e);
  }
}
async function Kd(s) {
  if (s === null || typeof s != "object")
    return;
  if (s[Symbol.asyncIterator]) {
    await s[Symbol.asyncIterator]().return?.();
    return;
  }
  const n = s.getReader(), e = n.cancel();
  n.releaseLock(), await e;
}
const Gd = ({ headers: s, body: n }) => ({
  bodyHeaders: {
    "content-type": "application/json"
  },
  body: JSON.stringify(n)
}), Dt = "1.10.0", sa = /^(\d+)\.(\d+)\.(\d+)(-(.+))?$/;
function Vd(s) {
  const n = /* @__PURE__ */ new Set([s]), e = /* @__PURE__ */ new Set(), t = s.match(sa);
  if (!t) return () => !1;
  const r = {
    major: +t[1],
    minor: +t[2],
    patch: +t[3],
    prerelease: t[4]
  };
  if (r.prerelease != null) return function(l) {
    return l === s;
  };
  function i(o) {
    return e.add(o), !1;
  }
  function a(o) {
    return n.add(o), !0;
  }
  return function(l) {
    if (n.has(l)) return !0;
    if (e.has(l)) return !1;
    const d = l.match(sa);
    if (!d) return i(l);
    const p = {
      major: +d[1],
      minor: +d[2],
      patch: +d[3],
      prerelease: d[4]
    };
    return p.prerelease != null || r.major !== p.major ? i(l) : r.major === 0 ? r.minor === p.minor && r.patch <= p.patch ? a(l) : i(l) : r.minor <= p.minor ? a(l) : i(l);
  };
}
const Jd = Vd(Dt), Yd = Dt.split(".")[0], Ds = Symbol.for(`opentelemetry.js.api.${Yd}`), Ks = typeof globalThis == "object" ? globalThis : typeof self == "object" ? self : typeof window == "object" ? window : typeof global == "object" ? global : {};
function Xd() {
  return Object.defineProperty({}, "version", {
    value: Dt,
    enumerable: !0,
    writable: !1,
    configurable: !1
  });
}
function Vt(s, n, e, t = !1) {
  var r;
  const i = Ks[Ds] = (r = Ks[Ds]) !== null && r !== void 0 ? r : Xd();
  if (!t && i[s]) {
    const a = /* @__PURE__ */ new Error(`@opentelemetry/api: Attempted duplicate registration of API: ${s}`);
    return e.error(a.stack || a.message), !1;
  }
  if (i.version !== "1.10.0") {
    const a = /* @__PURE__ */ new Error(`@opentelemetry/api: Registration of version v${i.version} for ${s} does not match previously registered API v${Dt}`);
    return e.error(a.stack || a.message), !1;
  }
  return i[s] = n, e.debug(`@opentelemetry/api: Registered a global for ${s} v${Dt}.`), !0;
}
let ra;
function Ze(s) {
  const n = Ks[Ds];
  if (n != null) {
    if (n !== ra) {
      if (!n.version || !Jd(n.version)) return;
      ra = n;
    }
    return n[s];
  }
}
function Jt(s, n) {
  n.debug(`@opentelemetry/api: Unregistering a global for ${s} v${Dt}.`);
  const e = Ks[Ds];
  e && delete e[s];
}
var Qd = class {
  constructor(s) {
    this._namespace = s.namespace || "DiagComponentLogger";
  }
  debug(...s) {
    return Xt("debug", this._namespace, s);
  }
  error(...s) {
    return Xt("error", this._namespace, s);
  }
  info(...s) {
    return Xt("info", this._namespace, s);
  }
  warn(...s) {
    return Xt("warn", this._namespace, s);
  }
  verbose(...s) {
    return Xt("verbose", this._namespace, s);
  }
};
function Xt(s, n, e) {
  const t = Ze("diag");
  if (t)
    return t[s](n, ...e);
}
function Zd(s, n) {
  s < 0 ? s = 0 : s > 9999 && (s = 9999), n = n || {};
  function e(t, r) {
    const i = n[t];
    return typeof i == "function" && s >= r ? i.bind(n) : function() {
    };
  }
  return {
    error: e("error", 30),
    warn: e("warn", 50),
    info: e("info", 60),
    debug: e("debug", 70),
    verbose: e("verbose", 80)
  };
}
const eh = "diag";
var pe = class Nl {
  /** Get the singleton instance of the DiagAPI API */
  static instance() {
    return this._instance || (this._instance = new Nl()), this._instance;
  }
  /**
  * Private internal constructor
  * @private
  */
  constructor() {
    function n(r) {
      return function(...i) {
        const a = Ze("diag");
        if (a)
          return a[r](...i);
      };
    }
    const e = this, t = (r, i = { logLevel: 60 }) => {
      var a;
      if (r === e) {
        var o;
        const h = /* @__PURE__ */ new Error("Cannot use diag as the logger for itself. Please use a DiagLogger implementation like ConsoleDiagLogger or a custom implementation");
        return e.error((o = h.stack) !== null && o !== void 0 ? o : h.message), !1;
      }
      typeof i == "number" && (i = { logLevel: i });
      const l = Ze("diag"), d = Zd((a = i.logLevel) !== null && a !== void 0 ? a : 60, r);
      if (l && !i.suppressOverrideMessage) {
        var p;
        const h = (p = (/* @__PURE__ */ new Error()).stack) !== null && p !== void 0 ? p : "<failed to generate stacktrace>";
        l.warn(`Current logger will be overwritten from ${h}`), d.warn(`Current logger will overwrite one already registered from ${h}`);
      }
      return Vt("diag", d, e, !0);
    };
    e.setLogger = t, e.disable = () => {
      Jt(eh, e);
    }, e.createComponentLogger = (r) => new Qd(r), e.verbose = n("verbose"), e.debug = n("debug"), e.info = n("info"), e.warn = n("warn"), e.error = n("error");
  }
}, th = class Rn {
  constructor(n) {
    this._entries = n ? new Map(n) : /* @__PURE__ */ new Map();
  }
  getEntry(n) {
    const e = this._entries.get(n);
    if (e)
      return Object.assign({}, e);
  }
  getAllEntries() {
    return Array.from(this._entries.entries());
  }
  setEntry(n, e) {
    const t = new Rn(this._entries);
    return t._entries.set(n, e), t;
  }
  removeEntry(n) {
    const e = new Rn(this._entries);
    return e._entries.delete(n), e;
  }
  removeEntries(...n) {
    const e = new Rn(this._entries);
    for (const t of n) e._entries.delete(t);
    return e;
  }
  clear() {
    return new Rn();
  }
};
pe.instance();
function nh(s = {}) {
  return new th(new Map(Object.entries(s)));
}
function Ll(s) {
  return Symbol.for(s);
}
const sh = new class ni {
  /**
  * Construct a new context which inherits values from an optional parent context.
  *
  * @param parentContext a context from which to inherit values
  */
  constructor(n) {
    const e = this;
    e._currentContext = n ? new Map(n) : /* @__PURE__ */ new Map(), e.getValue = (t) => e._currentContext.get(t), e.setValue = (t, r) => {
      const i = new ni(e._currentContext);
      return i._currentContext.set(t, r), i;
    }, e.deleteValue = (t) => {
      const r = new ni(e._currentContext);
      return r._currentContext.delete(t), r;
    };
  }
}();
var rh = class {
  constructor() {
  }
  /**
  * @see {@link Meter.createGauge}
  */
  createGauge(s, n) {
    return _h;
  }
  /**
  * @see {@link Meter.createHistogram}
  */
  createHistogram(s, n) {
    return fh;
  }
  /**
  * @see {@link Meter.createCounter}
  */
  createCounter(s, n) {
    return ph;
  }
  /**
  * @see {@link Meter.createUpDownCounter}
  */
  createUpDownCounter(s, n) {
    return gh;
  }
  /**
  * @see {@link Meter.createObservableGauge}
  */
  createObservableGauge(s, n) {
    return yh;
  }
  /**
  * @see {@link Meter.createObservableCounter}
  */
  createObservableCounter(s, n) {
    return mh;
  }
  /**
  * @see {@link Meter.createObservableUpDownCounter}
  */
  createObservableUpDownCounter(s, n) {
    return bh;
  }
  /**
  * @see {@link Meter.addBatchObservableCallback}
  */
  addBatchObservableCallback(s, n) {
  }
  /**
  * @see {@link Meter.removeBatchObservableCallback}
  */
  removeBatchObservableCallback(s) {
  }
}, nr = class {
}, ih = class extends nr {
  add(s, n) {
  }
}, ah = class extends nr {
  add(s, n) {
  }
}, oh = class extends nr {
  record(s, n) {
  }
}, ch = class extends nr {
  record(s, n) {
  }
}, xi = class {
  addCallback(s) {
  }
  removeCallback(s) {
  }
}, lh = class extends xi {
}, uh = class extends xi {
}, dh = class extends xi {
};
const hh = new rh(), ph = new ih(), _h = new oh(), fh = new ch(), gh = new ah(), mh = new lh(), yh = new uh(), bh = new dh();
var ql = class {
  emit(s) {
  }
  enabled() {
    return !1;
  }
};
const wh = new ql(), vh = {
  get(s, n) {
    if (s != null)
      return s[n];
  },
  keys(s) {
    return s == null ? [] : Object.keys(s);
  }
}, kh = { set(s, n, e) {
  s != null && (s[n] = e);
} }, Sh = "0000000000000000", Th = "00000000000000000000000000000000", Ah = {
  traceId: Th,
  spanId: Sh,
  traceFlags: 0
};
var Pn = class {
  constructor(s = Ah) {
    this._spanContext = s;
  }
  spanContext() {
    return this._spanContext;
  }
  setAttribute(s, n) {
    return this;
  }
  setAttributes(s) {
    return this;
  }
  addEvent(s, n) {
    return this;
  }
  addLink(s) {
    return this;
  }
  addLinks(s) {
    return this;
  }
  setStatus(s) {
    return this;
  }
  updateName(s) {
    return this;
  }
  end(s) {
  }
  isRecording() {
    return !1;
  }
  recordException(s, n) {
  }
};
const jn = new Uint8Array([
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  1,
  1,
  1,
  1,
  1,
  1,
  1,
  1,
  1,
  1,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  1,
  1,
  1,
  1,
  1,
  1,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  1,
  1,
  1,
  1,
  1,
  1
]);
function Bl(s, n) {
  if (typeof s != "string" || s.length !== n) return !1;
  let e = 0;
  for (let t = 0; t < s.length; t += 4) e += (jn[s.charCodeAt(t)] | 0) + (jn[s.charCodeAt(t + 1)] | 0) + (jn[s.charCodeAt(t + 2)] | 0) + (jn[s.charCodeAt(t + 3)] | 0);
  return e === n;
}
function xh(s) {
  return Bl(s, 32) && s !== "00000000000000000000000000000000";
}
function Eh(s) {
  return Bl(s, 16) && s !== "0000000000000000";
}
function Ul(s) {
  return xh(s.traceId) && Eh(s.spanId);
}
function Rh(s) {
  return new Pn(s);
}
var Ph = class {
  active() {
    return sh;
  }
  with(s, n, e, ...t) {
    return n.call(e, ...t);
  }
  bind(s, n) {
    return n;
  }
  enable() {
    return this;
  }
  disable() {
    return this;
  }
  /** @experimental This API is experimental and may change in minor releases without prior notice. */
  attach(s) {
    return { dispose() {
    } };
  }
};
const pr = "context", zh = new Ph(), Mh = Object.freeze({ dispose: () => {
} });
var sr = class jl {
  /** Empty private constructor prevents end users from constructing a new instance of the API */
  constructor() {
    this._attachUnsupportedWarned = !1;
  }
  /** Get the singleton instance of the Context API */
  static getInstance() {
    return this._instance || (this._instance = new jl()), this._instance;
  }
  /**
  * Set the current context manager.
  *
  * @returns true if the context manager was successfully registered, else false
  */
  setGlobalContextManager(n) {
    return Vt(pr, n, pe.instance());
  }
  /**
  * Get the currently active context
  */
  active() {
    return this._getContextManager().active();
  }
  /**
  * Execute a function with an active context
  *
  * @param context context to be active during function execution
  * @param fn function to execute in a context
  * @param thisArg optional receiver to be used for calling fn
  * @param args optional arguments forwarded to fn
  */
  with(n, e, t, ...r) {
    return this._getContextManager().with(n, e, t, ...r);
  }
  /**
  * Bind a context to a target function or event emitter
  *
  * @param context context to bind to the event emitter or function. Defaults to the currently active context
  * @param target function or event emitter to bind
  */
  bind(n, e) {
    return this._getContextManager().bind(n, e);
  }
  /**
  * Imperatively sets `context` as active, returning a {@link ContextManagementToken} whose
  * {@link ContextManagementToken.dispose} restores the previous context.
  *
  * This is a delicate, low-level API - prefer {@link with}/{@link bind}, which
  * restore context automatically. Use `attach` only to bridge callback
  * boundaries that `with` cannot wrap. Call `token.dispose()` when the
  * operation is done.
  *
  * **Caveat for async functions:** If called inside an async function before
  * the first `await`, the context change may leak into the caller's context
  * and remain active there. Prefer {@link with} for async code.
  *
  * Support is best-effort and varies by the active ContextManager (see
  * {@link ContextManager.attach}); if it does not implement `attach`, this logs
  * a warning and returns a no-op token.
  *
  * @param context The Context to attach
  * @returns A {@link ContextManagementToken} whose dispose() restores the previous Context
  * @since 1.10.0
  * @experimental This API is experimental and may change in minor releases without prior notice.
  */
  attach(n) {
    const e = this._getContextManager();
    return e.attach ? e.attach(n) : (this._attachUnsupportedWarned || (this._attachUnsupportedWarned = !0, pe.instance().warn("The current ContextManager does not implement attach(). The context will not be attached. Use a ContextManager that supports attach() (e.g. AsyncLocalStorageContextManager) or use with()/bind() instead.")), Mh);
  }
  _getContextManager() {
    return Ze(pr) || zh;
  }
  /** Disable and remove the global context manager */
  disable() {
    this._getContextManager().disable(), Jt(pr, pe.instance());
  }
};
const Ei = Ll("OpenTelemetry Context Key SPAN");
function Ri(s) {
  return s.getValue(Ei) || void 0;
}
function Oh() {
  return Ri(sr.getInstance().active());
}
function Pi(s, n) {
  return s.setValue(Ei, n);
}
function Ch(s) {
  return s.deleteValue(Ei);
}
function Ih(s, n) {
  return Pi(s, new Pn(n));
}
function Fl(s) {
  var n;
  return (n = Ri(s)) === null || n === void 0 ? void 0 : n.spanContext();
}
const _r = sr.getInstance();
var Wl = class {
  startSpan(s, n, e = _r.active()) {
    if (n?.root) return new Pn();
    const t = e && Fl(e);
    return $h(t) && Ul(t) ? new Pn(t) : new Pn();
  }
  startActiveSpan(s, n, e, t) {
    var r;
    let i, a, o;
    if (arguments.length < 2) return;
    arguments.length === 2 ? o = n : arguments.length === 3 ? (i = n, o = e) : (i = n, a = e, o = t);
    const l = (r = a) !== null && r !== void 0 ? r : _r.active(), d = this.startSpan(s, i, l), p = Pi(l, d);
    return _r.with(p, o, void 0, d);
  }
};
function $h(s) {
  return s !== null && typeof s == "object" && "spanId" in s && typeof s.spanId == "string" && "traceId" in s && typeof s.traceId == "string" && "traceFlags" in s && typeof s.traceFlags == "number";
}
const Nh = new Wl();
var Lh = class {
  constructor(s, n, e, t) {
    this._provider = s, this.name = n, this.version = e, this.options = t;
  }
  startSpan(s, n, e) {
    return this._getTracer().startSpan(s, n, e);
  }
  startActiveSpan(s, n, e, t) {
    const r = this._getTracer();
    return Reflect.apply(r.startActiveSpan, r, arguments);
  }
  /**
  * Try to get a tracer from the proxy tracer provider.
  * If the proxy tracer provider has no delegate, return a noop tracer.
  */
  _getTracer() {
    if (this._delegate) return this._delegate;
    const s = this._provider.getDelegateTracer(this.name, this.version, this.options);
    return s ? (this._delegate = s, this._delegate) : Nh;
  }
};
let rr = /* @__PURE__ */ (function(s) {
  return s[s.INTERNAL = 0] = "INTERNAL", s[s.SERVER = 1] = "SERVER", s[s.CLIENT = 2] = "CLIENT", s[s.PRODUCER = 3] = "PRODUCER", s[s.CONSUMER = 4] = "CONSUMER", s;
})({}), bt = /* @__PURE__ */ (function(s) {
  return s[s.UNSET = 0] = "UNSET", s[s.OK = 1] = "OK", s[s.ERROR = 2] = "ERROR", s;
})({});
var qh = class {
  getTracer(s, n, e) {
    return new Wl();
  }
};
const Bh = new qh();
var ia = class {
  /**
  * Get a {@link ProxyTracer}
  */
  getTracer(s, n, e) {
    var t;
    return (t = this.getDelegateTracer(s, n, e)) !== null && t !== void 0 ? t : new Lh(this, s, n, e);
  }
  getDelegate() {
    var s;
    return (s = this._delegate) !== null && s !== void 0 ? s : Bh;
  }
  /**
  * Set the delegate tracer provider
  */
  setDelegate(s) {
    this._delegate = s;
  }
  getDelegateTracer(s, n, e) {
    var t;
    return (t = this._delegate) === null || t === void 0 ? void 0 : t.getTracer(s, n, e);
  }
};
const _e = sr.getInstance();
pe.instance();
var Uh = class {
  getLogger(s, n, e) {
    return new ql();
  }
};
const jh = new Uh();
var Fh = class {
  constructor(s, n, e, t) {
    this._provider = s, this.name = n, this.version = e, this.options = t;
  }
  /**
  * Emit a log record. This method should only be used by log appenders.
  *
  * @param logRecord
  */
  emit(s) {
    this._getLogger().emit(s);
  }
  enabled(s) {
    return this._getLogger().enabled(s);
  }
  /**
  * Try to get a logger from the proxy logger provider.
  * If the proxy logger provider has no delegate, return a noop logger.
  */
  _getLogger() {
    if (this._delegate) return this._delegate;
    const s = this._provider._getDelegateLogger(this.name, this.version, this.options);
    return s ? (this._delegate = s, this._delegate) : wh;
  }
}, aa = class {
  getLogger(s, n, e) {
    var t;
    return (t = this._getDelegateLogger(s, n, e)) !== null && t !== void 0 ? t : new Fh(this, s, n, e);
  }
  /**
  * Get the delegate logger provider.
  * Used by tests only.
  * @internal
  */
  _getDelegate() {
    var s;
    return (s = this._delegate) !== null && s !== void 0 ? s : jh;
  }
  /**
  * Set the delegate logger provider
  * @internal
  */
  _setDelegate(s) {
    this._delegate = s;
  }
  /**
  * @internal
  */
  _getDelegateLogger(s, n, e) {
    var t;
    return (t = this._delegate) === null || t === void 0 ? void 0 : t.getLogger(s, n, e);
  }
};
const fr = "logs";
var Wh = class Hl {
  /** Empty private constructor prevents end users from constructing a new instance of the API */
  constructor() {
    this._proxyLoggerProvider = new aa();
  }
  /** Get the singleton instance of the Logs API */
  static getInstance() {
    return this._instance || (this._instance = new Hl()), this._instance;
  }
  setGlobalLoggerProvider(n) {
    const e = Vt(fr, n, pe.instance());
    return e && this._proxyLoggerProvider._setDelegate(n), e;
  }
  /**
  * Returns the global logger provider.
  *
  * @returns LoggerProvider
  */
  getLoggerProvider() {
    return Ze(fr) || this._proxyLoggerProvider;
  }
  /**
  * Returns a Logger, creating one if one with the given name, version,
  * schemaUrl, and attributes is not already created.
  *
  * Getting a Logger may be expensive, especially when `attributes` are
  * provided. Reuse Logger instances where possible instead of calling
  * `getLogger()` on hot paths.
  *
  * @param name The name of the logger or instrumentation library.
  * @param version The version of the logger or instrumentation library.
  * @param options The options of the logger or instrumentation library.
  * @returns {@link Logger}
  */
  getLogger(n, e, t) {
    return this.getLoggerProvider().getLogger(n, e, t);
  }
  /** Remove the global logger provider */
  disable() {
    Jt(fr, pe.instance()), this._proxyLoggerProvider = new aa();
  }
};
Wh.getInstance();
var Hh = class {
  getMeter(s, n, e) {
    return hh;
  }
};
const Dh = new Hh(), gr = "metrics";
var Kh = class Dl {
  /** Empty private constructor prevents end users from constructing a new instance of the API */
  constructor() {
  }
  /** Get the singleton instance of the Metrics API */
  static getInstance() {
    return this._instance || (this._instance = new Dl()), this._instance;
  }
  /**
  * Set the current global meter provider.
  * Returns true if the meter provider was successfully registered, else false.
  */
  setGlobalMeterProvider(n) {
    return Vt(gr, n, pe.instance());
  }
  /**
  * Returns the global meter provider.
  */
  getMeterProvider() {
    return Ze(gr) || Dh;
  }
  /**
  * Returns a meter from the global meter provider.
  */
  getMeter(n, e, t) {
    return this.getMeterProvider().getMeter(n, e, t);
  }
  /** Remove the global meter provider */
  disable() {
    Jt(gr, pe.instance());
  }
};
Kh.getInstance();
var Gh = class {
  /** Noop inject function does nothing */
  inject(s, n) {
  }
  /** Noop extract function does nothing and returns the input context */
  extract(s, n) {
    return s;
  }
  fields() {
    return [];
  }
};
const zi = Ll("OpenTelemetry Baggage Key");
function Kl(s) {
  return s.getValue(zi) || void 0;
}
function Vh() {
  return Kl(sr.getInstance().active());
}
function Jh(s, n) {
  return s.setValue(zi, n);
}
function Yh(s) {
  return s.deleteValue(zi);
}
const mr = "propagation", Xh = new Gh();
var Qh = class Gl {
  /** Empty private constructor prevents end users from constructing a new instance of the API */
  constructor() {
    this.createBaggage = nh, this.getBaggage = Kl, this.getActiveBaggage = Vh, this.setBaggage = Jh, this.deleteBaggage = Yh;
  }
  /** Get the singleton instance of the Propagator API */
  static getInstance() {
    return this._instance || (this._instance = new Gl()), this._instance;
  }
  /**
  * Set the current propagator.
  *
  * @returns true if the propagator was successfully registered, else false
  */
  setGlobalPropagator(n) {
    return Vt(mr, n, pe.instance());
  }
  /**
  * Inject context into a carrier to be propagated inter-process
  *
  * @param context Context carrying tracing data to inject
  * @param carrier carrier to inject context into
  * @param setter Function used to set values on the carrier
  */
  inject(n, e, t = kh) {
    return this._getGlobalPropagator().inject(n, e, t);
  }
  /**
  * Extract context from a carrier
  *
  * @param context Context which the newly created context will inherit from
  * @param carrier Carrier to extract context from
  * @param getter Function used to extract keys from a carrier
  */
  extract(n, e, t = vh) {
    return this._getGlobalPropagator().extract(n, e, t);
  }
  /**
  * Return a list of all fields which may be used by the propagator.
  */
  fields() {
    return this._getGlobalPropagator().fields();
  }
  /** Remove the global propagator */
  disable() {
    Jt(mr, pe.instance());
  }
  _getGlobalPropagator() {
    return Ze(mr) || Xh;
  }
};
const Vl = Qh.getInstance(), yr = "trace";
var Zh = class Jl {
  /** Empty private constructor prevents end users from constructing a new instance of the API */
  constructor() {
    this._proxyTracerProvider = new ia(), this.wrapSpanContext = Rh, this.isSpanContextValid = Ul, this.deleteSpan = Ch, this.getSpan = Ri, this.getActiveSpan = Oh, this.getSpanContext = Fl, this.setSpan = Pi, this.setSpanContext = Ih;
  }
  /** Get the singleton instance of the Trace API */
  static getInstance() {
    return this._instance || (this._instance = new Jl()), this._instance;
  }
  /**
  * Set the current global tracer.
  *
  * @returns true if the tracer provider was successfully registered, else false
  */
  setGlobalTracerProvider(n) {
    const e = Vt(yr, this._proxyTracerProvider, pe.instance());
    return e && this._proxyTracerProvider.setDelegate(n), e;
  }
  /**
  * Returns the global tracer provider.
  */
  getTracerProvider() {
    return Ze(yr) || this._proxyTracerProvider;
  }
  /**
  * Returns a tracer from the global tracer provider.
  */
  getTracer(n, e) {
    return this.getTracerProvider().getTracer(n, e);
  }
  /** Remove the global tracer provider */
  disable() {
    Jt(yr, pe.instance()), this._proxyTracerProvider = new ia();
  }
};
const wt = Zh.getInstance();
function ep(s) {
  let n = 0;
  for (const r of s)
    n += r.length;
  const e = new Uint8Array(n);
  let t = 0;
  for (const r of s)
    e.set(r, t), t += r.length;
  return e;
}
let oa;
function Yl(s) {
  let n;
  return (oa ?? (n = new globalThis.TextEncoder(), oa = n.encode.bind(n)))(s);
}
let ca;
function si(s) {
  let n;
  return (ca ?? (n = new globalThis.TextDecoder(), ca = n.decode.bind(n)))(s);
}
var ae, oe, Mi = /* @__PURE__ */ (() => {
  class s {
    constructor() {
      ae.set(this, void 0), oe.set(this, void 0), w(this, ae, new Uint8Array()), w(this, oe, null);
    }
    decode(e) {
      if (e == null)
        return [];
      const t = e instanceof ArrayBuffer ? new Uint8Array(e) : typeof e == "string" ? Yl(e) : e;
      w(this, ae, ep([c(this, ae, "f"), t]));
      const r = [];
      let i;
      for (; (i = tp(c(this, ae, "f"), c(this, oe, "f"))) != null; ) {
        if (i.carriage && c(this, oe, "f") == null) {
          w(this, oe, i.index);
          continue;
        }
        if (c(this, oe, "f") != null && (i.index !== c(this, oe, "f") + 1 || i.carriage)) {
          r.push(si(c(this, ae, "f").subarray(0, c(this, oe, "f") - 1))), w(this, ae, c(this, ae, "f").subarray(c(this, oe, "f"))), w(this, oe, null);
          continue;
        }
        const a = c(this, oe, "f") !== null ? i.preceding - 1 : i.preceding, o = si(c(this, ae, "f").subarray(0, a));
        r.push(o), w(this, ae, c(this, ae, "f").subarray(i.index)), w(this, oe, null);
      }
      return r;
    }
    flush() {
      return c(this, ae, "f").length ? this.decode(`
`) : [];
    }
  }
  return ae = /* @__PURE__ */ new WeakMap(), oe = /* @__PURE__ */ new WeakMap(), s.NEWLINE_CHARS = /* @__PURE__ */ new Set([`
`, "\r"]), s.NEWLINE_REGEXP = /\r\n|[\n\r]/g, s;
})();
function tp(s, n) {
  for (let r = n ?? 0; r < s.length; r++) {
    if (s[r] === 10)
      return { preceding: r, index: r + 1, carriage: !1 };
    if (s[r] === 13)
      return { preceding: r, index: r + 1, carriage: !0 };
  }
  return null;
}
const O = (s) => {
  if (typeof globalThis.process < "u")
    return globalThis.process.env?.[s]?.trim() || void 0;
  if (typeof globalThis.Deno < "u")
    return globalThis.Deno.env?.get?.(s)?.trim() || void 0;
}, Gs = "warn", Vs = {
  off: 0,
  error: 200,
  warn: 300,
  info: 400,
  debug: 500
}, ri = (s, n, e) => {
  if (s) {
    if (Nd(Vs, s))
      return s;
    e.warn(`${n} was set to ${JSON.stringify(s)}, expected one of ${JSON.stringify(Object.keys(Vs))}`);
  }
};
function qt() {
}
function Fn(s, n, e) {
  return !n || Vs[s] > Vs[e] ? qt : n[s].bind(n);
}
const np = {
  error: qt,
  warn: qt,
  info: qt,
  debug: qt
};
let la = /* @__PURE__ */ new WeakMap();
function ii(s, n) {
  const e = la.get(s);
  if (e && e[0] === n)
    return e[1];
  const t = {
    error: Fn("error", s, n),
    warn: Fn("warn", s, n),
    info: Fn("info", s, n),
    debug: Fn("debug", s, n)
  };
  return la.set(s, [n, t]), t;
}
function M(s) {
  const n = s.logger, e = s.logLevel ?? "off";
  return n ? ii(n, e) : np;
}
let ua, br;
function Xl() {
  const s = O("ANTHROPIC_LOG");
  return (!br || s !== ua) && (ua = s, br = ii(console, ri(s, "process.env['ANTHROPIC_LOG']", ii(console, Gs)) ?? Gs)), br;
}
function Ve(s, n, e) {
  s.debug !== qt && s.debug(n, sp(e));
}
const sp = (s) => (s.options && (s.options = { ...s.options }, delete s.options.headers), s.headers && (s.headers = Object.fromEntries((s.headers instanceof Headers ? [...s.headers] : Object.entries(s.headers)).map(([n, e]) => [
  n,
  n.toLowerCase() === "authorization" || n.toLowerCase() === "proxy-authorization" || n.toLowerCase() === "api-key" || n.toLowerCase() === "x-api-key" || n.toLowerCase() === "x-amz-security-token" || n.toLowerCase() === "cookie" || n.toLowerCase() === "set-cookie" ? "***" : e
]))), "retryOfRequestLogID" in s && (s.retryOfRequestLogID && (s.retryOf = s.retryOfRequestLogID), delete s.retryOfRequestLogID), s);
var Qt, Ne = /* @__PURE__ */ (() => {
  class s {
    constructor(e, t, r) {
      this.iterator = e, Qt.set(this, void 0), this.controller = t, w(this, Qt, r);
    }
    /**
     * Iterate the raw Server-Sent Events from `response` — `{event, data, raw}`
     * objects, before any JSON parsing or event-name filtering.
     *
     * This reads `response.body` directly (not a clone), so the response is
     * consumed. Use this in middleware that fully replaces the stream body; for
     * read-only observation of parsed events, use `ctx.parse()` instead.
     */
    static rawEvents(e, t = new AbortController()) {
      return da(e, t);
    }
    static fromSSEResponse(e, t, r) {
      let i = !1;
      const a = r ? M(r) : console;
      async function* o() {
        if (i)
          throw new R("Cannot iterate over a consumed stream, use `.tee()` to split the stream.");
        i = !0;
        let l = !1;
        try {
          for await (const d of da(e, t))
            if (d.event !== "ping" && d.event !== null)
              if (d.event === "error") {
                const p = Ol(d.data) ?? d.data, h = p?.error?.type;
                throw new W(void 0, p, void 0, e.headers, h);
              } else {
                if (!d.data)
                  continue;
                try {
                  yield JSON.parse(d.data);
                } catch (p) {
                  throw a.error("Could not parse message into JSON:", d.data), a.error("From chunk:", d.raw), p;
                }
              }
          l = !0;
        } catch (d) {
          if (yt(d))
            return;
          throw d;
        } finally {
          l || t.abort(), ft(t);
        }
      }
      return new s(o, t, r);
    }
    /**
     * Generates a Stream from a newline-separated ReadableStream
     * where each item is a JSON value.
     */
    static fromReadableStream(e, t, r) {
      let i = !1;
      async function* a() {
        const l = new Mi(), d = Ai(e);
        for await (const p of d)
          for (const h of l.decode(p))
            yield h;
        for (const p of l.flush())
          yield p;
      }
      async function* o() {
        if (i)
          throw new R("Cannot iterate over a consumed stream, use `.tee()` to split the stream.");
        i = !0;
        let l = !1;
        try {
          for await (const d of a())
            l || d && (yield JSON.parse(d));
          l = !0;
        } catch (d) {
          if (yt(d))
            return;
          throw d;
        } finally {
          l || t.abort(), ft(t);
        }
      }
      return new s(o, t, r);
    }
    [(Qt = /* @__PURE__ */ new WeakMap(), Symbol.asyncIterator)]() {
      return this.iterator();
    }
    /**
     * Splits the stream into two streams which can be
     * independently read from at different speeds.
     */
    tee() {
      const e = [], t = [], r = this[Symbol.asyncIterator](), i = (a) => ({
        next: () => {
          if (a.length === 0) {
            const o = r.next();
            e.push(o), t.push(o);
          }
          return a.shift();
        }
      });
      return [
        new s(() => i(e), this.controller, c(this, Qt, "f")),
        new s(() => i(t), this.controller, c(this, Qt, "f"))
      ];
    }
    /**
     * Converts this stream to a newline-separated ReadableStream of
     * JSON stringified values in the stream
     * which can be turned back into a Stream with `Stream.fromReadableStream()`.
     */
    toReadableStream() {
      const e = this;
      let t;
      return Il({
        async start() {
          t = e[Symbol.asyncIterator]();
        },
        async pull(r) {
          try {
            const { value: i, done: a } = await t.next();
            if (a)
              return r.close();
            const o = Yl(JSON.stringify(i) + `
`);
            r.enqueue(o);
          } catch (i) {
            r.error(i);
          }
        },
        async cancel() {
          await t.return?.();
        }
      });
    }
  }
  return s;
})();
async function* da(s, n) {
  if (!s.body)
    throw n.abort(), typeof globalThis.navigator < "u" && globalThis.navigator.product === "ReactNative" ? new R("The default react-native fetch implementation does not support streaming. Please use expo/fetch: https://docs.expo.dev/versions/latest/sdk/expo/#expofetch-api") : new R("Attempted to iterate over a response with no body");
  const e = new rp(), t = new Mi(), r = Ai(s.body);
  for await (const i of r)
    for (const a of t.decode(i)) {
      const o = e.decode(a);
      o && (yield o);
    }
  for (const i of t.flush()) {
    const a = e.decode(i);
    a && (yield a);
  }
}
class rp {
  constructor() {
    this.event = null, this.data = [], this.chunks = [];
  }
  decode(n) {
    if (n.endsWith("\r") && (n = n.substring(0, n.length - 1)), !n) {
      if (!this.event && !this.data.length)
        return null;
      const i = {
        event: this.event,
        data: this.data.join(`
`),
        raw: this.chunks
      };
      return this.event = null, this.data = [], this.chunks = [], i;
    }
    if (this.chunks.push(n), n.startsWith(":"))
      return null;
    let [e, t, r] = ip(n, ":");
    return r.startsWith(" ") && (r = r.substring(1)), e === "event" ? this.event = r : e === "data" && this.data.push(r), null;
  }
}
function ip(s, n) {
  const e = s.indexOf(n);
  return e !== -1 ? [s.substring(0, e), n, s.substring(e + n.length)] : [s, "", ""];
}
const Ql = Symbol.for("brand.privateNullableHeaders");
function* ap(s) {
  if (!s)
    return;
  if (Ql in s) {
    const { values: t, nulls: r } = s;
    yield* t.entries();
    for (const i of r)
      yield [i, null];
    return;
  }
  let n = !1, e;
  s instanceof Headers ? e = s.entries() : Yi(s) ? e = s : (n = !0, e = Object.entries(s ?? {}));
  for (let t of e) {
    const r = t[0];
    if (typeof r != "string")
      throw new TypeError("expected header name to be a string");
    const i = Yi(t[1]) ? t[1] : [t[1]];
    let a = !1;
    for (const o of i)
      o !== void 0 && (n && !a && (a = !0, yield [r, $s]), yield [r, o]);
  }
}
const $s = Symbol("clear"), op = /* @__PURE__ */ new Set(["x-stainless-helper"]), cp = (s, n) => {
  const e = s ? s.split(",").map((t) => t.trim()).filter(Boolean) : [];
  for (const t of n.split(",").map((r) => r.trim()))
    t && !e.includes(t) && e.push(t);
  return e.join(", ");
}, f = (s) => {
  const n = new Headers(), e = /* @__PURE__ */ new Set();
  for (const t of s) {
    const r = /* @__PURE__ */ new Set();
    for (const [i, a] of ap(t)) {
      const o = i.toLowerCase();
      if (op.has(o)) {
        if (a === $s)
          continue;
        a === null ? (n.delete(i), e.add(o)) : (n.set(i, cp(n.get(i), a)), e.delete(o));
        continue;
      }
      (a === $s || !r.has(o)) && (n.delete(i), r.add(o), a === $s) || (a === null ? (n.delete(i), e.add(o)) : (n.append(i, a), e.delete(o)));
    }
  }
  return { [Ql]: !0, values: n, nulls: e };
}, ha = "com.anthropic.sdk.typescript", lp = "error.type", Oi = "gen_ai.conversation.id", ir = "gen_ai.provider.name", up = "http.request.method", dp = "http.request.resend_count", Ci = "http.response.status_code", hp = "http.route", pp = "server.address", _p = "server.port", fp = "url.full", gp = "url.path", mp = "url.query", yp = "url.scheme", bp = "anthropic.session.thread.id", wp = 75e4;
function vp(s) {
  const { tracerProvider: n, propagation: e, traces: t } = s === !1 ? { traces: !1 } : s ?? kp(), { enabled: r, contentMode: i, maxContentBytes: a } = typeof t == "boolean" ? { enabled: t } : t ?? {};
  return Object.freeze({
    tracerProvider: n,
    propagation: e ?? !0,
    traces: Object.freeze({
      enabled: r ?? !0,
      contentMode: i === "content" ? "content" : "metadata_only",
      maxContentBytes: a !== void 0 && Number.isInteger(a) && a >= 1 ? a : wp
    })
  });
}
function kp() {
  return {
    propagation: O("ANTHROPIC_OPEN_TELEMETRY_PROPAGATION")?.toLowerCase() !== "false",
    traces: {
      enabled: O("ANTHROPIC_OPEN_TELEMETRY")?.toLowerCase() !== "false",
      contentMode: O("ANTHROPIC_OPEN_TELEMETRY_TRACES_CONTENT_MODE")?.toLowerCase() === "content" ? "content" : "metadata_only",
      // The variable holds decimal digits only: `1e3` and `0x10` are not sizes.
      maxContentBytes: Number(/^\d+$/.exec(O("ANTHROPIC_OPEN_TELEMETRY_TRACES_MAX_CONTENT_BYTES") ?? "")?.[0] ?? NaN)
    }
  };
}
function Sp(s, n, e) {
  if (!s.traces.enabled)
    return;
  const t = e !== void 0 ? `${ha}.${e}` : ha;
  return (s.tracerProvider ?? wt.getTracerProvider()).getTracer(t, n);
}
function j(s, n) {
  try {
    return n();
  } catch (e) {
    s && M(s).debug("could not record telemetry", e);
    return;
  }
}
function u(s, n, e, t) {
  if (e?.__span)
    return e.__span;
  const r = s._tracer;
  if (r)
    return j(s, () => {
      const i = Date.now(), a = t?.attributes?.[bp], o = e?.openTelemetry?.conversationId ?? (typeof a == "string" ? a : void 0), l = r.startSpan(n, {
        kind: rr.CLIENT,
        // On the span from its start, with what the method gives, for a sampler to decide on.
        attributes: {
          [ir]: s._genAIProviderName,
          ...Ap(s.baseURL),
          ...o != null ? { [Oi]: o } : void 0,
          ...t?.route != null ? { [hp]: t.route } : void 0,
          ...t?.attributes
        }
      });
      if (!(!l.isRecording() && !(s.openTelemetry.propagation ? Object.keys(eu(l)).length > 0 : wt.isSpanContextValid(l.spanContext()))))
        return { ...t, span: l, name: n, startTime: i };
    });
}
function Tp(s, n) {
  if (s.createdIDAttribute === void 0 || typeof n != "object" || n === null)
    return;
  const e = n[s.createdIDField ?? "id"];
  typeof e == "string" && s.span.setAttribute(s.createdIDAttribute, e);
}
function Ap(s) {
  try {
    const { hostname: n, port: e, protocol: t } = new URL(s);
    return {
      // `URL.hostname` keeps an IPv6 literal's brackets, which delimit it in a URL;
      // `server.address` is the bare address.
      [pp]: n.replace(/^\[(.*)\]$/, "$1"),
      [_p]: e ? Number(e) : t === "http:" ? 80 : 443
    };
  } catch {
    return {};
  }
}
function xp(s, n, e, t = !1) {
  if (s.attempts = (s.attempts ?? 0) + 1, s.attempts > 1) {
    s.span.setAttribute(dp, s.attempts - 1);
    return;
  }
  s.span.setAttribute(up, n);
  try {
    const { protocol: r, host: i, pathname: a, search: o } = new URL(e), l = Rp(o.slice(1), s.queryParams, s.contentQueryParams);
    if (s.span.setAttributes({
      [yp]: r.slice(0, -1),
      [gp]: a
    }), l?.content && !t)
      return;
    s.span.setAttributes({
      ...l !== void 0 ? { [mp]: l.value } : void 0,
      // With the recorded query, not the one sent.
      [fp]: `${r}//${i}${a}${l !== void 0 ? `?${l.value}` : ""}`
    });
  } catch {
  }
}
const Ep = ["email", "path_prefix", "expected_content_sha256"];
function Rp(s, n, e) {
  if (!s || !n?.length)
    return;
  let t = !1;
  const r = s.split("&").filter((i) => {
    try {
      const a = decodeURIComponent(i.split("=", 1)[0]), o = n.includes(a) || !a.endsWith("[]") ? a : a.slice(0, -2);
      return n.includes(o) ? (t || (t = Ep.includes(o) || !!e?.includes(o)), !0) : !1;
    } catch {
      return !1;
    }
  });
  return r.length ? { value: r.join("&"), content: t } : void 0;
}
function Pp(s, n) {
  const e = f([n]).values;
  for (const [t, r] of Object.entries(eu(s)))
    e.set(t, r);
  return e;
}
function zn(s, n) {
  if (s.isRecording()) {
    switch (Mp(s, n), n.status) {
      case "success":
        s.setStatus({ code: bt.OK });
        break;
      case "error":
        Ye(s, n.error);
        break;
    }
    s.end();
  }
}
function Zl(s, n, e) {
  const t = s[Symbol.asyncIterator];
  let r = !1;
  const i = (l) => {
    if (!r) {
      r = !0, n.removeEventListener("abort", a);
      try {
        e.onEnd(l);
      } catch {
      }
    }
  }, a = () => i({ reason: "canceled" });
  if (n.aborted)
    return a();
  n.addEventListener("abort", a, { once: !0 });
  let o = !1;
  s[Symbol.asyncIterator] = function() {
    const l = t.call(this);
    if (o)
      return l;
    o = !0, n.removeEventListener("abort", a);
    const d = {
      async next() {
        let p;
        try {
          p = await l.next();
        } catch (h) {
          throw i({ reason: "failed", error: h }), h;
        }
        if (p.done)
          i({ reason: n.aborted ? "canceled" : "completed" });
        else if (!r)
          try {
            e.onItem?.(p.value);
          } catch {
          }
        return p;
      },
      async return(p) {
        return a(), await l.return?.(p) ?? { done: !0, value: p };
      },
      async throw(p) {
        if (a(), l.throw)
          return l.throw(p);
        throw p;
      },
      [Symbol.asyncIterator]: () => d
    };
    return d;
  };
}
function zp(s, n, e) {
  if (!s.isRecording())
    return;
  s.setAttribute(Ci, e.response.status);
  const t = n instanceof Ne;
  Zl(n, e.controller.signal, {
    onEnd(r) {
      r.reason === "failed" ? Ye(s, r.error) : r.reason === "completed" && !t && s.setStatus({ code: bt.OK }), s.end();
    }
  });
}
function Mp(s, n) {
  const e = n.response?.status ?? (n.status === "error" && n.error instanceof W ? n.error.status : void 0);
  e !== void 0 && s.setAttribute(Ci, e);
}
function Ye(s, n, e) {
  n instanceof he || yt(n) || (s.setStatus({ code: bt.ERROR }), s.setAttribute(lp, e ?? Op(n)));
}
function eu(s) {
  const n = {};
  return Vl.inject(wt.setSpan(_e.active(), s), n), n;
}
function Op(s) {
  if (s instanceof ti)
    return "client_timeout_error";
  if (s instanceof Ht)
    return "connection_error";
  if (s instanceof W) {
    if (s.type)
      return s.type;
    if (s.status !== void 0)
      return String(s.status);
  }
  return "client_error";
}
const tu = "RFC3986", nu = (s) => String(s), pa = {
  RFC1738: (s) => String(s).replace(/%20/g, "+"),
  RFC3986: nu
}, Cp = "RFC1738";
let ai = (s, n) => (ai = Object.hasOwn ?? Function.prototype.call.bind(Object.prototype.hasOwnProperty), ai(s, n));
const be = /* @__PURE__ */ (() => {
  const s = [];
  for (let n = 0; n < 256; ++n)
    s.push("%" + ((n < 16 ? "0" : "") + n.toString(16)).toUpperCase());
  return s;
})(), wr = 1024, Ip = (s, n, e, t, r) => {
  if (s.length === 0)
    return s;
  let i = s;
  if (typeof s == "symbol" ? i = Symbol.prototype.toString.call(s) : typeof s != "string" && (i = String(s)), e === "iso-8859-1")
    return escape(i).replace(/%u[0-9a-f]{4}/gi, function(o) {
      return "%26%23" + parseInt(o.slice(2), 16) + "%3B";
    });
  let a = "";
  for (let o = 0; o < i.length; o += wr) {
    const l = i.length >= wr ? i.slice(o, o + wr) : i, d = [];
    for (let p = 0; p < l.length; ++p) {
      let h = l.charCodeAt(p);
      if (h === 45 || // -
      h === 46 || // .
      h === 95 || // _
      h === 126 || // ~
      h >= 48 && h <= 57 || // 0-9
      h >= 65 && h <= 90 || // a-z
      h >= 97 && h <= 122 || // A-Z
      r === Cp && (h === 40 || h === 41)) {
        d[d.length] = l.charAt(p);
        continue;
      }
      if (h < 128) {
        d[d.length] = be[h];
        continue;
      }
      if (h < 2048) {
        d[d.length] = be[192 | h >> 6] + be[128 | h & 63];
        continue;
      }
      if (h < 55296 || h >= 57344) {
        d[d.length] = be[224 | h >> 12] + be[128 | h >> 6 & 63] + be[128 | h & 63];
        continue;
      }
      p += 1, h = 65536 + ((h & 1023) << 10 | l.charCodeAt(p) & 1023), d[d.length] = be[240 | h >> 18] + be[128 | h >> 12 & 63] + be[128 | h >> 6 & 63] + be[128 | h & 63];
    }
    a += d.join("");
  }
  return a;
};
function $p(s) {
  return !s || typeof s != "object" ? !1 : !!(s.constructor && s.constructor.isBuffer && s.constructor.isBuffer(s));
}
function _a(s, n) {
  if (se(s)) {
    const e = [];
    for (let t = 0; t < s.length; t += 1)
      e.push(n(s[t]));
    return e;
  }
  return n(s);
}
const su = {
  brackets(s) {
    return String(s) + "[]";
  },
  comma: "comma",
  indices(s, n) {
    return String(s) + "[" + n + "]";
  },
  repeat(s) {
    return String(s);
  }
}, ru = function(s, n) {
  Array.prototype.push.apply(s, se(n) ? n : [n]);
};
let fa;
const D = {
  addQueryPrefix: !1,
  allowDots: !1,
  allowEmptyArrays: !1,
  arrayFormat: "indices",
  charset: "utf-8",
  charsetSentinel: !1,
  delimiter: "&",
  encode: !0,
  encodeDotInKeys: !1,
  encoder: Ip,
  encodeValuesOnly: !1,
  format: tu,
  formatter: nu,
  /** @deprecated */
  indices: !1,
  serializeDate(s) {
    return (fa ?? (fa = Function.prototype.call.bind(Date.prototype.toISOString)))(s);
  },
  skipNulls: !1,
  strictNullHandling: !1
};
function Np(s) {
  return typeof s == "string" || typeof s == "number" || typeof s == "boolean" || typeof s == "symbol" || typeof s == "bigint";
}
const vr = {};
function iu(s, n, e, t, r, i, a, o, l, d, p, h, m, _, b, y, k, E) {
  let A = s, T = E, v = 0, S = !1;
  for (; (T = T.get(vr)) !== void 0 && !S; ) {
    const I = T.get(s);
    if (v += 1, typeof I < "u") {
      if (I === v)
        throw new RangeError("Cyclic object value");
      S = !0;
    }
    typeof T.get(vr) > "u" && (v = 0);
  }
  if (typeof d == "function" ? A = d(n, A) : A instanceof Date ? A = m?.(A) : e === "comma" && se(A) && (A = _a(A, function(I) {
    return I instanceof Date ? m?.(I) : I;
  })), A === null) {
    if (i)
      return l && !y ? (
        // @ts-expect-error
        l(n, D.encoder, k, "key", _)
      ) : n;
    A = "";
  }
  if (Np(A) || $p(A)) {
    if (l) {
      const I = y ? n : l(n, D.encoder, k, "key", _);
      return [
        b?.(I) + "=" + // @ts-expect-error
        b?.(l(A, D.encoder, k, "value", _))
      ];
    }
    return [b?.(n) + "=" + b?.(String(A))];
  }
  const P = [];
  if (typeof A > "u")
    return P;
  let C;
  if (e === "comma" && se(A))
    y && l && (A = _a(A, l)), C = [{ value: A.length > 0 ? A.join(",") || null : void 0 }];
  else if (se(d))
    C = d;
  else {
    const I = Object.keys(A);
    C = p ? I.sort(p) : I;
  }
  const $ = o ? String(n).replace(/\./g, "%2E") : String(n), N = t && se(A) && A.length === 1 ? $ + "[]" : $;
  if (r && se(A) && A.length === 0)
    return N + "[]";
  for (let I = 0; I < C.length; ++I) {
    const fe = C[I], Be = (
      // @ts-ignore
      typeof fe == "object" && typeof fe.value < "u" ? fe.value : A[fe]
    );
    if (a && Be === null)
      continue;
    const Ue = h && o ? fe.replace(/\./g, "%2E") : fe, ld = se(A) ? typeof e == "function" ? e(N, Ue) : N : N + (h ? "." + Ue : "[" + Ue + "]");
    E.set(s, v);
    const Di = /* @__PURE__ */ new WeakMap();
    Di.set(vr, E), ru(P, iu(
      Be,
      ld,
      e,
      t,
      r,
      i,
      a,
      o,
      // @ts-ignore
      e === "comma" && y && se(A) ? null : l,
      d,
      p,
      h,
      m,
      _,
      b,
      y,
      k,
      Di
    ));
  }
  return P;
}
function Lp(s = D) {
  if (typeof s.allowEmptyArrays < "u" && typeof s.allowEmptyArrays != "boolean")
    throw new TypeError("`allowEmptyArrays` option can only be `true` or `false`, when provided");
  if (typeof s.encodeDotInKeys < "u" && typeof s.encodeDotInKeys != "boolean")
    throw new TypeError("`encodeDotInKeys` option can only be `true` or `false`, when provided");
  if (s.encoder !== null && typeof s.encoder < "u" && typeof s.encoder != "function")
    throw new TypeError("Encoder has to be a function.");
  const n = s.charset || D.charset;
  if (typeof s.charset < "u" && s.charset !== "utf-8" && s.charset !== "iso-8859-1")
    throw new TypeError("The charset option must be either utf-8, iso-8859-1, or undefined");
  let e = tu;
  if (typeof s.format < "u") {
    if (!ai(pa, s.format))
      throw new TypeError("Unknown format option provided.");
    e = s.format;
  }
  const t = pa[e];
  let r = D.filter;
  (typeof s.filter == "function" || se(s.filter)) && (r = s.filter);
  let i;
  if (s.arrayFormat && s.arrayFormat in su ? i = s.arrayFormat : "indices" in s ? i = s.indices ? "indices" : "repeat" : i = D.arrayFormat, "commaRoundTrip" in s && typeof s.commaRoundTrip != "boolean")
    throw new TypeError("`commaRoundTrip` must be a boolean, or absent");
  const a = typeof s.allowDots > "u" ? s.encodeDotInKeys ? !0 : D.allowDots : !!s.allowDots;
  return {
    addQueryPrefix: typeof s.addQueryPrefix == "boolean" ? s.addQueryPrefix : D.addQueryPrefix,
    // @ts-ignore
    allowDots: a,
    allowEmptyArrays: typeof s.allowEmptyArrays == "boolean" ? !!s.allowEmptyArrays : D.allowEmptyArrays,
    arrayFormat: i,
    charset: n,
    charsetSentinel: typeof s.charsetSentinel == "boolean" ? s.charsetSentinel : D.charsetSentinel,
    commaRoundTrip: !!s.commaRoundTrip,
    delimiter: typeof s.delimiter > "u" ? D.delimiter : s.delimiter,
    encode: typeof s.encode == "boolean" ? s.encode : D.encode,
    encodeDotInKeys: typeof s.encodeDotInKeys == "boolean" ? s.encodeDotInKeys : D.encodeDotInKeys,
    encoder: typeof s.encoder == "function" ? s.encoder : D.encoder,
    encodeValuesOnly: typeof s.encodeValuesOnly == "boolean" ? s.encodeValuesOnly : D.encodeValuesOnly,
    filter: r,
    format: e,
    formatter: t,
    serializeDate: typeof s.serializeDate == "function" ? s.serializeDate : D.serializeDate,
    skipNulls: typeof s.skipNulls == "boolean" ? s.skipNulls : D.skipNulls,
    // @ts-ignore
    sort: typeof s.sort == "function" ? s.sort : null,
    strictNullHandling: typeof s.strictNullHandling == "boolean" ? s.strictNullHandling : D.strictNullHandling
  };
}
function qp(s, n = {}) {
  let e = s;
  const t = Lp(n);
  let r, i;
  typeof t.filter == "function" ? (i = t.filter, e = i("", e)) : se(t.filter) && (i = t.filter, r = i);
  const a = [];
  if (typeof e != "object" || e === null)
    return "";
  const o = su[t.arrayFormat], l = o === "comma" && t.commaRoundTrip;
  r || (r = Object.keys(e)), t.sort && r.sort(t.sort);
  const d = /* @__PURE__ */ new WeakMap();
  for (let m = 0; m < r.length; ++m) {
    const _ = r[m];
    t.skipNulls && e[_] === null || ru(a, iu(
      e[_],
      _,
      // @ts-expect-error
      o,
      l,
      t.allowEmptyArrays,
      t.strictNullHandling,
      t.skipNulls,
      t.encodeDotInKeys,
      t.encode ? t.encoder : null,
      t.filter,
      t.sort,
      t.allowDots,
      t.serializeDate,
      t.format,
      t.formatter,
      t.encodeValuesOnly,
      t.charset,
      d
    ));
  }
  const p = a.join(t.delimiter);
  let h = t.addQueryPrefix === !0 ? "?" : "";
  return t.charsetSentinel && (t.charset === "iso-8859-1" ? h += "utf8=%26%2310003%3B&" : h += "utf8=%E2%9C%93&"), p.length > 0 ? h + p : "";
}
function Bp(s) {
  return qp(s, { arrayFormat: "brackets" });
}
const Up = "urn:ietf:params:oauth:grant-type:jwt-bearer", jp = "refresh_token", au = "/v1/oauth/token", Js = "oauth-2025-04-20", Fp = "oidc-federation-2026-04-01", Wp = 120, Ii = 30, Hp = 5, ga = 1 << 20;
function ou(s) {
  if (!s)
    return;
  let n;
  try {
    n = new URL(s);
  } catch (t) {
    throw new B(`Invalid token endpoint base URL "${s}": ${t}`);
  }
  if (n.protocol === "https:")
    return;
  const e = n.hostname.toLowerCase().replace(/^\[|\]$/g, "");
  if (!(n.protocol === "http:" && (e === "localhost" || e === "127.0.0.1" || e === "::1")))
    throw new B(`Refusing to send credential over non-https token endpoint "${s}"`);
}
async function cu(s, n) {
  const e = await Kp(s);
  let t;
  try {
    t = JSON.parse(e);
  } catch {
    throw new B(`Token endpoint returned non-JSON response (status ${s.status})`, s.status, me(e), n);
  }
  if (!t.access_token)
    throw new B(`Token endpoint response missing access_token: ${JSON.stringify(me(t))}`, s.status, me(t), n);
  if (t.token_type && t.token_type.toLowerCase() !== "bearer")
    throw new B(`Token endpoint response: unsupported token_type "${t.token_type}" (want Bearer)`, s.status, me(t), n);
  return t;
}
const kr = 2e3, Dp = /* @__PURE__ */ new Set(["error", "error_description", "error_uri"]);
function me(s) {
  if (s == null)
    return s;
  if (typeof s == "string") {
    let n;
    try {
      n = JSON.parse(s);
    } catch {
      return s.length <= kr ? s : s.slice(0, kr) + `... <${s.length - kr} more chars>`;
    }
    return JSON.stringify(me(n));
  }
  if (typeof s == "object" && !Array.isArray(s)) {
    const n = {};
    for (const [e, t] of Object.entries(s))
      Dp.has(e) && (n[e] = t);
    return n;
  }
  return null;
}
async function lu(s, n = (e) => console.warn(`anthropic-sdk: ${e}`)) {
  if (typeof process > "u" || process.platform === "win32")
    return;
  const { fs: e } = await Promise.resolve().then(() => qe);
  let t = s, r;
  try {
    t = await e.promises.realpath(s), r = await e.promises.stat(t);
  } catch {
    return;
  }
  const i = r.mode & 511;
  if (i & 18)
    throw new B(`Credentials file at ${t} is group/world-writable (mode 0o${i.toString(8)}); this allows other local users to plant tokens. Run \`chmod 600 ${t}\`.`);
  if (i & 36)
    throw new B(`Credentials file at ${t} is group/world-readable (mode 0o${i.toString(8)}); run \`chmod 600 ${t}\` before retrying.`);
  typeof process.getuid == "function" && r.uid !== process.getuid() && n(`credentials file at ${t} is owned by uid ${r.uid} (current process uid ${process.getuid()}); verify this is intentional.`);
}
async function uu(s, n) {
  const { fs: e, path: t } = await Promise.resolve().then(() => qe), r = t.dirname(s);
  await e.promises.mkdir(r, { recursive: !0, mode: 448 });
  const i = `${s}.${process.pid}.${Math.random().toString(36).slice(2)}.tmp`;
  try {
    const a = await e.promises.open(i, "w", 384);
    try {
      await a.writeFile(JSON.stringify(n, null, 2)), await a.sync();
    } finally {
      await a.close();
    }
    await e.promises.rename(i, s);
  } catch (a) {
    throw await e.promises.unlink(i).catch(() => {
    }), a;
  }
  try {
    const a = await e.promises.open(r, "r");
    try {
      await a.sync();
    } finally {
      await a.close();
    }
  } catch {
  }
}
async function Kp(s) {
  if (!s.body)
    return "";
  const n = s.body.getReader(), e = [];
  let t = 0;
  for (; ; ) {
    const { done: i, value: a } = await n.read();
    if (i)
      break;
    if (t + a.length > ga) {
      const o = ga - t;
      o > 0 && e.push(a.subarray(0, o)), await n.cancel();
      break;
    }
    e.push(a), t += a.length;
  }
  let r;
  if (e.length === 1)
    r = e[0];
  else {
    r = new Uint8Array(e.reduce((a, o) => a + o.length, 0));
    let i = 0;
    for (const a of e)
      r.set(a, i), i += a.length;
  }
  return new TextDecoder("utf-8").decode(r);
}
class B extends R {
  constructor(n, e = null, t = null, r = null) {
    super(n), this.statusCode = e, this.body = t, this.requestId = r;
  }
}
function gt() {
  return Math.floor(Date.now() / 1e3);
}
class Gp {
  constructor(n, e) {
    this.cached = null, this.pendingRefresh = null, this.nextForce = !1, this.lastAdvisoryError = 0, this.provider = n, this.onAdvisoryRefreshError = e;
  }
  async getToken() {
    const n = this.nextForce;
    this.nextForce = !1;
    const e = this.cached;
    if (n || e == null)
      return (await this.refresh(n)).token;
    if (e.expiresAt == null)
      return e.token;
    const t = e.expiresAt - gt();
    return t > Wp ? e.token : t > Ii ? (this.backgroundRefresh(), e.token) : (await this.refresh()).token;
  }
  /**
   * Clears the cached token and marks the next {@link getToken} as a forced
   * refresh, so the underlying provider bypasses any on-disk freshness check.
   * Called after a 401 — the server has just told us the token is bad even
   * if its `expires_at` still looks fresh.
   */
  invalidate() {
    this.cached = null, this.nextForce = !0;
  }
  /**
   * Mandatory refresh. Joins any in-flight refresh unless forced — a forced
   * refresh must not coalesce into a non-forced one that may re-serve the
   * same stale disk token.
   */
  refresh(n = !1) {
    return this.pendingRefresh && !n ? this.pendingRefresh : this.doRefresh(n);
  }
  /**
   * Advisory background refresh. Shares the same in-flight promise as
   * mandatory refreshes for deduplication, but swallows errors so the
   * stale cached token keeps being served. Backs off for
   * {@link ADVISORY_REFRESH_BACKOFF_IN_SECONDS} after a failure so an
   * outage during the advisory window doesn't hammer the token endpoint.
   */
  backgroundRefresh() {
    this.pendingRefresh || gt() - this.lastAdvisoryError < Hp || this.doRefresh().catch((n) => {
      this.lastAdvisoryError = gt(), this.onAdvisoryRefreshError?.(n);
    });
  }
  /**
   * Core refresh. Sets {@link pendingRefresh} so concurrent callers
   * (both advisory and mandatory) coalesce into a single provider call.
   */
  doRefresh(n = !1) {
    return this.pendingRefresh = this.provider(n ? { forceRefresh: !0 } : void 0).then((e) => (this.cached = e, this.pendingRefresh = null, e), (e) => {
      throw this.pendingRefresh = null, e;
    }), this.pendingRefresh;
  }
}
const Vp = "gen_ai.agent.name", On = "gen_ai.input.messages", $i = "gen_ai.operation.name", Kt = "gen_ai.output.messages", du = "gen_ai.output.type", Jp = "gen_ai.request.max_tokens", Ln = "gen_ai.request.model", Yp = "gen_ai.request.reasoning.level", oi = "gen_ai.request.stop_sequences", Xp = "gen_ai.request.stream", Qp = "gen_ai.request.temperature", Zp = "gen_ai.request.top_k", e_ = "gen_ai.request.top_p", t_ = "gen_ai.response.id", n_ = "gen_ai.response.model", s_ = "gen_ai.response.time_to_first_chunk", Cn = "gen_ai.system_instructions", r_ = "gen_ai.tool.call.arguments", i_ = "gen_ai.tool.call.id", a_ = "gen_ai.tool.description", o_ = "gen_ai.tool.name", c_ = "gen_ai.tool.type", l_ = "gen_ai.usage.cache_write.input_tokens", u_ = "gen_ai.usage.cache_read.input_tokens", d_ = "gen_ai.usage.input_tokens", h_ = "gen_ai.usage.output_tokens", p_ = "gen_ai.usage.reasoning.output_tokens", __ = "chat", f_ = "execute_tool", g_ = "invoke_agent", hu = "json", m_ = "function", y_ = "anthropic.request.id", b_ = "anthropic.organization.id", w_ = "anthropic.workspace.id", v_ = "anthropic.beta", k_ = "anthropic.content.truncated", S_ = "anthropic.message.stop_reason", T_ = "anthropic.message.count_tokens.input_tokens", A_ = "anthropic.request.service_tier", x_ = "anthropic.response.service_tier", E_ = "anthropic.thinking.budget_tokens", R_ = "anthropic.thinking.type", ci = "anthropic.tool_result.content", P_ = "anthropic.toolset.name", z_ = "anthropic.usage.cache_creation.ephemeral_1h_input_tokens", M_ = "anthropic.usage.cache_creation.ephemeral_5m_input_tokens", O_ = "anthropic.usage.compaction.input_tokens", C_ = "anthropic.usage.compaction.output_tokens", I_ = [
  [y_, "request-id"],
  [b_, "anthropic-organization-id"],
  [w_, "anthropic-workspace-id"]
];
function Ni(s, n, e, t) {
  const r = s.span, i = s.requestContentSize;
  if (e !== void 0 && i !== void 0) {
    const o = JSON.stringify([{ role: "assistant", parts: Wn(e) }]);
    if (i + 3 * o.length <= t || i + ar(o) <= t) {
      r.setAttribute(Kt, o);
      return;
    }
  }
  const a = _u(r, {
    // An empty list sets no attribute.
    [oi]: n.stop_sequences?.length ? [...n.stop_sequences] : void 0,
    [Cn]: n.system === void 0 ? void 0 : Wn(n.system),
    [On]: n.messages.map((o) => ({ role: o.role, parts: Wn(o.content) })),
    [Kt]: e === void 0 ? void 0 : [{ role: "assistant", parts: Wn(e) }]
  }, t);
  e === void 0 && (s.requestContentSize = a);
}
function Wn(s) {
  return typeof s == "string" ? [{ type: "text", content: s }] : s?.map($_) ?? [];
}
function $_(s) {
  switch (s.type) {
    case "text":
      return { type: "text", content: s.text };
    case "thinking":
      return { type: "reasoning", content: s.thinking };
    case "tool_use":
      return {
        type: "tool_call",
        id: s.id,
        name: s.name,
        arguments: s.input,
        // Only a call to a member of a toolset, such as `computer`, has one.
        ...typeof s.toolset_name == "string" ? { anthropic_toolset_name: s.toolset_name } : void 0
      };
    case "server_tool_use":
      return { type: "tool_call", id: s.id, name: s.name, arguments: s.input };
    case "mcp_tool_use":
      return {
        type: "tool_call",
        id: s.id,
        name: s.name,
        arguments: s.input,
        anthropic_mcp_server_name: s.server_name
      };
    case "tool_result":
      return {
        type: "tool_call_response",
        id: s.tool_use_id,
        response: pu(s.content)
      };
    default:
      return typeof s.type != "string" ? { type: "anthropic_unknown" } : s.type.endsWith("_tool_result") && "tool_use_id" in s ? {
        type: "tool_call_response",
        id: s.tool_use_id,
        response: N_(s.content)
      } : { type: `anthropic_${s.type}` };
  }
}
function pu(s) {
  return s == null ? [] : typeof s == "string" ? [{ type: "text", text: s }] : s.map((n) => n.type === "text" || n.type === "search_result" ? In(n) : typeof n.type != "string" ? { type: "unknown" } : { type: n.type });
}
function N_(s) {
  return s == null ? [] : typeof s == "string" ? [{ type: "text", text: s }] : Array.isArray(s) ? s.map((n) => n.type === "text" || n.type === "search_result" || n.type === "web_search_result" ? In(n) : typeof n.type != "string" ? { type: "unknown" } : { type: n.type }) : [In(s)];
}
function In(s) {
  if (Array.isArray(s))
    return s.map(In);
  if (typeof s != "object" || s === null)
    return s;
  const { type: n, file_type: e } = s;
  if (n === "image" || n === "document")
    return { type: n };
  const t = n === "text_editor_code_execution_view_result" && (e === "image" || e === "pdf");
  return Object.fromEntries(Object.entries(s).filter(([r]) => !r.startsWith("encrypted_") && !(r === "content" && t)).map(([r, i]) => [r, In(i)]));
}
function _u(s, n, e) {
  const { [oi]: t, [Cn]: r, [On]: i, [Kt]: a, [ci]: o, ...l } = n, d = {
    [Cn]: r,
    [On]: i,
    [Kt]: a
  }, p = {}, h = o?.map((v) => JSON.stringify(v)), _ = 3 * ([...t ?? [], ...h ?? []].reduce((v, S) => v + S.length + 1, 2) + Sr(l, p) + Sr(d, p)) <= e ? (v) => 3 * v.length : ar, b = () => Object.keys(d).reduce((v, S) => v + _(p[S] ?? ""), 0), y = t?.reduce((v, S) => v + _(S), 0) ?? 0, k = t !== void 0 && y <= e;
  let E = k ? y : 0, A = t !== void 0 && !k;
  for (const v of Object.keys(l)) {
    const S = _(p[v] ?? "");
    S > e ? (delete p[v], A = !0) : E += S;
  }
  let T = b();
  if (E + T > e) {
    const { truncated: v, ...S } = L_(d, E + T - e);
    A || (A = v), Sr(S, p), T = b();
  }
  if (E += T, h !== void 0) {
    const v = B_(h, e - E, _);
    p[ci] = v.json, E += v.size, A || (A = v.truncated);
  }
  A && s.setAttribute(k_, !0), k && s.setAttribute(oi, t);
  for (const [v, S] of Object.entries(p))
    s.setAttribute(v, S);
  return E;
}
function Sr(s, n) {
  let e = 0;
  for (const [t, r] of Object.entries(s))
    r !== void 0 && (n[t] = JSON.stringify(r), e += n[t].length);
  return e;
}
function L_(s, n) {
  const e = (d) => d?.map((p) => ({ ...p, parts: [...p.parts] })), t = s[Cn]?.slice(), r = e(s[On]), i = e(s[Kt]), a = [t ?? [], ...[...r ?? [], ...i ?? []].map(({ parts: d }) => d)];
  let o = a.reduce((d, p) => d + p.length, 0), l = !1;
  for (const d of a) {
    let p = 0;
    for (; n > 0 && p < d.length; ) {
      const h = d[p], m = ar(JSON.stringify(h)), _ = h.content;
      if (o === 1 && h.type === "text" && typeof _ == "string") {
        const b = q_(h, _, m - n);
        b !== _ && (d[p] = { ...h, content: b }, l = !0);
        break;
      }
      n -= m + (p + 1 < d.length ? 1 : 0), p++, o--, l = !0;
    }
    d.splice(0, p);
  }
  return {
    [Cn]: t,
    [On]: r,
    [Kt]: i,
    truncated: l
  };
}
function q_(s, n, e) {
  const t = e - ar(JSON.stringify({ ...s, content: "" })), r = n.slice(0, Math.max(t, 0)), i = JSON.stringify(r);
  let a = 0, o = 0, l = 0;
  for (; a < r.length; ) {
    const d = i.codePointAt(1 + o), p = d > 65535 ? 2 : 1, h = d !== 92 ? p : i[2 + o] === "u" ? 6 : 2;
    if (l += d < 128 ? h : d < 2048 ? 2 : d < 65536 ? 3 : 4, l > t)
      break;
    o += h, a += p;
  }
  return n.slice(0, a);
}
function B_(s, n, e) {
  const t = [];
  let r = 2;
  for (const i of s) {
    const a = r + (t.length === 0 ? 0 : 1) + e(i);
    if (a > n)
      break;
    t.push(i), r = a;
  }
  return { json: "[" + t.join(",") + "]", size: r, truncated: t.length < s.length };
}
function ar(s) {
  let n = 0;
  for (let e = 0; e < s.length; e++) {
    const t = s.charCodeAt(e);
    t < 128 ? n += 1 : t < 2048 ? n += 2 : t >= 55296 && t < 56320 && (s.charCodeAt(e + 1) & 64512) === 56320 ? (n += 4, e++) : n += 3;
  }
  return n;
}
function fu(s, n, e, t) {
  s.setAttribute(t_, n.id), s.setAttribute(n_, n.model), s.setAttribute(d_, e.input_tokens + (e.cache_read_input_tokens ?? 0) + (e.cache_creation_input_tokens ?? 0)), e.cache_creation_input_tokens != null && s.setAttribute(l_, e.cache_creation_input_tokens), e.cache_read_input_tokens != null && s.setAttribute(u_, e.cache_read_input_tokens);
  const r = e.cache_creation;
  if (r != null && (s.setAttribute(M_, r.ephemeral_5m_input_tokens), s.setAttribute(z_, r.ephemeral_1h_input_tokens)), e.service_tier != null && s.setAttribute(x_, e.service_tier), !t)
    return;
  s.setAttribute(h_, e.output_tokens);
  const i = e.output_tokens_details;
  i != null && s.setAttribute(p_, i.thinking_tokens);
  const a = e.iterations?.filter((o) => o.type === "compaction") ?? [];
  a.length > 0 && (s.setAttribute(O_, a.reduce((o, l) => o + l.input_tokens + l.cache_read_input_tokens + l.cache_creation_input_tokens, 0)), s.setAttribute(C_, a.reduce((o, l) => o + l.output_tokens, 0))), n.stop_reason != null && s.setAttribute(S_, n.stop_reason);
}
function Ns(s, n, e) {
  if (n.isRecording())
    try {
      const t = e.status === "error" ? e.error : void 0, r = e.response?.headers ?? (t instanceof W ? t.headers : void 0);
      for (const [i, a] of I_) {
        const o = r?.get(a);
        o && n.setAttribute(i, o);
      }
    } catch (t) {
      M(s).debug("could not record the API call on its span", t);
    }
}
function or(s, n, e) {
  const t = {
    [$i]: __,
    [Ln]: n.model
  };
  try {
    const r = (f([s._options.defaultHeaders, e]).values.get("anthropic-beta") ?? "").split(",").map((o) => o.trim()).filter(Boolean);
    r.length && (t[v_] = r), t[Jp] = n.max_tokens, n.temperature != null && (t[Qp] = n.temperature), n.top_p != null && (t[e_] = n.top_p), n.top_k != null && (t[Zp] = n.top_k), n.stream === !0 && (t[Xp] = !0), n.output_config?.format?.type === "json_schema" && (t[du] = hu);
    const i = n.output_config?.effort;
    i != null && (t[Yp] = i), n.service_tier != null && (t[A_] = n.service_tier);
    const a = n.thinking;
    a != null && (t[R_] = a.type), a?.type === "enabled" && (t[E_] = a.budget_tokens);
  } catch (r) {
    M(s).debug("could not record the request on its span", r);
  }
  return { route: "/v1/messages", attributes: t };
}
function gu(s, n, e) {
  if (!n?.span.isRecording())
    return n;
  try {
    const { contentMode: t, maxContentBytes: r } = s.openTelemetry.traces;
    t === "content" && Ni(n, e, void 0, r);
  } catch (t) {
    M(s).debug("could not record the request on its span", t);
  }
  return n;
}
function mu(s, n, e, t) {
  if (!n?.span.isRecording() || t instanceof Ne)
    return;
  const r = n.span;
  try {
    fu(r, t, t.usage, !0);
    const { contentMode: i, maxContentBytes: a } = s.openTelemetry.traces;
    i === "content" && Ni(n, e, t.content, a);
  } catch (i) {
    M(s).debug("could not record the response on its span", i);
  }
}
function yu(s, n, e) {
  try {
    n?.span.setAttribute(T_, e.input_tokens);
  } catch (t) {
    M(s).debug("could not record the response on its span", t);
  }
}
function U_(s, n, e) {
  try {
    n?.span.setAttributes({
      [Vp]: e.agent.name,
      [Ln]: e.agent.model.id
    });
  } catch (t) {
    M(s).debug("could not record the response on its span", t);
  }
}
function j_() {
  const s = /* @__PURE__ */ new Set(["traceparent", "tracestate", "baggage"]);
  try {
    for (const n of Vl.fields())
      s.add(n.toLowerCase());
  } catch (n) {
    Xl().debug("could not record telemetry", n);
  }
  return s;
}
function bu(s) {
  const n = j_(), e = Array.from(s.entries()).filter(([t]) => n.has(t));
  for (const [t] of e)
    s.delete(t);
  return e;
}
function F_(s) {
  return (n, e, t) => {
    const r = new Headers(n.headers), i = bu(r);
    return s({ ...n, headers: r }, (a) => {
      const o = new Headers(a.headers);
      for (const [l, d] of i)
        o.set(l, d);
      return e({ ...a, headers: o });
    }, t);
  };
}
function Li(s, n, e, t) {
  if (!(!n.span.isRecording() || s.openTelemetry.traces.contentMode !== "content"))
    try {
      Ni(n, e, t.content, s.openTelemetry.traces.maxContentBytes);
    } catch (r) {
      M(s).debug("could not record the streamed message on its span", r);
    }
}
function W_(s, n, e, t) {
  t.options.__span?.name === "anthropic.messages.create" && e instanceof Ne ? H_(s, n, e, t) : zp(n, e, t);
}
function H_(s, n, e, t) {
  if (!n.isRecording())
    return;
  n.setAttribute(Ci, t.response.status);
  const r = t.options.__span, i = r?.startTime;
  let a, o, l = !1, d = !1, p = !1;
  Zl(e, t.controller.signal, {
    onItem(h) {
      try {
        switch (h.type) {
          case "message_start": {
            const { id: m, model: _, stop_reason: b } = h.message;
            a = { id: m, model: _, stop_reason: b }, o = { ...h.message.usage };
            break;
          }
          case "content_block_start":
            a && h.content_block.type === "fallback" && (a.model = h.content_block.to.model);
            break;
          case "message_delta":
            a && o && (o.output_tokens = h.usage.output_tokens, h.usage.input_tokens != null && (o.input_tokens = h.usage.input_tokens), h.usage.cache_creation_input_tokens != null && (o.cache_creation_input_tokens = h.usage.cache_creation_input_tokens), h.usage.cache_read_input_tokens != null && (o.cache_read_input_tokens = h.usage.cache_read_input_tokens), h.usage.output_tokens_details != null && (o.output_tokens_details = h.usage.output_tokens_details), "iterations" in h.usage && h.usage.iterations != null && (o.iterations = h.usage.iterations), h.delta.stop_reason != null && (a.stop_reason = h.delta.stop_reason), d = !0);
            break;
          case "message_stop":
            p = !0;
            break;
          case "content_block_delta":
            !l && i !== void 0 && n.setAttribute(s_, (Date.now() - i) / 1e3), l = !0;
            break;
          case "content_block_stop":
            break;
          default:
        }
      } catch (m) {
        M(s).debug("could not record the stream on its span", m);
      }
    },
    onEnd(h) {
      try {
        a && o && fu(n, a, o, d || p);
      } catch (_) {
        M(s).debug("could not record the stream on its span", _);
      }
      const m = r?.failure;
      !p && r?.streamed && m === void 0 && Li(s, r, r.streamed.body, r.streamed.message), h.reason === "failed" ? Ye(n, h.error) : m !== void 0 ? Ye(n, m, "client_error") : h.reason === "completed" && (p ? n.setStatus({ code: bt.OK }) : Ye(n, new R("The stream ended before message_stop."), "api_error")), j(s, () => n.end());
    }
  });
}
function D_(s, n, e) {
  return s._tracer?.startSpan("anthropic.environment.work", {
    kind: rr.INTERNAL,
    attributes: {
      [ir]: s._genAIProviderName,
      "anthropic.environment.id": n.environment_id,
      "anthropic.environment.work.id": n.id,
      "anthropic.session.id": n.data.id
    }
  }, e);
}
function wu(s, n) {
  s?.isRecording() && (n.aborted || s.setStatus({ code: bt.OK }), s.end());
}
function vu(s, n, e) {
  s?.isRecording() && (n.aborted || Ye(s, e), s.end());
}
async function K_(s, n, e, t) {
  if (!n)
    return t();
  try {
    await _e.with(wt.setSpan(_e.active(), n), t);
  } catch (r) {
    throw j(s, () => vu(n, e, r)), r;
  }
  j(s, () => wu(n, e));
}
const qn = "x-stainless-helper", qi = "x-stainless-helper-method";
function ku(s) {
  return { [qn]: s };
}
const $e = Symbol("anthropic.sdk.stainlessHelper");
function pt(s) {
  return typeof s == "object" && s !== null && $e in s;
}
function Su(s, n) {
  const e = /* @__PURE__ */ new Set();
  if (s)
    for (const t of s)
      pt(t) && e.add(t[$e]);
  if (n)
    for (const t of n) {
      pt(t) && e.add(t[$e]);
      const r = t.content;
      if (Array.isArray(r))
        for (const i of r) {
          pt(i) && e.add(i[$e]);
          const a = i?.tool?.definition;
          pt(a) && e.add(a[$e]);
        }
    }
  return Array.from(e);
}
function Tu(s, n) {
  const e = Su(s, n);
  return e.length === 0 ? {} : { [qn]: e.join(", ") };
}
function Au(s) {
  return pt(s) ? { [qn]: s[$e] } : {};
}
function G_(s, n, e) {
  if (!s._tracer)
    return;
  const t = n.output_config?.format?.type === "json_schema" || n.output_format?.type === "json_schema";
  return s._tracer.startSpan("anthropic.messages.tool_runner", {
    kind: rr.INTERNAL,
    attributes: {
      [$i]: g_,
      [ir]: s._genAIProviderName,
      [Ln]: n.model,
      ...t ? { [du]: hu } : void 0,
      ...e != null ? { [Oi]: e } : void 0
    }
  });
}
async function Bi(s, n, e, t, r) {
  const i = s._tracer;
  if (!i)
    return r();
  const { signal: a, conversationId: o, sessionID: l, parentContext: d = _e.active() } = t, p = "description" in n ? n.description : void 0, h = {
    [$i]: f_,
    [ir]: s._genAIProviderName,
    [o_]: e.name,
    // Only a call to a member of a toolset, such as `computer`, has one.
    ..."toolset_name" in e && typeof e.toolset_name == "string" ? { [P_]: e.toolset_name } : void 0,
    ...p ? { [a_]: p } : void 0,
    [i_]: e.id,
    [c_]: m_,
    ...o != null ? { [Oi]: o } : void 0,
    ...l != null ? { "anthropic.session.id": l } : void 0,
    // Only a Session event of a child thread has one.
    ..."session_thread_id" in e && e.session_thread_id != null ? { "anthropic.session.thread.id": e.session_thread_id } : void 0
  }, m = e.type === "agent.tool_use" ? "anthropic.tool_use" : pt(n) && n[$e] === "mcpTool" ? "anthropic.mcp_tool_use" : "anthropic.custom_tool_use", _ = j(s, () => i.startSpan(`${m} ${e.name}`, { kind: rr.INTERNAL, attributes: h }, d));
  if (!_)
    return r();
  let b;
  try {
    return b = await _e.with(wt.setSpan(d, _), r), b;
  } finally {
    const y = b !== void 0 && !b.isError, k = !y && a?.aborted === !0, { contentMode: E, maxContentBytes: A } = s.openTelemetry.traces;
    if (E === "content" && _.isRecording())
      try {
        _u(_, {
          [r_]: e.input,
          [ci]: b && !k ? pu(b.content) : void 0
        }, A);
      } catch (T) {
        M(s).debug("could not record the tool run on its span", T);
      }
    j(s, () => {
      y ? _.setStatus({ code: bt.OK }) : k || Ye(_, b, "tool_error"), _.end();
    });
  }
}
const V_ = (s) => {
  if (typeof globalThis.Buffer < "u") {
    const n = globalThis.Buffer.from(s, "base64");
    return new Uint8Array(n.buffer, n.byteOffset, n.byteLength);
  }
  if (typeof atob < "u") {
    const n = atob(s), e = new Uint8Array(n.length);
    for (let t = 0; t < n.length; t++)
      e[t] = n.charCodeAt(t);
    return e;
  }
  throw new R("Cannot decode base64 string; Expected `Buffer` or `atob` to be defined");
};
let li = function() {
  const { crypto: s } = globalThis;
  if (s?.randomUUID)
    return li = s.randomUUID.bind(s), s.randomUUID();
  const n = new Uint8Array(1), e = s ? () => s.getRandomValues(n)[0] : () => Math.random() * 255 & 255;
  return "10000000-1000-4000-8000-100000000000".replace(/[018]/g, (t) => (+t ^ e() & 15 >> +t / 4).toString(16));
};
const xu = "1.0", J_ = /^[A-Za-z0-9_.-]+$/;
function Eu(s) {
  if (!s)
    throw new Error("profile name is empty");
  if (s === "." || s === "..")
    throw new Error(`profile name "${s}" is not allowed`);
  if (s.includes("/") || s.includes("\\"))
    throw new Error(`profile name "${s}" must not contain path separators`);
  if (!J_.test(s))
    throw new Error(`profile name "${s}" contains disallowed characters (allowed: letters, digits, '_', '.', '-')`);
}
const Y_ = async (s) => {
  var n, e;
  const t = await Ui();
  if (t === null)
    return null;
  const r = s ?? await Ru();
  if (r === null)
    return null;
  Eu(r);
  const { fs: i, path: a } = await Promise.resolve().then(() => qe), o = a.join(t, "configs", `${r}.json`);
  let l;
  try {
    l = await i.promises.readFile(o, "utf-8");
  } catch (h) {
    if (h?.code !== "ENOENT")
      throw new Error(`failed to read config file ${o}: ${h}`);
    l = null;
  }
  if (l === null) {
    const h = O("ANTHROPIC_ORGANIZATION_ID"), m = O("ANTHROPIC_IDENTITY_TOKEN_FILE"), _ = O("ANTHROPIC_FEDERATION_RULE_ID");
    return _ && h ? {
      fromFile: !1,
      config: {
        organization_id: h,
        // A defaulted-but-empty CI variable (`ANTHROPIC_WORKSPACE_ID=""`) is
        // treated as unset — readEnv coerces empty to undefined, and the body
        // builder's truthy check skips it — so `"workspace_id": ""` never goes
        // on the wire.
        workspace_id: O("ANTHROPIC_WORKSPACE_ID"),
        base_url: O("ANTHROPIC_BASE_URL"),
        authentication: {
          type: "oidc_federation",
          federation_rule_id: _,
          service_account_id: O("ANTHROPIC_SERVICE_ACCOUNT_ID"),
          identity_token: m ? { source: "file", path: m } : void 0,
          scope: O("ANTHROPIC_SCOPE")
        }
      }
    } : null;
  }
  let d;
  try {
    d = JSON.parse(l);
  } catch (h) {
    throw new Error(`failed to parse config file ${o}: ${h}`);
  }
  if (!d.authentication)
    throw new Error(`config file ${o} is missing "authentication"`);
  const p = d.authentication.type;
  if (p !== "oidc_federation" && p !== "user_oauth")
    throw new Error(`authentication.type "${p}" is not a known authentication type`);
  if (d.organization_id ?? (d.organization_id = O("ANTHROPIC_ORGANIZATION_ID")), d.workspace_id ?? (d.workspace_id = O("ANTHROPIC_WORKSPACE_ID")), d.base_url ?? (d.base_url = O("ANTHROPIC_BASE_URL")), (n = d.authentication).scope ?? (n.scope = O("ANTHROPIC_SCOPE")), d.authentication.type === "oidc_federation") {
    if (!d.authentication.identity_token) {
      const h = O("ANTHROPIC_IDENTITY_TOKEN_FILE");
      h && (d.authentication.identity_token = {
        source: "file",
        path: h
      });
    }
    d.authentication.federation_rule_id || (d.authentication.federation_rule_id = O("ANTHROPIC_FEDERATION_RULE_ID") ?? ""), (e = d.authentication).service_account_id ?? (e.service_account_id = O("ANTHROPIC_SERVICE_ACCOUNT_ID"));
  }
  return { config: d, fromFile: !0 };
}, X_ = async (s, n) => {
  if (s?.authentication.credentials_path)
    return s.authentication.credentials_path;
  const e = await Ui();
  if (!e)
    return null;
  const t = n ?? await Ru();
  if (!t)
    return null;
  Eu(t);
  const { path: r } = await Promise.resolve().then(() => qe);
  return r.join(e, "credentials", `${t}.json`);
}, Ui = async () => {
  if (!Q_())
    return null;
  const { path: s } = await Promise.resolve().then(() => qe), n = O("ANTHROPIC_CONFIG_DIR");
  if (n)
    return n;
  if (Ti()["X-Stainless-OS"] === "Windows") {
    const i = O("APPDATA");
    if (i)
      return s.join(i, "Anthropic");
    const a = O("USERPROFILE");
    return a ? s.join(a, "AppData", "Roaming", "Anthropic") : null;
  }
  const t = O("XDG_CONFIG_HOME");
  if (t)
    return s.join(t, "anthropic");
  const r = O("HOME");
  return r ? s.join(r, ".config", "anthropic") : null;
}, Q_ = () => {
  const s = Ti()["X-Stainless-Runtime"];
  return s === "node" || s === "deno";
}, Ru = async () => {
  const s = await Ui();
  if (!s)
    return null;
  const n = O("ANTHROPIC_PROFILE");
  if (n)
    return n;
  const { fs: e, path: t } = await Promise.resolve().then(() => qe), r = t.join(s, "active_config");
  try {
    return (await e.promises.readFile(r, "utf-8")).trim() || "default";
  } catch (i) {
    if (i?.code !== "ENOENT")
      throw new Error(`failed to read ${r}: ${i}`);
    return "default";
  }
};
function ma(s) {
  if (!s)
    throw new R("Identity token file path is empty");
  return async () => {
    const { fs: n } = await Promise.resolve().then(() => qe);
    let e;
    try {
      e = await n.promises.readFile(s, "utf-8");
    } catch (r) {
      throw new R(`Failed to read identity token file at ${s}: ${r}`);
    }
    const t = e.trim();
    if (!t)
      throw new R(`Identity token file at ${s} is empty`);
    return t;
  };
}
function Z_(s) {
  if (!s)
    throw new R("Identity token value is empty");
  return () => s;
}
function ef(s) {
  return async () => {
    ou(s.baseURL);
    const n = await s.identityTokenProvider();
    if (n.length > 16 * 1024)
      throw new B(`Identity token is ${Math.ceil(n.length / 1024)} KiB, exceeds the 16 KiB assertion limit`);
    const e = {
      grant_type: Up,
      assertion: n,
      federation_rule_id: s.federationRuleId,
      organization_id: s.organizationId
    };
    s.serviceAccountId && (e.service_account_id = s.serviceAccountId), s.workspaceId && (e.workspace_id = s.workspaceId);
    const t = `${s.baseURL}${au}`;
    let r;
    try {
      r = await s.fetch(t, {
        method: "POST",
        redirect: "manual",
        headers: {
          "Content-Type": "application/json",
          "anthropic-beta": `${Js},${Fp}`,
          "User-Agent": s.userAgent || `anthropic-sdk-typescript/${Ie} oidcFederationProvider`
        },
        body: JSON.stringify(e)
      });
    } catch (l) {
      throw new B(`Failed to reach token endpoint ${t}: ${l}`);
    }
    const i = r.headers.get("Request-Id");
    if (!r.ok) {
      const l = await r.text().catch(() => ""), d = me(l);
      let p = "";
      throw r.status === 401 && (p = ` Ensure your federation rule matches your identity token. ${s.workspaceId ? "" : "If your federation rule is scoped to multiple workspaces, set the ANTHROPIC_WORKSPACE_ID environment variable, the 'workspace_id' config key, or the `workspaceId` option. "}View your authentication events in the Workload identity page of Claude Console for more details.`), new B(`Token exchange failed with status ${r.status}${i ? ` (request-id ${i})` : ""}: ${d}${p}`, r.status, d, i);
    }
    const a = await cu(r, i), o = Number(a.expires_in);
    if (!Number.isFinite(o))
      throw new B(`Token endpoint response missing required fields: ${JSON.stringify(me(a))}`, r.status, me(a), i);
    return {
      token: a.access_token,
      expiresAt: gt() + o
    };
  };
}
function tf(s) {
  return async (n) => {
    const { fs: e } = await Promise.resolve().then(() => qe);
    await lu(s.credentialsPath, s.onSafetyWarning);
    let t;
    try {
      t = await e.promises.readFile(s.credentialsPath, "utf-8");
    } catch (k) {
      throw new B(`Credentials file not found at ${s.credentialsPath}: ${k}`);
    }
    let r;
    try {
      r = JSON.parse(t);
    } catch (k) {
      throw new B(`Credentials file at ${s.credentialsPath} is not valid JSON: ${k}`);
    }
    const i = r.access_token;
    if (!i)
      throw new B(`Credentials file at ${s.credentialsPath} must include 'access_token'`);
    const a = r.expires_at;
    if (!n?.forceRefresh && (a == null || gt() < a - Ii))
      return { token: i, expiresAt: a ?? null };
    const o = r.refresh_token;
    if (!s.clientId || !o)
      throw new B(`Access token at ${s.credentialsPath} has expired and no refresh is available (client_id ${s.clientId ? "set" : "empty"}, refresh_token ${o ? "set" : "empty"})`);
    ou(s.baseURL);
    const l = {
      grant_type: jp,
      refresh_token: o,
      client_id: s.clientId
    }, d = `${s.baseURL}${au}`;
    let p;
    try {
      p = await s.fetch(d, {
        method: "POST",
        redirect: "manual",
        headers: {
          "Content-Type": "application/json",
          "anthropic-beta": Js,
          "User-Agent": s.userAgent || `anthropic-sdk-typescript/${Ie} userOAuthProvider`
        },
        body: JSON.stringify(l)
      });
    } catch (k) {
      throw new B(`User OAuth refresh failed to reach token endpoint: ${k}`);
    }
    const h = p.headers.get("Request-Id");
    if (!p.ok) {
      const k = await p.text().catch(() => "");
      throw new B(`User OAuth refresh failed (HTTP ${p.status}): ${me(k)}`, p.status, me(k), h);
    }
    const m = await cu(p, h), _ = Number(m.expires_in);
    if (!Number.isFinite(_))
      throw new B(`User OAuth refresh response missing or invalid expires_in: ${JSON.stringify(me(m))}`, p.status, me(m), h);
    const b = gt() + _, y = m.refresh_token || o;
    return await uu(s.credentialsPath, {
      ...r,
      version: xu,
      type: "oauth_token",
      access_token: m.access_token,
      expires_at: b,
      refresh_token: y
    }), { token: m.access_token, expiresAt: b };
  };
}
function Pu(s, n) {
  const e = s.authentication.credentials_path ?? null, t = (s.base_url || n.baseURL).replace(/\/+$/, ""), r = sf(s, e, t, n), i = {};
  return s.workspace_id && s.authentication.type === "user_oauth" && (i["anthropic-workspace-id"] = s.workspace_id), { provider: r, extraHeaders: i, baseURL: s.base_url || void 0 };
}
async function nf(s, n) {
  const e = await Y_(n);
  if (!e)
    return null;
  const { config: t, fromFile: r } = e, i = t.authentication.credentials_path || !r ? t : {
    ...t,
    authentication: {
      ...t.authentication,
      credentials_path: await X_(t, n) ?? void 0
    }
  };
  return Pu(i, s);
}
function sf(s, n, e, t) {
  switch (s.authentication.type) {
    case "oidc_federation": {
      const r = s.authentication, i = rf(r);
      if (!i)
        throw new B("oidc_federation config requires an identity token (set authentication.identity_token, ANTHROPIC_IDENTITY_TOKEN_FILE, or ANTHROPIC_IDENTITY_TOKEN)");
      if (!r.federation_rule_id)
        throw new B("oidc_federation config requires 'federation_rule_id'. Set it in authentication.federation_rule_id in your profile, or via ANTHROPIC_FEDERATION_RULE_ID (profile takes precedence).");
      if (!s.organization_id)
        throw new B("oidc_federation config requires organization_id (set ANTHROPIC_ORGANIZATION_ID or config.organization_id)");
      const a = ef({
        identityTokenProvider: i,
        federationRuleId: r.federation_rule_id,
        organizationId: s.organization_id,
        serviceAccountId: r.service_account_id,
        workspaceId: s.workspace_id,
        baseURL: e,
        fetch: t.fetch,
        userAgent: t.userAgent
      });
      return n ? af(a, n, t.onCacheWriteError, t.onSafetyWarning) : a;
    }
    case "user_oauth": {
      if (!n)
        throw new B("user_oauth config requires authentication.credentials_path (or load via a profile so it defaults to <config_dir>/credentials/<profile>.json)");
      return tf({
        credentialsPath: n,
        clientId: s.authentication.client_id,
        baseURL: e,
        fetch: t.fetch,
        userAgent: t.userAgent,
        onSafetyWarning: t.onSafetyWarning
      });
    }
    default: {
      const r = s.authentication.type;
      throw new B(`authentication.type "${r}" is not a known authentication type`);
    }
  }
}
function rf(s) {
  if (s.identity_token) {
    const t = s.identity_token.source;
    if (t !== "file")
      throw new B(`identity_token.source "${t}" is not supported by this SDK version (only "file")`);
    if (!s.identity_token.path)
      throw new B('identity_token.source "file" requires a non-empty path');
    return ma(s.identity_token.path);
  }
  const n = O("ANTHROPIC_IDENTITY_TOKEN_FILE");
  if (n)
    return ma(n);
  const e = O("ANTHROPIC_IDENTITY_TOKEN");
  return e ? Z_(e) : null;
}
function af(s, n, e, t) {
  return async (r) => {
    const { fs: i } = await Promise.resolve().then(() => qe);
    await lu(n, t);
    let a;
    try {
      const l = await i.promises.readFile(n, "utf-8");
      a = JSON.parse(l);
      const d = a?.access_token;
      if (d && !r?.forceRefresh) {
        const p = a?.expires_at;
        if (p == null || gt() < p - Ii)
          return { token: d, expiresAt: p ?? null };
      }
    } catch (l) {
      l?.code !== "ENOENT" && !(l instanceof SyntaxError) && e?.(l);
    }
    const o = await s(r);
    try {
      await uu(n, {
        ...a ?? {},
        version: xu,
        type: "oauth_token",
        access_token: o.token,
        expires_at: o.expiresAt
      });
    } catch (l) {
      e?.(l);
    }
    return o;
  };
}
async function zu(s, n) {
  const { response: e, requestLogID: t, retryOfRequestLogID: r, startTime: i } = n, a = await (async () => {
    if (n.options.stream)
      return M(s).debug("response", e.status, e.url, e.headers, e.body), Ne.fromSSEResponse(e, n.controller, s);
    if (e.status === 204)
      return null;
    if (n.options.__binaryResponse)
      return e;
    const l = e.headers.get("content-type")?.split(";")[0]?.trim();
    if (l?.includes("application/json") || l?.endsWith("+json")) {
      if (e.headers.get("content-length") === "0")
        return;
      const m = await e.json();
      return ji(m, e);
    }
    return await e.text();
  })().finally(() => {
    !n.options.stream && !n.options.__binaryResponse && ft(n.controller);
  });
  return Ve(M(s), `[${t}] response parsed`, {
    retryOfRequestLogID: r,
    url: e.url,
    status: e.status,
    body: a,
    durationMs: Date.now() - i
  }), a;
}
function ji(s, n) {
  return !s || typeof s != "object" || Array.isArray(s) ? s : Object.defineProperties(s, {
    _request_id: { value: n.headers.get("request-id"), enumerable: !1 },
    _workspace_id: { value: n.headers.get("anthropic-workspace-id"), enumerable: !1 }
  });
}
const Mu = /* @__PURE__ */ new WeakSet();
function Ou(s) {
  return typeof s == "object" && s !== null && Mu.has(s);
}
function of(s) {
  const n = /* @__PURE__ */ new Set();
  for (; typeof s == "object" && s !== null && !n.has(s); ) {
    if (n.add(s), Ou(s) || yt(s) || s instanceof Ht || s instanceof Cd)
      return !0;
    s = s.cause;
  }
  return !1;
}
function ya(s, n, e, t) {
  return async (r, i = {}) => {
    if (n.length === 0)
      return s.call(void 0, r, i);
    const a = i.headers instanceof Headers ? i.headers : new Headers(i.headers), o = await lf(s, n, e, t)({
      ...i,
      headers: a,
      url: typeof r == "string" ? r : r instanceof URL ? r.href : r.url
    });
    if (o.bodyUsed || o.body?.locked)
      throw new R("middleware consumed the response body; use response.clone() to inspect it, or return new Response(body, response) to consume and replace it");
    return o;
  };
}
function cf(s, n) {
  const e = /* @__PURE__ */ new WeakMap();
  return {
    options: s,
    // Resolved per chain, so changes to the client's `logLevel`/`logger`
    // apply to subsequent requests.
    logger: n ? M(n) : Xl(),
    parse(t) {
      if (s?.stream && t.ok)
        return ba(t, s, n);
      let r = e.get(t);
      return r || (r = ba(t, s, n), e.set(t, r)), r;
    }
  };
}
async function ba(s, n, e) {
  if (s.bodyUsed || s.body?.locked)
    throw new R("cannot ctx.parse() a response whose body was already consumed; call ctx.parse() instead of reading the body, or read via response.clone()");
  if (n?.stream && s.ok)
    return Ne.fromSSEResponse(s.clone(), new AbortController(), e);
  if (s.status === 204)
    return null;
  if (n?.__binaryResponse)
    return s;
  const r = s.headers.get("content-type")?.split(";")[0]?.trim();
  return r?.includes("application/json") || r?.endsWith("+json") ? s.headers.get("content-length") === "0" ? void 0 : ji(await s.clone().json(), s) : await s.clone().text();
}
function lf(s, n, e, t) {
  let r = async ({ url: a, ...o }) => {
    try {
      return await s.call(void 0, a, o);
    } catch (l) {
      const d = Ws(l);
      throw Mu.add(d), d;
    }
  };
  const i = cf(e, t);
  for (let a = n.length - 1; a >= 0; a--) {
    const o = n[a], l = r;
    r = async (d) => o(d, l, i);
  }
  return r;
}
const Cu = () => {
  if (typeof File > "u") {
    const { process: s } = globalThis, n = typeof s?.versions?.node == "string" && parseInt(s.versions.node.split(".")) < 20;
    throw new Error("`File` is not defined as a global, which is required for file uploads." + (n ? " Update to Node 20 LTS or newer, or set `globalThis.File` to `import('node:buffer').File`." : ""));
  }
};
function Bt(s, n, e) {
  return Cu(), new File(s, n ?? "", e);
}
function Ls(s, n) {
  const e = typeof s == "object" && s !== null && ("name" in s && s.name && String(s.name) || "url" in s && s.url && String(s.url) || "filename" in s && s.filename && String(s.filename) || "path" in s && s.path && String(s.path)) || "";
  return n ? e.split(/[\\/]/).pop() || void 0 : e;
}
const Fi = (s) => s != null && typeof s == "object" && typeof s[Symbol.asyncIterator] == "function", Le = async (s, n, e = !0) => {
  try {
    return { ...s, body: await df(s.body, n, e) };
  } catch (t) {
    const r = s.__span?.span;
    throw r && j(typeof n == "function" ? void 0 : n, () => zn(r, { status: "error", options: s, error: t })), t;
  }
}, wa = /* @__PURE__ */ new WeakMap();
function uf(s) {
  const n = typeof s == "function" ? s : s.fetch, e = wa.get(n);
  if (e)
    return e;
  const t = (async () => {
    try {
      const r = "Response" in n ? n.Response : (await n("data:,")).constructor, i = new FormData();
      return i.toString() !== await new r(i).text();
    } catch {
      return !0;
    }
  })();
  return wa.set(n, t), t;
}
const df = async (s, n, e = !0) => {
  if (!await uf(n))
    throw new TypeError("The provided fetch function does not support file uploads with the current global FormData class.");
  const t = new FormData();
  return await Promise.all(Object.entries(s || {}).map(([r, i]) => ui(t, r, i, e))), t;
}, ui = async (s, n, e, t) => {
  if (e !== void 0) {
    if (e == null)
      throw new TypeError(`Received null for "${n}"; to pass null in FormData, you must use the string 'null'`);
    if (typeof e == "string" || typeof e == "number" || typeof e == "boolean")
      s.append(n, String(e));
    else if (e instanceof Response) {
      let r = {};
      const i = e.headers.get("Content-Type");
      i && (r = { type: i }), s.append(n, Bt([await e.blob()], Ls(e, t), r));
    } else if (Fi(e))
      s.append(n, Bt([await new Response($l(e)).blob()], Ls(e, t)));
    else if (e instanceof Blob) {
      const i = typeof File < "u" && e instanceof File ? e.name : Ls(e, t);
      s.append(n, Bt([e], i, { type: e.type }));
    } else if (Array.isArray(e))
      await Promise.all(e.map((r) => ui(s, n + "[]", r, t)));
    else {
      if (typeof e.then == "function")
        throw new TypeError(`Received a Promise for "${n}"; await it first, e.g. \`await toFile(...)\``);
      if (e instanceof ArrayBuffer || ArrayBuffer.isView(e))
        throw new TypeError(`Received ${e.constructor.name} for "${n}"; to upload raw bytes, wrap them with \`await toFile(bytes, 'filename')\``);
      if (typeof e == "object")
        await Promise.all(Object.entries(e).map(([r, i]) => ui(s, `${n}[${r}]`, i, t)));
      else
        throw new TypeError(`Invalid value given to form, expected a string, number, boolean, object, Array, File or Blob but got ${e} instead`);
    }
  }
};
var J, di = /* @__PURE__ */ (() => {
  class s extends Promise {
    constructor(e, t, r = zu) {
      super((i) => {
        i(null);
      }), this.responsePromise = t, this.parseResponse = r, J.set(this, void 0), w(this, J, e);
    }
    _thenUnwrap(e) {
      return new s(c(this, J, "f"), this.responsePromise, async (t, r) => ji(e(await this.parseResponse(t, r), r), r.response));
    }
    /**
     * Gets the raw `Response` instance instead of parsing the response
     * data.
     *
     * If you want to parse the response body but still get the `Response`
     * instance, you can use {@link withResponse()}.
     *
     * 👋 Getting the wrong TypeScript type for `Response`?
     * Try setting `"moduleResolution": "NodeNext"` or add `"lib": ["DOM"]`
     * to your `tsconfig.json`.
     */
    asResponse() {
      return this.responsePromise.then((e) => {
        const t = e.options.__span?.span;
        if (t && !this.parsedPromise) {
          const r = { status: "success", ...e, data: void 0 };
          Ns(c(this, J, "f"), t, r), j(c(this, J, "f"), () => zn(t, r));
        }
        return e.response;
      });
    }
    /**
     * Gets the parsed response data, the raw `Response` instance and the ID of the request,
     * returned via the `request-id` header which is useful for debugging requests and resporting
     * issues to Anthropic.
     *
     * If you just want to get the raw `Response` instance without parsing it,
     * you can use {@link asResponse()}.
     *
     * 👋 Getting the wrong TypeScript type for `Response`?
     * Try setting `"moduleResolution": "NodeNext"` or add `"lib": ["DOM"]`
     * to your `tsconfig.json`.
     */
    async withResponse() {
      const [e, t] = await Promise.all([this.parse(), this.asResponse()]);
      return {
        data: e,
        response: t,
        request_id: t.headers.get("request-id"),
        workspace_id: t.headers.get("anthropic-workspace-id")
      };
    }
    parse() {
      return this.parsedPromise || (this.parsedPromise = this.responsePromise.then((e) => this.parseResponseTraced(e))), this.parsedPromise;
    }
    /**
     * Parses the body of an API call. When the call has a span, the span ends with the parse, or,
     * when the parse returns a streamed body, when the application has read that stream.
     */
    async parseResponseTraced(e) {
      const t = e.options.__span;
      if (!t)
        return this.parseResponse(c(this, J, "f"), e);
      const { span: r } = t;
      let i;
      try {
        i = await this.parseResponse(c(this, J, "f"), e);
      } catch (o) {
        const l = { status: "error", ...e, error: o };
        throw Ns(c(this, J, "f"), r, l), j(c(this, J, "f"), () => zn(r, l)), o;
      }
      const a = { status: "success", ...e, data: i };
      return j(c(this, J, "f"), () => Tp(t, i)), Ns(c(this, J, "f"), r, a), e.options.stream && Fi(i) ? j(c(this, J, "f"), () => W_(c(this, J, "f"), r, i, e)) : j(c(this, J, "f"), () => zn(r, a)), i;
    }
    then(e, t) {
      return this.parse().then(e, t);
    }
    catch(e) {
      return this.parse().catch(e);
    }
    finally(e) {
      return this.parse().finally(e);
    }
  }
  return J = /* @__PURE__ */ new WeakMap(), s;
})(), Zt, cr = /* @__PURE__ */ (() => {
  class s {
    constructor(e, t, r, i) {
      Zt.set(this, void 0), w(this, Zt, e), this.options = i, this.response = t, this.body = r;
    }
    hasNextPage() {
      return this.getPaginatedItems().length ? this.nextPageRequestOptions() != null : !1;
    }
    async getNextPage() {
      const e = this.nextPageRequestOptions();
      if (!e)
        throw new R("No next page expected; please check `.hasNextPage()` before calling `.getNextPage()`.");
      const t = this.options.__span;
      return await c(this, Zt, "f").requestAPIList(this.constructor, {
        ...e,
        __span: t && u(c(this, Zt, "f"), t.name, { openTelemetry: this.options.openTelemetry }, {
          route: t.route,
          queryParams: t.queryParams,
          contentQueryParams: t.contentQueryParams,
          attributes: t.attributes
        })
      });
    }
    async *iterPages() {
      let e = this;
      for (yield e; e.hasNextPage(); )
        e = await e.getNextPage(), yield e;
    }
    async *[(Zt = /* @__PURE__ */ new WeakMap(), Symbol.asyncIterator)]() {
      for await (const e of this.iterPages())
        for (const t of e.getPaginatedItems())
          yield t;
    }
  }
  return s;
})(), va = /* @__PURE__ */ (() => {
  class s extends di {
    constructor(e, t, r) {
      super(e, t, async (i, a) => new r(i, a.response, await zu(i, a), a.options));
    }
    /**
     * Allow auto-paginating iteration on an unawaited list call, eg:
     *
     *    for await (const item of client.items.list()) {
     *      console.log(item)
     *    }
     */
    async *[Symbol.asyncIterator]() {
      const e = await this;
      for await (const t of e)
        yield t;
    }
  }
  return s;
})();
class Y extends cr {
  constructor(n, e, t, r) {
    super(n, e, t, r), this.data = t.data || [], this.has_more = t.has_more || !1, this.first_id = t.first_id || null, this.last_id = t.last_id || null;
  }
  getPaginatedItems() {
    return this.data ?? [];
  }
  hasNextPage() {
    return this.has_more === !1 ? !1 : super.hasNextPage();
  }
  nextPageRequestOptions() {
    if (this.options.query?.before_id) {
      const e = this.first_id;
      return e ? {
        ...this.options,
        query: {
          ...Mn(this.options.query),
          before_id: e
        }
      } : null;
    }
    const n = this.last_id;
    return n ? {
      ...this.options,
      query: {
        ...Mn(this.options.query),
        after_id: n
      }
    } : null;
  }
}
class z extends cr {
  constructor(n, e, t, r) {
    super(n, e, t, r), this.data = t.data || [], this.next_page = t.next_page || null;
  }
  getPaginatedItems() {
    return this.data ?? [];
  }
  hasNextPage() {
    return this.nextPageRequestOptions() != null;
  }
  nextPageRequestOptions() {
    const n = this.next_page;
    return n ? {
      ...this.options,
      query: {
        ...Mn(this.options.query),
        page: n
      }
    } : null;
  }
}
class hf extends cr {
  constructor(n, e, t, r) {
    super(n, e, t, r), this.data = t.data || [], this.next_page = t.next_page || null, this.prev_page = t.prev_page || null;
  }
  getPaginatedItems() {
    return this.data ?? [];
  }
  hasNextPage() {
    return this.nextPageRequestOptions() != null;
  }
  nextPageRequestOptions() {
    const n = this.next_page;
    return n ? {
      ...this.options,
      query: {
        ...Mn(this.options.query),
        page: n
      }
    } : null;
  }
}
class lr extends cr {
  constructor(n, e, t, r) {
    super(n, e, t, r), this.data = t.data || [], this.next_page = t.next_page || null, this.has_more = t.has_more || !1, this.data_refreshed_at = t.data_refreshed_at || null;
  }
  getPaginatedItems() {
    return this.data ?? [];
  }
  hasNextPage() {
    return this.has_more === !1 ? !1 : this.nextPageRequestOptions() != null;
  }
  nextPageRequestOptions() {
    const n = this.next_page;
    return n ? {
      ...this.options,
      query: {
        ...Mn(this.options.query),
        page: n
      }
    } : null;
  }
}
const Iu = (s) => s != null && typeof s == "object" && typeof s.size == "number" && typeof s.type == "string" && typeof s.text == "function" && typeof s.slice == "function" && typeof s.arrayBuffer == "function", pf = (s) => s != null && typeof s == "object" && typeof s.name == "string" && typeof s.lastModified == "number" && Iu(s), _f = (s) => s != null && typeof s == "object" && typeof s.url == "string" && typeof s.blob == "function";
async function ff(s, n, e) {
  if (Cu(), s = await s, n || (n = s instanceof File ? s.name : Ls(s, !0)), pf(s))
    return s instanceof File && n == null && e == null ? s : Bt([await s.arrayBuffer()], n ?? s.name, {
      type: s.type,
      lastModified: s.lastModified,
      ...e
    });
  if (_f(s)) {
    const r = await s.blob();
    return n || (n = new URL(s.url).pathname.split(/[\\/]/).pop()), Bt(await hi(r), n, e);
  }
  const t = await hi(s);
  if (!e?.type) {
    const r = t.find((i) => typeof i == "object" && "type" in i && i.type);
    typeof r == "string" && (e = { ...e, type: r });
  }
  return Bt(t, n, e);
}
async function hi(s) {
  let n = [];
  if (typeof s == "string" || ArrayBuffer.isView(s) || // includes Uint8Array, Buffer, etc.
  s instanceof ArrayBuffer)
    n.push(s);
  else if (Iu(s))
    n.push(s instanceof Blob ? s : await s.arrayBuffer());
  else if (Fi(s))
    for await (const e of s)
      n.push(...await hi(e));
  else {
    const e = s?.constructor?.name;
    throw new Error(`Unexpected data type: ${typeof s}${e ? `; constructor: ${e}` : ""}${gf(s)}`);
  }
  return n;
}
function gf(s) {
  return typeof s != "object" || s === null ? "" : `; props: [${Object.getOwnPropertyNames(s).map((e) => `"${e}"`).join(", ")}]`;
}
class x {
  constructor(n) {
    this._client = n;
  }
}
function $u(s, n) {
  const { user_profile_id: e, workspace_id: t, tools: r, messages: i } = s;
  return f([
    {
      ...e != null ? { "anthropic-user-profile-id": e } : void 0,
      ...t != null ? { "anthropic-workspace-id": t } : void 0
    },
    Tu(r, i),
    n?.headers
  ]);
}
function mf(s, n, e) {
  if (!s._tracer)
    return;
  const t = $u(n, e);
  return u(s, "anthropic.messages.create", e, or(s, { ...n, stream: !0 }, t));
}
function Nu(s) {
  return s?.output_config?.format;
}
function ka(s, n, e) {
  const t = Nu(n);
  return !n || !("parse" in (t ?? {})) ? {
    ...s,
    content: s.content.map((r) => r.type === "text" ? Object.defineProperty({ ...r }, "parsed_output", {
      value: null,
      enumerable: !1
    }) : r),
    parsed_output: null
  } : Lu(s, n);
}
function Lu(s, n, e) {
  let t = null;
  const r = s.content.map((i) => {
    if (i.type === "text") {
      const a = yf(n, i.text);
      return t === null && (t = a), Object.defineProperty({ ...i }, "parsed_output", {
        value: a,
        enumerable: !1
      });
    }
    return i;
  });
  return {
    ...s,
    content: r,
    parsed_output: t
  };
}
function yf(s, n) {
  const e = Nu(s);
  if (e?.type !== "json_schema")
    return null;
  try {
    return "parse" in e ? e.parse(n) : JSON.parse(n);
  } catch (t) {
    throw new R(`Failed to parse structured output: ${t}`);
  }
}
const bf = (s) => {
  let n = 0, e = [];
  for (; n < s.length; ) {
    let t = s[n];
    if (t === "\\") {
      n++;
      continue;
    }
    if (t === "{") {
      e.push({
        type: "brace",
        value: "{"
      }), n++;
      continue;
    }
    if (t === "}") {
      e.push({
        type: "brace",
        value: "}"
      }), n++;
      continue;
    }
    if (t === "[") {
      e.push({
        type: "paren",
        value: "["
      }), n++;
      continue;
    }
    if (t === "]") {
      e.push({
        type: "paren",
        value: "]"
      }), n++;
      continue;
    }
    if (t === ":") {
      e.push({
        type: "separator",
        value: ":"
      }), n++;
      continue;
    }
    if (t === ",") {
      e.push({
        type: "delimiter",
        value: ","
      }), n++;
      continue;
    }
    if (t === '"') {
      const o = n + 1;
      let l = o, d = !1;
      for (; ; ) {
        if (l = s.indexOf('"', l), l === -1) {
          d = !0;
          break;
        }
        let p = 0, h = l - 1;
        for (; h >= o && s[h] === "\\"; )
          p++, h--;
        if (p % 2 === 0)
          break;
        l++;
      }
      d ? n = s.length : (e.push({
        type: "string",
        value: s.slice(o, l)
      }), n = l + 1);
      continue;
    }
    if (t && /\s/.test(t)) {
      n++;
      continue;
    }
    let i = /[0-9]/;
    if (t && i.test(t) || t === "-" || t === ".") {
      let o = "";
      for (t === "-" && (o += t, t = s[++n]); t && (i.test(t) || t === "." || // exponent marker, e.g. `1e10` or `1.5E-9`
      t === "e" || t === "E" || // exponent sign, only valid immediately after the exponent marker
      (t === "-" || t === "+") && (o[o.length - 1] === "e" || o[o.length - 1] === "E")); )
        o += t, t = s[++n];
      e.push({
        type: "number",
        value: o,
        unterminated: n === s.length
      });
      continue;
    }
    let a = /[a-z]/i;
    if (t && a.test(t)) {
      let o = "";
      for (; t && a.test(t) && n !== s.length; )
        o += t, t = s[++n];
      if (o == "true" || o == "false" || o === "null")
        e.push({
          type: "name",
          value: o
        });
      else {
        n++;
        continue;
      }
      continue;
    }
    n++;
  }
  return e;
}, wf = (s) => {
  let n = [];
  for (const i of s)
    (i.type === "brace" || i.type === "paren") && (i.value === "{" || i.value === "[" ? n.push(i.value) : n.pop());
  let e = n[n.length - 1], t = s.length, r = /^-?(0|[1-9][0-9]*)(\.[0-9]+)?([eE][-+]?[0-9]+)?$/;
  for (; t > 0; ) {
    let i = s[t - 1];
    switch (i.type) {
      case "separator":
        t--;
        continue;
      case "number":
        if (i.unterminated || !r.test(i.value)) {
          t--;
          continue;
        }
        break;
      case "string":
        let a = s[t - 2];
        if (e === "{" && (a?.type === "delimiter" || a?.type === "brace" && a.value === "{")) {
          t--;
          continue;
        }
        break;
      case "delimiter":
        t--;
        break;
    }
    break;
  }
  return s.slice(0, t);
}, vf = (s) => {
  let n = [];
  return s.map((e) => {
    e.type === "brace" && (e.value === "{" ? n.push("}") : n.splice(n.lastIndexOf("}"), 1)), e.type === "paren" && (e.value === "[" ? n.push("]") : n.splice(n.lastIndexOf("]"), 1));
  }), n.length > 0 && n.reverse().map((e) => {
    e === "}" ? s.push({
      type: "brace",
      value: "}"
    }) : e === "]" && s.push({
      type: "paren",
      value: "]"
    });
  }), s;
}, kf = (s) => {
  let n = "";
  return s.map((e) => {
    switch (e.type) {
      case "string":
        n += '"' + e.value + '"';
        break;
      default:
        n += e.value;
        break;
    }
  }), n;
}, Sf = (s) => JSON.parse(kf(vf(wf(bf(s))))), Ut = "__json_buf";
function qu(s, n) {
  const e = {};
  for (const i of Object.keys(s))
    i !== "input" && (e[i] = s[i]);
  Object.defineProperty(e, Ut, { value: n, enumerable: !1, writable: !0 });
  let t, r = !1;
  return Object.defineProperty(e, "input", {
    enumerable: !0,
    configurable: !0,
    get() {
      return r || (t = n ? Sf(n) : {}, r = !0), t;
    }
  }), e;
}
var ge, je, we, en, Hn, tn, nn, Dn, sn, ve, rn, Kn, Gn, et, Vn, Jn, Yn, an, tt, X, Tr, Sa, Ar, xr, Er, Rr, Ta;
function Pr(s) {
  return s.type === "tool_use" || s.type === "server_tool_use";
}
var Tf = /* @__PURE__ */ (() => {
  class s {
    constructor(e, t) {
      ge.add(this), this.messages = [], this.receivedMessages = [], je.set(this, void 0), we.set(this, null), this.controller = new AbortController(), en.set(this, void 0), Hn.set(this, () => {
      }), tn.set(this, () => {
      }), nn.set(this, void 0), Dn.set(this, () => {
      }), sn.set(this, () => {
      }), ve.set(this, {}), rn.set(this, !1), Kn.set(this, !1), Gn.set(this, !1), et.set(this, !1), Vn.set(this, void 0), Jn.set(this, void 0), Yn.set(this, void 0), an.set(this, void 0), tt.set(this, void 0), X.set(this, void 0), Ar.set(this, (r) => {
        if (w(this, Kn, !0), c(this, X, "f") && (c(this, X, "f").streamed = void 0), yt(r) && (r = new he()), r instanceof he)
          return w(this, Gn, !0), this._emit("abort", r);
        if (r instanceof R)
          return this._emit("error", r);
        if (r instanceof Error) {
          const i = new R(r.message);
          return i.cause = r, this._emit("error", i);
        }
        return this._emit("error", new R(String(r)));
      }), w(this, en, new Promise((r, i) => {
        w(this, Hn, r, "f"), w(this, tn, i, "f");
      })), w(this, nn, new Promise((r, i) => {
        w(this, Dn, r, "f"), w(this, sn, i, "f");
      })), c(this, en, "f").catch(() => {
      }), c(this, nn, "f").catch(() => {
      }), w(this, we, e), w(this, an, t?.logger ?? console), w(this, tt, t?.client);
    }
    get response() {
      return c(this, Vn, "f");
    }
    get request_id() {
      return c(this, Jn, "f");
    }
    get workspace_id() {
      return c(this, Yn, "f");
    }
    /**
     * Returns the `MessageStream` data, the raw `Response` instance and the ID of the request,
     * returned vie the `request-id` header which is useful for debugging requests and resporting
     * issues to Anthropic.
     *
     * This is the same as the `APIPromise.withResponse()` method.
     *
     * This method will raise an error if you created the stream using `MessageStream.fromReadableStream`
     * as no `Response` is available.
     */
    async withResponse() {
      w(this, et, !0);
      const e = await c(this, en, "f");
      if (!e)
        throw new Error("Could not resolve a `Response` object");
      return {
        data: this,
        response: e,
        request_id: e.headers.get("request-id"),
        workspace_id: e.headers.get("anthropic-workspace-id")
      };
    }
    /**
     * Intended for use on the frontend, consuming a stream produced with
     * `.toReadableStream()` on the backend.
     *
     * Note that messages sent to the model do not appear in `.on('message')`
     * in this context.
     */
    static fromReadableStream(e) {
      const t = new s(null);
      return t._run(() => t._fromReadableStream(e)), t;
    }
    static createMessage(e, t, r, { logger: i, client: a } = {}) {
      const o = new s(t, { logger: i, client: a });
      for (const l of t.messages)
        o._addMessageParam(l);
      return w(o, we, { ...t, stream: !0 }), o._run(() => o._createMessage(e, { ...t, stream: !0 }, { ...r, headers: { ...r?.headers, [qi]: "stream" } })), o;
    }
    _run(e) {
      e().then(() => {
        this._emitFinal(), this._emit("end");
      }, c(this, Ar, "f"));
    }
    _addMessageParam(e) {
      this.messages.push(e);
    }
    _addMessage(e, t = !0) {
      this.receivedMessages.push(e), t && this._emit("message", e);
    }
    async _createMessage(e, t, r) {
      const i = r?.signal;
      let a;
      i && (i.aborted && this.controller.abort(), a = this.controller.abort.bind(this.controller), i.addEventListener("abort", a));
      try {
        c(this, ge, "m", xr).call(this), w(this, X, r?.__span ?? (c(this, tt, "f") && mf(c(this, tt, "f"), t, r)), "f");
        const { response: o, data: l } = await e.create({ ...t, stream: !0 }, { ...r, __span: c(this, X, "f"), signal: this.controller.signal }).withResponse();
        try {
          this._connected(o);
        } catch (d) {
          throw c(this, X, "f") && (c(this, X, "f").failure = d), l.controller.abort(), d;
        }
        for await (const d of l)
          try {
            c(this, ge, "m", Er).call(this, d);
          } catch (p) {
            throw c(this, X, "f") && (c(this, X, "f").failure = p), p;
          }
        if (l.controller.signal?.aborted)
          throw new he();
        c(this, ge, "m", Rr).call(this);
      } finally {
        i && a && i.removeEventListener("abort", a);
      }
    }
    _connected(e) {
      this.ended || (w(this, Vn, e), w(this, Jn, e?.headers.get("request-id")), w(this, Yn, e?.headers.get("anthropic-workspace-id")), c(this, Hn, "f").call(this, e), this._emit("connect"));
    }
    get ended() {
      return c(this, rn, "f");
    }
    get errored() {
      return c(this, Kn, "f");
    }
    get aborted() {
      return c(this, Gn, "f");
    }
    abort() {
      this.controller.abort();
    }
    /**
     * Adds the listener function to the end of the listeners array for the event.
     * No checks are made to see if the listener has already been added. Multiple calls passing
     * the same combination of event and listener will result in the listener being added, and
     * called, multiple times.
     * @returns this MessageStream, so that calls can be chained
     */
    on(e, t) {
      return (c(this, ve, "f")[e] || (c(this, ve, "f")[e] = [])).push({ listener: t }), this;
    }
    /**
     * Removes the specified listener from the listener array for the event.
     * off() will remove, at most, one instance of a listener from the listener array. If any single
     * listener has been added multiple times to the listener array for the specified event, then
     * off() must be called multiple times to remove each instance.
     * @returns this MessageStream, so that calls can be chained
     */
    off(e, t) {
      const r = c(this, ve, "f")[e];
      if (!r)
        return this;
      const i = r.findIndex((a) => a.listener === t);
      return i >= 0 && r.splice(i, 1), this;
    }
    /**
     * Adds a one-time listener function for the event. The next time the event is triggered,
     * this listener is removed and then invoked.
     * @returns this MessageStream, so that calls can be chained
     */
    once(e, t) {
      return (c(this, ve, "f")[e] || (c(this, ve, "f")[e] = [])).push({ listener: t, once: !0 }), this;
    }
    /**
     * This is similar to `.once()`, but returns a Promise that resolves the next time
     * the event is triggered, instead of calling a listener callback.
     * @returns a Promise that resolves the next time given event is triggered,
     * or rejects if an error is emitted.  (If you request the 'error' event,
     * returns a promise that resolves with the error).
     *
     * Example:
     *
     *   const message = await stream.emitted('message') // rejects if the stream errors
     */
    emitted(e) {
      return new Promise((t, r) => {
        w(this, et, !0), e !== "error" && this.once("error", r), this.once(e, t);
      });
    }
    async done() {
      w(this, et, !0), await c(this, nn, "f");
    }
    get currentMessage() {
      return c(this, je, "f");
    }
    /**
     * @returns a promise that resolves with the the final assistant Message response,
     * or rejects if an error occurred or the stream ended prematurely without producing a Message.
     * If structured outputs were used, this will be a ParsedMessage with a `parsed_output` field.
     */
    async finalMessage() {
      return await this.done(), c(this, ge, "m", Tr).call(this);
    }
    /**
     * @returns a promise that resolves with the the final assistant Message's text response, concatenated
     * together if there are more than one text blocks.
     * Rejects if an error occurred or the stream ended prematurely without producing a Message.
     */
    async finalText() {
      return await this.done(), c(this, ge, "m", Sa).call(this);
    }
    _emit(e, ...t) {
      if (c(this, rn, "f"))
        return;
      e === "end" && (w(this, rn, !0), c(this, Dn, "f").call(this));
      const r = c(this, ve, "f")[e];
      if (r && (c(this, ve, "f")[e] = r.filter((i) => !i.once), r.forEach(({ listener: i }) => i(...t))), e === "abort") {
        const i = t[0];
        !c(this, et, "f") && !r?.length && Promise.reject(i), c(this, tn, "f").call(this, i), c(this, sn, "f").call(this, i), this._emit("end");
        return;
      }
      if (e === "error") {
        const i = t[0];
        !c(this, et, "f") && !r?.length && Promise.reject(i), c(this, tn, "f").call(this, i), c(this, sn, "f").call(this, i), this._emit("end");
      }
    }
    _emitFinal() {
      this.receivedMessages.at(-1) && this._emit("finalMessage", c(this, ge, "m", Tr).call(this));
    }
    async _fromReadableStream(e, t) {
      const r = t?.signal;
      let i;
      r && (r.aborted && this.controller.abort(), i = this.controller.abort.bind(this.controller), r.addEventListener("abort", i));
      try {
        c(this, ge, "m", xr).call(this), this._connected(null);
        const a = Ne.fromReadableStream(e, this.controller);
        for await (const o of a)
          c(this, ge, "m", Er).call(this, o);
        if (a.controller.signal?.aborted)
          throw new he();
        c(this, ge, "m", Rr).call(this);
      } finally {
        r && i && r.removeEventListener("abort", i);
      }
    }
    [(je = /* @__PURE__ */ new WeakMap(), we = /* @__PURE__ */ new WeakMap(), en = /* @__PURE__ */ new WeakMap(), Hn = /* @__PURE__ */ new WeakMap(), tn = /* @__PURE__ */ new WeakMap(), nn = /* @__PURE__ */ new WeakMap(), Dn = /* @__PURE__ */ new WeakMap(), sn = /* @__PURE__ */ new WeakMap(), ve = /* @__PURE__ */ new WeakMap(), rn = /* @__PURE__ */ new WeakMap(), Kn = /* @__PURE__ */ new WeakMap(), Gn = /* @__PURE__ */ new WeakMap(), et = /* @__PURE__ */ new WeakMap(), Vn = /* @__PURE__ */ new WeakMap(), Jn = /* @__PURE__ */ new WeakMap(), Yn = /* @__PURE__ */ new WeakMap(), an = /* @__PURE__ */ new WeakMap(), tt = /* @__PURE__ */ new WeakMap(), X = /* @__PURE__ */ new WeakMap(), Ar = /* @__PURE__ */ new WeakMap(), ge = /* @__PURE__ */ new WeakSet(), Tr = function() {
      if (this.receivedMessages.length === 0)
        throw new R("stream ended without producing a Message with role=assistant");
      return this.receivedMessages.at(-1);
    }, Sa = function() {
      if (this.receivedMessages.length === 0)
        throw new R("stream ended without producing a Message with role=assistant");
      const t = this.receivedMessages.at(-1).content.filter((r) => r.type === "text").map((r) => r.text);
      if (t.length === 0)
        throw new R("stream ended without producing a content block with type=text");
      return t.join(" ");
    }, xr = function() {
      this.ended || w(this, je, void 0);
    }, Er = function(t) {
      if (this.ended)
        return;
      const r = c(this, ge, "m", Ta).call(this, t);
      if (this._emit("_rawEvent", t), !!r)
        switch (this._emit("streamEvent", t, r), t.type) {
          case "content_block_delta": {
            const i = r.content.at(-1);
            switch (t.delta.type) {
              case "text_delta": {
                i.type === "text" && this._emit("text", t.delta.text, i.text || "");
                break;
              }
              case "citations_delta": {
                i.type === "text" && this._emit("citation", t.delta.citation, i.citations ?? []);
                break;
              }
              case "input_json_delta": {
                Pr(i) && c(this, ve, "f").inputJson?.length && this._emit("inputJson", t.delta.partial_json, i.input);
                break;
              }
              case "thinking_delta": {
                i.type === "thinking" && this._emit("thinking", t.delta.thinking, i.thinking);
                break;
              }
              case "signature_delta": {
                i.type === "thinking" && this._emit("signature", i.signature);
                break;
              }
              default:
                t.delta;
            }
            break;
          }
          case "message_stop": {
            c(this, tt, "f") && c(this, X, "f") && c(this, we, "f") && Li(c(this, tt, "f"), c(this, X, "f"), c(this, we, "f"), r), this._addMessageParam(r), this._addMessage(ka(r, c(this, we, "f"), { logger: c(this, an, "f") }), !0);
            break;
          }
          case "content_block_stop": {
            this._emit("contentBlock", r.content.at(-1));
            break;
          }
          case "message_start": {
            w(this, je, r), c(this, X, "f") && c(this, we, "f") && (c(this, X, "f").streamed = { body: c(this, we, "f"), message: r });
            break;
          }
        }
    }, Rr = function() {
      if (this.ended)
        throw new R("stream has ended, this shouldn't happen");
      const t = c(this, je, "f");
      if (!t)
        throw new R("request ended without sending any chunks");
      return w(this, je, void 0), ka(t, c(this, we, "f"), { logger: c(this, an, "f") });
    }, Ta = function(t) {
      let r = c(this, je, "f");
      if (t.type === "message_start") {
        if (r)
          throw new R(`Unexpected event order, got ${t.type} before receiving "message_stop"`);
        return t.message;
      }
      if (r)
        switch (t.type) {
          case "message_stop":
            return r;
          case "message_delta":
            return r.stop_reason = t.delta.stop_reason, r.stop_sequence = t.delta.stop_sequence, r.stop_details = t.delta.stop_details, r.usage.output_tokens = t.usage.output_tokens, t.delta.container != null && (r.container = t.delta.container), t.usage.input_tokens != null && (r.usage.input_tokens = t.usage.input_tokens), t.usage.cache_creation_input_tokens != null && (r.usage.cache_creation_input_tokens = t.usage.cache_creation_input_tokens), t.usage.cache_read_input_tokens != null && (r.usage.cache_read_input_tokens = t.usage.cache_read_input_tokens), t.usage.server_tool_use != null && (r.usage.server_tool_use = t.usage.server_tool_use), t.usage.output_tokens_details != null && (r.usage.output_tokens_details = t.usage.output_tokens_details), r;
          case "content_block_start":
            return r.content.push({ ...t.content_block }), r;
          case "content_block_delta": {
            const i = r.content.at(t.index);
            switch (t.delta.type) {
              case "text_delta": {
                i?.type === "text" && (r.content[t.index] = {
                  ...i,
                  text: (i.text || "") + t.delta.text
                });
                break;
              }
              case "citations_delta": {
                i?.type === "text" && (r.content[t.index] = {
                  ...i,
                  citations: [...i.citations ?? [], t.delta.citation]
                });
                break;
              }
              case "input_json_delta": {
                if (i && Pr(i)) {
                  const a = (i[Ut] || "") + t.delta.partial_json;
                  r.content[t.index] = qu(i, a);
                }
                break;
              }
              case "thinking_delta": {
                i?.type === "thinking" && (r.content[t.index] = {
                  ...i,
                  thinking: i.thinking + t.delta.thinking
                });
                break;
              }
              case "signature_delta": {
                i?.type === "thinking" && (r.content[t.index] = {
                  ...i,
                  signature: t.delta.signature
                });
                break;
              }
              default:
                t.delta;
            }
            return r;
          }
          case "content_block_stop": {
            const i = r.content.at(t.index);
            return i && Pr(i) && Ut in i && Object.defineProperty(i, "input", {
              value: i.input,
              enumerable: !0,
              configurable: !0,
              writable: !0
            }), r;
          }
          default:
            return r;
        }
    }, Symbol.asyncIterator)]() {
      const e = [], t = [];
      let r = !1;
      return this.on("_rawEvent", (i) => {
        const a = t.shift();
        a ? a.resolve(i) : e.push(i);
      }), this.on("end", () => {
        r = !0;
        for (const i of t)
          i.resolve(void 0);
        t.length = 0;
      }), this.on("abort", (i) => {
        r = !0;
        for (const a of t)
          a.reject(i);
        t.length = 0;
      }), this.on("error", (i) => {
        r = !0;
        for (const a of t)
          a.reject(i);
        t.length = 0;
      }), {
        next: async () => e.length ? { value: e.shift(), done: !1 } : r ? { value: void 0, done: !0 } : new Promise((a, o) => t.push({ resolve: a, reject: o })).then((a) => a ? { value: a, done: !1 } : { value: void 0, done: !0 }),
        return: async () => (this.abort(), { value: void 0, done: !0 })
      };
    }
    toReadableStream() {
      return new Ne(this[Symbol.asyncIterator].bind(this), this.controller).toReadableStream();
    }
  }
  return s;
})(), Bu = /* @__PURE__ */ (() => {
  class s {
    constructor(e, t, r) {
      this.iterator = e, this.response = r, this.controller = t;
    }
    async *decoder() {
      const e = this.iterator;
      if (!e)
        throw new R("Cannot iterate over a consumed stream.");
      this.iterator = void 0;
      const t = new Mi();
      for await (const r of e)
        for (const i of t.decode(r))
          yield JSON.parse(i);
      for (const r of t.flush())
        yield JSON.parse(r);
    }
    [Symbol.asyncIterator]() {
      return this.decoder();
    }
    static fromResponse(e, t) {
      if (!e.body)
        throw t.abort(), typeof globalThis.navigator < "u" && globalThis.navigator.product === "ReactNative" ? new R("The default react-native fetch implementation does not support streaming. Please use expo/fetch: https://docs.expo.dev/versions/latest/sdk/expo/#expofetch-api") : new R("Attempted to iterate over a response with no body");
      return new s(Ai(e.body), t, e);
    }
  }
  return s;
})();
function Uu(s) {
  return s.replace(/[^A-Za-z0-9\-._~!$&'()*+,;=:@]+/g, encodeURIComponent);
}
const Aa = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.create(null)), Af = (s = Uu) => function(e, ...t) {
  if (e.length === 1)
    return e[0];
  let r = !1;
  const i = [], a = e.reduce((p, h, m) => {
    /[?#]/.test(h) && (r = !0);
    const _ = t[m];
    let b = (r ? encodeURIComponent : s)("" + _);
    return m !== t.length && (_ == null || typeof _ == "object" && // handle values from other realms
    _.toString === Object.getPrototypeOf(Object.getPrototypeOf(_.hasOwnProperty ?? Aa) ?? Aa)?.toString) && (b = _ + "", i.push({
      start: p.length + h.length,
      length: b.length,
      error: `Value of type ${Object.prototype.toString.call(_).slice(8, -1)} is not a valid path parameter`
    })), !r && b === "" && i.push({
      start: p.length + h.length,
      length: 0,
      error: `Value "" can't be safely passed as a path parameter`
    }), p + h + (m === t.length ? "" : b);
  }, ""), o = a.split(/[?#]/, 1)[0], l = /(?<=^|\/)(?:\.|%2e){1,2}(?=\/|$)/gi;
  let d;
  for (; (d = l.exec(o)) !== null; )
    i.push({
      start: d.index,
      length: d[0].length,
      error: `Value "${d[0]}" can't be safely passed as a path parameter`
    });
  if (i.sort((p, h) => p.start - h.start), i.length > 0) {
    const p = [];
    for (const m of i)
      for (let _ = m.start; _ < m.start + Math.max(1, m.length); _++)
        p[_] = "^";
    const h = Array.from(p, (m) => m ?? " ").join("");
    throw new R(`Path parameters result in path with invalid segments:
${i.map((m) => m.error).join(`
`)}
${a}
${h}`);
  }
  return a;
}, g = /* @__PURE__ */ Af(Uu);
let xa = class extends x {
  /**
   * Send a batch of Message creation requests.
   *
   * The Message Batches API can be used to process multiple Messages API requests at
   * once. Once a Message Batch is created, it begins processing immediately. Batches
   * can take up to 24 hours to complete.
   *
   * Learn more about the Message Batches API in our
   * [user guide](https://platform.claude.com/docs/en/build-with-claude/batch-processing)
   *
   * @example
   * ```ts
   * const messageBatch = await client.messages.batches.create({
   *   requests: [
   *     {
   *       custom_id: 'my-custom-id-1',
   *       params: {
   *         max_tokens: 1024,
   *         messages: [
   *           { content: 'Hello, world', role: 'user' },
   *         ],
   *         model: 'claude-opus-5-5',
   *       },
   *     },
   *   ],
   * });
   * ```
   */
  create(n, e) {
    const { user_profile_id: t, workspace_id: r, ...i } = n;
    return this._client.post("/v1/messages/batches", {
      body: i,
      ...e,
      headers: f([
        {
          ...t != null ? { "anthropic-user-profile-id": t } : void 0,
          ...r != null ? { "anthropic-workspace-id": r } : void 0
        },
        e?.headers
      ]),
      __span: u(this._client, "anthropic.messages.batches.create", e, {
        route: "/v1/messages/batches",
        // A request without `requests` is for the API to refuse, not for this line to throw on.
        attributes: { "anthropic.message.batch.request_count": i.requests?.length },
        createdIDAttribute: "anthropic.message.batch.id"
      })
    });
  }
  /**
   * This endpoint is idempotent and can be used to poll for Message Batch
   * completion. To access the results of a Message Batch, make a request to the
   * `results_url` field in the response.
   *
   * Learn more about the Message Batches API in our
   * [user guide](https://platform.claude.com/docs/en/build-with-claude/batch-processing)
   *
   * @example
   * ```ts
   * const messageBatch = await client.messages.batches.retrieve(
   *   'message_batch_id',
   * );
   * ```
   */
  retrieve(n, e = {}, t) {
    const { workspace_id: r } = e ?? {};
    return this._client.get(g`/v1/messages/batches/${n}`, {
      ...t,
      headers: f([
        { ...r != null ? { "anthropic-workspace-id": r } : void 0 },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.messages.batches.retrieve", t, {
        route: "/v1/messages/batches/{message_batch_id}",
        attributes: { "anthropic.message.batch.id": n }
      })
    });
  }
  /**
   * List all Message Batches within a Workspace. Most recently created batches are
   * returned first.
   *
   * Learn more about the Message Batches API in our
   * [user guide](https://platform.claude.com/docs/en/build-with-claude/batch-processing)
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const messageBatch of client.messages.batches.list()) {
   *   // ...
   * }
   * ```
   */
  list(n = {}, e) {
    const { workspace_id: t, ...r } = n ?? {};
    return this._client.getAPIList("/v1/messages/batches", Y, {
      query: r,
      ...e,
      headers: f([
        { ...t != null ? { "anthropic-workspace-id": t } : void 0 },
        e?.headers
      ]),
      __span: u(this._client, "anthropic.messages.batches.list", e, {
        route: "/v1/messages/batches",
        queryParams: ["after_id", "before_id", "limit"]
      })
    });
  }
  /**
   * Delete a Message Batch.
   *
   * Message Batches can only be deleted once they've finished processing. If you'd
   * like to delete an in-progress batch, you must first cancel it.
   *
   * Learn more about the Message Batches API in our
   * [user guide](https://platform.claude.com/docs/en/build-with-claude/batch-processing)
   *
   * @example
   * ```ts
   * const deletedMessageBatch =
   *   await client.messages.batches.delete('message_batch_id');
   * ```
   */
  delete(n, e = {}, t) {
    const { workspace_id: r } = e ?? {};
    return this._client.delete(g`/v1/messages/batches/${n}`, {
      ...t,
      headers: f([
        { ...r != null ? { "anthropic-workspace-id": r } : void 0 },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.messages.batches.delete", t, {
        route: "/v1/messages/batches/{message_batch_id}",
        attributes: { "anthropic.message.batch.id": n }
      })
    });
  }
  /**
   * Batches may be canceled any time before processing ends. Once cancellation is
   * initiated, the batch enters a `canceling` state, at which time the system may
   * complete any in-progress, non-interruptible requests before finalizing
   * cancellation.
   *
   * The number of canceled requests is specified in `request_counts`. To determine
   * which requests were canceled, check the individual results within the batch.
   * Note that cancellation may not result in any canceled requests if they were
   * non-interruptible.
   *
   * Learn more about the Message Batches API in our
   * [user guide](https://platform.claude.com/docs/en/build-with-claude/batch-processing)
   *
   * @example
   * ```ts
   * const messageBatch = await client.messages.batches.cancel(
   *   'message_batch_id',
   * );
   * ```
   */
  cancel(n, e = {}, t) {
    const { workspace_id: r } = e ?? {};
    return this._client.post(g`/v1/messages/batches/${n}/cancel`, {
      ...t,
      headers: f([
        { ...r != null ? { "anthropic-workspace-id": r } : void 0 },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.messages.batches.cancel", t, {
        route: "/v1/messages/batches/{message_batch_id}/cancel",
        attributes: { "anthropic.message.batch.id": n }
      })
    });
  }
  /**
   * Streams the results of a Message Batch as a `.jsonl` file.
   *
   * Each line in the file is a JSON object containing the result of a single request
   * in the Message Batch. Results are not guaranteed to be in the same order as
   * requests. Use the `custom_id` field to match results to requests.
   *
   * Learn more about the Message Batches API in our
   * [user guide](https://platform.claude.com/docs/en/build-with-claude/batch-processing)
   *
   * @example
   * ```ts
   * const stream = await client.messages.batches.results(
   *   'message_batch_id',
   * );
   * for await (const messageBatchIndividualResponse of stream) {
   *   // ...
   * }
   * ```
   */
  async results(n, e = {}, t) {
    const r = await this.retrieve(n, e, t);
    if (!r.results_url)
      throw new R(`No batch \`results_url\`; Has it finished processing? ${r.processing_status} - ${r.id}`);
    const { workspace_id: i } = e ?? {};
    return this._client.get(r.results_url, {
      ...t,
      headers: f([
        {
          Accept: "application/binary",
          ...i != null ? { "anthropic-workspace-id": i } : void 0
        },
        t?.headers
      ]),
      stream: !0,
      __binaryResponse: !0,
      __span: u(this._client, "anthropic.messages.batches.results", t, {
        route: "/v1/messages/batches/{message_batch_id}/results",
        attributes: { "anthropic.message.batch.id": n }
      })
    })._thenUnwrap((a, o) => Bu.fromResponse(o.response, o.controller));
  }
};
const ju = {
  "claude-opus-4@20250514": 8192,
  "anthropic.claude-opus-4-1-20250805-v1:0": 8192,
  "claude-opus-4-1@20250805": 8192
};
var Ea = /* @__PURE__ */ (() => {
  class s extends x {
    constructor() {
      super(...arguments), this.batches = new xa(this._client);
    }
    create(e, t) {
      const { user_profile_id: r, workspace_id: i, ...a } = e;
      a.model in Ra && console.warn(`The model '${a.model}' is deprecated and will reach end-of-life on ${Ra[a.model]}
Please migrate to a newer model. Visit https://docs.anthropic.com/en/docs/resources/model-deprecations for more information.`), xf.includes(a.model) && a.thinking && a.thinking.type === "enabled" && console.warn(`Using Claude with ${a.model} and 'thinking.type=enabled' is deprecated. Use 'thinking.type=adaptive' instead which results in better model performance in our testing: https://platform.claude.com/docs/en/build-with-claude/adaptive-thinking`);
      let o = t?.timeout ?? this._client._options.timeout;
      if (!a.stream && o == null) {
        const h = ju[a.model] ?? void 0;
        o = this._client.calculateNonstreamingTimeout(a.max_tokens, h);
      }
      const l = $u(e, t), d = this._client._tracer && u(this._client, "anthropic.messages.create", t, or(this._client, a, l));
      gu(this._client, d, a);
      const p = this._client.post("/v1/messages", {
        body: a,
        timeout: o ?? 6e5,
        ...t,
        __span: d,
        headers: l,
        stream: e.stream ?? !1
      });
      return d ? p._thenUnwrap((h) => (mu(this._client, d, a, h), h)) : p;
    }
    /**
     * Send a structured list of input messages with text and/or image content, along with an expected `output_config.format` and
     * the response will be automatically parsed and available in the `parsed_output` property of the message.
     *
     * @example
     * ```ts
     * const message = await client.messages.parse({
     *   model: 'claude-sonnet-5-5',
     *   max_tokens: 1024,
     *   messages: [{ role: 'user', content: 'What is 2+2?' }],
     *   output_config: {
     *     format: zodOutputFormat(z.object({ answer: z.number() })),
     *   },
     * });
     *
     * console.log(message.parsed_output?.answer); // 4
     * ```
     */
    parse(e, t) {
      return this.create(e, t).then((r) => Lu(r, e, { logger: this._client.logger ?? console }));
    }
    /**
     * Create a Message stream.
     *
     * If `output_config.format` is provided with a parseable format (like `zodOutputFormat()`),
     * the final message will include a `parsed_output` property with the parsed content.
     *
     * @example
     * ```ts
     * const stream = client.messages.stream({
     *   model: 'claude-sonnet-5-5',
     *   max_tokens: 1024,
     *   messages: [{ role: 'user', content: 'What is 2+2?' }],
     *   output_config: {
     *     format: zodOutputFormat(z.object({ answer: z.number() })),
     *   },
     * });
     *
     * const message = await stream.finalMessage();
     * console.log(message.parsed_output?.answer); // 4
     * ```
     */
    stream(e, t) {
      const r = e;
      return Tf.createMessage(this, r, t, {
        logger: this._client.logger ?? console,
        client: this._client
      });
    }
    /**
     * Count the number of tokens in a Message.
     *
     * The Token Count API can be used to count the number of tokens in a Message,
     * including tools, images, and documents, without creating it.
     *
     * Learn more about token counting in our
     * [user guide](https://platform.claude.com/docs/en/build-with-claude/token-counting)
     *
     * @example
     * ```ts
     * const messageTokensCount =
     *   await client.messages.countTokens({
     *     messages: [{ content: 'Hello, world', role: 'user' }],
     *     model: 'claude-opus-5-5',
     *   });
     * ```
     */
    countTokens(e, t) {
      const { user_profile_id: r, workspace_id: i, ...a } = e, o = f([
        {
          ...r != null ? { "anthropic-user-profile-id": r } : void 0,
          ...i != null ? { "anthropic-workspace-id": i } : void 0
        },
        t?.headers
      ]), l = u(this._client, "anthropic.messages.count_tokens", t, {
        route: "/v1/messages/count_tokens",
        attributes: { [Ln]: a.model }
      }), d = this._client.post("/v1/messages/count_tokens", {
        body: a,
        ...t,
        __span: l,
        headers: o
      });
      return l ? d._thenUnwrap((p) => (yu(this._client, l, p), p)) : d;
    }
  }
  return s.Batches = xa, s;
})();
const Ra = {
  "claude-sonnet-4-5": "November 30th, 2026",
  "claude-sonnet-4-5-20250929": "November 30th, 2026"
}, xf = ["claude-mythos-preview", "claude-opus-4-6"];
class Pa extends x {
  /**
   * Get Deployment Run
   *
   * @example
   * ```ts
   * const betaManagedAgentsDeploymentRun =
   *   await client.beta.deploymentRuns.retrieve(
   *     'deployment_run_id',
   *   );
   * ```
   */
  retrieve(n, e = {}, t) {
    const { betas: r, workspace_id: i } = e ?? {};
    return this._client.get(g`/v1/deployment_runs/${n}?beta=true`, {
      ...t,
      headers: f([
        {
          "anthropic-beta": [...r ?? [], "managed-agents-2026-04-01"].toString(),
          ...i != null ? { "anthropic-workspace-id": i } : void 0
        },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.deployment_runs.retrieve", t, {
        route: "/v1/deployment_runs/{deployment_run_id}",
        attributes: { "anthropic.deployment_run.id": n }
      })
    });
  }
  /**
   * List Deployment Runs
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaManagedAgentsDeploymentRun of client.beta.deploymentRuns.list()) {
   *   // ...
   * }
   * ```
   */
  list(n = {}, e) {
    const { betas: t, workspace_id: r, ...i } = n ?? {};
    return this._client.getAPIList("/v1/deployment_runs?beta=true", z, {
      query: i,
      ...e,
      headers: f([
        {
          "anthropic-beta": [...t ?? [], "managed-agents-2026-04-01"].toString(),
          ...r != null ? { "anthropic-workspace-id": r } : void 0
        },
        e?.headers
      ]),
      __span: u(this._client, "anthropic.deployment_runs.list", e, {
        route: "/v1/deployment_runs",
        queryParams: [
          "created_at[gt]",
          "created_at[gte]",
          "created_at[lt]",
          "created_at[lte]",
          "deployment_id",
          "has_error",
          "limit",
          "page",
          "trigger_type"
        ]
      })
    });
  }
}
class za extends x {
  /**
   * Create Deployment
   *
   * @example
   * ```ts
   * const betaManagedAgentsDeployment =
   *   await client.beta.deployments.create({
   *     agent: 'string',
   *     environment_id: 'x',
   *     initial_events: [
   *       {
   *         content: [
   *           {
   *             text: 'Where is my order #1234?',
   *             type: 'text',
   *           },
   *         ],
   *         type: 'user.message',
   *       },
   *     ],
   *     name: 'x',
   *   });
   * ```
   */
  create(n, e) {
    const { betas: t, workspace_id: r, ...i } = n;
    return this._client.post("/v1/deployments?beta=true", {
      body: i,
      ...e,
      headers: f([
        {
          "anthropic-beta": [...t ?? [], "managed-agents-2026-04-01"].toString(),
          ...r != null ? { "anthropic-workspace-id": r } : void 0
        },
        e?.headers
      ]),
      __span: u(this._client, "anthropic.deployments.create", e, {
        route: "/v1/deployments",
        createdIDAttribute: "anthropic.deployment.id"
      })
    });
  }
  /**
   * Get Deployment
   *
   * @example
   * ```ts
   * const betaManagedAgentsDeployment =
   *   await client.beta.deployments.retrieve(
   *     'depl_011CZkZcDH3vPqd7xnEfwTai',
   *   );
   * ```
   */
  retrieve(n, e = {}, t) {
    const { betas: r, workspace_id: i } = e ?? {};
    return this._client.get(g`/v1/deployments/${n}?beta=true`, {
      ...t,
      headers: f([
        {
          "anthropic-beta": [...r ?? [], "managed-agents-2026-04-01"].toString(),
          ...i != null ? { "anthropic-workspace-id": i } : void 0
        },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.deployments.retrieve", t, {
        route: "/v1/deployments/{deployment_id}",
        attributes: { "anthropic.deployment.id": n }
      })
    });
  }
  /**
   * Update Deployment
   *
   * @example
   * ```ts
   * const betaManagedAgentsDeployment =
   *   await client.beta.deployments.update(
   *     'depl_011CZkZcDH3vPqd7xnEfwTai',
   *   );
   * ```
   */
  update(n, e, t) {
    const { betas: r, workspace_id: i, ...a } = e;
    return this._client.post(g`/v1/deployments/${n}?beta=true`, {
      body: a,
      ...t,
      headers: f([
        {
          "anthropic-beta": [...r ?? [], "managed-agents-2026-04-01"].toString(),
          ...i != null ? { "anthropic-workspace-id": i } : void 0
        },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.deployments.update", t, {
        route: "/v1/deployments/{deployment_id}",
        attributes: { "anthropic.deployment.id": n }
      })
    });
  }
  /**
   * List Deployments
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaManagedAgentsDeployment of client.beta.deployments.list()) {
   *   // ...
   * }
   * ```
   */
  list(n = {}, e) {
    const { betas: t, workspace_id: r, ...i } = n ?? {};
    return this._client.getAPIList("/v1/deployments?beta=true", z, {
      query: i,
      ...e,
      headers: f([
        {
          "anthropic-beta": [...t ?? [], "managed-agents-2026-04-01"].toString(),
          ...r != null ? { "anthropic-workspace-id": r } : void 0
        },
        e?.headers
      ]),
      __span: u(this._client, "anthropic.deployments.list", e, {
        route: "/v1/deployments",
        queryParams: [
          "agent_id",
          "created_at[gte]",
          "created_at[lte]",
          "include_archived",
          "limit",
          "page",
          "status"
        ]
      })
    });
  }
  /**
   * Archive Deployment
   *
   * @example
   * ```ts
   * const betaManagedAgentsDeployment =
   *   await client.beta.deployments.archive(
   *     'depl_011CZkZcDH3vPqd7xnEfwTai',
   *   );
   * ```
   */
  archive(n, e = {}, t) {
    const { betas: r, workspace_id: i } = e ?? {};
    return this._client.post(g`/v1/deployments/${n}/archive?beta=true`, {
      ...t,
      headers: f([
        {
          "anthropic-beta": [...r ?? [], "managed-agents-2026-04-01"].toString(),
          ...i != null ? { "anthropic-workspace-id": i } : void 0
        },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.deployments.archive", t, {
        route: "/v1/deployments/{deployment_id}/archive",
        attributes: { "anthropic.deployment.id": n }
      })
    });
  }
  /**
   * Pause Deployment
   *
   * @example
   * ```ts
   * const betaManagedAgentsDeployment =
   *   await client.beta.deployments.pause(
   *     'depl_011CZkZcDH3vPqd7xnEfwTai',
   *   );
   * ```
   */
  pause(n, e = {}, t) {
    const { betas: r, workspace_id: i } = e ?? {};
    return this._client.post(g`/v1/deployments/${n}/pause?beta=true`, {
      ...t,
      headers: f([
        {
          "anthropic-beta": [...r ?? [], "managed-agents-2026-04-01"].toString(),
          ...i != null ? { "anthropic-workspace-id": i } : void 0
        },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.deployments.pause", t, {
        route: "/v1/deployments/{deployment_id}/pause",
        attributes: { "anthropic.deployment.id": n }
      })
    });
  }
  /**
   * Run Deployment Now
   *
   * @example
   * ```ts
   * const betaManagedAgentsDeploymentRun =
   *   await client.beta.deployments.run(
   *     'depl_011CZkZcDH3vPqd7xnEfwTai',
   *   );
   * ```
   */
  run(n, e = {}, t) {
    const { betas: r, workspace_id: i } = e ?? {};
    return this._client.post(g`/v1/deployments/${n}/run?beta=true`, {
      ...t,
      headers: f([
        {
          "anthropic-beta": [...r ?? [], "managed-agents-2026-04-01"].toString(),
          ...i != null ? { "anthropic-workspace-id": i } : void 0
        },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.deployments.run", t, {
        route: "/v1/deployments/{deployment_id}/run",
        attributes: { "anthropic.deployment.id": n }
      })
    });
  }
  /**
   * Unpause Deployment
   *
   * @example
   * ```ts
   * const betaManagedAgentsDeployment =
   *   await client.beta.deployments.unpause(
   *     'depl_011CZkZcDH3vPqd7xnEfwTai',
   *   );
   * ```
   */
  unpause(n, e = {}, t) {
    const { betas: r, workspace_id: i } = e ?? {};
    return this._client.post(g`/v1/deployments/${n}/unpause?beta=true`, {
      ...t,
      headers: f([
        {
          "anthropic-beta": [...r ?? [], "managed-agents-2026-04-01"].toString(),
          ...i != null ? { "anthropic-workspace-id": i } : void 0
        },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.deployments.unpause", t, {
        route: "/v1/deployments/{deployment_id}/unpause",
        attributes: { "anthropic.deployment.id": n }
      })
    });
  }
}
class Ma extends x {
  /**
   * Start an asynchronous job that uses past sessions to produce a reorganized
   * version of a memory store and get back the dream to poll for the result.
   *
   * By default the dream writes its result to a new memory store and doesn't change
   * the input memory store. The response has `status` set to `pending` and an empty
   * `outputs` array. Poll the dream until `status` is `completed`, `failed`, or
   * `canceled`.
   *
   * See the
   * [Dreams guide](https://platform.claude.com/docs/en/managed-agents/dreams#create-a-dream)
   * to learn more about creating dreams.
   *
   * @example
   * ```ts
   * const betaDream = await client.beta.dreams.create({
   *   inputs: [{ memory_store_id: 'x', type: 'memory_store' }],
   *   model: 'string',
   * });
   * ```
   */
  create(n, e) {
    const { betas: t, workspace_id: r, ...i } = n;
    return this._client.post("/v1/dreams?beta=true", {
      body: i,
      ...e,
      headers: f([
        {
          "anthropic-beta": [...t ?? [], "dreaming-2026-04-21"].toString(),
          ...r != null ? { "anthropic-workspace-id": r } : void 0
        },
        e?.headers
      ]),
      __span: u(this._client, "anthropic.dreams.create", e, {
        route: "/v1/dreams",
        createdIDAttribute: "anthropic.dream.id"
      })
    });
  }
  /**
   * Get a dream by ID to check its status, output memory store, and token usage.
   *
   * Archived dreams are returned too.
   *
   * See the
   * [Dreams guide](https://platform.claude.com/docs/en/managed-agents/dreams#track-progress)
   * for how to poll a dream and what each status means.
   *
   * @example
   * ```ts
   * const betaDream = await client.beta.dreams.retrieve(
   *   'dream_id',
   * );
   * ```
   */
  retrieve(n, e = {}, t) {
    const { betas: r, workspace_id: i } = e ?? {};
    return this._client.get(g`/v1/dreams/${n}?beta=true`, {
      ...t,
      headers: f([
        {
          "anthropic-beta": [...r ?? [], "dreaming-2026-04-21"].toString(),
          ...i != null ? { "anthropic-workspace-id": i } : void 0
        },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.dreams.retrieve", t, {
        route: "/v1/dreams/{dream_id}",
        attributes: { "anthropic.dream.id": n }
      })
    });
  }
  /**
   * List the dreams in the workspace, newest first.
   *
   * Archived dreams are left out unless `include_archived` is `true`.
   *
   * See the
   * [Dreams guide](https://platform.claude.com/docs/en/managed-agents/dreams#list-dreams)
   * for how to page through dreams.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaDream of client.beta.dreams.list()) {
   *   // ...
   * }
   * ```
   */
  list(n = {}, e) {
    const { betas: t, workspace_id: r, ...i } = n ?? {};
    return this._client.getAPIList("/v1/dreams?beta=true", z, {
      query: i,
      ...e,
      headers: f([
        {
          "anthropic-beta": [...t ?? [], "dreaming-2026-04-21"].toString(),
          ...r != null ? { "anthropic-workspace-id": r } : void 0
        },
        e?.headers
      ]),
      __span: u(this._client, "anthropic.dreams.list", e, {
        route: "/v1/dreams",
        queryParams: ["created_at[gt]", "created_at[lt]", "include_archived", "limit", "page", "statuses"]
      })
    });
  }
  /**
   * Hide a `completed`, `failed`, or `canceled` dream from the default list of
   * dreams.
   *
   * Archiving a `pending` or `running` dream returns a 400 error, so cancel it
   * first. Archiving an archived dream returns it unchanged. An archived dream can
   * still be fetched by ID. Archiving can't be undone.
   *
   * See the
   * [Dreams guide](https://platform.claude.com/docs/en/managed-agents/dreams#archive-a-dream)
   * to learn more about archiving dreams.
   *
   * @example
   * ```ts
   * const betaDream = await client.beta.dreams.archive(
   *   'dream_id',
   * );
   * ```
   */
  archive(n, e = {}, t) {
    const { betas: r, workspace_id: i } = e ?? {};
    return this._client.post(g`/v1/dreams/${n}/archive?beta=true`, {
      ...t,
      headers: f([
        {
          "anthropic-beta": [...r ?? [], "dreaming-2026-04-21"].toString(),
          ...i != null ? { "anthropic-workspace-id": i } : void 0
        },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.dreams.archive", t, {
        route: "/v1/dreams/{dream_id}/archive",
        attributes: { "anthropic.dream.id": n }
      })
    });
  }
  /**
   * Stop a `pending` or `running` dream.
   *
   * The response shows `status` as `canceled`, unless the dream reached `completed`
   * or `failed` first. `usage` can keep changing after the response. Canceling a
   * `canceled` dream returns it unchanged. Canceling a `completed` or `failed` dream
   * returns a 400 error.
   *
   * See the
   * [Dreams guide](https://platform.claude.com/docs/en/managed-agents/dreams#cancel-a-dream)
   * to learn more about canceling dreams.
   *
   * @example
   * ```ts
   * const betaDream = await client.beta.dreams.cancel(
   *   'dream_id',
   * );
   * ```
   */
  cancel(n, e = {}, t) {
    const { betas: r, workspace_id: i } = e ?? {};
    return this._client.post(g`/v1/dreams/${n}/cancel?beta=true`, {
      ...t,
      headers: f([
        {
          "anthropic-beta": [...r ?? [], "dreaming-2026-04-21"].toString(),
          ...i != null ? { "anthropic-workspace-id": i } : void 0
        },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.dreams.cancel", t, {
        route: "/v1/dreams/{dream_id}/cancel",
        attributes: { "anthropic.dream.id": n }
      })
    });
  }
}
let Oa = class extends x {
  /**
   * List Files
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaFileMetadata of client.beta.files.list()) {
   *   // ...
   * }
   * ```
   */
  list(n = {}, e) {
    const { betas: t, workspace_id: r, ...i } = n ?? {};
    return this._client.getAPIList("/v1/files?beta=true", z, {
      query: i,
      ...e,
      headers: f([
        {
          ...t?.toString() != null ? { "anthropic-beta": t?.toString() } : void 0,
          ...r != null ? { "anthropic-workspace-id": r } : void 0
        },
        e?.headers
      ]),
      __span: u(this._client, "anthropic.files.list", e, {
        route: "/v1/files",
        queryParams: ["ids", "limit", "page", "scope_id"]
      })
    });
  }
  /**
   * Delete File
   *
   * @example
   * ```ts
   * const betaDeletedFile = await client.beta.files.delete(
   *   'file_id',
   * );
   * ```
   */
  delete(n, e = {}, t) {
    const { betas: r, workspace_id: i } = e ?? {};
    return this._client.delete(g`/v1/files/${n}?beta=true`, {
      ...t,
      headers: f([
        {
          ...r?.toString() != null ? { "anthropic-beta": r?.toString() } : void 0,
          ...i != null ? { "anthropic-workspace-id": i } : void 0
        },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.files.delete", t, {
        route: "/v1/files/{file_id}",
        attributes: { "anthropic.file.id": n }
      })
    });
  }
  /**
   * Download File
   *
   * @example
   * ```ts
   * const response = await client.beta.files.download(
   *   'file_id',
   * );
   *
   * const content = await response.blob();
   * console.log(content);
   * ```
   */
  download(n, e = {}, t) {
    const { betas: r, workspace_id: i } = e ?? {};
    return this._client.get(g`/v1/files/${n}/content?beta=true`, {
      ...t,
      headers: f([
        {
          Accept: "application/binary",
          ...r?.toString() != null ? { "anthropic-beta": r?.toString() } : void 0,
          ...i != null ? { "anthropic-workspace-id": i } : void 0
        },
        t?.headers
      ]),
      __binaryResponse: !0,
      __span: u(this._client, "anthropic.files.download", t, {
        route: "/v1/files/{file_id}/content",
        attributes: { "anthropic.file.id": n }
      })
    });
  }
  /**
   * Get File Metadata
   *
   * @example
   * ```ts
   * const betaFileMetadata =
   *   await client.beta.files.retrieveMetadata('file_id');
   * ```
   */
  retrieveMetadata(n, e = {}, t) {
    const { betas: r, workspace_id: i } = e ?? {};
    return this._client.get(g`/v1/files/${n}?beta=true`, {
      ...t,
      headers: f([
        {
          ...r?.toString() != null ? { "anthropic-beta": r?.toString() } : void 0,
          ...i != null ? { "anthropic-workspace-id": i } : void 0
        },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.files.retrieve_metadata", t, {
        route: "/v1/files/{file_id}",
        attributes: { "anthropic.file.id": n }
      })
    });
  }
  /**
   * Upload File
   *
   * @example
   * ```ts
   * const betaFileMetadata = await client.beta.files.upload({
   *   file: fs.createReadStream('path/to/file'),
   * });
   * ```
   */
  upload(n, e) {
    const { betas: t, workspace_id: r, ...i } = n;
    return this._client.post("/v1/files?beta=true", Le({
      body: i,
      ...e,
      headers: f([
        {
          ...t?.toString() != null ? { "anthropic-beta": t?.toString() } : void 0,
          ...r != null ? { "anthropic-workspace-id": r } : void 0
        },
        Au(i.file),
        e?.headers
      ]),
      __span: u(this._client, "anthropic.files.upload", e, {
        route: "/v1/files",
        createdIDAttribute: "anthropic.file.id"
      })
    }, this._client));
  }
}, Ca = class extends x {
  /**
   * Get a specific model.
   *
   * The Models API response can be used to determine information about a specific
   * model or resolve a model alias to a model ID.
   *
   * @example
   * ```ts
   * const betaModelInfo = await client.beta.models.retrieve(
   *   'model_id',
   * );
   * ```
   */
  retrieve(n, e = {}, t) {
    const { betas: r, workspace_id: i } = e ?? {};
    return this._client.get(g`/v1/models/${n}?beta=true`, {
      ...t,
      headers: f([
        {
          ...r?.toString() != null ? { "anthropic-beta": r?.toString() } : void 0,
          ...i != null ? { "anthropic-workspace-id": i } : void 0
        },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.models.retrieve", t, {
        route: "/v1/models/{model_id}",
        attributes: { "anthropic.model.id": n }
      })
    });
  }
  /**
   * List available models.
   *
   * The Models API response can be used to determine which models are available for
   * use in the API. More recently released models are listed first.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaModelInfo of client.beta.models.list()) {
   *   // ...
   * }
   * ```
   */
  list(n = {}, e) {
    const { betas: t, workspace_id: r, ...i } = n ?? {};
    return this._client.getAPIList("/v1/models?beta=true", Y, {
      query: i,
      ...e,
      headers: f([
        {
          ...t?.toString() != null ? { "anthropic-beta": t?.toString() } : void 0,
          ...r != null ? { "anthropic-workspace-id": r } : void 0
        },
        e?.headers
      ]),
      __span: u(this._client, "anthropic.models.list", e, {
        route: "/v1/models",
        queryParams: ["after_id", "before_id", "lifecycle", "limit"]
      })
    });
  }
};
var nt = {}, Q = {}, Ia;
function Ef() {
  if (Ia) return Q;
  Ia = 1;
  var s = Q && Q.__extends || /* @__PURE__ */ (function() {
    var p = function(h, m) {
      return p = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(_, b) {
        _.__proto__ = b;
      } || function(_, b) {
        for (var y in b) b.hasOwnProperty(y) && (_[y] = b[y]);
      }, p(h, m);
    };
    return function(h, m) {
      p(h, m);
      function _() {
        this.constructor = h;
      }
      h.prototype = m === null ? Object.create(m) : (_.prototype = m.prototype, new _());
    };
  })();
  Object.defineProperty(Q, "__esModule", { value: !0 });
  var n = 256, e = (
    /** @class */
    (function() {
      function p(h) {
        h === void 0 && (h = "="), this._paddingCharacter = h;
      }
      return p.prototype.encodedLength = function(h) {
        return this._paddingCharacter ? (h + 2) / 3 * 4 | 0 : (h * 8 + 5) / 6 | 0;
      }, p.prototype.encode = function(h) {
        for (var m = "", _ = 0; _ < h.length - 2; _ += 3) {
          var b = h[_] << 16 | h[_ + 1] << 8 | h[_ + 2];
          m += this._encodeByte(b >>> 18 & 63), m += this._encodeByte(b >>> 12 & 63), m += this._encodeByte(b >>> 6 & 63), m += this._encodeByte(b >>> 0 & 63);
        }
        var y = h.length - _;
        if (y > 0) {
          var b = h[_] << 16 | (y === 2 ? h[_ + 1] << 8 : 0);
          m += this._encodeByte(b >>> 18 & 63), m += this._encodeByte(b >>> 12 & 63), y === 2 ? m += this._encodeByte(b >>> 6 & 63) : m += this._paddingCharacter || "", m += this._paddingCharacter || "";
        }
        return m;
      }, p.prototype.maxDecodedLength = function(h) {
        return this._paddingCharacter ? h / 4 * 3 | 0 : (h * 6 + 7) / 8 | 0;
      }, p.prototype.decodedLength = function(h) {
        return this.maxDecodedLength(h.length - this._getPaddingLength(h));
      }, p.prototype.decode = function(h) {
        if (h.length === 0)
          return new Uint8Array(0);
        for (var m = this._getPaddingLength(h), _ = h.length - m, b = new Uint8Array(this.maxDecodedLength(_)), y = 0, k = 0, E = 0, A = 0, T = 0, v = 0, S = 0; k < _ - 4; k += 4)
          A = this._decodeChar(h.charCodeAt(k + 0)), T = this._decodeChar(h.charCodeAt(k + 1)), v = this._decodeChar(h.charCodeAt(k + 2)), S = this._decodeChar(h.charCodeAt(k + 3)), b[y++] = A << 2 | T >>> 4, b[y++] = T << 4 | v >>> 2, b[y++] = v << 6 | S, E |= A & n, E |= T & n, E |= v & n, E |= S & n;
        if (k < _ - 1 && (A = this._decodeChar(h.charCodeAt(k)), T = this._decodeChar(h.charCodeAt(k + 1)), b[y++] = A << 2 | T >>> 4, E |= A & n, E |= T & n), k < _ - 2 && (v = this._decodeChar(h.charCodeAt(k + 2)), b[y++] = T << 4 | v >>> 2, E |= v & n), k < _ - 3 && (S = this._decodeChar(h.charCodeAt(k + 3)), b[y++] = v << 6 | S, E |= S & n), E !== 0)
          throw new Error("Base64Coder: incorrect characters for decoding");
        return b;
      }, p.prototype._encodeByte = function(h) {
        var m = h;
        return m += 65, m += 25 - h >>> 8 & 6, m += 51 - h >>> 8 & -75, m += 61 - h >>> 8 & -15, m += 62 - h >>> 8 & 3, String.fromCharCode(m);
      }, p.prototype._decodeChar = function(h) {
        var m = n;
        return m += (42 - h & h - 44) >>> 8 & -n + h - 43 + 62, m += (46 - h & h - 48) >>> 8 & -n + h - 47 + 63, m += (47 - h & h - 58) >>> 8 & -n + h - 48 + 52, m += (64 - h & h - 91) >>> 8 & -n + h - 65 + 0, m += (96 - h & h - 123) >>> 8 & -n + h - 97 + 26, m;
      }, p.prototype._getPaddingLength = function(h) {
        var m = 0;
        if (this._paddingCharacter) {
          for (var _ = h.length - 1; _ >= 0 && h[_] === this._paddingCharacter; _--)
            m++;
          if (h.length < 4 || m > 2)
            throw new Error("Base64Coder: incorrect padding");
        }
        return m;
      }, p;
    })()
  );
  Q.Coder = e;
  var t = new e();
  function r(p) {
    return t.encode(p);
  }
  Q.encode = r;
  function i(p) {
    return t.decode(p);
  }
  Q.decode = i;
  var a = (
    /** @class */
    (function(p) {
      s(h, p);
      function h() {
        return p !== null && p.apply(this, arguments) || this;
      }
      return h.prototype._encodeByte = function(m) {
        var _ = m;
        return _ += 65, _ += 25 - m >>> 8 & 6, _ += 51 - m >>> 8 & -75, _ += 61 - m >>> 8 & -13, _ += 62 - m >>> 8 & 49, String.fromCharCode(_);
      }, h.prototype._decodeChar = function(m) {
        var _ = n;
        return _ += (44 - m & m - 46) >>> 8 & -n + m - 45 + 62, _ += (94 - m & m - 96) >>> 8 & -n + m - 95 + 63, _ += (47 - m & m - 58) >>> 8 & -n + m - 48 + 52, _ += (64 - m & m - 91) >>> 8 & -n + m - 65 + 0, _ += (96 - m & m - 123) >>> 8 & -n + m - 97 + 26, _;
      }, h;
    })(e)
  );
  Q.URLSafeCoder = a;
  var o = new a();
  function l(p) {
    return o.encode(p);
  }
  Q.encodeURLSafe = l;
  function d(p) {
    return o.decode(p);
  }
  return Q.decodeURLSafe = d, Q.encodedLength = function(p) {
    return t.encodedLength(p);
  }, Q.maxDecodedLength = function(p) {
    return t.maxDecodedLength(p);
  }, Q.decodedLength = function(p) {
    return t.decodedLength(p);
  }, Q;
}
var qs = { exports: {} }, Rf = qs.exports, $a;
function Pf() {
  return $a || ($a = 1, (function(s) {
    (function(n, e) {
      var t = {};
      e(t);
      var r = t.default;
      for (var i in t)
        r[i] = t[i];
      s.exports = r;
    })(Rf, function(n) {
      n.__esModule = !0, n.digestLength = 32, n.blockSize = 64;
      var e = new Uint32Array([
        1116352408,
        1899447441,
        3049323471,
        3921009573,
        961987163,
        1508970993,
        2453635748,
        2870763221,
        3624381080,
        310598401,
        607225278,
        1426881987,
        1925078388,
        2162078206,
        2614888103,
        3248222580,
        3835390401,
        4022224774,
        264347078,
        604807628,
        770255983,
        1249150122,
        1555081692,
        1996064986,
        2554220882,
        2821834349,
        2952996808,
        3210313671,
        3336571891,
        3584528711,
        113926993,
        338241895,
        666307205,
        773529912,
        1294757372,
        1396182291,
        1695183700,
        1986661051,
        2177026350,
        2456956037,
        2730485921,
        2820302411,
        3259730800,
        3345764771,
        3516065817,
        3600352804,
        4094571909,
        275423344,
        430227734,
        506948616,
        659060556,
        883997877,
        958139571,
        1322822218,
        1537002063,
        1747873779,
        1955562222,
        2024104815,
        2227730452,
        2361852424,
        2428436474,
        2756734187,
        3204031479,
        3329325298
      ]);
      function t(m, _, b, y, k) {
        for (var E, A, T, v, S, P, C, $, N, I, fe, Be, Ue; k >= 64; ) {
          for (E = _[0], A = _[1], T = _[2], v = _[3], S = _[4], P = _[5], C = _[6], $ = _[7], I = 0; I < 16; I++)
            fe = y + I * 4, m[I] = (b[fe] & 255) << 24 | (b[fe + 1] & 255) << 16 | (b[fe + 2] & 255) << 8 | b[fe + 3] & 255;
          for (I = 16; I < 64; I++)
            N = m[I - 2], Be = (N >>> 17 | N << 15) ^ (N >>> 19 | N << 13) ^ N >>> 10, N = m[I - 15], Ue = (N >>> 7 | N << 25) ^ (N >>> 18 | N << 14) ^ N >>> 3, m[I] = (Be + m[I - 7] | 0) + (Ue + m[I - 16] | 0);
          for (I = 0; I < 64; I++)
            Be = (((S >>> 6 | S << 26) ^ (S >>> 11 | S << 21) ^ (S >>> 25 | S << 7)) + (S & P ^ ~S & C) | 0) + ($ + (e[I] + m[I] | 0) | 0) | 0, Ue = ((E >>> 2 | E << 30) ^ (E >>> 13 | E << 19) ^ (E >>> 22 | E << 10)) + (E & A ^ E & T ^ A & T) | 0, $ = C, C = P, P = S, S = v + Be | 0, v = T, T = A, A = E, E = Be + Ue | 0;
          _[0] += E, _[1] += A, _[2] += T, _[3] += v, _[4] += S, _[5] += P, _[6] += C, _[7] += $, y += 64, k -= 64;
        }
        return y;
      }
      var r = (
        /** @class */
        (function() {
          function m() {
            this.digestLength = n.digestLength, this.blockSize = n.blockSize, this.state = new Int32Array(8), this.temp = new Int32Array(64), this.buffer = new Uint8Array(128), this.bufferLength = 0, this.bytesHashed = 0, this.finished = !1, this.reset();
          }
          return m.prototype.reset = function() {
            return this.state[0] = 1779033703, this.state[1] = 3144134277, this.state[2] = 1013904242, this.state[3] = 2773480762, this.state[4] = 1359893119, this.state[5] = 2600822924, this.state[6] = 528734635, this.state[7] = 1541459225, this.bufferLength = 0, this.bytesHashed = 0, this.finished = !1, this;
          }, m.prototype.clean = function() {
            for (var _ = 0; _ < this.buffer.length; _++)
              this.buffer[_] = 0;
            for (var _ = 0; _ < this.temp.length; _++)
              this.temp[_] = 0;
            this.reset();
          }, m.prototype.update = function(_, b) {
            if (b === void 0 && (b = _.length), this.finished)
              throw new Error("SHA256: can't update because hash was finished.");
            var y = 0;
            if (this.bytesHashed += b, this.bufferLength > 0) {
              for (; this.bufferLength < 64 && b > 0; )
                this.buffer[this.bufferLength++] = _[y++], b--;
              this.bufferLength === 64 && (t(this.temp, this.state, this.buffer, 0, 64), this.bufferLength = 0);
            }
            for (b >= 64 && (y = t(this.temp, this.state, _, y, b), b %= 64); b > 0; )
              this.buffer[this.bufferLength++] = _[y++], b--;
            return this;
          }, m.prototype.finish = function(_) {
            if (!this.finished) {
              var b = this.bytesHashed, y = this.bufferLength, k = b / 536870912 | 0, E = b << 3, A = b % 64 < 56 ? 64 : 128;
              this.buffer[y] = 128;
              for (var T = y + 1; T < A - 8; T++)
                this.buffer[T] = 0;
              this.buffer[A - 8] = k >>> 24 & 255, this.buffer[A - 7] = k >>> 16 & 255, this.buffer[A - 6] = k >>> 8 & 255, this.buffer[A - 5] = k >>> 0 & 255, this.buffer[A - 4] = E >>> 24 & 255, this.buffer[A - 3] = E >>> 16 & 255, this.buffer[A - 2] = E >>> 8 & 255, this.buffer[A - 1] = E >>> 0 & 255, t(this.temp, this.state, this.buffer, 0, A), this.finished = !0;
            }
            for (var T = 0; T < 8; T++)
              _[T * 4 + 0] = this.state[T] >>> 24 & 255, _[T * 4 + 1] = this.state[T] >>> 16 & 255, _[T * 4 + 2] = this.state[T] >>> 8 & 255, _[T * 4 + 3] = this.state[T] >>> 0 & 255;
            return this;
          }, m.prototype.digest = function() {
            var _ = new Uint8Array(this.digestLength);
            return this.finish(_), _;
          }, m.prototype._saveState = function(_) {
            for (var b = 0; b < this.state.length; b++)
              _[b] = this.state[b];
          }, m.prototype._restoreState = function(_, b) {
            for (var y = 0; y < this.state.length; y++)
              this.state[y] = _[y];
            this.bytesHashed = b, this.finished = !1, this.bufferLength = 0;
          }, m;
        })()
      );
      n.Hash = r;
      var i = (
        /** @class */
        (function() {
          function m(_) {
            this.inner = new r(), this.outer = new r(), this.blockSize = this.inner.blockSize, this.digestLength = this.inner.digestLength;
            var b = new Uint8Array(this.blockSize);
            if (_.length > this.blockSize)
              new r().update(_).finish(b).clean();
            else
              for (var y = 0; y < _.length; y++)
                b[y] = _[y];
            for (var y = 0; y < b.length; y++)
              b[y] ^= 54;
            this.inner.update(b);
            for (var y = 0; y < b.length; y++)
              b[y] ^= 106;
            this.outer.update(b), this.istate = new Uint32Array(8), this.ostate = new Uint32Array(8), this.inner._saveState(this.istate), this.outer._saveState(this.ostate);
            for (var y = 0; y < b.length; y++)
              b[y] = 0;
          }
          return m.prototype.reset = function() {
            return this.inner._restoreState(this.istate, this.inner.blockSize), this.outer._restoreState(this.ostate, this.outer.blockSize), this;
          }, m.prototype.clean = function() {
            for (var _ = 0; _ < this.istate.length; _++)
              this.ostate[_] = this.istate[_] = 0;
            this.inner.clean(), this.outer.clean();
          }, m.prototype.update = function(_) {
            return this.inner.update(_), this;
          }, m.prototype.finish = function(_) {
            return this.outer.finished ? this.outer.finish(_) : (this.inner.finish(_), this.outer.update(_, this.digestLength).finish(_)), this;
          }, m.prototype.digest = function() {
            var _ = new Uint8Array(this.digestLength);
            return this.finish(_), _;
          }, m;
        })()
      );
      n.HMAC = i;
      function a(m) {
        var _ = new r().update(m), b = _.digest();
        return _.clean(), b;
      }
      n.hash = a, n.default = a;
      function o(m, _) {
        var b = new i(m).update(_), y = b.digest();
        return b.clean(), y;
      }
      n.hmac = o;
      function l(m, _, b, y) {
        var k = y[0];
        if (k === 0)
          throw new Error("hkdf: cannot expand more");
        _.reset(), k > 1 && _.update(m), b && _.update(b), _.update(y), _.finish(m), y[0]++;
      }
      var d = new Uint8Array(n.digestLength);
      function p(m, _, b, y) {
        _ === void 0 && (_ = d), y === void 0 && (y = 32);
        for (var k = new Uint8Array([1]), E = o(_, m), A = new i(E), T = new Uint8Array(A.digestLength), v = T.length, S = new Uint8Array(y), P = 0; P < y; P++)
          v === T.length && (l(T, A, b, k), v = 0), S[P] = T[v++];
        return A.clean(), T.fill(0), k.fill(0), S;
      }
      n.hkdf = p;
      function h(m, _, b, y) {
        for (var k = new i(m), E = k.digestLength, A = new Uint8Array(4), T = new Uint8Array(E), v = new Uint8Array(E), S = new Uint8Array(y), P = 0; P * E < y; P++) {
          var C = P + 1;
          A[0] = C >>> 24 & 255, A[1] = C >>> 16 & 255, A[2] = C >>> 8 & 255, A[3] = C >>> 0 & 255, k.reset(), k.update(_), k.update(A), k.finish(v);
          for (var $ = 0; $ < E; $++)
            T[$] = v[$];
          for (var $ = 2; $ <= b; $++) {
            k.reset(), k.update(v).finish(v);
            for (var N = 0; N < E; N++)
              T[N] ^= v[N];
          }
          for (var $ = 0; $ < E && P * E + $ < y; $++)
            S[P * E + $] = T[$];
        }
        for (var P = 0; P < E; P++)
          T[P] = v[P] = 0;
        for (var P = 0; P < 4; P++)
          A[P] = 0;
        return k.clean(), S;
      }
      n.pbkdf2 = h;
    });
  })(qs)), qs.exports;
}
var Xn = {}, Na;
function zf() {
  if (Na) return Xn;
  Na = 1, Object.defineProperty(Xn, "__esModule", { value: !0 }), Xn.timingSafeEqual = n;
  function s(e, t = "") {
    if (!e)
      throw new Error(t);
  }
  function n(e, t) {
    if (e.byteLength !== t.byteLength)
      return !1;
    e instanceof DataView || (e = new DataView(ArrayBuffer.isView(e) ? e.buffer : e)), t instanceof DataView || (t = new DataView(ArrayBuffer.isView(t) ? t.buffer : t)), s(e instanceof DataView), s(t instanceof DataView);
    const r = e.byteLength;
    let i = 0, a = -1;
    for (; ++a < r; )
      i |= e.getUint8(a) ^ t.getUint8(a);
    return i === 0;
  }
  return Xn;
}
var La;
function Mf() {
  if (La) return nt;
  La = 1, Object.defineProperty(nt, "__esModule", { value: !0 }), nt.Webhook = nt.WebhookVerificationError = void 0;
  const s = Ef(), n = Pf(), e = zf(), t = 300;
  class r extends Error {
    constructor(l) {
      super(l), Object.setPrototypeOf(this, r.prototype), this.name = "ExtendableError", this.stack = new Error(l).stack;
    }
  }
  class i extends r {
    constructor(l) {
      super(l), Object.setPrototypeOf(this, i.prototype), this.name = "WebhookVerificationError";
    }
  }
  nt.WebhookVerificationError = i;
  class a {
    constructor(l, d) {
      if (d?.format === "raw")
        l instanceof Uint8Array ? this.key = l : this.key = Uint8Array.from(l, (p) => p.charCodeAt(0));
      else {
        if (typeof l != "string")
          throw new Error("Expected secret to be of type string");
        l.startsWith(a.prefix) && (l = l.substring(a.prefix.length)), this.key = s.decode(l);
      }
      if (this.key.length === 0)
        throw new Error("Secret can't be empty.");
    }
    verify(l, d, p) {
      var h;
      const m = (h = p?.jsonParse) !== null && h !== void 0 ? h : !0, _ = {};
      for (const P of Object.keys(d))
        _[P.toLowerCase()] = d[P];
      const b = _["webhook-id"], y = _["webhook-signature"], k = _["webhook-timestamp"];
      if (!y || !b || !k)
        throw new i("Missing required headers");
      const E = this.verifyTimestamp(k), T = this.sign(b, E, l).split(",")[1], v = y.split(" "), S = new globalThis.TextEncoder();
      for (const P of v) {
        const [C, $] = P.split(",");
        if (C === "v1" && (0, e.timingSafeEqual)(S.encode($), S.encode(T))) {
          const N = l.toString();
          return N === "" ? void 0 : m ? JSON.parse(N) : void 0;
        }
      }
      throw new i("No matching signature found");
    }
    sign(l, d, p) {
      if (typeof p != "string") if (p.constructor.name === "Buffer")
        p = p.toString();
      else
        throw new Error("Expected payload to be of type string or Buffer.");
      const h = new TextEncoder(), m = Math.floor(d.getTime() / 1e3), _ = h.encode(`${l}.${m}.${p}`);
      return `v1,${s.encode(n.hmac(this.key, _))}`;
    }
    verifyTimestamp(l) {
      const d = Math.floor(Date.now() / 1e3), p = parseInt(l, 10);
      if (Number.isNaN(p))
        throw new i("Invalid Signature Headers");
      if (d - p > t)
        throw new i("Message timestamp too old");
      if (p > d + t)
        throw new i("Message timestamp too new");
      return new Date(p * 1e3);
    }
  }
  return nt.Webhook = a, a.prefix = "whsec_", nt;
}
var Of = Mf();
let qa = class extends x {
  /**
   * Parses a webhook payload into an event without verifying its signature. Prefer
   * `unwrap()` unless you have already verified the signature yourself.
   */
  parseUnverified(n) {
    return JSON.parse(n);
  }
  /**
   * Verifies the webhook signature from the `webhook-id`, `webhook-timestamp` and
   * `webhook-signature` headers using your webhook signing key, then parses the
   * payload into an event. Fails if the signature is missing or invalid.
   */
  unwrap(n, e) {
    const t = e?.headers;
    if (t == null)
      throw new Error("Webhook headers are required in order to verify the signature");
    const r = e.key === void 0 ? this._client.webhookKey : e.key;
    if (!r)
      throw new Error("Webhook key must not be null or empty in order to unwrap");
    return new Of.Webhook(r).verify(n, t), JSON.parse(n);
  }
}, Ba = class extends x {
  /**
   * List Agent Versions
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaManagedAgentsAgent of client.beta.agents.versions.list(
   *   'agent_011CZkYpogX7uDKUyvBTophP',
   * )) {
   *   // ...
   * }
   * ```
   */
  list(n, e = {}, t) {
    const { betas: r, workspace_id: i, ...a } = e ?? {};
    return this._client.getAPIList(g`/v1/agents/${n}/versions?beta=true`, z, {
      query: a,
      ...t,
      headers: f([
        {
          "anthropic-beta": [...r ?? [], "managed-agents-2026-04-01"].toString(),
          ...i != null ? { "anthropic-workspace-id": i } : void 0
        },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.agents.versions.list", t, {
        route: "/v1/agents/{agent_id}/versions",
        queryParams: ["limit", "page"],
        attributes: { "gen_ai.agent.id": n }
      })
    });
  }
};
var Ua = /* @__PURE__ */ (() => {
  class s extends x {
    constructor() {
      super(...arguments), this.versions = new Ba(this._client);
    }
    /**
     * Create Agent
     *
     * @example
     * ```ts
     * const betaManagedAgentsAgent =
     *   await client.beta.agents.create({
     *     model: 'claude-opus-5-5',
     *     name: 'My First Agent',
     *   });
     * ```
     */
    create(e, t) {
      const { betas: r, workspace_id: i, ...a } = e;
      return this._client.post("/v1/agents?beta=true", {
        body: a,
        ...t,
        headers: f([
          {
            "anthropic-beta": [...r ?? [], "managed-agents-2026-04-01"].toString(),
            ...i != null ? { "anthropic-workspace-id": i } : void 0
          },
          t?.headers
        ]),
        __span: u(this._client, "anthropic.agents.create", t, {
          route: "/v1/agents",
          createdIDAttribute: "gen_ai.agent.id"
        })
      });
    }
    /**
     * Get Agent
     *
     * @example
     * ```ts
     * const betaManagedAgentsAgent =
     *   await client.beta.agents.retrieve(
     *     'agent_011CZkYpogX7uDKUyvBTophP',
     *   );
     * ```
     */
    retrieve(e, t = {}, r) {
      const { betas: i, workspace_id: a, ...o } = t ?? {};
      return this._client.get(g`/v1/agents/${e}?beta=true`, {
        query: o,
        ...r,
        headers: f([
          {
            "anthropic-beta": [...i ?? [], "managed-agents-2026-04-01"].toString(),
            ...a != null ? { "anthropic-workspace-id": a } : void 0
          },
          r?.headers
        ]),
        __span: u(this._client, "anthropic.agents.retrieve", r, {
          route: "/v1/agents/{agent_id}",
          queryParams: ["version"],
          attributes: { "gen_ai.agent.id": e }
        })
      });
    }
    /**
     * Update Agent
     *
     * @example
     * ```ts
     * const betaManagedAgentsAgent =
     *   await client.beta.agents.update(
     *     'agent_011CZkYpogX7uDKUyvBTophP',
     *     { description: 'updated' },
     *   );
     * ```
     */
    update(e, t, r) {
      const { betas: i, workspace_id: a, ...o } = t;
      return this._client.post(g`/v1/agents/${e}?beta=true`, {
        body: o,
        ...r,
        headers: f([
          {
            "anthropic-beta": [...i ?? [], "managed-agents-2026-04-01"].toString(),
            ...a != null ? { "anthropic-workspace-id": a } : void 0
          },
          r?.headers
        ]),
        __span: u(this._client, "anthropic.agents.update", r, {
          route: "/v1/agents/{agent_id}",
          attributes: { "gen_ai.agent.id": e }
        })
      });
    }
    /**
     * List Agents
     *
     * @example
     * ```ts
     * // Automatically fetches more pages as needed.
     * for await (const betaManagedAgentsAgent of client.beta.agents.list()) {
     *   // ...
     * }
     * ```
     */
    list(e = {}, t) {
      const { betas: r, workspace_id: i, ...a } = e ?? {};
      return this._client.getAPIList("/v1/agents?beta=true", z, {
        query: a,
        ...t,
        headers: f([
          {
            "anthropic-beta": [...r ?? [], "managed-agents-2026-04-01"].toString(),
            ...i != null ? { "anthropic-workspace-id": i } : void 0
          },
          t?.headers
        ]),
        __span: u(this._client, "anthropic.agents.list", t, {
          route: "/v1/agents",
          queryParams: ["created_at[gte]", "created_at[lte]", "include_archived", "limit", "page"]
        })
      });
    }
    /**
     * Archive Agent
     *
     * @example
     * ```ts
     * const betaManagedAgentsAgent =
     *   await client.beta.agents.archive(
     *     'agent_011CZkYpogX7uDKUyvBTophP',
     *   );
     * ```
     */
    archive(e, t = {}, r) {
      const { betas: i, workspace_id: a } = t ?? {};
      return this._client.post(g`/v1/agents/${e}/archive?beta=true`, {
        ...r,
        headers: f([
          {
            "anthropic-beta": [...i ?? [], "managed-agents-2026-04-01"].toString(),
            ...a != null ? { "anthropic-workspace-id": a } : void 0
          },
          r?.headers
        ]),
        __span: u(this._client, "anthropic.agents.archive", r, {
          route: "/v1/agents/{agent_id}/archive",
          attributes: { "gen_ai.agent.id": e }
        })
      });
    }
  }
  return s.Versions = Ba, s;
})();
function $n(s, n) {
  if (!s)
    return () => {
    };
  if (s.aborted)
    return n.abort(), () => {
    };
  const e = () => n.abort();
  return s.addEventListener("abort", e), () => s.removeEventListener("abort", e);
}
function jt(s, n) {
  return s instanceof W && s.status === n;
}
function Cf(s) {
  return s instanceof W && typeof s.status == "number" && s.status >= 400 && s.status < 500;
}
function Ys(s) {
  return Cf(s) && !jt(s, 408) && !jt(s, 409) && !jt(s, 429);
}
function Fu(s, n, e) {
  return Math.min(n * 2 ** s, e);
}
function If(s, n) {
  return s + Math.random() * (n - s);
}
function Wu(s) {
  return s * (1 - Math.random() * 0.25);
}
function Hu(s, { authToken: n, helper: e }) {
  if (!n)
    throw new R(`copyClientForHelper: expected a non-empty authToken but received ${JSON.stringify(n)}`);
  const t = s._options.defaultHeaders, r = s._authState?.extraHeaders, i = r ? Object.fromEntries(Object.entries(r).filter(([o]) => {
    const l = o.toLowerCase();
    return l !== "authorization" && l !== "x-api-key";
  })) : void 0, a = f([
    i,
    t,
    { [qn]: e }
  ]);
  return s.withOptions({
    apiKey: null,
    authToken: n,
    baseURL: s.baseURL,
    credentials: void 0,
    defaultHeaders: a
  });
}
var vt, Qn, Z, Zn, es, ts, on, cn, kt, St, ns, Tt, ln;
const $f = 999, Nf = 1e3, Lf = 6e4, qf = 3e5;
var pi = /* @__PURE__ */ (() => {
  class s {
    constructor(e) {
      vt.set(this, void 0), Qn.set(this, !1), Z.set(this, void 0), Zn.set(this, void 0), es.set(this, void 0), ts.set(this, void 0), on.set(this, void 0), cn.set(this, void 0), kt.set(this, void 0), this.client = e.client, this.environmentId = e.environmentId, this.environmentKey = e.environmentKey, this.workerId = e.workerId ?? jf(), w(this, vt, Hu(e.client, {
        authToken: e.environmentKey,
        helper: "environments-work-poller"
      })), w(this, es, e.autoStop ?? !0), w(this, ts, e.drain ?? !1), w(this, on, e.blockMs === void 0 ? $f : e.blockMs), w(this, cn, e.reclaimOlderThanMs ?? null), w(this, kt, e.requestOptions), w(this, Z, new AbortController()), w(this, Zn, $n(e.signal, c(this, Z, "f")));
    }
    /** Read-only view of this iterator's abort signal. */
    get signal() {
      return c(this, Z, "f").signal;
    }
    /** Abort the iterator. The current `for await` will exit cleanly. */
    abort() {
      c(this, Z, "f").abort();
    }
    async *[(vt = /* @__PURE__ */ new WeakMap(), Qn = /* @__PURE__ */ new WeakMap(), Z = /* @__PURE__ */ new WeakMap(), Zn = /* @__PURE__ */ new WeakMap(), es = /* @__PURE__ */ new WeakMap(), ts = /* @__PURE__ */ new WeakMap(), on = /* @__PURE__ */ new WeakMap(), cn = /* @__PURE__ */ new WeakMap(), kt = /* @__PURE__ */ new WeakMap(), Symbol.asyncIterator)]() {
      if (c(this, Qn, "f"))
        throw new R("Cannot iterate over a consumed WorkPoller");
      w(this, Qn, !0);
      let e = _e.active();
      const t = M(this.client);
      t.info("poller starting", {
        component: "work-poller",
        environment_id: this.environmentId
      });
      const r = new Uf(t, this.environmentId);
      try {
        let i = 0;
        for (; !c(this, Z, "f").signal.aborted; ) {
          let a;
          try {
            a = await c(this, vt, "f").beta.environments.work.poll(this.environmentId, {
              "Anthropic-Worker-ID": this.workerId,
              ...c(this, on, "f") !== null ? { block_ms: c(this, on, "f") } : {},
              ...c(this, cn, "f") !== null ? { reclaim_older_than_ms: c(this, cn, "f") } : {}
            }, { headers: f([c(this, kt, "f")?.headers]), signal: c(this, Z, "f").signal });
          } catch (o) {
            if (c(this, Z, "f").signal.aborted)
              return;
            if (Ys(o))
              throw t.error("poll failed permanently, stopping poller", { error: String(o) }), o;
            const l = Wu(Bf(i));
            t.warn("poll failed, backing off", { error: String(o), backoff_ms: l }), i++, await _t(l, c(this, Z, "f").signal);
            continue;
          }
          if (i = 0, a == null) {
            if (c(this, ts, "f"))
              return;
            r.onEmptyPoll(), await _t(If(1e3, 3e3), c(this, Z, "f").signal);
            continue;
          }
          r.onClaim(), this._workSpan = j(this.client, () => D_(this.client, a, e)), t.info("claimed work", {
            component: "work-poller",
            environment_id: this.environmentId,
            work_id: a.id,
            work_type: a.data.type
          });
          try {
            await c(this, vt, "f").beta.environments.work.ack(a.id, { environment_id: a.environment_id }, { headers: f([c(this, kt, "f")?.headers]), signal: c(this, Z, "f").signal });
          } catch (o) {
            t.error("ack failed", { work_id: a.id, error: String(o) }), j(this.client, () => vu(this._workSpan, c(this, Z, "f").signal, o));
            continue;
          }
          try {
            yield a, e = _e.active();
          } finally {
            if (c(this, es, "f"))
              try {
                await c(this, vt, "f").beta.environments.work.stop(a.id, { environment_id: a.environment_id }, { headers: f([c(this, kt, "f")?.headers]) });
              } catch (o) {
                jt(o, 409) || t.warn("stop failed", { work_id: a.id, error: String(o) });
              }
            j(this.client, () => wu(this._workSpan, c(this, Z, "f").signal));
          }
        }
      } finally {
        c(this, Zn, "f").call(this);
      }
    }
  }
  return s;
})();
function Bf(s) {
  return Fu(s, Nf, Lf);
}
var Uf = /* @__PURE__ */ (() => {
  class s {
    constructor(e, t) {
      St.set(this, void 0), ns.set(this, void 0), Tt.set(this, void 0), ln.set(this, 0), w(this, St, e), w(this, ns, t);
    }
    onEmptyPoll() {
      const e = Date.now(), t = { component: "work-poller", environment_id: c(this, ns, "f") };
      c(this, Tt, "f") === void 0 ? (w(this, Tt, w(this, ln, e, "f")), c(this, St, "f").info("idle; polling for work", t)) : e - c(this, ln, "f") >= qf ? (w(this, ln, e), c(this, St, "f").info(`still polling; idle for ${Math.round((e - c(this, Tt, "f")) / 1e3)}s`, t)) : c(this, St, "f").debug("poll returned no work", t);
    }
    onClaim() {
      w(this, Tt, void 0);
    }
  }
  return St = /* @__PURE__ */ new WeakMap(), ns = /* @__PURE__ */ new WeakMap(), Tt = /* @__PURE__ */ new WeakMap(), ln = /* @__PURE__ */ new WeakMap(), s;
})();
function jf() {
  const n = globalThis.process?.env?.HOSTNAME;
  return n ? `${n}-${li()}` : li();
}
var At, Fe, xt, Ff = /* @__PURE__ */ (() => {
  class s {
    constructor() {
      At.set(this, []), Fe.set(this, []), xt.set(this, !1);
    }
    /** Enqueue an item, or hand it directly to a waiting reader. Returns `false` once closed. */
    push(e) {
      if (c(this, xt, "f"))
        return !1;
      const t = c(this, Fe, "f").shift();
      return t ? t({ done: !1, value: e }) : c(this, At, "f").push(e), !0;
    }
    /** Mark the queue done. Idempotent; wakes every pending reader with `done: true`. */
    close() {
      if (!c(this, xt, "f"))
        for (w(this, xt, !0); c(this, Fe, "f").length > 0; )
          c(this, Fe, "f").shift()({ done: !0, value: void 0 });
    }
    /**
     * Resolve with the next item, or `done: true` once the queue is closed and
     * drained. When `signal` is supplied, aborting it resolves a pending read
     * with `done: true` (cancellation is pushed down here rather than handled by
     * an outer `Promise.race`).
     */
    next(e) {
      return c(this, At, "f").length > 0 ? Promise.resolve({ done: !1, value: c(this, At, "f").shift() }) : c(this, xt, "f") || e?.aborted ? Promise.resolve({ done: !0, value: void 0 }) : new Promise((t) => {
        const r = (a) => {
          e?.removeEventListener("abort", i), t(a);
        }, i = () => {
          const a = c(this, Fe, "f").indexOf(r);
          a >= 0 && c(this, Fe, "f").splice(a, 1), t({ done: !0, value: void 0 });
        };
        c(this, Fe, "f").push(r), e?.addEventListener("abort", i, { once: !0 });
      });
    }
    /** Synchronously remove and return the next buffered item, or `undefined` if empty. */
    tryShift() {
      return c(this, At, "f").shift();
    }
  }
  return At = /* @__PURE__ */ new WeakMap(), Fe = /* @__PURE__ */ new WeakMap(), xt = /* @__PURE__ */ new WeakMap(), s;
})(), Wi = /* @__PURE__ */ (() => {
  class s extends Error {
    constructor(e) {
      const t = typeof e == "string" ? e : e.map((r) => r.type === "text" ? r.text : `[${r.type}]`).join(" ");
      super(t), this.name = "ToolError", this.content = e;
    }
  }
  return s;
})();
const Wf = "\\x00-\\x1f\\x7f-\\x9f\\u061c\\u200e\\u200f\\u2028\\u2029\\u202a-\\u202e\\u2066-\\u2069", Hf = new RegExp(`[${Wf}]+`, "g"), Df = /[\uD800-\uDFFF]/gu;
function Xs(s) {
  return s.replace(Df, "�");
}
const Du = 4096, Kf = 200;
function Gf(s, n = Du) {
  return Gu(Xs(s).replace(Hf, " ").trim(), n);
}
function Vf(s) {
  return Gf(s, Kf);
}
function Xe(s) {
  return Vf(s).replace(/[' ]+/g, " ").trim();
}
function Ku(s) {
  return `Error: ${s instanceof Error ? s.message : String(s)}`;
}
function Jf(s) {
  return Gu(Xs(Ku(s)), Du);
}
function Gu(s, n) {
  if (s.length <= n)
    return s;
  let e = 0, t = 0;
  for (const r of s) {
    if (t === n)
      break;
    t += 1, e += r.length;
  }
  return s.slice(0, e);
}
function Yf(s) {
  return typeof s == "string" ? Xs(s) : s.filter((n) => n.type === "text" && n.text !== "").map((n) => ({ ...n, text: Xs(n.text) }));
}
function ja(s) {
  return "name" in s ? s.name : "mcp_server_name" in s ? s.mcp_server_name : s.type;
}
function Xf(s) {
  return s instanceof Wi ? s.content : Ku(s);
}
async function Vu(s, n, e) {
  try {
    const t = s.parse ? s.parse(n) : n;
    return { content: await s.run(t, e), isError: !1 };
  } catch (t) {
    return { content: Xf(t), isError: !0 };
  }
}
var un, ss, Et, st, ye, U, rs, K, is, Rt, as, H, Pt, ce, zt, We, Mt, Ee, os, dn, le, cs, hn, pn, ls, Fa, Wa, Ha, zr, Da, Mr, Ka, us, ds, Or, Ga, Va;
const Ja = 500, Qf = 1e4, Zf = 12e4, eg = 3e4, tg = 1e3, ng = 3e4, sg = 5 * 6e4, rg = 6e4;
function Ju(s) {
  return s.type !== "session.status_idle" ? !1 : s.stop_reason?.type !== "requires_action";
}
var ig = /* @__PURE__ */ (() => {
  class s {
    constructor(e, t) {
      un.set(this, void 0), ss.set(this, void 0), Et.set(this, /* @__PURE__ */ new Set()), st.set(this, !1), ye.set(this, void 0), w(this, un, e), w(this, ss, t);
    }
    /**
     * Arm on an idle that ends the turn; disarm otherwise. `user.tool_confirmation`
     * is neutral: it signals neither agent activity nor an idle, and its effect
     * on the clock flows through {@link block} / {@link unblock} instead —
     * disarming here would discard the pending arm the verdict is about to
     * settle.
     */
    noteEvent(e) {
      e.type !== "user.tool_confirmation" && (Ju(e) ? this.arm() : this.disarm());
    }
    /** Register gated work that must resolve before an idle countdown starts. */
    block(e) {
      c(this, Et, "f").add(e), c(this, ye, "f") !== void 0 && (w(this, st, !0), clearTimeout(c(this, ye, "f")), w(this, ye, void 0));
    }
    /**
     * Retire gated work (a no-op for ids never blocked); applies a pending arm —
     * with a fresh full `maxIdleMs` window — once the last blocker retires.
     */
    unblock(e) {
      c(this, Et, "f").delete(e), c(this, Et, "f").size === 0 && c(this, st, "f") && this.arm();
    }
    /**
     * (Re)start the idle countdown — or, while blockers are outstanding, hold
     * the arm pending instead. Stopping then would drop a held call when its
     * verdict later arrives, or cut the runner off before a released call's
     * result can drive the next turn.
     */
    arm() {
      if (!(c(this, un, "f") <= 0)) {
        if (c(this, Et, "f").size > 0) {
          w(this, st, !0);
          return;
        }
        w(this, st, !1), c(this, ye, "f") !== void 0 && clearTimeout(c(this, ye, "f")), w(this, ye, setTimeout(c(this, ss, "f"), c(this, un, "f")));
      }
    }
    /**
     * Cancel the idle countdown and any pending arm. Blockers persist — they
     * track real outstanding work, retired only by {@link unblock}.
     */
    disarm() {
      w(this, st, !1), c(this, ye, "f") !== void 0 && (clearTimeout(c(this, ye, "f")), w(this, ye, void 0));
    }
  }
  return un = /* @__PURE__ */ new WeakMap(), ss = /* @__PURE__ */ new WeakMap(), Et = /* @__PURE__ */ new WeakMap(), st = /* @__PURE__ */ new WeakMap(), ye = /* @__PURE__ */ new WeakMap(), s;
})(), _i = /* @__PURE__ */ (() => {
  class s {
    constructor(e, t) {
      U.add(this), rs.set(this, !1), K.set(this, void 0), is.set(this, void 0), Rt.set(this, void 0), as.set(this, void 0), H.set(this, void 0), Pt.set(this, /* @__PURE__ */ new Set()), ce.set(this, /* @__PURE__ */ new Set()), zt.set(this, /* @__PURE__ */ new Map()), We.set(this, /* @__PURE__ */ new Map()), Mt.set(this, new Ff()), Ee.set(this, 0), os.set(this, sg), dn.set(this, null), le.set(this, void 0), cs.set(this, void 0), hn.set(this, void 0), pn.set(this, !1), this.client = t.client, this.sessionId = e, this.tools = t.tools, this.maxIdleMs = t.maxIdleMs ?? rg, w(this, H, M(t.client)), w(this, as, new Map(t.tools.map((r) => [ja(r), r]))), w(this, K, new AbortController()), w(this, is, $n(t.signal, c(this, K, "f"))), w(this, Rt, t.requestOptions), w(this, le, new ig(this.maxIdleMs, () => {
        c(this, H, "f").info("session idle after its turn ended; stopping", {
          component: "session-tool-runner",
          session_id: this.sessionId,
          max_idle_ms: this.maxIdleMs
        }), c(this, K, "f").abort();
      }));
    }
    /** Read-only view of this runner's abort signal. */
    get signal() {
      return c(this, K, "f").signal;
    }
    /** Abort the runner. Background tasks will wind down and `for await` will exit cleanly. */
    abort() {
      c(this, K, "f").abort();
    }
    /**
     * @internal
     * `EnvironmentWorker` keeps this equal to the lease TTL each heartbeat
     * reports; applies to a send already retrying.
     */
    _setSendRetryWindow(e) {
      w(this, os, e);
    }
    async *[(rs = /* @__PURE__ */ new WeakMap(), K = /* @__PURE__ */ new WeakMap(), is = /* @__PURE__ */ new WeakMap(), Rt = /* @__PURE__ */ new WeakMap(), as = /* @__PURE__ */ new WeakMap(), H = /* @__PURE__ */ new WeakMap(), Pt = /* @__PURE__ */ new WeakMap(), ce = /* @__PURE__ */ new WeakMap(), zt = /* @__PURE__ */ new WeakMap(), We = /* @__PURE__ */ new WeakMap(), Mt = /* @__PURE__ */ new WeakMap(), Ee = /* @__PURE__ */ new WeakMap(), os = /* @__PURE__ */ new WeakMap(), dn = /* @__PURE__ */ new WeakMap(), le = /* @__PURE__ */ new WeakMap(), cs = /* @__PURE__ */ new WeakMap(), hn = /* @__PURE__ */ new WeakMap(), pn = /* @__PURE__ */ new WeakMap(), U = /* @__PURE__ */ new WeakSet(), Symbol.asyncIterator)]() {
      if (c(this, rs, "f"))
        throw new R("Cannot iterate over a consumed SessionToolRunner");
      w(this, rs, !0), w(this, cs, this.client._tracer ? _e.active() : void 0), c(this, H, "f").info("session tool runner starting", {
        component: "session-tool-runner",
        session_id: this.sessionId
      });
      const e = c(this, U, "m", Fa).call(this).catch((t) => {
        c(this, K, "f").signal.aborted || c(this, H, "f").error("stream loop failed", { error: String(t) }), c(this, K, "f").abort();
      });
      try {
        for (; ; ) {
          const r = await c(this, Mt, "f").next(c(this, K, "f").signal);
          if (r.done)
            break;
          yield r.value;
        }
        await e;
        let t;
        for (; (t = c(this, Mt, "f").tryShift()) !== void 0; )
          yield t;
      } finally {
        c(this, K, "f").abort(), c(this, le, "f").disarm(), await e;
        try {
          await c(this, U, "m", Va).call(this);
        } catch (t) {
          c(this, H, "f").warn("drain failed", { error: String(t) });
        }
        c(this, Mt, "f").close();
        for (const t of this.tools)
          try {
            await t.close?.();
          } catch (r) {
            c(this, H, "f").warn("tool.close failed", { tool: ja(t), error: String(r) });
          }
        c(this, is, "f").call(this);
      }
    }
  }
  return ls = function() {
    return {
      ...c(this, Rt, "f"),
      headers: f([ku("session-tool-runner"), c(this, Rt, "f")?.headers]),
      signal: c(this, K, "f").signal
    };
  }, Fa = // ===== event stream =====
  async function() {
    const e = c(this, K, "f");
    let t = Ja;
    for (; !e.signal.aborted; ) {
      try {
        const r = await this.client.beta.sessions.events.stream(this.sessionId, {}, c(this, U, "m", ls).call(this));
        await c(this, U, "m", Wa).call(this);
        for await (const i of r)
          if (t = Ja, await c(this, U, "m", Da).call(this, i))
            return;
      } catch (r) {
        if (e.signal.throwIfAborted(), Ys(r))
          throw c(this, H, "f").error("permanent stream failure, shutting down", { error: String(r) }), e.abort(), r;
        c(this, H, "f").warn("stream disconnected, reconnecting", {
          error: String(r),
          backoff_ms: t
        });
      }
      e.signal.throwIfAborted(), await _t(t, e.signal), t = Math.min(t * 2, Qf);
    }
  }, Wa = /**
   * Read full history before dispatching so a `tool_use` whose result appears
   * later in the same history is not re-executed. Runs after the live stream is
   * already attached (see {@link SessionToolRunner.#streamLoop}).
   */
  async function() {
    const e = c(this, K, "f"), t = [];
    let r = !1;
    w(this, pn, !1);
    try {
      for await (const o of this.client.beta.sessions.events.list(this.sessionId, { limit: 1e3 }, c(this, U, "m", ls).call(this)))
        c(this, U, "m", Ha).call(this, o, t), o.type !== "user.tool_confirmation" && (r = Ju(o));
    } catch (o) {
      e.signal.throwIfAborted(), c(this, H, "f").warn("reconcile list failed", { error: String(o) });
      for (const l of t)
        c(this, Pt, "f").delete(l.id);
      return;
    }
    w(this, pn, !0);
    const i = t.filter((o) => !c(this, ce, "f").has(o.id));
    c(this, le, "f").disarm();
    for (const o of i)
      await c(this, U, "m", Mr).call(this, o);
    for (const o of [...c(this, We, "f").values()]) {
      const l = c(this, zt, "f").get(o.id);
      l !== void 0 && await c(this, U, "m", us).call(this, o, l);
    }
    const a = i.filter((o) => !c(this, ce, "f").has(o.id) && !c(this, We, "f").has(o.id));
    r && a.length === 0 ? c(this, le, "f").arm() : c(this, le, "f").disarm();
  }, Ha = function(e, t) {
    c(this, U, "m", zr).call(this, e), e.type === "agent.tool_use" || e.type === "agent.custom_tool_use" ? (c(this, Pt, "f").add(e.id), c(this, ce, "f").has(e.id) || t.push(e)) : e.type === "user.tool_result" ? c(this, ce, "f").add(e.tool_use_id) : e.type === "user.custom_tool_result" ? c(this, ce, "f").add(e.custom_tool_use_id) : e.type === "user.tool_confirmation" && (c(this, ce, "f").has(e.tool_use_id) || c(this, zt, "f").set(e.tool_use_id, e.result));
  }, zr = function(e) {
    if (!(!this.client._tracer || c(this, hn, "f") !== void 0))
      switch (e.type) {
        case "session.thread_status_running":
        case "session.thread_status_idle":
        case "session.thread_status_rescheduled":
        case "session.thread_status_terminated":
          w(this, hn, e.session_thread_id);
      }
  }, Da = /** Returns true when the runner should exit. */
  async function(e) {
    switch (c(this, le, "f").noteEvent(e), c(this, pn, "f") && c(this, U, "m", zr).call(this, e), e.type) {
      case "agent.tool_use":
      case "agent.custom_tool_use":
        return c(this, Pt, "f").has(e.id) || (c(this, Pt, "f").add(e.id), await c(this, U, "m", Mr).call(this, e)), !1;
      case "user.tool_confirmation":
        return await c(this, U, "m", Ka).call(this, e), !1;
      case "user.tool_result":
        return c(this, ce, "f").add(e.tool_use_id), !1;
      case "user.custom_tool_result":
        return c(this, ce, "f").add(e.custom_tool_use_id), !1;
      case "session.status_terminated":
      case "session.deleted":
        return c(this, H, "f").info("session terminated", {
          component: "session-tool-runner",
          session_id: this.sessionId
        }), c(this, K, "f").abort(), !0;
      default:
        return !1;
    }
  }, Mr = // ===== confirmation gating (always_ask tools) =====
  /**
   * Dispatch `ev`, honoring its evaluated permission. A call the server gated
   * (`evaluated_permission == "ask"`) is held until its `user.tool_confirmation`
   * arrives. Fails closed: only an explicit `allow` verdict releases a gated
   * call; a server-side `deny` overrides any recorded verdict; an unrecognized
   * permission is held like `ask` and an unrecognized verdict is denied.
   */
  async function(e) {
    const t = e.evaluated_permission, r = t === "deny" ? "deny" : c(this, zt, "f").get(e.id);
    if (r === void 0) {
      t === void 0 || t === "allow" ? await c(this, U, "m", Or).call(this, e, void 0) : c(this, We, "f").has(e.id) || (c(this, H, "f").info("tool call awaiting confirmation; holding", {
        component: "session-tool-runner",
        session_id: this.sessionId,
        tool: e.name,
        tool_use_id: e.id
      }), c(this, We, "f").set(e.id, e), c(this, le, "f").block(e.id));
      return;
    }
    await c(this, U, "m", us).call(this, e, r);
  }, Ka = /** Record an allow/deny verdict and release the held call it gates, if any. */
  async function(e) {
    c(this, zt, "f").set(e.tool_use_id, e.result);
    const t = c(this, We, "f").get(e.tool_use_id);
    t !== void 0 && await c(this, U, "m", us).call(this, t, e.result);
  }, us = /**
   * Dispatch or resolve a gated call according to its verdict.
   *
   * The idle-clock blocker accounting lives here: a denial retires the held
   * call's blocker, while an allow keeps one on the call — taking it now if the
   * verdict was already known when the call was routed, so it was never held —
   * until `#execute` has finished with it. The countdown must not run over
   * gated work that is still in flight.
   */
  async function(e, t) {
    const r = c(this, We, "f").delete(e.id);
    if (t === "allow") {
      c(this, H, "f").info("tool call confirmed", {
        component: "session-tool-runner",
        session_id: this.sessionId,
        tool: e.name,
        tool_use_id: e.id
      }), r || c(this, le, "f").block(e.id);
      try {
        await c(this, U, "m", Or).call(this, e, "allow");
      } finally {
        c(this, le, "f").unblock(e.id);
      }
      return;
    }
    r && c(this, le, "f").unblock(e.id), c(this, ce, "f").add(e.id), c(this, H, "f").info("tool call denied; not executing", {
      component: "session-tool-runner",
      session_id: this.sessionId,
      tool: e.name,
      tool_use_id: e.id
    }), c(this, U, "m", ds).call(this, {
      event: e,
      toolUseId: e.id,
      name: e.name,
      isError: !1,
      posted: !1,
      confirmation: "deny"
    });
  }, ds = function(e) {
    c(this, Mt, "f").push(e);
  }, Or = // ===== tool execution =====
  async function(e, t) {
    var r, i;
    if (!c(this, ce, "f").has(e.id)) {
      c(this, H, "f").info("executing tool", {
        component: "session-tool-runner",
        session_id: this.sessionId,
        tool: e.name,
        tool_use_id: e.id
      }), w(this, Ee, (r = c(this, Ee, "f"), r++, r));
      try {
        const a = c(this, as, "f").get(e.name);
        if (!a) {
          c(this, H, "f").info("tool not owned by this runner; leaving the tool_use_id pending for its owner", {
            component: "session-tool-runner",
            session_id: this.sessionId,
            tool: e.name,
            tool_use_id: e.id
          }), t === "allow" && c(this, le, "f").disarm(), c(this, U, "m", ds).call(this, {
            event: e,
            toolUseId: e.id,
            name: e.name,
            isError: !1,
            posted: !1,
            confirmation: t
          });
          return;
        }
        let o, l;
        const d = c(this, Rt, "f")?.openTelemetry?.conversationId ?? (e.session_thread_id || c(this, hn, "f")), p = new AbortController(), h = $n(c(this, K, "f").signal, p), m = setTimeout(() => p.abort(), Zf);
        try {
          const y = {
            signal: c(this, K, "f").signal,
            conversationId: d,
            sessionID: this.sessionId,
            parentContext: c(this, cs, "f")
          }, k = await Bi(this.client, a, e, y, async () => {
            const E = await Vu(a, e.input, {
              toolUse: e,
              toolUseBlock: e,
              signal: p.signal
            }), A = og(E.content), T = this.client._tracer ? A.map((v, S) => {
              const P = typeof E.content == "string" ? void 0 : E.content[S];
              return P && P.type !== "text" && v.type === "text" ? P : v;
            }) : A;
            return { sent: A, content: T, isError: E.isError };
          });
          o = k.sent, l = k.isError;
        } finally {
          clearTimeout(m), h();
        }
        const _ = ag(e, l, o), b = await c(this, U, "m", Ga).call(this, _, e.id, d);
        c(this, U, "m", ds).call(this, {
          event: e,
          result: _,
          toolUseId: e.id,
          name: e.name,
          isError: l,
          posted: b,
          confirmation: t
        });
      } finally {
        w(this, Ee, (i = c(this, Ee, "f"), i--, i)), c(this, Ee, "f") === 0 && c(this, dn, "f")?.call(this);
      }
    }
  }, Ga = async function(e, t, r) {
    const i = c(this, K, "f"), a = Date.now();
    let o, l = 0;
    for (; ; ) {
      l++, i.signal.throwIfAborted();
      try {
        return await this.client.beta.sessions.events.send(this.sessionId, { events: [e] }, { ...c(this, U, "m", ls).call(this), openTelemetry: { conversationId: r } }), c(this, ce, "f").add(t), !0;
      } catch (d) {
        if (o = d, Ys(d))
          break;
        const p = c(this, os, "f") - (Date.now() - a);
        if (p <= 0)
          break;
        const h = Math.min(Wu(Fu(l - 1, tg, ng)), p);
        c(this, H, "f").warn("tool result send failed; retrying", {
          tool_use_id: t,
          attempt: l,
          backoff_ms: h,
          error: String(d)
        }), await _t(h, i.signal);
      }
    }
    return c(this, H, "f").error("failed to send tool result", {
      tool_use_id: t,
      attempts: l,
      error: String(o)
    }), !1;
  }, Va = /** Wait (bounded) for in-flight tool executions to finish during teardown. */
  async function() {
    c(this, Ee, "f") !== 0 && (await Promise.race([new Promise((e) => w(this, dn, e)), _t(eg)]), w(this, dn, null), c(this, Ee, "f") > 0 && c(this, H, "f").warn("drain timeout exceeded"));
  }, s;
})();
function ag(s, n, e) {
  return s.type === "agent.custom_tool_use" ? { type: "user.custom_tool_result", custom_tool_use_id: s.id, is_error: n, content: e } : { type: "user.tool_result", tool_use_id: s.id, is_error: n, content: e };
}
function og(s) {
  if (typeof s == "string")
    return [{ type: "text", text: s || "(no output)" }];
  const n = s.map((e) => e.type === "text" ? { type: "text", text: e.text || "(no output)" } : e.type === "image" || e.type === "document" ? e : e.type === "search_result" ? {
    type: "search_result",
    source: e.source,
    title: e.title,
    content: e.content.map((t) => ({ type: "text", text: t.text })),
    citations: { enabled: e.citations?.enabled ?? !1 }
  } : { type: "text", text: JSON.stringify(e) });
  return n.length > 0 ? n : [{ type: "text", text: "(no output)" }];
}
const cg = 15e3, fi = 5e3;
function lg(s, n) {
  if (!(s >= fi))
    throw new R(`${n} must be at least ${fi}ms (got ${s}); to run without memory sync, pass \`memorySyncIntervalMs: null\` to the worker instead`);
}
var hs, _n, Cr, fn, rt;
const Ya = 3e4, ug = 9e4, dg = "NO_HEARTBEAT";
function hg(s) {
  return s.resources.some((n) => n.type === "memory_store");
}
function pg(s) {
  if (!s)
    return null;
  let n;
  try {
    const t = s.replace(/-/g, "+").replace(/_/g, "/"), r = t.padEnd(Math.ceil(t.length / 4) * 4, "=");
    n = JSON.parse(si(V_(r)));
  } catch {
    return null;
  }
  if (n === null || typeof n != "object" || Array.isArray(n))
    return null;
  const e = n.sessions_token;
  return typeof e == "string" && e !== "" ? e : null;
}
var Xa = /* @__PURE__ */ (() => {
  class s {
    constructor(e) {
      if (hs.add(this), _n.set(this, void 0), e.unrestrictedPaths !== void 0)
        throw new R("The `unrestrictedPaths` option you passed to EnvironmentWorker (or client.beta.environments.work.worker()) is no longer supported. The worker's file tools (read, write, edit, glob, grep) are now always confined to `workdir` plus the session's memory folders. Remove `unrestrictedPaths` from your options; to let the file tools reach any other directory, add it to `AgentToolContext.allowedRoots` from a `tools` factory.");
      this.client = e.client, this.environmentId = e.environmentId, this.environmentKey = e.environmentKey, this.tools = e.tools, this.workdir = e.workdir ?? process.cwd(), this.maxFileBytes = e.maxFileBytes, this.maxIdleMs = e.maxIdleMs, e.memorySyncIntervalMs != null && lg(e.memorySyncIntervalMs, "memorySyncIntervalMs"), this.memorySyncIntervalMs = e.memorySyncIntervalMs, this.memorySyncDeletions = e.memorySyncDeletions ?? "enabled", this.workerId = e.workerId, this.requestOptions = e.requestOptions, w(this, _n, e.signal);
    }
    /**
     * Poll the environment and service each claimed session until the supplied
     * signal (or the one passed to the constructor) aborts. Throws if
     * `environmentId` / `environmentKey` were not provided to the constructor.
     */
    async run(e) {
      const { environmentId: t, environmentKey: r } = this;
      if (t === void 0 || r === void 0)
        throw new R("EnvironmentWorker.run: environmentId and environmentKey are required to poll for work");
      const i = e ?? c(this, _n, "f"), a = new pi({
        client: this.client,
        environmentId: t,
        environmentKey: r,
        ...this.workerId !== void 0 ? { workerId: this.workerId } : {},
        ...i ? { signal: i } : {},
        ...this.requestOptions !== void 0 ? { requestOptions: this.requestOptions } : {},
        // The per-item handler stops or releases every work item on exit; let it
        // be the single owner of `work.stop` rather than double-posting from the
        // poller.
        autoStop: !1
      });
      for await (const o of a) {
        const l = a._workSpan;
        try {
          await K_(this.client, l, a.signal, () => c(this, hs, "m", Cr).call(this, o, r, a.signal, l));
        } catch (d) {
          if (a.signal?.aborted)
            throw d;
          M(this.client).error("work item failed", { work_id: o.id, error: String(d) });
        }
      }
    }
    /**
     * Service a single, already-claimed work item without the poll loop: build the
     * per-session {@link AgentToolContext} (workdir from this worker's options),
     * download the session agent's skills (`setupSkills`), run a
     * {@link SessionToolRunner} for the session while heartbeating the work-item
     * lease, and force-stop the work item on exit (whether the runner finishes
     * normally, throws, or the control plane signals shutdown). The one
     * exception is a lost lease: the item then belongs to the queue or another
     * worker and is left alone.
     *
     * Use this when something else does the claiming — e.g. a `worker poll
     * --on-work` script that hands an already-claimed item to a fresh process. The
     * work id / environment id / session id each fall back to `ANTHROPIC_WORK_ID` /
     * `ANTHROPIC_ENVIRONMENT_ID` / `ANTHROPIC_SESSION_ID` (the env vars that
     * command sets) when not passed; the environment key resolves from this
     * option, then the worker's own `environmentKey`, then
     * `ANTHROPIC_ENVIRONMENT_KEY`, and is needed only when the work item's
     * `secret` yields no sessions token — a host that receives only the
     * per-item secret runs without ever holding the key. With no arguments
     * inside that command it just works. Throws a clear error naming the first
     * required value still missing after resolution, and — rather than ever
     * running unauthenticated — when neither a sessions token nor an
     * environment key resolved. Throws `SessionMemoryError` when the
     * session has memory stores attached but they cannot be mounted — the work
     * item carried no sessions token (unless `memorySyncIntervalMs` turned
     * memory off), or a store failed to download.
     *
     * `workSecret` is the work item's per-item `secret` payload from the poll
     * response, falling back to `ANTHROPIC_WORK_SECRET`; unlike the others it is
     * optional — when present, the sessions token extracted from it is preferred
     * as the Bearer credential for this item's heartbeat / force-stop / session
     * calls; when absent (or undecodable) those calls use the environment key.
     */
    async handleItem(e) {
      const t = e?.workId ?? O("ANTHROPIC_WORK_ID"), r = e?.environmentId ?? O("ANTHROPIC_ENVIRONMENT_ID"), i = e?.sessionId ?? O("ANTHROPIC_SESSION_ID"), a = (e?.environmentKey ?? this.environmentKey ?? O("ANTHROPIC_ENVIRONMENT_KEY")) || void 0, o = e?.workSecret || O("ANTHROPIC_WORK_SECRET") || null;
      if (!t)
        throw new R("handleItem: workId is required — pass it or set ANTHROPIC_WORK_ID");
      if (!r)
        throw new R("handleItem: environmentId is required — pass it or set ANTHROPIC_ENVIRONMENT_ID");
      if (!i)
        throw new R("handleItem: sessionId is required — pass it or set ANTHROPIC_SESSION_ID");
      if (!a && !o)
        throw new R("handleItem: environmentKey is required when there is no work secret — pass it, construct the worker with it, or set ANTHROPIC_ENVIRONMENT_KEY");
      const l = {
        id: t,
        environment_id: r,
        secret: o,
        data: { type: "session", id: i }
      };
      await c(this, hs, "m", Cr).call(this, l, a, e?.signal ?? c(this, _n, "f"));
    }
  }
  return _n = /* @__PURE__ */ new WeakMap(), hs = /* @__PURE__ */ new WeakSet(), Cr = /**
   * The per-item body shared by {@link EnvironmentWorker.run}'s poll loop and
   * {@link EnvironmentWorker.handleItem}: run a {@link SessionToolRunner} for the
   * work item's session while heartbeating its lease, force-stopping on exit
   * unless the lease was lost. Non-session work items are ignored.
   *
   * When the poll response carried a per-item `secret` (a short-lived payload
   * scoped to this work item), the sessions token extracted from it is
   * preferred over `environmentKey` as the Bearer credential for those
   * per-item calls; a missing/undecodable secret falls back to
   * `environmentKey` unchanged.
   */
  async function(e, t, r, i) {
    const a = M(this.client), o = pg(e.secret), l = o ?? t;
    if (l === void 0)
      throw new R("handleItem: the work item carried a secret payload but no sessions token could be extracted, and there is no environment key to fall back to; the poller must issue a secret whose payload carries `sessions_token`, or provide the environment key (pass it, construct the worker with it, or set ANTHROPIC_ENVIRONMENT_KEY)");
    e.secret && o === null && a.warn("work item carried a secret payload but no sessions token could be extracted; falling back to the environment key", { work_id: e.id });
    const d = Hu(this.client, {
      authToken: l,
      helper: "environments-worker"
    }), p = e.data.id, h = new AbortController(), m = $n(r, h), _ = new fg(h), b = await Promise.resolve().then(() => jm);
    let y, k;
    const E = mg(d, e, _, a, this.requestOptions, (S) => {
      y = S, k?._setSendRetryWindow(S);
    }).catch((S) => {
      h.signal.aborted || a.error("heartbeat loop failed", { work_id: e.id, error: String(S) }), h.abort();
    });
    let A = async () => {
    }, T, v = !1;
    try {
      if (e.data.type !== "session") {
        a.debug("skipping non-session work item", { work_id: e.id, type: e.data.type });
        return;
      }
      const S = await d.beta.sessions.retrieve(p);
      if (o === null && this.memorySyncIntervalMs !== null && hg(S))
        throw new b.SessionMemoryError(`cannot mount the session's memories: the work item carried no sessions token (work_id=${e.id}, session_id=${p}); the memory endpoints reject the environment key, so the poller must issue a per-item \`secret\` carrying \`sessions_token\`, or set \`memorySyncIntervalMs: null\` to run without memory`);
      const P = {
        workdir: this.workdir,
        // The scoped sub-client, not the parent: the skill download
        // `setupSkills` performs for this session rides the same per-item
        // credential as every other per-item call.
        client: d,
        session: S,
        ...this.maxFileBytes !== void 0 ? { maxFileBytes: this.maxFileBytes } : {}
      };
      try {
        A = await b.setupSkills(P);
      } catch ($) {
        a.warn("skill setup failed", { session_id: p, work_id: e.id, error: String($) });
      }
      o !== null && this.memorySyncIntervalMs !== null ? (T = new b.SessionMemoryStores(d, {
        workdir: this.workdir,
        ...this.memorySyncIntervalMs !== void 0 ? { syncIntervalMs: this.memorySyncIntervalMs } : {},
        syncDeletions: this.memorySyncDeletions
      }), await T.download(S), P.allowedRoots = T.roots, P.readOnlyRoots = T.readOnlyRoots) : a.debug("memory stores disabled for this item", { work_id: e.id });
      const C = typeof this.tools == "function" ? this.tools(P) : this.tools ?? b.betaAgentToolset20260401(P);
      k = new _i(p, {
        client: d,
        tools: C,
        ...this.maxIdleMs !== void 0 ? { maxIdleMs: this.maxIdleMs } : {},
        ...this.requestOptions !== void 0 ? { requestOptions: this.requestOptions } : {},
        signal: h.signal
      }), y !== void 0 && k._setSendRetryWindow(y);
      for await (const $ of k)
        T && await T.syncIfDue();
      v = !h.signal.aborted;
    } finally {
      try {
        await A().catch((S) => {
          a.warn("skill cleanup failed", { session_id: p, work_id: e.id, error: String(S) });
        });
      } finally {
        if (T) {
          const S = b.MEMORY_FLUSH_TIMEOUT_MS;
          v && await Qa(T.finish(), S) && a.warn(`final memory sync cut off after ${S}ms; the flush that follows still uploads changed files`, { session_id: p, work_id: e.id });
          const P = new AbortController();
          await Qa(T.flushWrites(P.signal), S) && (P.abort(), a.warn(`memory flush cut off after ${S}ms; changed files it had not uploaded yet are not saved`, { session_id: p, work_id: e.id })), await T.dispose().catch(($) => {
            a.warn("memory store cleanup failed", {
              session_id: p,
              work_id: e.id,
              error: String($)
            });
          });
        }
      }
      _.finish("runner_done"), m(), await E, _.lost ? a.info("lease lost; released without stopping it", { session_id: p, work_id: e.id }) : await _g(d, e, a, this.requestOptions), (_.lost || _.rejected) && j(this.client, () => i?.end());
    }
  }, s;
})();
async function Qa(s, n) {
  let e;
  try {
    return await Promise.race([
      s.then(() => !1, () => !1),
      new Promise((t) => {
        e = setTimeout(() => t(!0), n);
      })
    ]);
  } finally {
    e !== void 0 && clearTimeout(e);
  }
}
async function _g(s, n, e, t) {
  try {
    await s.beta.environments.work.stop(
      n.id,
      { environment_id: n.environment_id, force: !0 },
      // Caller's headers pass through; the helper-tag header is on the scoped
      // sub-client's default_headers via copyClientForHelper, so no per-call
      // re-stamping needed.
      { ...t, headers: f([t?.headers]) }
    );
  } catch (r) {
    jt(r, 409) || e.error("force-stop on exit failed", { work_id: n.id, error: String(r) });
  }
}
var fg = /* @__PURE__ */ (() => {
  class s {
    constructor(e) {
      fn.set(this, void 0), rt.set(this, void 0), w(this, fn, e);
    }
    get signal() {
      return c(this, fn, "f").signal;
    }
    finish(e) {
      w(this, rt, c(this, rt, "f") ?? e), c(this, fn, "f").abort();
    }
    /** True once the item belongs to the queue or another worker. */
    get lost() {
      return c(this, rt, "f") === "lease_lost" || c(this, rt, "f") === "assumed_lost";
    }
    /** True once the API rejected a heartbeat for good, so the worker cannot keep the lease. */
    get rejected() {
      return c(this, rt, "f") === "heartbeat_rejected";
    }
  }
  return fn = /* @__PURE__ */ new WeakMap(), rt = /* @__PURE__ */ new WeakMap(), s;
})();
function gg(s) {
  let n = s instanceof W ? s.error : void 0;
  for (const e of ["error", "details", "current_state"]) {
    if (!Qi(n))
      return {};
    n = n[e];
  }
  return Qi(n) ? n : {};
}
async function mg(s, n, e, t, r, i) {
  let a = Ya, o = ug, l = Date.now(), d = dg;
  const p = async () => {
    const h = new AbortController(), m = $n(e.signal, h), _ = setTimeout(() => h.abort(), a);
    try {
      const b = await s.beta.environments.work.heartbeat(n.id, { environment_id: n.environment_id, expected_last_heartbeat: d }, { ...r, headers: f([r?.headers]), signal: h.signal });
      l = Date.now(), d = b.last_heartbeat, b.ttl_seconds > 0 && (o = b.ttl_seconds * 1e3, a = Math.max(1e3, Math.min(o / 2, Ya)), i?.(o)), (b.state === "stopping" || b.state === "stopped") && (t.info("heartbeat signals shutdown", { work_id: n.id, state: b.state }), e.finish("control_plane_stop")), b.lease_extended || (t.warn("lease not extended, shutting down", { work_id: n.id }), e.finish("control_plane_stop"));
    } catch (b) {
      if (e.signal.throwIfAborted(), jt(b, 412)) {
        const y = gg(b);
        t.error("lease lost: heartbeat precondition failed", {
          work_id: n.id,
          server_state: y.state,
          server_ttl_seconds: y.ttl_seconds,
          server_last_heartbeat: y.last_heartbeat
        }), e.finish("lease_lost");
        return;
      }
      if (Ys(b))
        throw t.error("permanent heartbeat failure", { work_id: n.id, error: String(b) }), e.finish("heartbeat_rejected"), b;
      if (Date.now() - l > o) {
        t.error("lease assumed lost: no successful heartbeat in ttl", {
          work_id: n.id,
          ttl_ms: o,
          error: String(b)
        }), e.finish("assumed_lost");
        return;
      }
      t.warn("transient heartbeat failure", { work_id: n.id, error: String(b) });
    } finally {
      clearTimeout(_), m();
    }
  };
  for (await p(); !e.signal.aborted; )
    await _t(a, e.signal), e.signal.throwIfAborted(), await p();
}
var Za = /* @__PURE__ */ (() => {
  class s extends x {
    /**
     * Note: these endpoints are called automatically by the pre-built environment
     * worker provided in the SDKs and CLI, for orchestrating sessions with self-hosted
     * sandbox environments. They are included here as a reference; you do not need to
     * invoke them directly.
     *
     * Retrieve detailed information about a specific work item.
     *
     * @example
     * ```ts
     * const betaSelfHostedWork =
     *   await client.beta.environments.work.retrieve('work_id', {
     *     environment_id: 'env_011CZkZ9X2dpNyB7HsEFoRfW',
     *   });
     * ```
     */
    retrieve(e, t, r) {
      const { environment_id: i, betas: a, workspace_id: o } = t;
      return this._client.get(g`/v1/environments/${i}/work/${e}?beta=true`, {
        ...r,
        headers: f([
          {
            "anthropic-beta": [...a ?? [], "managed-agents-2026-04-01"].toString(),
            ...o != null ? { "anthropic-workspace-id": o } : void 0
          },
          r?.headers
        ]),
        __span: u(this._client, "anthropic.environments.work.retrieve", r, {
          route: "/v1/environments/{environment_id}/work/{work_id}",
          attributes: { "anthropic.environment.id": i, "anthropic.environment.work.id": e }
        })
      });
    }
    /**
     * Note: these endpoints are called automatically by the pre-built environment
     * worker provided in the SDKs and CLI, for orchestrating sessions with self-hosted
     * sandbox environments. They are included here as a reference; you do not need to
     * invoke them directly.
     *
     * Update work item metadata with merge semantics.
     *
     * @example
     * ```ts
     * const betaSelfHostedWork =
     *   await client.beta.environments.work.update('work_id', {
     *     environment_id: 'env_011CZkZ9X2dpNyB7HsEFoRfW',
     *     metadata: { foo: 'string' },
     *   });
     * ```
     */
    update(e, t, r) {
      const { environment_id: i, betas: a, workspace_id: o, ...l } = t;
      return this._client.post(g`/v1/environments/${i}/work/${e}?beta=true`, {
        body: l,
        ...r,
        headers: f([
          {
            "anthropic-beta": [...a ?? [], "managed-agents-2026-04-01"].toString(),
            ...o != null ? { "anthropic-workspace-id": o } : void 0
          },
          r?.headers
        ]),
        __span: u(this._client, "anthropic.environments.work.update", r, {
          route: "/v1/environments/{environment_id}/work/{work_id}",
          attributes: { "anthropic.environment.id": i, "anthropic.environment.work.id": e }
        })
      });
    }
    /**
     * Note: these endpoints are called automatically by the pre-built environment
     * worker provided in the SDKs and CLI, for orchestrating sessions with self-hosted
     * sandbox environments. They are included here as a reference; you do not need to
     * invoke them directly.
     *
     * List work items in an environment.
     *
     * @example
     * ```ts
     * // Automatically fetches more pages as needed.
     * for await (const betaSelfHostedWork of client.beta.environments.work.list(
     *   'env_011CZkZ9X2dpNyB7HsEFoRfW',
     * )) {
     *   // ...
     * }
     * ```
     */
    list(e, t = {}, r) {
      const { betas: i, ...a } = t ?? {};
      return this._client.getAPIList(g`/v1/environments/${e}/work?beta=true`, z, {
        query: a,
        ...r,
        headers: f([
          { "anthropic-beta": [...i ?? [], "managed-agents-2026-04-01"].toString() },
          r?.headers
        ]),
        __span: u(this._client, "anthropic.environments.work.list", r, {
          route: "/v1/environments/{environment_id}/work",
          queryParams: ["limit", "page"],
          attributes: { "anthropic.environment.id": e }
        })
      });
    }
    /**
     * Note: these endpoints are called automatically by the pre-built environment
     * worker provided in the SDKs and CLI, for orchestrating sessions with self-hosted
     * sandbox environments. They are included here as a reference; you do not need to
     * invoke them directly.
     *
     * Acknowledge receipt of a work item, transitioning it from 'queued' to 'starting'
     * and removing it from the queue.
     *
     * @example
     * ```ts
     * const betaSelfHostedWork =
     *   await client.beta.environments.work.ack('work_id', {
     *     environment_id: 'env_011CZkZ9X2dpNyB7HsEFoRfW',
     *   });
     * ```
     */
    ack(e, t, r) {
      const { environment_id: i, betas: a } = t;
      return this._client.post(g`/v1/environments/${i}/work/${e}/ack?beta=true`, {
        ...r,
        headers: f([
          { "anthropic-beta": [...a ?? [], "managed-agents-2026-04-01"].toString() },
          r?.headers
        ]),
        __span: u(this._client, "anthropic.environments.work.ack", r, {
          route: "/v1/environments/{environment_id}/work/{work_id}/ack",
          attributes: { "anthropic.environment.id": i, "anthropic.environment.work.id": e }
        })
      });
    }
    /**
     * Note: these endpoints are called automatically by the pre-built environment
     * worker provided in the SDKs and CLI, for orchestrating sessions with self-hosted
     * sandbox environments. They are included here as a reference; you do not need to
     * invoke them directly.
     *
     * Record a heartbeat for a work item to maintain the lease.
     *
     * @example
     * ```ts
     * const betaSelfHostedWorkHeartbeatResponse =
     *   await client.beta.environments.work.heartbeat('work_id', {
     *     environment_id: 'env_011CZkZ9X2dpNyB7HsEFoRfW',
     *   });
     * ```
     */
    heartbeat(e, t, r) {
      const { environment_id: i, desired_ttl_seconds: a, expected_last_heartbeat: o, betas: l } = t;
      return this._client.post(g`/v1/environments/${i}/work/${e}/heartbeat?beta=true`, {
        query: { desired_ttl_seconds: a, expected_last_heartbeat: o },
        ...r,
        headers: f([
          { "anthropic-beta": [...l ?? [], "managed-agents-2026-04-01"].toString() },
          r?.headers
        ]),
        __span: u(this._client, "anthropic.environments.work.heartbeat", r, {
          route: "/v1/environments/{environment_id}/work/{work_id}/heartbeat",
          queryParams: ["desired_ttl_seconds", "expected_last_heartbeat"],
          attributes: { "anthropic.environment.id": i, "anthropic.environment.work.id": e }
        })
      });
    }
    /**
     * Note: these endpoints are called automatically by the pre-built environment
     * worker provided in the SDKs and CLI, for orchestrating sessions with self-hosted
     * sandbox environments. They are included here as a reference; you do not need to
     * invoke them directly.
     *
     * Long poll for work items in the queue.
     *
     * @example
     * ```ts
     * const betaSelfHostedWork =
     *   await client.beta.environments.work.poll(
     *     'env_011CZkZ9X2dpNyB7HsEFoRfW',
     *   );
     * ```
     */
    poll(e, t = {}, r) {
      const { betas: i, "Anthropic-Worker-ID": a, ...o } = t ?? {};
      return this._client.get(g`/v1/environments/${e}/work/poll?beta=true`, {
        query: o,
        ...r,
        headers: f([
          {
            "anthropic-beta": [...i ?? [], "managed-agents-2026-04-01"].toString(),
            ...a != null ? { "Anthropic-Worker-ID": a } : void 0
          },
          r?.headers
        ]),
        __span: u(this._client, "anthropic.environments.work.poll", r, {
          route: "/v1/environments/{environment_id}/work/poll",
          queryParams: ["block_ms", "reclaim_older_than_ms"],
          attributes: { "anthropic.environment.id": e }
        })
      });
    }
    /**
     * Get statistics about the work queue for an environment.
     *
     * @example
     * ```ts
     * const betaSelfHostedWorkQueueStats =
     *   await client.beta.environments.work.stats(
     *     'env_011CZkZ9X2dpNyB7HsEFoRfW',
     *   );
     * ```
     */
    stats(e, t = {}, r) {
      const { betas: i, workspace_id: a } = t ?? {};
      return this._client.get(g`/v1/environments/${e}/work/stats?beta=true`, {
        ...r,
        headers: f([
          {
            "anthropic-beta": [...i ?? [], "managed-agents-2026-04-01"].toString(),
            ...a != null ? { "anthropic-workspace-id": a } : void 0
          },
          r?.headers
        ]),
        __span: u(this._client, "anthropic.environments.work.stats", r, {
          route: "/v1/environments/{environment_id}/work/stats",
          attributes: { "anthropic.environment.id": e }
        })
      });
    }
    /**
     * Note: these endpoints are called automatically by the pre-built environment
     * worker provided in the SDKs and CLI, for orchestrating sessions with self-hosted
     * sandbox environments. They are included here as a reference; you do not need to
     * invoke them directly.
     *
     * Stop a work item, initiating graceful or forced shutdown.
     *
     * @example
     * ```ts
     * const betaSelfHostedWork =
     *   await client.beta.environments.work.stop('work_id', {
     *     environment_id: 'env_011CZkZ9X2dpNyB7HsEFoRfW',
     *   });
     * ```
     */
    stop(e, t, r) {
      const { environment_id: i, betas: a, workspace_id: o, ...l } = t;
      return this._client.post(g`/v1/environments/${i}/work/${e}/stop?beta=true`, {
        body: l,
        ...r,
        headers: f([
          {
            "anthropic-beta": [...a ?? [], "managed-agents-2026-04-01"].toString(),
            ...o != null ? { "anthropic-workspace-id": o } : void 0
          },
          r?.headers
        ]),
        __span: u(this._client, "anthropic.environments.work.stop", r, {
          route: "/v1/environments/{environment_id}/work/{work_id}/stop",
          attributes: { "anthropic.environment.id": i, "anthropic.environment.work.id": e }
        })
      });
    }
    /**
     * Continuously claim work from a self-hosted environment, ack each item,
     * and yield it. Posts `stop` automatically when the consumer's loop body
     * returns or when iteration ends.
     *
     * @example
     * ```ts
     * for await (const work of client.beta.environments.work.poller({
     *   environmentId,
     *   environmentKey,
     * })) {
     *   if (work.data.type !== 'session') continue;
     *   // ...service the work...
     * }
     * ```
     */
    poller(e) {
      return new pi({ ...e, client: this._client });
    }
    worker(e) {
      return new Xa({ ...e, client: this._client });
    }
  }
  return s.WorkPoller = pi, s.EnvironmentWorker = Xa, s;
})(), eo = /* @__PURE__ */ (() => {
  class s extends x {
    constructor() {
      super(...arguments), this.work = new Za(this._client);
    }
    /**
     * Create a new environment with the specified configuration.
     *
     * @example
     * ```ts
     * const betaEnvironment =
     *   await client.beta.environments.create({
     *     name: 'python-data-analysis',
     *   });
     * ```
     */
    create(e, t) {
      const { betas: r, workspace_id: i, ...a } = e;
      return this._client.post("/v1/environments?beta=true", {
        body: a,
        ...t,
        headers: f([
          {
            "anthropic-beta": [...r ?? [], "managed-agents-2026-04-01"].toString(),
            ...i != null ? { "anthropic-workspace-id": i } : void 0
          },
          t?.headers
        ]),
        __span: u(this._client, "anthropic.environments.create", t, {
          route: "/v1/environments",
          createdIDAttribute: "anthropic.environment.id"
        })
      });
    }
    /**
     * Retrieve a specific environment by ID.
     *
     * @example
     * ```ts
     * const betaEnvironment =
     *   await client.beta.environments.retrieve(
     *     'env_011CZkZ9X2dpNyB7HsEFoRfW',
     *   );
     * ```
     */
    retrieve(e, t = {}, r) {
      const { betas: i, workspace_id: a } = t ?? {};
      return this._client.get(g`/v1/environments/${e}?beta=true`, {
        ...r,
        headers: f([
          {
            "anthropic-beta": [...i ?? [], "managed-agents-2026-04-01"].toString(),
            ...a != null ? { "anthropic-workspace-id": a } : void 0
          },
          r?.headers
        ]),
        __span: u(this._client, "anthropic.environments.retrieve", r, {
          route: "/v1/environments/{environment_id}",
          attributes: { "anthropic.environment.id": e }
        })
      });
    }
    /**
     * Update an existing environment's configuration.
     *
     * @example
     * ```ts
     * const betaEnvironment =
     *   await client.beta.environments.update(
     *     'env_011CZkZ9X2dpNyB7HsEFoRfW',
     *   );
     * ```
     */
    update(e, t, r) {
      const { betas: i, workspace_id: a, ...o } = t;
      return this._client.post(g`/v1/environments/${e}?beta=true`, {
        body: o,
        ...r,
        headers: f([
          {
            "anthropic-beta": [...i ?? [], "managed-agents-2026-04-01"].toString(),
            ...a != null ? { "anthropic-workspace-id": a } : void 0
          },
          r?.headers
        ]),
        __span: u(this._client, "anthropic.environments.update", r, {
          route: "/v1/environments/{environment_id}",
          attributes: { "anthropic.environment.id": e }
        })
      });
    }
    /**
     * List environments with pagination support.
     *
     * @example
     * ```ts
     * // Automatically fetches more pages as needed.
     * for await (const betaEnvironment of client.beta.environments.list()) {
     *   // ...
     * }
     * ```
     */
    list(e = {}, t) {
      const { betas: r, workspace_id: i, ...a } = e ?? {};
      return this._client.getAPIList("/v1/environments?beta=true", z, {
        query: a,
        ...t,
        headers: f([
          {
            "anthropic-beta": [...r ?? [], "managed-agents-2026-04-01"].toString(),
            ...i != null ? { "anthropic-workspace-id": i } : void 0
          },
          t?.headers
        ]),
        __span: u(this._client, "anthropic.environments.list", t, {
          route: "/v1/environments",
          queryParams: ["include_archived", "limit", "page"]
        })
      });
    }
    /**
     * Delete an environment by ID. Returns a confirmation of the deletion.
     *
     * @example
     * ```ts
     * const betaEnvironmentDeleteResponse =
     *   await client.beta.environments.delete(
     *     'env_011CZkZ9X2dpNyB7HsEFoRfW',
     *   );
     * ```
     */
    delete(e, t = {}, r) {
      const { betas: i, workspace_id: a } = t ?? {};
      return this._client.delete(g`/v1/environments/${e}?beta=true`, {
        ...r,
        headers: f([
          {
            "anthropic-beta": [...i ?? [], "managed-agents-2026-04-01"].toString(),
            ...a != null ? { "anthropic-workspace-id": a } : void 0
          },
          r?.headers
        ]),
        __span: u(this._client, "anthropic.environments.delete", r, {
          route: "/v1/environments/{environment_id}",
          attributes: { "anthropic.environment.id": e }
        })
      });
    }
    /**
     * Archive an environment by ID. Archived environments cannot be used to create new
     * sessions.
     *
     * @example
     * ```ts
     * const betaEnvironment =
     *   await client.beta.environments.archive(
     *     'env_011CZkZ9X2dpNyB7HsEFoRfW',
     *   );
     * ```
     */
    archive(e, t = {}, r) {
      const { betas: i, workspace_id: a } = t ?? {};
      return this._client.post(g`/v1/environments/${e}/archive?beta=true`, {
        ...r,
        headers: f([
          {
            "anthropic-beta": [...i ?? [], "managed-agents-2026-04-01"].toString(),
            ...a != null ? { "anthropic-workspace-id": a } : void 0
          },
          r?.headers
        ]),
        __span: u(this._client, "anthropic.environments.archive", r, {
          route: "/v1/environments/{environment_id}/archive",
          attributes: { "anthropic.environment.id": e }
        })
      });
    }
  }
  return s.Work = Za, s;
})();
class to extends x {
  /**
   * Create a Memory
   *
   * @example
   * ```ts
   * const betaManagedAgentsMemory =
   *   await client.beta.memoryStores.memories.create(
   *     'memory_store_id',
   *     { content: 'content', path: 'xx' },
   *   );
   * ```
   */
  create(n, e, t) {
    const { view: r, betas: i, workspace_id: a, ...o } = e;
    return this._client.post(g`/v1/memory_stores/${n}/memories?beta=true`, {
      query: { view: r },
      body: o,
      ...t,
      headers: f([
        {
          "anthropic-beta": [...i ?? [], "agent-memory-2026-07-22"].toString(),
          ...a != null ? { "anthropic-workspace-id": a } : void 0
        },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.memory_stores.memories.create", t, {
        route: "/v1/memory_stores/{memory_store_id}/memories",
        queryParams: ["view"],
        attributes: { "gen_ai.memory.store.id": n },
        createdIDAttribute: "gen_ai.memory.record.id"
      })
    });
  }
  /**
   * Retrieve a Memory
   *
   * @example
   * ```ts
   * const betaManagedAgentsMemory =
   *   await client.beta.memoryStores.memories.retrieve(
   *     'memory_id',
   *     { memory_store_id: 'memory_store_id' },
   *   );
   * ```
   */
  retrieve(n, e, t) {
    const { memory_store_id: r, betas: i, workspace_id: a, ...o } = e;
    return this._client.get(g`/v1/memory_stores/${r}/memories/${n}?beta=true`, {
      query: o,
      ...t,
      headers: f([
        {
          "anthropic-beta": [...i ?? [], "agent-memory-2026-07-22"].toString(),
          ...a != null ? { "anthropic-workspace-id": a } : void 0
        },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.memory_stores.memories.retrieve", t, {
        route: "/v1/memory_stores/{memory_store_id}/memories/{memory_id}",
        queryParams: ["view"],
        attributes: { "gen_ai.memory.store.id": r, "gen_ai.memory.record.id": n }
      })
    });
  }
  /**
   * Update a Memory
   *
   * @example
   * ```ts
   * const betaManagedAgentsMemory =
   *   await client.beta.memoryStores.memories.update(
   *     'memory_id',
   *     { memory_store_id: 'memory_store_id' },
   *   );
   * ```
   */
  update(n, e, t) {
    const { memory_store_id: r, view: i, betas: a, workspace_id: o, ...l } = e;
    return this._client.post(g`/v1/memory_stores/${r}/memories/${n}?beta=true`, {
      query: { view: i },
      body: l,
      ...t,
      headers: f([
        {
          "anthropic-beta": [...a ?? [], "agent-memory-2026-07-22"].toString(),
          ...o != null ? { "anthropic-workspace-id": o } : void 0
        },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.memory_stores.memories.update", t, {
        route: "/v1/memory_stores/{memory_store_id}/memories/{memory_id}",
        queryParams: ["view"],
        attributes: { "gen_ai.memory.store.id": r, "gen_ai.memory.record.id": n }
      })
    });
  }
  /**
   * List Memories
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaManagedAgentsMemoryListItem of client.beta.memoryStores.memories.list(
   *   'memory_store_id',
   * )) {
   *   // ...
   * }
   * ```
   */
  list(n, e = {}, t) {
    const { betas: r, workspace_id: i, ...a } = e ?? {};
    return this._client.getAPIList(g`/v1/memory_stores/${n}/memories?beta=true`, z, {
      query: a,
      ...t,
      headers: f([
        {
          "anthropic-beta": [...r ?? [], "agent-memory-2026-07-22"].toString(),
          ...i != null ? { "anthropic-workspace-id": i } : void 0
        },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.memory_stores.memories.list", t, {
        route: "/v1/memory_stores/{memory_store_id}/memories",
        queryParams: ["depth", "limit", "page", "path_prefix", "view"],
        contentQueryParams: ["page"],
        attributes: { "gen_ai.memory.store.id": n }
      })
    });
  }
  /**
   * Delete a Memory
   *
   * @example
   * ```ts
   * const betaManagedAgentsDeletedMemory =
   *   await client.beta.memoryStores.memories.delete(
   *     'memory_id',
   *     { memory_store_id: 'memory_store_id' },
   *   );
   * ```
   */
  delete(n, e, t) {
    const { memory_store_id: r, expected_content_sha256: i, betas: a, workspace_id: o } = e;
    return this._client.delete(g`/v1/memory_stores/${r}/memories/${n}?beta=true`, {
      query: { expected_content_sha256: i },
      ...t,
      headers: f([
        {
          "anthropic-beta": [...a ?? [], "agent-memory-2026-07-22"].toString(),
          ...o != null ? { "anthropic-workspace-id": o } : void 0
        },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.memory_stores.memories.delete", t, {
        route: "/v1/memory_stores/{memory_store_id}/memories/{memory_id}",
        queryParams: ["expected_content_sha256"],
        attributes: { "gen_ai.memory.store.id": r, "gen_ai.memory.record.id": n }
      })
    });
  }
}
class no extends x {
  /**
   * Retrieve a Memory Version
   *
   * @example
   * ```ts
   * const betaManagedAgentsMemoryVersion =
   *   await client.beta.memoryStores.memoryVersions.retrieve(
   *     'memory_version_id',
   *     { memory_store_id: 'memory_store_id' },
   *   );
   * ```
   */
  retrieve(n, e, t) {
    const { memory_store_id: r, betas: i, workspace_id: a, ...o } = e;
    return this._client.get(g`/v1/memory_stores/${r}/memory_versions/${n}?beta=true`, {
      query: o,
      ...t,
      headers: f([
        {
          "anthropic-beta": [...i ?? [], "agent-memory-2026-07-22"].toString(),
          ...a != null ? { "anthropic-workspace-id": a } : void 0
        },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.memory_stores.memory_versions.retrieve", t, {
        route: "/v1/memory_stores/{memory_store_id}/memory_versions/{memory_version_id}",
        queryParams: ["view"],
        attributes: {
          "gen_ai.memory.store.id": r,
          "anthropic.memory_store.memory_version.id": n
        }
      })
    });
  }
  /**
   * List Memory Versions
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaManagedAgentsMemoryVersion of client.beta.memoryStores.memoryVersions.list(
   *   'memory_store_id',
   * )) {
   *   // ...
   * }
   * ```
   */
  list(n, e = {}, t) {
    const { betas: r, workspace_id: i, ...a } = e ?? {};
    return this._client.getAPIList(g`/v1/memory_stores/${n}/memory_versions?beta=true`, z, {
      query: a,
      ...t,
      headers: f([
        {
          "anthropic-beta": [...r ?? [], "agent-memory-2026-07-22"].toString(),
          ...i != null ? { "anthropic-workspace-id": i } : void 0
        },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.memory_stores.memory_versions.list", t, {
        route: "/v1/memory_stores/{memory_store_id}/memory_versions",
        queryParams: [
          "api_key_id",
          "created_at[gte]",
          "created_at[lte]",
          "limit",
          "memory_id",
          "operation",
          "page",
          "service_account_id",
          "session_id",
          "view"
        ],
        attributes: { "gen_ai.memory.store.id": n }
      })
    });
  }
  /**
   * Redact a Memory Version
   *
   * @example
   * ```ts
   * const betaManagedAgentsMemoryVersion =
   *   await client.beta.memoryStores.memoryVersions.redact(
   *     'memory_version_id',
   *     { memory_store_id: 'memory_store_id' },
   *   );
   * ```
   */
  redact(n, e, t) {
    const { memory_store_id: r, betas: i, workspace_id: a } = e;
    return this._client.post(g`/v1/memory_stores/${r}/memory_versions/${n}/redact?beta=true`, {
      ...t,
      headers: f([
        {
          "anthropic-beta": [...i ?? [], "agent-memory-2026-07-22"].toString(),
          ...a != null ? { "anthropic-workspace-id": a } : void 0
        },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.memory_stores.memory_versions.redact", t, {
        route: "/v1/memory_stores/{memory_store_id}/memory_versions/{memory_version_id}/redact",
        attributes: {
          "gen_ai.memory.store.id": r,
          "anthropic.memory_store.memory_version.id": n
        }
      })
    });
  }
}
var so = /* @__PURE__ */ (() => {
  class s extends x {
    constructor() {
      super(...arguments), this.memories = new to(this._client), this.memoryVersions = new no(this._client);
    }
    /**
     * Create a Memory Store
     *
     * @example
     * ```ts
     * const betaManagedAgentsMemoryStore =
     *   await client.beta.memoryStores.create({ name: 'x' });
     * ```
     */
    create(e, t) {
      const { betas: r, workspace_id: i, ...a } = e;
      return this._client.post("/v1/memory_stores?beta=true", {
        body: a,
        ...t,
        headers: f([
          {
            "anthropic-beta": [...r ?? [], "agent-memory-2026-07-22"].toString(),
            ...i != null ? { "anthropic-workspace-id": i } : void 0
          },
          t?.headers
        ]),
        __span: u(this._client, "anthropic.memory_stores.create", t, {
          route: "/v1/memory_stores",
          createdIDAttribute: "gen_ai.memory.store.id"
        })
      });
    }
    /**
     * Retrieve a Memory Store
     *
     * @example
     * ```ts
     * const betaManagedAgentsMemoryStore =
     *   await client.beta.memoryStores.retrieve(
     *     'memory_store_id',
     *   );
     * ```
     */
    retrieve(e, t = {}, r) {
      const { betas: i, workspace_id: a } = t ?? {};
      return this._client.get(g`/v1/memory_stores/${e}?beta=true`, {
        ...r,
        headers: f([
          {
            "anthropic-beta": [...i ?? [], "agent-memory-2026-07-22"].toString(),
            ...a != null ? { "anthropic-workspace-id": a } : void 0
          },
          r?.headers
        ]),
        __span: u(this._client, "anthropic.memory_stores.retrieve", r, {
          route: "/v1/memory_stores/{memory_store_id}",
          attributes: { "gen_ai.memory.store.id": e }
        })
      });
    }
    /**
     * Update a Memory Store
     *
     * @example
     * ```ts
     * const betaManagedAgentsMemoryStore =
     *   await client.beta.memoryStores.update('memory_store_id');
     * ```
     */
    update(e, t, r) {
      const { betas: i, workspace_id: a, ...o } = t;
      return this._client.post(g`/v1/memory_stores/${e}?beta=true`, {
        body: o,
        ...r,
        headers: f([
          {
            "anthropic-beta": [...i ?? [], "agent-memory-2026-07-22"].toString(),
            ...a != null ? { "anthropic-workspace-id": a } : void 0
          },
          r?.headers
        ]),
        __span: u(this._client, "anthropic.memory_stores.update", r, {
          route: "/v1/memory_stores/{memory_store_id}",
          attributes: { "gen_ai.memory.store.id": e }
        })
      });
    }
    /**
     * List Memory Stores
     *
     * @example
     * ```ts
     * // Automatically fetches more pages as needed.
     * for await (const betaManagedAgentsMemoryStore of client.beta.memoryStores.list()) {
     *   // ...
     * }
     * ```
     */
    list(e = {}, t) {
      const { betas: r, workspace_id: i, ...a } = e ?? {};
      return this._client.getAPIList("/v1/memory_stores?beta=true", z, {
        query: a,
        ...t,
        headers: f([
          {
            "anthropic-beta": [...r ?? [], "agent-memory-2026-07-22"].toString(),
            ...i != null ? { "anthropic-workspace-id": i } : void 0
          },
          t?.headers
        ]),
        __span: u(this._client, "anthropic.memory_stores.list", t, {
          route: "/v1/memory_stores",
          queryParams: ["created_at[gte]", "created_at[lte]", "include_archived", "limit", "page"]
        })
      });
    }
    /**
     * Delete a Memory Store
     *
     * @example
     * ```ts
     * const betaManagedAgentsDeletedMemoryStore =
     *   await client.beta.memoryStores.delete('memory_store_id');
     * ```
     */
    delete(e, t = {}, r) {
      const { betas: i, workspace_id: a } = t ?? {};
      return this._client.delete(g`/v1/memory_stores/${e}?beta=true`, {
        ...r,
        headers: f([
          {
            "anthropic-beta": [...i ?? [], "agent-memory-2026-07-22"].toString(),
            ...a != null ? { "anthropic-workspace-id": a } : void 0
          },
          r?.headers
        ]),
        __span: u(this._client, "anthropic.memory_stores.delete", r, {
          route: "/v1/memory_stores/{memory_store_id}",
          attributes: { "gen_ai.memory.store.id": e }
        })
      });
    }
    /**
     * Archive a Memory Store
     *
     * @example
     * ```ts
     * const betaManagedAgentsMemoryStore =
     *   await client.beta.memoryStores.archive('memory_store_id');
     * ```
     */
    archive(e, t = {}, r) {
      const { betas: i, workspace_id: a } = t ?? {};
      return this._client.post(g`/v1/memory_stores/${e}/archive?beta=true`, {
        ...r,
        headers: f([
          {
            "anthropic-beta": [...i ?? [], "agent-memory-2026-07-22"].toString(),
            ...a != null ? { "anthropic-workspace-id": a } : void 0
          },
          r?.headers
        ]),
        __span: u(this._client, "anthropic.memory_stores.archive", r, {
          route: "/v1/memory_stores/{memory_store_id}/archive",
          attributes: { "gen_ai.memory.store.id": e }
        })
      });
    }
  }
  return s.Memories = to, s.MemoryVersions = no, s;
})();
class ro extends x {
  /**
   * Send a batch of Message creation requests.
   *
   * The Message Batches API can be used to process multiple Messages API requests at
   * once. Once a Message Batch is created, it begins processing immediately. Batches
   * can take up to 24 hours to complete.
   *
   * Learn more about the Message Batches API in our
   * [user guide](https://platform.claude.com/docs/en/build-with-claude/batch-processing)
   *
   * @example
   * ```ts
   * const betaMessageBatch =
   *   await client.beta.messages.batches.create({
   *     requests: [
   *       {
   *         custom_id: 'my-custom-id-1',
   *         params: {
   *           max_tokens: 1024,
   *           messages: [
   *             { content: 'Hello, world', role: 'user' },
   *           ],
   *           model: 'claude-opus-5-5',
   *         },
   *       },
   *     ],
   *   });
   * ```
   */
  create(n, e) {
    const { betas: t, user_profile_id: r, workspace_id: i, ...a } = n;
    return this._client.post("/v1/messages/batches?beta=true", {
      body: a,
      ...e,
      headers: f([
        {
          "anthropic-beta": [...t ?? [], "message-batches-2024-09-24"].toString(),
          ...r != null ? { "anthropic-user-profile-id": r } : void 0,
          ...i != null ? { "anthropic-workspace-id": i } : void 0
        },
        e?.headers
      ]),
      __span: u(this._client, "anthropic.messages.batches.create", e, {
        route: "/v1/messages/batches",
        // A request without `requests` is for the API to refuse, not for this line to throw on.
        attributes: { "anthropic.message.batch.request_count": a.requests?.length },
        createdIDAttribute: "anthropic.message.batch.id"
      })
    });
  }
  /**
   * This endpoint is idempotent and can be used to poll for Message Batch
   * completion. To access the results of a Message Batch, make a request to the
   * `results_url` field in the response.
   *
   * Learn more about the Message Batches API in our
   * [user guide](https://platform.claude.com/docs/en/build-with-claude/batch-processing)
   *
   * @example
   * ```ts
   * const betaMessageBatch =
   *   await client.beta.messages.batches.retrieve(
   *     'message_batch_id',
   *   );
   * ```
   */
  retrieve(n, e = {}, t) {
    const { betas: r, workspace_id: i } = e ?? {};
    return this._client.get(g`/v1/messages/batches/${n}?beta=true`, {
      ...t,
      headers: f([
        {
          "anthropic-beta": [...r ?? [], "message-batches-2024-09-24"].toString(),
          ...i != null ? { "anthropic-workspace-id": i } : void 0
        },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.messages.batches.retrieve", t, {
        route: "/v1/messages/batches/{message_batch_id}",
        attributes: { "anthropic.message.batch.id": n }
      })
    });
  }
  /**
   * List all Message Batches within a Workspace. Most recently created batches are
   * returned first.
   *
   * Learn more about the Message Batches API in our
   * [user guide](https://platform.claude.com/docs/en/build-with-claude/batch-processing)
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaMessageBatch of client.beta.messages.batches.list()) {
   *   // ...
   * }
   * ```
   */
  list(n = {}, e) {
    const { betas: t, workspace_id: r, ...i } = n ?? {};
    return this._client.getAPIList("/v1/messages/batches?beta=true", Y, {
      query: i,
      ...e,
      headers: f([
        {
          "anthropic-beta": [...t ?? [], "message-batches-2024-09-24"].toString(),
          ...r != null ? { "anthropic-workspace-id": r } : void 0
        },
        e?.headers
      ]),
      __span: u(this._client, "anthropic.messages.batches.list", e, {
        route: "/v1/messages/batches",
        queryParams: ["after_id", "before_id", "limit"]
      })
    });
  }
  /**
   * Delete a Message Batch.
   *
   * Message Batches can only be deleted once they've finished processing. If you'd
   * like to delete an in-progress batch, you must first cancel it.
   *
   * Learn more about the Message Batches API in our
   * [user guide](https://platform.claude.com/docs/en/build-with-claude/batch-processing)
   *
   * @example
   * ```ts
   * const betaDeletedMessageBatch =
   *   await client.beta.messages.batches.delete(
   *     'message_batch_id',
   *   );
   * ```
   */
  delete(n, e = {}, t) {
    const { betas: r, workspace_id: i } = e ?? {};
    return this._client.delete(g`/v1/messages/batches/${n}?beta=true`, {
      ...t,
      headers: f([
        {
          "anthropic-beta": [...r ?? [], "message-batches-2024-09-24"].toString(),
          ...i != null ? { "anthropic-workspace-id": i } : void 0
        },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.messages.batches.delete", t, {
        route: "/v1/messages/batches/{message_batch_id}",
        attributes: { "anthropic.message.batch.id": n }
      })
    });
  }
  /**
   * Batches may be canceled any time before processing ends. Once cancellation is
   * initiated, the batch enters a `canceling` state, at which time the system may
   * complete any in-progress, non-interruptible requests before finalizing
   * cancellation.
   *
   * The number of canceled requests is specified in `request_counts`. To determine
   * which requests were canceled, check the individual results within the batch.
   * Note that cancellation may not result in any canceled requests if they were
   * non-interruptible.
   *
   * Learn more about the Message Batches API in our
   * [user guide](https://platform.claude.com/docs/en/build-with-claude/batch-processing)
   *
   * @example
   * ```ts
   * const betaMessageBatch =
   *   await client.beta.messages.batches.cancel(
   *     'message_batch_id',
   *   );
   * ```
   */
  cancel(n, e = {}, t) {
    const { betas: r, workspace_id: i } = e ?? {};
    return this._client.post(g`/v1/messages/batches/${n}/cancel?beta=true`, {
      ...t,
      headers: f([
        {
          "anthropic-beta": [...r ?? [], "message-batches-2024-09-24"].toString(),
          ...i != null ? { "anthropic-workspace-id": i } : void 0
        },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.messages.batches.cancel", t, {
        route: "/v1/messages/batches/{message_batch_id}/cancel",
        attributes: { "anthropic.message.batch.id": n }
      })
    });
  }
  /**
   * Streams the results of a Message Batch as a `.jsonl` file.
   *
   * Each line in the file is a JSON object containing the result of a single request
   * in the Message Batch. Results are not guaranteed to be in the same order as
   * requests. Use the `custom_id` field to match results to requests.
   *
   * Learn more about the Message Batches API in our
   * [user guide](https://platform.claude.com/docs/en/build-with-claude/batch-processing)
   *
   * @example
   * ```ts
   * const stream = await client.beta.messages.batches.results(
   *   'message_batch_id',
   * );
   * for await (const betaMessageBatchIndividualResponse of stream) {
   *   // ...
   * }
   * ```
   */
  async results(n, e = {}, t) {
    const r = await this.retrieve(n, e, t);
    if (!r.results_url)
      throw new R(`No batch \`results_url\`; Has it finished processing? ${r.processing_status} - ${r.id}`);
    const { betas: i, workspace_id: a } = e ?? {};
    return this._client.get(r.results_url, {
      ...t,
      headers: f([
        {
          "anthropic-beta": [...i ?? [], "message-batches-2024-09-24"].toString(),
          Accept: "application/binary",
          ...a != null ? { "anthropic-workspace-id": a } : void 0
        },
        t?.headers
      ]),
      stream: !0,
      __binaryResponse: !0,
      __span: u(this._client, "anthropic.messages.batches.results", t, {
        route: "/v1/messages/batches/{message_batch_id}/results",
        attributes: { "anthropic.message.batch.id": n }
      })
    })._thenUnwrap((o, l) => Bu.fromResponse(l.response, l.controller));
  }
}
function Yu(s) {
  return s?.output_format ?? s?.output_config?.format;
}
function io(s, n, e) {
  const t = Yu(n);
  return !n || !("parse" in (t ?? {})) ? {
    ...s,
    content: s.content.map((r) => {
      if (r.type === "text") {
        const i = Object.defineProperty({ ...r }, "parsed_output", {
          value: null,
          enumerable: !1
        });
        return Object.defineProperty(i, "parsed", {
          get() {
            return e.logger.warn("The `parsed` property on `text` blocks is deprecated, please use `parsed_output` instead."), null;
          },
          enumerable: !1
        });
      }
      return r;
    }),
    parsed_output: null
  } : Xu(s, n, e);
}
function Xu(s, n, e) {
  let t = null;
  const r = s.content.map((i) => {
    if (i.type === "text") {
      const a = yg(n, i.text);
      t === null && (t = a);
      const o = Object.defineProperty({ ...i }, "parsed_output", {
        value: a,
        enumerable: !1
      });
      return Object.defineProperty(o, "parsed", {
        get() {
          return e.logger.warn("The `parsed` property on `text` blocks is deprecated, please use `parsed_output` instead."), a;
        },
        enumerable: !1
      });
    }
    return i;
  });
  return {
    ...s,
    content: r,
    parsed_output: t
  };
}
function yg(s, n) {
  const e = Yu(s);
  if (e?.type !== "json_schema")
    return null;
  try {
    return "parse" in e ? e.parse(n) : JSON.parse(n);
  } catch (t) {
    throw new R(`Failed to parse structured output: ${t}`);
  }
}
function Qu(s, n) {
  const { betas: e, user_profile_id: t, workspace_id: r, tools: i, messages: a } = s;
  return f([
    {
      ...e?.toString() != null ? { "anthropic-beta": e?.toString() } : void 0,
      ...t != null ? { "anthropic-user-profile-id": t } : void 0,
      ...r != null ? { "anthropic-workspace-id": r } : void 0
    },
    Tu(i, a),
    n?.headers
  ]);
}
function bg(s, n, e) {
  if (!s._tracer)
    return;
  const t = Qu(n, e);
  return u(s, "anthropic.messages.create", e, or(s, { ...gi(n), stream: !0 }, t));
}
function gi(s) {
  if (!s.output_format)
    return s;
  if (s.output_config?.format)
    throw new R("Both output_format and output_config.format were provided. Please use only output_config.format (output_format is deprecated).");
  const { output_format: n, ...e } = s;
  return {
    ...e,
    output_config: {
      ...s.output_config,
      format: n
    }
  };
}
var ee, He, ke, gn, ps, mn, yn, _s, bn, Se, wn, fs, gs, it, ms, ys, bs, vn, at, te, Ir, ao, kn, $r, Nr, Lr, oo, qr;
function Br(s) {
  return s.type === "tool_use" || s.type === "server_tool_use" || s.type === "mcp_tool_use";
}
var Zu = /* @__PURE__ */ (() => {
  class s {
    constructor(e, t) {
      ee.add(this), this.messages = [], this.receivedMessages = [], He.set(this, void 0), ke.set(this, null), this.controller = new AbortController(), gn.set(this, void 0), ps.set(this, () => {
      }), mn.set(this, () => {
      }), yn.set(this, void 0), _s.set(this, () => {
      }), bn.set(this, () => {
      }), Se.set(this, {}), wn.set(this, !1), fs.set(this, !1), gs.set(this, !1), it.set(this, !1), ms.set(this, void 0), ys.set(this, void 0), bs.set(this, void 0), vn.set(this, void 0), at.set(this, void 0), te.set(this, void 0), kn.set(this, (r) => {
        if (w(this, fs, !0), c(this, te, "f") && (c(this, te, "f").streamed = void 0), yt(r) && (r = new he()), r instanceof he)
          return w(this, gs, !0), this._emit("abort", r);
        if (r instanceof R)
          return this._emit("error", r);
        if (r instanceof Error) {
          const i = new R(r.message);
          return i.cause = r, this._emit("error", i);
        }
        return this._emit("error", new R(String(r)));
      }), w(this, gn, new Promise((r, i) => {
        w(this, ps, r, "f"), w(this, mn, i, "f");
      })), w(this, yn, new Promise((r, i) => {
        w(this, _s, r, "f"), w(this, bn, i, "f");
      })), c(this, gn, "f").catch(() => {
      }), c(this, yn, "f").catch(() => {
      }), w(this, ke, e), w(this, vn, t?.logger ?? console), w(this, at, t?.client);
    }
    get response() {
      return c(this, ms, "f");
    }
    get request_id() {
      return c(this, ys, "f");
    }
    get workspace_id() {
      return c(this, bs, "f");
    }
    /**
     * Returns the `MessageStream` data, the raw `Response` instance and the ID of the request,
     * returned vie the `request-id` header which is useful for debugging requests and resporting
     * issues to Anthropic.
     *
     * This is the same as the `APIPromise.withResponse()` method.
     *
     * This method will raise an error if you created the stream using `MessageStream.fromReadableStream`
     * as no `Response` is available.
     */
    async withResponse() {
      w(this, it, !0);
      const e = await c(this, gn, "f");
      if (!e)
        throw new Error("Could not resolve a `Response` object");
      return {
        data: this,
        response: e,
        request_id: e.headers.get("request-id"),
        workspace_id: e.headers.get("anthropic-workspace-id")
      };
    }
    /**
     * Intended for use on the frontend, consuming a stream produced with
     * `.toReadableStream()` on the backend.
     *
     * Note that messages sent to the model do not appear in `.on('message')`
     * in this context.
     */
    static fromReadableStream(e) {
      const t = new s(null);
      return t._run(() => t._fromReadableStream(e)), t;
    }
    static createMessage(e, t, r, { logger: i, client: a } = {}) {
      const o = new s(t, {
        logger: i,
        client: a
      });
      for (const l of t.messages)
        o._addMessageParam(l);
      return w(o, ke, { ...t, stream: !0 }), o._run(() => o._createMessage(e, { ...t, stream: !0 }, { ...r, headers: { ...r?.headers, [qi]: "stream" } })), o;
    }
    _run(e) {
      e().then(() => {
        this._emitFinal(), this._emit("end");
      }, c(this, kn, "f"));
    }
    _addMessageParam(e) {
      this.messages.push(e);
    }
    _addMessage(e, t = !0) {
      this.receivedMessages.push(e), t && this._emit("message", e);
    }
    async _createMessage(e, t, r) {
      const i = r?.signal;
      let a;
      i && (i.aborted && this.controller.abort(), a = this.controller.abort.bind(this.controller), i.addEventListener("abort", a));
      try {
        c(this, ee, "m", $r).call(this), w(this, te, r?.__span ?? (c(this, at, "f") && bg(c(this, at, "f"), t, r)), "f");
        const { response: o, data: l } = await e.create({ ...t, stream: !0 }, { ...r, __span: c(this, te, "f"), signal: this.controller.signal }).withResponse();
        try {
          this._connected(o);
        } catch (d) {
          throw c(this, te, "f") && (c(this, te, "f").failure = d), l.controller.abort(), d;
        }
        for await (const d of l)
          try {
            c(this, ee, "m", Nr).call(this, d);
          } catch (p) {
            throw c(this, te, "f") && (c(this, te, "f").failure = p), p;
          }
        if (l.controller.signal?.aborted)
          throw new he();
        c(this, ee, "m", Lr).call(this);
      } finally {
        i && a && i.removeEventListener("abort", a);
      }
    }
    _connected(e) {
      this.ended || (w(this, ms, e), w(this, ys, e?.headers.get("request-id")), w(this, bs, e?.headers.get("anthropic-workspace-id")), c(this, ps, "f").call(this, e), this._emit("connect"));
    }
    get ended() {
      return c(this, wn, "f");
    }
    get errored() {
      return c(this, fs, "f");
    }
    get aborted() {
      return c(this, gs, "f");
    }
    abort() {
      this.controller.abort();
    }
    /**
     * Adds the listener function to the end of the listeners array for the event.
     * No checks are made to see if the listener has already been added. Multiple calls passing
     * the same combination of event and listener will result in the listener being added, and
     * called, multiple times.
     * @returns this MessageStream, so that calls can be chained
     */
    on(e, t) {
      return (c(this, Se, "f")[e] || (c(this, Se, "f")[e] = [])).push({ listener: t }), this;
    }
    /**
     * Removes the specified listener from the listener array for the event.
     * off() will remove, at most, one instance of a listener from the listener array. If any single
     * listener has been added multiple times to the listener array for the specified event, then
     * off() must be called multiple times to remove each instance.
     * @returns this MessageStream, so that calls can be chained
     */
    off(e, t) {
      const r = c(this, Se, "f")[e];
      if (!r)
        return this;
      const i = r.findIndex((a) => a.listener === t);
      return i >= 0 && r.splice(i, 1), this;
    }
    /**
     * Adds a one-time listener function for the event. The next time the event is triggered,
     * this listener is removed and then invoked.
     * @returns this MessageStream, so that calls can be chained
     */
    once(e, t) {
      return (c(this, Se, "f")[e] || (c(this, Se, "f")[e] = [])).push({ listener: t, once: !0 }), this;
    }
    /**
     * This is similar to `.once()`, but returns a Promise that resolves the next time
     * the event is triggered, instead of calling a listener callback.
     * @returns a Promise that resolves the next time given event is triggered,
     * or rejects if an error is emitted.  (If you request the 'error' event,
     * returns a promise that resolves with the error).
     *
     * Example:
     *
     *   const message = await stream.emitted('message') // rejects if the stream errors
     */
    emitted(e) {
      return new Promise((t, r) => {
        w(this, it, !0), e !== "error" && this.once("error", r), this.once(e, t);
      });
    }
    async done() {
      w(this, it, !0), await c(this, yn, "f");
    }
    get currentMessage() {
      return c(this, He, "f");
    }
    /**
     * @returns a promise that resolves with the the final assistant Message response,
     * or rejects if an error occurred or the stream ended prematurely without producing a Message.
     * If structured outputs were used, this will be a ParsedMessage with a `parsed` field.
     */
    async finalMessage() {
      return await this.done(), c(this, ee, "m", Ir).call(this);
    }
    /**
     * @returns a promise that resolves with the the final assistant Message's text response, concatenated
     * together if there are more than one text blocks.
     * Rejects if an error occurred or the stream ended prematurely without producing a Message.
     */
    async finalText() {
      return await this.done(), c(this, ee, "m", ao).call(this);
    }
    _emit(e, ...t) {
      if (c(this, wn, "f"))
        return;
      e === "end" && (w(this, wn, !0), c(this, _s, "f").call(this));
      const r = c(this, Se, "f")[e];
      if (r && (c(this, Se, "f")[e] = r.filter((i) => !i.once), r.forEach(({ listener: i }) => i(...t))), e === "abort") {
        const i = t[0];
        !c(this, it, "f") && !r?.length && Promise.reject(i), c(this, mn, "f").call(this, i), c(this, bn, "f").call(this, i), this._emit("end");
        return;
      }
      if (e === "error") {
        const i = t[0];
        !c(this, it, "f") && !r?.length && Promise.reject(i), c(this, mn, "f").call(this, i), c(this, bn, "f").call(this, i), this._emit("end");
      }
    }
    _emitFinal() {
      this.receivedMessages.at(-1) && this._emit("finalMessage", c(this, ee, "m", Ir).call(this));
    }
    /** @internal A method so that the tool runner's stream can act before and after an event's listeners. */
    _deliverEvent(e, t) {
      this._emit("_rawEvent", e), t && this._emit("streamEvent", e, t);
    }
    async _fromReadableStream(e, t) {
      const r = t?.signal;
      let i;
      r && (r.aborted && this.controller.abort(), i = this.controller.abort.bind(this.controller), r.addEventListener("abort", i));
      try {
        c(this, ee, "m", $r).call(this), this._connected(null);
        const a = Ne.fromReadableStream(e, this.controller);
        for await (const o of a)
          c(this, ee, "m", Nr).call(this, o);
        if (a.controller.signal?.aborted)
          throw new he();
        c(this, ee, "m", Lr).call(this);
      } finally {
        r && i && r.removeEventListener("abort", i);
      }
    }
    [(He = /* @__PURE__ */ new WeakMap(), ke = /* @__PURE__ */ new WeakMap(), gn = /* @__PURE__ */ new WeakMap(), ps = /* @__PURE__ */ new WeakMap(), mn = /* @__PURE__ */ new WeakMap(), yn = /* @__PURE__ */ new WeakMap(), _s = /* @__PURE__ */ new WeakMap(), bn = /* @__PURE__ */ new WeakMap(), Se = /* @__PURE__ */ new WeakMap(), wn = /* @__PURE__ */ new WeakMap(), fs = /* @__PURE__ */ new WeakMap(), gs = /* @__PURE__ */ new WeakMap(), it = /* @__PURE__ */ new WeakMap(), ms = /* @__PURE__ */ new WeakMap(), ys = /* @__PURE__ */ new WeakMap(), bs = /* @__PURE__ */ new WeakMap(), vn = /* @__PURE__ */ new WeakMap(), at = /* @__PURE__ */ new WeakMap(), te = /* @__PURE__ */ new WeakMap(), kn = /* @__PURE__ */ new WeakMap(), ee = /* @__PURE__ */ new WeakSet(), Ir = function() {
      if (this.receivedMessages.length === 0)
        throw new R("stream ended without producing a Message with role=assistant");
      return this.receivedMessages.at(-1);
    }, ao = function() {
      if (this.receivedMessages.length === 0)
        throw new R("stream ended without producing a Message with role=assistant");
      const t = this.receivedMessages.at(-1).content.filter((r) => r.type === "text").map((r) => r.text);
      if (t.length === 0)
        throw new R("stream ended without producing a content block with type=text");
      return t.join(" ");
    }, $r = function() {
      this.ended || w(this, He, void 0);
    }, Nr = function(t) {
      if (this.ended)
        return;
      const r = c(this, ee, "m", oo).call(this, t);
      if (this._deliverEvent(t, r), !!r)
        switch (t.type) {
          case "content_block_delta": {
            const i = r.content.at(-1);
            switch (t.delta.type) {
              case "text_delta": {
                i.type === "text" && this._emit("text", t.delta.text, i.text || "");
                break;
              }
              case "citations_delta": {
                i.type === "text" && this._emit("citation", t.delta.citation, i.citations ?? []);
                break;
              }
              case "input_json_delta": {
                if (Br(i) && c(this, Se, "f").inputJson?.length) {
                  let a;
                  try {
                    a = i.input;
                  } catch (o) {
                    c(this, kn, "f").call(this, c(this, ee, "m", qr).call(this, i, o));
                    break;
                  }
                  this._emit("inputJson", t.delta.partial_json, a);
                }
                break;
              }
              case "thinking_delta": {
                i.type === "thinking" && this._emit("thinking", t.delta.thinking, i.thinking);
                break;
              }
              case "signature_delta": {
                i.type === "thinking" && this._emit("signature", i.signature);
                break;
              }
              case "compaction_delta": {
                i.type === "compaction" && i.content && this._emit("compaction", i.content);
                break;
              }
              default:
                t.delta;
            }
            break;
          }
          case "message_stop": {
            c(this, at, "f") && c(this, te, "f") && c(this, ke, "f") && Li(c(this, at, "f"), c(this, te, "f"), c(this, ke, "f"), r), this._addMessageParam(r), this._addMessage(io(r, c(this, ke, "f"), { logger: c(this, vn, "f") }), !0);
            break;
          }
          case "content_block_stop": {
            this._emit("contentBlock", r.content.at(-1));
            break;
          }
          case "message_start": {
            w(this, He, r), c(this, te, "f") && c(this, ke, "f") && (c(this, te, "f").streamed = { body: c(this, ke, "f"), message: r });
            break;
          }
        }
    }, Lr = function() {
      if (this.ended)
        throw new R("stream has ended, this shouldn't happen");
      const t = c(this, He, "f");
      if (!t)
        throw new R("request ended without sending any chunks");
      return w(this, He, void 0), io(t, c(this, ke, "f"), { logger: c(this, vn, "f") });
    }, oo = function(t) {
      let r = c(this, He, "f");
      if (t.type === "message_start") {
        if (r)
          throw new R(`Unexpected event order, got ${t.type} before receiving "message_stop"`);
        return t.message;
      }
      if (r)
        switch (t.type) {
          case "message_stop":
            return r;
          case "message_delta":
            return r.stop_reason = t.delta.stop_reason, r.stop_sequence = t.delta.stop_sequence, r.stop_details = t.delta.stop_details, r.usage.output_tokens = t.usage.output_tokens, t.delta.container != null && (r.container = t.delta.container), t.context_management != null && (r.context_management = t.context_management), t.input_transformations != null && (r.input_transformations = t.input_transformations), t.usage.input_tokens != null && (r.usage.input_tokens = t.usage.input_tokens), t.usage.cache_creation_input_tokens != null && (r.usage.cache_creation_input_tokens = t.usage.cache_creation_input_tokens), t.usage.cache_read_input_tokens != null && (r.usage.cache_read_input_tokens = t.usage.cache_read_input_tokens), t.usage.server_tool_use != null && (r.usage.server_tool_use = t.usage.server_tool_use), t.usage.iterations != null && (r.usage.iterations = t.usage.iterations), t.usage.fallback_credit != null && (r.usage.fallback_credit = t.usage.fallback_credit), t.usage.output_tokens_details != null && (r.usage.output_tokens_details = t.usage.output_tokens_details), r;
          case "content_block_start":
            return r.content.push(t.content_block), t.content_block.type === "fallback" && (r.model = t.content_block.to.model), r;
          case "content_block_delta": {
            const i = r.content.at(t.index);
            switch (t.delta.type) {
              case "text_delta": {
                i?.type === "text" && (r.content[t.index] = {
                  ...i,
                  text: (i.text || "") + t.delta.text
                });
                break;
              }
              case "citations_delta": {
                i?.type === "text" && (r.content[t.index] = {
                  ...i,
                  citations: [...i.citations ?? [], t.delta.citation]
                });
                break;
              }
              case "input_json_delta": {
                if (i && Br(i)) {
                  const a = (i[Ut] || "") + t.delta.partial_json;
                  r.content[t.index] = qu(i, a);
                }
                break;
              }
              case "thinking_delta": {
                i?.type === "thinking" && (r.content[t.index] = {
                  ...i,
                  thinking: i.thinking + t.delta.thinking
                });
                break;
              }
              case "signature_delta": {
                i?.type === "thinking" && (r.content[t.index] = {
                  ...i,
                  signature: t.delta.signature
                });
                break;
              }
              case "compaction_delta": {
                if (i?.type === "compaction") {
                  const a = { ...i, content: t.delta.content };
                  "encrypted_content" in t.delta && (a.encrypted_content = t.delta.encrypted_content), r.content[t.index] = a;
                }
                break;
              }
              default:
                t.delta;
            }
            return r;
          }
          case "content_block_stop": {
            const i = r.content.at(t.index);
            if (i && Br(i) && Ut in i) {
              let a;
              try {
                a = i.input;
              } catch (o) {
                a = {}, c(this, kn, "f").call(this, c(this, ee, "m", qr).call(this, i, o));
              }
              Object.defineProperty(i, "input", {
                value: a,
                enumerable: !0,
                configurable: !0,
                writable: !0
              });
            }
            return r;
          }
          default:
            return r;
        }
    }, qr = function(t, r) {
      const i = t[Ut];
      return new R(`Unable to parse tool parameter JSON from model. Please retry your request or adjust your prompt. Error: ${r}. JSON: ${i}`);
    }, Symbol.asyncIterator)]() {
      const e = [], t = [];
      let r = !1;
      return this.on("_rawEvent", (i) => {
        const a = t.shift();
        a ? a.resolve(i) : e.push(i);
      }), this.on("end", () => {
        r = !0;
        for (const i of t)
          i.resolve(void 0);
        t.length = 0;
      }), this.on("abort", (i) => {
        r = !0;
        for (const a of t)
          a.reject(i);
        t.length = 0;
      }), this.on("error", (i) => {
        r = !0;
        for (const a of t)
          a.reject(i);
        t.length = 0;
      }), {
        next: async () => e.length ? { value: e.shift(), done: !1 } : r ? { value: void 0, done: !0 } : new Promise((a, o) => t.push({ resolve: a, reject: o })).then((a) => a ? { value: a, done: !1 } : { value: void 0, done: !0 }),
        return: async () => (this.abort(), { value: void 0, done: !0 })
      };
    }
    toReadableStream() {
      return new Ne(this[Symbol.asyncIterator].bind(this), this.controller).toReadableStream();
    }
  }
  return s;
})();
const ed = {
  browser_toolset_20260801: "browser",
  computer_toolset_20260801: "computer"
};
function Gt(s) {
  return ed[s.type];
}
function Nn(s) {
  return "run" in s && s.type != null && Object.prototype.hasOwnProperty.call(ed, s.type);
}
class td extends R {
  constructor(n, e) {
    super(n), this.name = "ToolsetUsageError", e && "cause" in e && (this.cause = e.cause);
  }
}
class Bs extends td {
  constructor(n, e) {
    super(n, e), this.name = "ToolsetContractError";
  }
}
const nd = "Not executed: an earlier action in this turn failed.", co = {
  browser: nd,
  computer: "Not executed: an earlier computer action in this turn failed."
};
function wg(s) {
  return Object.prototype.hasOwnProperty.call(co, s) ? co[s] : nd;
}
function Qs(s, n, e = !1) {
  return e && (n === "" || Array.isArray(n) && n.length === 0) && (n = "The tool call failed with an empty error message."), {
    type: "tool_result",
    tool_use_id: s.id,
    toolset_name: s.toolset_name ?? null,
    content: n,
    ...e ? { is_error: !0 } : {}
  };
}
function vg(s, n) {
  if (s instanceof td)
    throw s;
  kg(n.signal);
}
function kg(s) {
  if (s?.aborted)
    throw new he();
}
async function Sg(s, n, e = {}) {
  const t = Gt(s);
  if (n.toolset_name !== t)
    throw new Bs(`tool_use ${JSON.stringify(n.id)} (toolset_name=${JSON.stringify(n.toolset_name ?? null)}, name=${JSON.stringify(n.name)}) is not a member call of the ${JSON.stringify(t)} toolset`);
  const r = { ...e, toolUse: n, toolUseBlock: n };
  try {
    return Qs(n, await s.run(r, n));
  } catch (i) {
    return vg(i, r), Qs(n, Yf(i instanceof Wi ? i.content : Jf(i)), !0);
  }
}
let lo = class extends x {
  /**
   * Get API Key
   *
   * @example
   * ```ts
   * const betaAPIKey =
   *   await client.beta.organization.apiKeys.retrieve(
   *     'api_key_id',
   *   );
   * ```
   */
  retrieve(n, e) {
    return this._client.get(g`/v1/organizations/api_keys/${n}?beta=true`, {
      ...e,
      __span: u(this._client, "anthropic.organization.api_keys.retrieve", e, {
        route: "/v1/organizations/api_keys/{api_key_id}",
        attributes: { "anthropic.organization.api_key.id": n }
      })
    });
  }
  /**
   * Update API Key
   *
   * @example
   * ```ts
   * const betaAPIKey =
   *   await client.beta.organization.apiKeys.update(
   *     'api_key_id',
   *   );
   * ```
   */
  update(n, e, t) {
    return this._client.post(g`/v1/organizations/api_keys/${n}?beta=true`, {
      body: e,
      ...t,
      __span: u(this._client, "anthropic.organization.api_keys.update", t, {
        route: "/v1/organizations/api_keys/{api_key_id}",
        attributes: { "anthropic.organization.api_key.id": n }
      })
    });
  }
  /**
   * List API Keys
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaAPIKey of client.beta.organization.apiKeys.list()) {
   *   // ...
   * }
   * ```
   */
  list(n = {}, e) {
    return this._client.getAPIList("/v1/organizations/api_keys?beta=true", Y, {
      query: n,
      ...e,
      __span: u(this._client, "anthropic.organization.api_keys.list", e, {
        route: "/v1/organizations/api_keys",
        queryParams: ["after_id", "before_id", "created_by_user_id", "limit", "status", "workspace_id"]
      })
    });
  }
};
class uo extends x {
  /**
   * Get artifact-creation activity for a given day, broken out by MIME type.
   *
   * Returns the full (`artifact_type`, `is_shared`) cube for the organization;
   * `next_page` is null except for grouped queries, which paginate. The cube can be
   * broken out per product, per member, or per RBAC group via `group_by[]`, and
   * scoped via `filter[]`. Requires an API key with the `read:analytics` scope.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaAnalyticsArtifactActivity of client.beta.organization.analytics.artifacts.list(
   *   { date: '2019-12-27' },
   * )) {
   *   // ...
   * }
   * ```
   */
  list(n, e) {
    return this._client.getAPIList("/v1/organizations/analytics/artifacts?beta=true", z, {
      query: n,
      ...e,
      __span: u(this._client, "anthropic.organization.analytics.artifacts.list", e, {
        route: "/v1/organizations/analytics/artifacts",
        queryParams: ["date", "filter", "group_by", "limit", "page"]
      })
    });
  }
}
class ho extends x {
  /**
   * Get per-connector usage for a given day, with cursor-based pagination.
   *
   * Returns connector usage metrics for the organization, sorted by connector name.
   * Connector names are normalized from their various sources — for example,
   * "Atlassian MCP server" and "mcp-atlassian" both appear as "atlassian". Use
   * `group_by[]` to break usage out per member, per RBAC group, or per product
   * surface, and `filter[]` to scope results; the parameter descriptions list the
   * supported dimensions. Available to organizations on a Claude Enterprise plan.
   * Requires an API key with the `read:analytics` scope.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaAnalyticsConnectorActivity of client.beta.organization.analytics.connectors.list()) {
   *   // ...
   * }
   * ```
   */
  list(n = {}, e) {
    return this._client.getAPIList("/v1/organizations/analytics/connectors?beta=true", z, {
      query: n,
      ...e,
      __span: u(this._client, "anthropic.organization.analytics.connectors.list", e, {
        route: "/v1/organizations/analytics/connectors",
        queryParams: [
          "date",
          "ending_date",
          "filter",
          "group_by",
          "limit",
          "order",
          "order_by",
          "page",
          "starting_date"
        ],
        contentQueryParams: ["filter"]
      })
    });
  }
}
class po extends x {
  /**
   * Get cost in USD over time across a date range.
   *
   * Returns cost bucketed by minute, hour, or day, optionally broken down by
   * product, model, context window, inference region, speed, cost type, or token
   * type. Available to organizations on a Claude Enterprise plan. Requires an API
   * key with the `read:analytics` scope.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaAnalyticsCostReportTimeBucket of client.beta.organization.analytics.costReport.list(
   *   { starting_at: '2019-12-27T18:11:19.117Z' },
   * )) {
   *   // ...
   * }
   * ```
   */
  list(n, e) {
    return this._client.getAPIList("/v1/organizations/analytics/cost_report?beta=true", lr, {
      query: n,
      ...e,
      __span: u(this._client, "anthropic.organization.analytics.cost_report.list", e, {
        route: "/v1/organizations/analytics/cost_report",
        queryParams: [
          "bucket_width",
          "claude_tag_categories",
          "claude_tag_user_ids",
          "context_windows",
          "ending_at",
          "group_by",
          "inference_geos",
          "limit",
          "models",
          "page",
          "products",
          "rbac_group_ids",
          "slack_channel_ids",
          "speeds",
          "starting_at",
          "user_ids"
        ]
      })
    });
  }
}
let _o = class extends x {
  /**
   * Get per-plugin install + invocation usage for a given day, with pagination.
   *
   * Returns plugin usage metrics for the organization across Cowork and Claude Code,
   * sorted by plugin name. The `plugin_name` value `third-party` is an aggregate
   * bucket, not a plugin: it collects plugin activity, from either surface, for
   * which the reporting client did not provide a plugin name — so an organization's
   * own plugins can contribute both to their own named rows and to this bucket. Use
   * `group_by[]` to break usage out per member, per RBAC group, or per product
   * surface (Cowork / Claude Code), and `filter[]` to scope results; the parameter
   * descriptions list the supported dimensions. Requires an API key with the
   * `read:analytics` scope. `starting_date` / `ending_date` select range-rollup mode
   * like `/skills`.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaAnalyticsPluginActivity of client.beta.organization.analytics.plugins.list()) {
   *   // ...
   * }
   * ```
   */
  list(n = {}, e) {
    return this._client.getAPIList("/v1/organizations/analytics/plugins?beta=true", z, {
      query: n,
      ...e,
      __span: u(this._client, "anthropic.organization.analytics.plugins.list", e, {
        route: "/v1/organizations/analytics/plugins",
        queryParams: [
          "date",
          "ending_date",
          "filter",
          "group_by",
          "limit",
          "order",
          "order_by",
          "page",
          "starting_date"
        ],
        contentQueryParams: ["filter"]
      })
    });
  }
}, fo = class extends x {
  /**
   * Get per-skill usage for a given day, with cursor-based pagination.
   *
   * Returns skill usage metrics for the organization, sorted by skill name. Use
   * `group_by[]` to break usage out per member, per RBAC group, or per product
   * surface, and `filter[]` to scope results; the parameter descriptions list the
   * supported dimensions. Available to organizations on a Claude Enterprise plan.
   * Requires an API key with the `read:analytics` scope.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaAnalyticsSkillActivity of client.beta.organization.analytics.skills.list()) {
   *   // ...
   * }
   * ```
   */
  list(n = {}, e) {
    return this._client.getAPIList("/v1/organizations/analytics/skills?beta=true", z, {
      query: n,
      ...e,
      __span: u(this._client, "anthropic.organization.analytics.skills.list", e, {
        route: "/v1/organizations/analytics/skills",
        queryParams: [
          "date",
          "ending_date",
          "filter",
          "group_by",
          "limit",
          "order",
          "order_by",
          "page",
          "starting_date"
        ],
        contentQueryParams: ["filter"]
      })
    });
  }
};
class go extends x {
  /**
   * Get organization-wide activity summaries for a date range.
   *
   * Returns one entry per day from `starting_date` (inclusive) to `ending_date`
   * (exclusive) in `data`, the same `data` / `next_page` envelope as the other
   * analytics list endpoints; the series is currently returned in full, so
   * `next_page` is always null. Data is typically available with a 1-day lag and may
   * be revised by a few percent over the following days: when `ending_date` is
   * omitted it defaults to the most recent available day + 1, so the last entry
   * covers the most recent available day. The series can be scoped to an RBAC group
   * via `filter[]=rbac_group_id:{id}`. Available to organizations on a Claude
   * Enterprise plan. Requires an API key with the `read:analytics` scope.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaAnalyticsSingleDayActivitySummary of client.beta.organization.analytics.summaries.list(
   *   { starting_date: '2019-12-27' },
   * )) {
   *   // ...
   * }
   * ```
   */
  list(n, e) {
    return this._client.getAPIList("/v1/organizations/analytics/summaries?beta=true", z, {
      query: n,
      ...e,
      __span: u(this._client, "anthropic.organization.analytics.summaries.list", e, {
        route: "/v1/organizations/analytics/summaries",
        queryParams: ["ending_date", "filter", "limit", "page", "starting_date"]
      })
    });
  }
}
class mo extends x {
  /**
   * Get token usage over time across a date range.
   *
   * Returns token usage bucketed by minute, hour, or day, optionally broken down by
   * product, model, context window, inference region, or speed. Available to
   * organizations on a Claude Enterprise plan. Requires an API key with the
   * `read:analytics` scope.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaAnalyticsUsageReportTimeBucket of client.beta.organization.analytics.usageReport.list(
   *   { starting_at: '2019-12-27T18:11:19.117Z' },
   * )) {
   *   // ...
   * }
   * ```
   */
  list(n, e) {
    return this._client.getAPIList("/v1/organizations/analytics/usage_report?beta=true", lr, {
      query: n,
      ...e,
      __span: u(this._client, "anthropic.organization.analytics.usage_report.list", e, {
        route: "/v1/organizations/analytics/usage_report",
        queryParams: [
          "bucket_width",
          "claude_tag_categories",
          "claude_tag_user_ids",
          "context_windows",
          "ending_at",
          "group_by",
          "inference_geos",
          "limit",
          "models",
          "page",
          "products",
          "rbac_group_ids",
          "slack_channel_ids",
          "speeds",
          "starting_at",
          "user_ids"
        ]
      })
    });
  }
}
class yo extends x {
  /**
   * Get per-user cost in USD across a date range.
   *
   * Returns one row per user, ranked by spend. Use this to see which users account
   * for the most cost. Only cost attributable to a seat user is included; for
   * organization-wide totals including direct API-key and automation traffic, use
   * the bucketed `/v1/organizations/analytics/cost_report` endpoint. Available to
   * organizations on a Claude Enterprise plan. Requires an API key with the
   * `read:analytics` scope.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaAnalyticsCostUsersItem of client.beta.organization.analytics.userCostReport.list(
   *   { starting_at: '2019-12-27T18:11:19.117Z' },
   * )) {
   *   // ...
   * }
   * ```
   */
  list(n, e) {
    return this._client.getAPIList("/v1/organizations/analytics/user_cost_report?beta=true", lr, {
      query: n,
      ...e,
      __span: u(this._client, "anthropic.organization.analytics.user_cost_report.list", e, {
        route: "/v1/organizations/analytics/user_cost_report",
        queryParams: [
          "bucket_width",
          "claude_tag_categories",
          "claude_tag_user_ids",
          "context_windows",
          "ending_at",
          "exclude_deleted_users",
          "group_by",
          "inference_geos",
          "limit",
          "models",
          "order",
          "order_by",
          "page",
          "products",
          "rbac_group_ids",
          "slack_channel_ids",
          "speeds",
          "starting_at",
          "user_ids"
        ]
      })
    });
  }
}
class bo extends x {
  /**
   * Get per-user token usage across a date range.
   *
   * Returns one row per user, ranked by the chosen token metric. Use this to see
   * which users consume the most tokens. Only usage attributable to a seat user is
   * included; for organization-wide totals including direct API-key and automation
   * traffic, use the bucketed `/v1/organizations/analytics/usage_report` endpoint.
   * Available to organizations on a Claude Enterprise plan. Requires an API key with
   * the `read:analytics` scope.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaAnalyticsUsageUsersItem of client.beta.organization.analytics.userUsageReport.list(
   *   { starting_at: '2019-12-27T18:11:19.117Z' },
   * )) {
   *   // ...
   * }
   * ```
   */
  list(n, e) {
    return this._client.getAPIList("/v1/organizations/analytics/user_usage_report?beta=true", lr, {
      query: n,
      ...e,
      __span: u(this._client, "anthropic.organization.analytics.user_usage_report.list", e, {
        route: "/v1/organizations/analytics/user_usage_report",
        queryParams: [
          "bucket_width",
          "claude_tag_categories",
          "claude_tag_user_ids",
          "context_windows",
          "ending_at",
          "exclude_deleted_users",
          "group_by",
          "inference_geos",
          "limit",
          "models",
          "order",
          "order_by",
          "page",
          "products",
          "rbac_group_ids",
          "slack_channel_ids",
          "speeds",
          "starting_at",
          "user_ids"
        ]
      })
    });
  }
}
let wo = class extends x {
  /**
   * Get per-user activity for a given day, with cursor-based pagination.
   *
   * Returns activity metrics for each user in the organization, sorted by email
   * address. Use `group_by[]` for per-RBAC-group aggregates, or `filter[]` to scope
   * results to specific members, groups, or a chat project. Available to
   * organizations on a Claude Enterprise plan. Requires an API key with the
   * `read:analytics` scope.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaAnalyticsUserActivity of client.beta.organization.analytics.users.list()) {
   *   // ...
   * }
   * ```
   */
  list(n = {}, e) {
    return this._client.getAPIList("/v1/organizations/analytics/users?beta=true", z, {
      query: n,
      ...e,
      __span: u(this._client, "anthropic.organization.analytics.users.list", e, {
        route: "/v1/organizations/analytics/users",
        queryParams: [
          "date",
          "ending_date",
          "filter",
          "group_by",
          "limit",
          "order",
          "order_by",
          "page",
          "starting_date"
        ],
        contentQueryParams: ["page"]
      })
    });
  }
};
class vo extends x {
  /**
   * Get per-project activity for a given day, with cursor-based pagination.
   *
   * Returns activity metrics for each project in the organization, sorted by project
   * ID. Use `group_by[]` to break projects out per member or per RBAC group, and
   * `filter[]` to scope results; the parameter descriptions list the supported
   * dimensions. Available to organizations on a Claude Enterprise plan. Requires an
   * API key with the `read:analytics` scope.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaAnalyticsProjectActivity of client.beta.organization.analytics.apps.chat.projects.list()) {
   *   // ...
   * }
   * ```
   */
  list(n = {}, e) {
    return this._client.getAPIList("/v1/organizations/analytics/apps/chat/projects?beta=true", z, {
      query: n,
      ...e,
      __span: u(this._client, "anthropic.organization.analytics.apps.chat.projects.list", e, {
        route: "/v1/organizations/analytics/apps/chat/projects",
        queryParams: [
          "date",
          "ending_date",
          "filter",
          "group_by",
          "limit",
          "order",
          "order_by",
          "page",
          "starting_date"
        ]
      })
    });
  }
}
var ko = /* @__PURE__ */ (() => {
  class s extends x {
    constructor() {
      super(...arguments), this.projects = new vo(this._client);
    }
  }
  return s.Projects = vo, s;
})(), So = /* @__PURE__ */ (() => {
  class s extends x {
    constructor() {
      super(...arguments), this.chat = new ko(this._client);
    }
  }
  return s.Chat = ko, s;
})(), To = /* @__PURE__ */ (() => {
  class s extends x {
    constructor() {
      super(...arguments), this.summaries = new go(this._client), this.users = new wo(this._client), this.apps = new So(this._client), this.connectors = new ho(this._client), this.plugins = new _o(this._client), this.skills = new fo(this._client), this.artifacts = new uo(this._client), this.usageReport = new mo(this._client), this.userUsageReport = new bo(this._client), this.costReport = new po(this._client), this.userCostReport = new yo(this._client);
    }
  }
  return s.Summaries = go, s.Users = wo, s.Apps = So, s.Connectors = ho, s.Plugins = _o, s.Skills = fo, s.Artifacts = uo, s.UsageReport = mo, s.UserUsageReport = bo, s.CostReport = po, s.UserCostReport = yo, s;
})();
let Ao = class extends x {
  /**
   * Retrieve your organization's Compliance Settings.
   *
   * Compliance Settings is a singleton resource: there is exactly one per
   * organization, addressed without an identifier. The `state` field reflects
   * whether the Compliance API is enabled. An organization with a parent
   * organization reads the state inherited from the parent's configuration.
   *
   * @example
   * ```ts
   * const betaComplianceSettings =
   *   await client.beta.organization.complianceSettings.retrieve();
   * ```
   */
  retrieve(n) {
    return this._client.get("/v1/organizations/compliance_settings?beta=true", {
      ...n,
      __span: u(this._client, "anthropic.organization.compliance_settings.retrieve", n, {
        route: "/v1/organizations/compliance_settings"
      })
    });
  }
  /**
   * Update your organization's Compliance Settings.
   *
   * Setting `state` to `enabled` turns on the Compliance API and begins capturing
   * organization activity events. Setting it to `disabled` turns both off. `state`
   * reflects whether the Compliance API is enabled.
   *
   * A request that sets `state` to its current value succeeds and leaves the
   * resource unchanged. A `disabled` request stays in effect until a later `enabled`
   * request or the organization's next provisioning action that enables Access
   * Transparency: enabling Access Transparency also enables the Compliance API,
   * which serves its activity events, so such provisioning (including re-runs)
   * re-enables the Compliance API even after a `disabled` request. Automated
   * provisioning never disables compliance settings.
   *
   * @example
   * ```ts
   * const betaComplianceSettings =
   *   await client.beta.organization.complianceSettings.update({
   *     state: { type: 'enabled' },
   *   });
   * ```
   */
  update(n, e) {
    return this._client.post("/v1/organizations/compliance_settings?beta=true", {
      body: n,
      ...e,
      __span: u(this._client, "anthropic.organization.compliance_settings.update", e, {
        route: "/v1/organizations/compliance_settings"
      })
    });
  }
}, xo = class extends x {
  /**
   * Create an external key config owned by the caller's organization.
   *
   * @example
   * ```ts
   * const betaExternalKey =
   *   await client.beta.organization.externalKeys.create({
   *     provider_config: {
   *       kms_arn:
   *         'arn:aws:kms:us-east-1:111122223333:key/abcd1234-5678-90ab-cdef-000011112222',
   *       type: 'aws',
   *     },
   *   });
   * ```
   */
  create(n, e) {
    return this._client.post("/v1/organizations/external_keys?beta=true", {
      body: n,
      ...e,
      __span: u(this._client, "anthropic.organization.external_keys.create", e, {
        route: "/v1/organizations/external_keys",
        createdIDAttribute: "anthropic.organization.external_key.id"
      })
    });
  }
  /**
   * Retrieve a single external key config in the caller's organization by ID.
   *
   * @example
   * ```ts
   * const betaExternalKey =
   *   await client.beta.organization.externalKeys.retrieve(
   *     'external_key_id',
   *   );
   * ```
   */
  retrieve(n, e) {
    return this._client.get(g`/v1/organizations/external_keys/${n}?beta=true`, {
      ...e,
      __span: u(this._client, "anthropic.organization.external_keys.retrieve", e, {
        route: "/v1/organizations/external_keys/{external_key_id}",
        attributes: { "anthropic.organization.external_key.id": n }
      })
    });
  }
  /**
   * Partially update an external key config. Omitted fields are left unchanged.
   *
   * `display_name` is always editable. `geo` and `provider_config` cannot be changed
   * once any workspace references this config, because previously encrypted data
   * requires the original key identity to decrypt.
   *
   * @example
   * ```ts
   * const betaExternalKey =
   *   await client.beta.organization.externalKeys.update(
   *     'external_key_id',
   *   );
   * ```
   */
  update(n, e, t) {
    return this._client.post(g`/v1/organizations/external_keys/${n}?beta=true`, {
      body: e,
      ...t,
      __span: u(this._client, "anthropic.organization.external_keys.update", t, {
        route: "/v1/organizations/external_keys/{external_key_id}",
        attributes: { "anthropic.organization.external_key.id": n }
      })
    });
  }
  /**
   * List external key configs in the caller's organization.
   *
   * Results are ordered by creation time (newest first). Use the `next_page` cursor
   * from the response to fetch subsequent pages.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaExternalKey of client.beta.organization.externalKeys.list()) {
   *   // ...
   * }
   * ```
   */
  list(n = {}, e) {
    return this._client.getAPIList("/v1/organizations/external_keys?beta=true", z, {
      query: n,
      ...e,
      __span: u(this._client, "anthropic.organization.external_keys.list", e, {
        route: "/v1/organizations/external_keys",
        queryParams: ["limit", "page"]
      })
    });
  }
  /**
   * Delete an external key config.
   *
   * The request is rejected if any workspace still references this config.
   *
   * @example
   * ```ts
   * const externalKey =
   *   await client.beta.organization.externalKeys.delete(
   *     'external_key_id',
   *   );
   * ```
   */
  delete(n, e) {
    return this._client.delete(g`/v1/organizations/external_keys/${n}?beta=true`, {
      ...e,
      __span: u(this._client, "anthropic.organization.external_keys.delete", e, {
        route: "/v1/organizations/external_keys/{external_key_id}",
        attributes: { "anthropic.organization.external_key.id": n }
      })
    });
  }
  /**
   * Validate an external key config against the customer's KMS.
   *
   * Anthropic performs an encrypt/decrypt roundtrip against the configured KMS key
   * and waits up to 30 seconds for the result. The response status is `success` if
   * the roundtrip succeeded, or `failure` with an error message if it failed or
   * timed out.
   *
   * @example
   * ```ts
   * const response =
   *   await client.beta.organization.externalKeys.validate(
   *     'external_key_id',
   *   );
   * ```
   */
  validate(n, e) {
    return this._client.post(g`/v1/organizations/external_keys/${n}/validate?beta=true`, {
      ...e,
      __span: u(this._client, "anthropic.organization.external_keys.validate", e, {
        route: "/v1/organizations/external_keys/{external_key_id}/validate",
        attributes: { "anthropic.organization.external_key.id": n }
      })
    });
  }
}, Eo = class extends x {
  /**
   * **Requires an OAuth access token with the `org:admin` scope**, from
   * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
   * API keys are not accepted. See
   * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
   *
   * Register an OIDC issuer that Anthropic will trust for workload identity
   * federation in your organization.
   *
   * The `jwks` field controls how the issuer's signing keys are obtained and takes
   * one of three shapes selected by `type`: `discovery` (resolve keys through OIDC
   * discovery), `explicit_url` (fetch keys from a fixed JWKS URL), or `inline`
   * (provide a static key set). When `jwks.type` is `discovery` and no
   * `discovery_base` is set, the issuer URL must be publicly reachable over HTTPS so
   * Anthropic can fetch the discovery document; for `explicit_url` and `inline`
   * modes the issuer URL is only matched as the JWT's `iss` claim and is not
   * fetched.
   *
   * @example
   * ```ts
   * const betaFederationIssuer =
   *   await client.beta.organization.federation.issuers.create({
   *     issuer_url: 'x',
   *     name: 'x',
   *   });
   * ```
   */
  create(n, e) {
    const { betas: t, ...r } = n;
    return this._client.post("/v1/organizations/federation_issuers?beta=true", {
      body: r,
      ...e,
      headers: f([
        { ...t?.toString() != null ? { "anthropic-beta": t?.toString() } : void 0 },
        e?.headers
      ]),
      __span: u(this._client, "anthropic.organization.federation.issuers.create", e, {
        route: "/v1/organizations/federation_issuers",
        createdIDAttribute: "anthropic.organization.federation_issuer.id"
      })
    });
  }
  /**
   * **Requires an OAuth access token with the `org:admin` scope**, from
   * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
   * API keys are not accepted. See
   * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
   *
   * Retrieve a federation issuer by its ID (`fdis_...`).
   *
   * @example
   * ```ts
   * const betaFederationIssuer =
   *   await client.beta.organization.federation.issuers.retrieve(
   *     'federation_issuer_id',
   *   );
   * ```
   */
  retrieve(n, e = {}, t) {
    const { betas: r } = e ?? {};
    return this._client.get(g`/v1/organizations/federation_issuers/${n}?beta=true`, {
      ...t,
      headers: f([
        { ...r?.toString() != null ? { "anthropic-beta": r?.toString() } : void 0 },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.organization.federation.issuers.retrieve", t, {
        route: "/v1/organizations/federation_issuers/{federation_issuer_id}",
        attributes: { "anthropic.organization.federation_issuer.id": n }
      })
    });
  }
  /**
   * **Requires an OAuth access token with the `org:admin` scope**, from
   * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
   * API keys are not accepted. See
   * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
   *
   * Partially update a federation issuer.
   *
   * Setting `jwks` replaces the full JWKS shape at once. Archived issuers cannot be
   * updated; this returns 400. Create a new issuer instead.
   *
   * Updating an issuer that backs a rule with a scope outside `workspace:developer`
   * or `workspace:inference` requires a Console session.
   *
   * @example
   * ```ts
   * const betaFederationIssuer =
   *   await client.beta.organization.federation.issuers.update(
   *     'federation_issuer_id',
   *   );
   * ```
   */
  update(n, e, t) {
    const { betas: r, ...i } = e;
    return this._client.post(g`/v1/organizations/federation_issuers/${n}?beta=true`, {
      body: i,
      ...t,
      headers: f([
        { ...r?.toString() != null ? { "anthropic-beta": r?.toString() } : void 0 },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.organization.federation.issuers.update", t, {
        route: "/v1/organizations/federation_issuers/{federation_issuer_id}",
        attributes: { "anthropic.organization.federation_issuer.id": n }
      })
    });
  }
  /**
   * **Requires an OAuth access token with the `org:admin` scope**, from
   * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
   * API keys are not accepted. See
   * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
   *
   * List federation issuers in your organization.
   *
   * Archived issuers are excluded unless `include_archived=true`.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaFederationIssuer of client.beta.organization.federation.issuers.list()) {
   *   // ...
   * }
   * ```
   */
  list(n = {}, e) {
    const { betas: t, ...r } = n ?? {};
    return this._client.getAPIList("/v1/organizations/federation_issuers?beta=true", z, {
      query: r,
      ...e,
      headers: f([
        { ...t?.toString() != null ? { "anthropic-beta": t?.toString() } : void 0 },
        e?.headers
      ]),
      __span: u(this._client, "anthropic.organization.federation.issuers.list", e, {
        route: "/v1/organizations/federation_issuers",
        queryParams: ["include_archived", "limit", "page"]
      })
    });
  }
  /**
   * **Requires an OAuth access token with the `org:admin` scope**, from
   * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
   * API keys are not accepted. See
   * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
   *
   * Archive a federation issuer.
   *
   * Idempotent; re-archiving returns the issuer with its original `archived_at`.
   * Rejected with 400 if any live (non-archived) federation rule still references
   * the issuer; archive those rules first (a rule's issuer cannot be changed), or
   * recreate them against another issuer.
   *
   * @example
   * ```ts
   * const betaFederationIssuer =
   *   await client.beta.organization.federation.issuers.archive(
   *     'federation_issuer_id',
   *   );
   * ```
   */
  archive(n, e = {}, t) {
    const { betas: r } = e ?? {};
    return this._client.post(g`/v1/organizations/federation_issuers/${n}/archive?beta=true`, {
      ...t,
      headers: f([
        { ...r?.toString() != null ? { "anthropic-beta": r?.toString() } : void 0 },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.organization.federation.issuers.archive", t, {
        route: "/v1/organizations/federation_issuers/{federation_issuer_id}/archive",
        attributes: { "anthropic.organization.federation_issuer.id": n }
      })
    });
  }
}, Ro = class extends x {
  /**
   * **Requires an OAuth access token with the `org:admin` scope**, from
   * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
   * API keys are not accepted. See
   * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
   *
   * List workspaces where this federation rule is enabled.
   *
   * Returns all workspace enablements in a single response; the `limit` and `page`
   * parameters are accepted but have no effect, and `next_page` is always `null`.
   * Returns explicit per-workspace enablements only; for rules with
   * `applies_to_all_workspaces` or a legacy single `workspace_id`, check those
   * fields on the rule itself.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaFederationRuleWorkspace of client.beta.organization.federation.rules.workspaces.list(
   *   'federation_rule_id',
   * )) {
   *   // ...
   * }
   * ```
   */
  list(n, e = {}, t) {
    const { betas: r, ...i } = e ?? {};
    return this._client.getAPIList(g`/v1/organizations/federation_rules/${n}/workspaces?beta=true`, z, {
      query: i,
      ...t,
      headers: f([
        { ...r?.toString() != null ? { "anthropic-beta": r?.toString() } : void 0 },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.organization.federation.rules.workspaces.list", t, {
        route: "/v1/organizations/federation_rules/{federation_rule_id}/workspaces",
        queryParams: ["limit", "page"],
        attributes: { "anthropic.organization.federation_rule.id": n }
      })
    });
  }
  /**
   * **Requires an OAuth access token with the `org:admin` scope**, from
   * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
   * API keys are not accepted. See
   * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
   *
   * Enable a federation rule for a workspace.
   *
   * Idempotent; re-enabling returns the existing enablement. The rule and workspace
   * must both belong to your organization. Membership of the rule's target service
   * account in this workspace is not checked at enablement: token exchange into this
   * workspace is rejected unless the target is a member (it is implicitly a member
   * of the default workspace). Archived rules are rejected with 400. OAuth callers
   * may only manage rules whose `oauth_scope` is `workspace:developer` or
   * `workspace:inference`; other scopes require a Console session.
   *
   * @example
   * ```ts
   * const betaFederationRuleWorkspace =
   *   await client.beta.organization.federation.rules.workspaces.add(
   *     'federation_rule_id',
   *     { workspace_id: 'workspace_id' },
   *   );
   * ```
   */
  add(n, e, t) {
    const { betas: r, ...i } = e;
    return this._client.post(g`/v1/organizations/federation_rules/${n}/workspaces?beta=true`, {
      body: i,
      ...t,
      headers: f([
        { ...r?.toString() != null ? { "anthropic-beta": r?.toString() } : void 0 },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.organization.federation.rules.workspaces.add", t, {
        route: "/v1/organizations/federation_rules/{federation_rule_id}/workspaces",
        attributes: { "anthropic.organization.federation_rule.id": n },
        createdIDAttribute: "anthropic.organization.federation_rule.workspace.id",
        createdIDField: "workspace_id"
      })
    });
  }
  /**
   * **Requires an OAuth access token with the `org:admin` scope**, from
   * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
   * API keys are not accepted. See
   * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
   *
   * Disable a federation rule for a workspace.
   *
   * Idempotent; succeeds even if the enablement was already removed. OAuth callers
   * may only manage rules whose `oauth_scope` is `workspace:developer` or
   * `workspace:inference`; other scopes require a Console session.
   *
   * @example
   * ```ts
   * const workspace =
   *   await client.beta.organization.federation.rules.workspaces.remove(
   *     'workspace_id',
   *     { federation_rule_id: 'federation_rule_id' },
   *   );
   * ```
   */
  remove(n, e, t) {
    const { federation_rule_id: r, betas: i } = e;
    return this._client.delete(g`/v1/organizations/federation_rules/${r}/workspaces/${n}?beta=true`, {
      ...t,
      headers: f([
        { ...i?.toString() != null ? { "anthropic-beta": i?.toString() } : void 0 },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.organization.federation.rules.workspaces.remove", t, {
        route: "/v1/organizations/federation_rules/{federation_rule_id}/workspaces/{workspace_id}",
        attributes: {
          "anthropic.organization.federation_rule.id": r,
          "anthropic.organization.federation_rule.workspace.id": n
        }
      })
    });
  }
};
var Po = /* @__PURE__ */ (() => {
  class s extends x {
    constructor() {
      super(...arguments), this.workspaces = new Ro(this._client);
    }
    /**
     * **Requires an OAuth access token with the `org:admin` scope**, from
     * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
     * API keys are not accepted. See
     * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
     *
     * Create a federation rule owned by your organization.
     *
     * The referenced issuer and the target service account must already exist in the
     * same organization; invalid references are rejected with a 400 error. The
     * workspace reference is validated. Membership is not checked at rule creation:
     * token exchange resolves a single enabled workspace per call and is rejected
     * unless the target service account is a member of that workspace (it is
     * implicitly a member of the default workspace). Rules on well-known shared
     * issuers (GitHub Actions, GitLab, Buildkite, Terraform Cloud, Google) must
     * constrain tenant identity via an identity-bearing claim, a tenant-pinning
     * subject prefix (such as `repo:YOUR_ORG/...`), or a CEL condition referencing one
     * of those identity claims (e.g. `claims.repository_owner`). OAuth callers may
     * only manage rules whose `oauth_scope` is `workspace:developer` or
     * `workspace:inference`; other scopes require a Console session.
     *
     * @example
     * ```ts
     * const betaFederationRule =
     *   await client.beta.organization.federation.rules.create({
     *     issuer_id: 'issuer_id',
     *     match: {},
     *     name: 'x',
     *     oauth_scope: 'x',
     *     target: {
     *       service_account_id: 'svac_01SDCCSbTxrXDpWc1phhtcfK',
     *       type: 'service_account',
     *     },
     *   });
     * ```
     */
    create(e, t) {
      const { betas: r, ...i } = e;
      return this._client.post("/v1/organizations/federation_rules?beta=true", {
        body: i,
        ...t,
        headers: f([
          { ...r?.toString() != null ? { "anthropic-beta": r?.toString() } : void 0 },
          t?.headers
        ]),
        __span: u(this._client, "anthropic.organization.federation.rules.create", t, {
          route: "/v1/organizations/federation_rules",
          createdIDAttribute: "anthropic.organization.federation_rule.id"
        })
      });
    }
    /**
     * **Requires an OAuth access token with the `org:admin` scope**, from
     * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
     * API keys are not accepted. See
     * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
     *
     * Retrieve a federation rule by its ID (`fdrl_...`).
     *
     * @example
     * ```ts
     * const betaFederationRule =
     *   await client.beta.organization.federation.rules.retrieve(
     *     'federation_rule_id',
     *   );
     * ```
     */
    retrieve(e, t = {}, r) {
      const { betas: i } = t ?? {};
      return this._client.get(g`/v1/organizations/federation_rules/${e}?beta=true`, {
        ...r,
        headers: f([
          { ...i?.toString() != null ? { "anthropic-beta": i?.toString() } : void 0 },
          r?.headers
        ]),
        __span: u(this._client, "anthropic.organization.federation.rules.retrieve", r, {
          route: "/v1/organizations/federation_rules/{federation_rule_id}",
          attributes: { "anthropic.organization.federation_rule.id": e }
        })
      });
    }
    /**
     * **Requires an OAuth access token with the `org:admin` scope**, from
     * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
     * API keys are not accepted. See
     * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
     *
     * Partially update a federation rule.
     *
     * `issuer_id` is immutable. `match` and `target` are replaced as whole objects
     * when set. Referenced service accounts and workspaces must exist in your
     * organization; invalid references are rejected with a 400 error. Archived rules
     * cannot be updated; this returns 400. Create a new rule instead. Rules on
     * well-known shared issuers (GitHub Actions, GitLab, Buildkite, Terraform Cloud,
     * Google) must constrain tenant identity via an identity-bearing claim, a
     * tenant-pinning subject prefix (such as `repo:YOUR_ORG/...`), or a CEL condition
     * referencing one of those identity claims (e.g. `claims.repository_owner`). On
     * these issuers the requirement is re-checked on every update; if an existing
     * rule's stored match does not yet constrain tenant identity, any update (even a
     * rename or description change) must also supply a conforming `match` in the same
     * request. OAuth callers may only manage rules whose `oauth_scope` is
     * `workspace:developer` or `workspace:inference`; other scopes require a Console
     * session.
     *
     * @example
     * ```ts
     * const betaFederationRule =
     *   await client.beta.organization.federation.rules.update(
     *     'federation_rule_id',
     *   );
     * ```
     */
    update(e, t, r) {
      const { betas: i, ...a } = t;
      return this._client.post(g`/v1/organizations/federation_rules/${e}?beta=true`, {
        body: a,
        ...r,
        headers: f([
          { ...i?.toString() != null ? { "anthropic-beta": i?.toString() } : void 0 },
          r?.headers
        ]),
        __span: u(this._client, "anthropic.organization.federation.rules.update", r, {
          route: "/v1/organizations/federation_rules/{federation_rule_id}",
          attributes: { "anthropic.organization.federation_rule.id": e }
        })
      });
    }
    /**
     * **Requires an OAuth access token with the `org:admin` scope**, from
     * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
     * API keys are not accepted. See
     * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
     *
     * List federation rules in your organization.
     *
     * Optionally filter by issuer with `issuer_id`. Archived rules are excluded unless
     * `include_archived=true`.
     *
     * @example
     * ```ts
     * // Automatically fetches more pages as needed.
     * for await (const betaFederationRule of client.beta.organization.federation.rules.list()) {
     *   // ...
     * }
     * ```
     */
    list(e = {}, t) {
      const { betas: r, ...i } = e ?? {};
      return this._client.getAPIList("/v1/organizations/federation_rules?beta=true", z, {
        query: i,
        ...t,
        headers: f([
          { ...r?.toString() != null ? { "anthropic-beta": r?.toString() } : void 0 },
          t?.headers
        ]),
        __span: u(this._client, "anthropic.organization.federation.rules.list", t, {
          route: "/v1/organizations/federation_rules",
          queryParams: ["include_archived", "issuer_id", "limit", "page"]
        })
      });
    }
    /**
     * **Requires an OAuth access token with the `org:admin` scope**, from
     * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
     * API keys are not accepted. See
     * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
     *
     * Archive a federation rule.
     *
     * Token exchange through this rule stops immediately. Idempotent; re-archiving
     * returns the rule with its original `archived_at`. Archiving clears the rule's
     * workspace targeting (`workspace_id` and `workspace_ids` are emptied). Tokens
     * already minted before archive remain valid until they expire. OAuth callers may
     * only manage rules whose `oauth_scope` is `workspace:developer` or
     * `workspace:inference`; other scopes require a Console session.
     *
     * @example
     * ```ts
     * const betaFederationRule =
     *   await client.beta.organization.federation.rules.archive(
     *     'federation_rule_id',
     *   );
     * ```
     */
    archive(e, t = {}, r) {
      const { betas: i } = t ?? {};
      return this._client.post(g`/v1/organizations/federation_rules/${e}/archive?beta=true`, {
        ...r,
        headers: f([
          { ...i?.toString() != null ? { "anthropic-beta": i?.toString() } : void 0 },
          r?.headers
        ]),
        __span: u(this._client, "anthropic.organization.federation.rules.archive", r, {
          route: "/v1/organizations/federation_rules/{federation_rule_id}/archive",
          attributes: { "anthropic.organization.federation_rule.id": e }
        })
      });
    }
  }
  return s.Workspaces = Ro, s;
})(), zo = /* @__PURE__ */ (() => {
  class s extends x {
    constructor() {
      super(...arguments), this.issuers = new Eo(this._client), this.rules = new Po(this._client);
    }
  }
  return s.Issuers = Eo, s.Rules = Po, s;
})();
let Mo = class extends x {
  /**
   * Invite a user to join the organization by email.
   *
   * On plans that draw members from a finite pool of purchased seats, the invite
   * automatically consumes a seat from the lowest tier with availability; there is
   * no seat-tier parameter. When no seat is free the request fails with a 400 error
   * rather than purchasing a seat.
   *
   * @example
   * ```ts
   * const betaOrganizationInvite =
   *   await client.beta.organization.invites.create({
   *     email: 'user@emaildomain.com',
   *     role: 'user',
   *   });
   * ```
   */
  create(n, e) {
    return this._client.post("/v1/organizations/invites?beta=true", {
      body: n,
      ...e,
      __span: u(this._client, "anthropic.organization.invites.create", e, {
        route: "/v1/organizations/invites",
        createdIDAttribute: "anthropic.organization.invite.id"
      })
    });
  }
  /**
   * Retrieve an invite by ID.
   *
   * @example
   * ```ts
   * const betaOrganizationInvite =
   *   await client.beta.organization.invites.retrieve(
   *     'invite_id',
   *   );
   * ```
   */
  retrieve(n, e) {
    return this._client.get(g`/v1/organizations/invites/${n}?beta=true`, {
      ...e,
      __span: u(this._client, "anthropic.organization.invites.retrieve", e, {
        route: "/v1/organizations/invites/{invite_id}",
        attributes: { "anthropic.organization.invite.id": n }
      })
    });
  }
  /**
   * List the organization's invites.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaOrganizationInvite of client.beta.organization.invites.list()) {
   *   // ...
   * }
   * ```
   */
  list(n = {}, e) {
    return this._client.getAPIList("/v1/organizations/invites?beta=true", Y, {
      query: n,
      ...e,
      __span: u(this._client, "anthropic.organization.invites.list", e, {
        route: "/v1/organizations/invites",
        queryParams: ["after_id", "before_id", "email", "limit", "roles", "statuses"]
      })
    });
  }
  /**
   * Delete a pending invite.
   *
   * @example
   * ```ts
   * const invite =
   *   await client.beta.organization.invites.delete(
   *     'invite_id',
   *   );
   * ```
   */
  delete(n, e) {
    return this._client.delete(g`/v1/organizations/invites/${n}?beta=true`, {
      ...e,
      __span: u(this._client, "anthropic.organization.invites.delete", e, {
        route: "/v1/organizations/invites/{invite_id}",
        attributes: { "anthropic.organization.invite.id": n }
      })
    });
  }
};
class Oo extends x {
  /**
   * Retrieve a plugin marketplace by ID.
   *
   * **Accepted credentials:** an Admin API key with the `read:plugins` or
   * `read:org_audit` scope, or a Compliance Access Key with the
   * `read:compliance_org_data` scope.
   *
   * Every request must include the beta header
   * `anthropic-beta: ce-plugins-2026-09-01`. A request without it returns `404`,
   * exactly as if the endpoint did not exist. The Plugins API is in beta and is
   * available to Claude Enterprise organizations only. It is not available to Claude
   * Platform (Claude Console) organizations, or to organizations with HIPAA
   * readiness enabled.
   *
   * @example
   * ```ts
   * const betaPluginMarketplace =
   *   await client.beta.organization.pluginMarketplaces.retrieve(
   *     'marketplace_id',
   *   );
   * ```
   */
  retrieve(n, e = {}, t) {
    const { betas: r, ...i } = e ?? {};
    return this._client.get(g`/v1/organizations/plugin_marketplaces/${n}?beta=true`, {
      query: i,
      ...t,
      headers: f([
        { "anthropic-beta": [...r ?? [], "ce-plugins-2026-09-01"].toString() },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.organization.plugin_marketplaces.retrieve", t, {
        route: "/v1/organizations/plugin_marketplaces/{marketplace_id}",
        queryParams: ["organization_id"],
        attributes: { "anthropic.organization.plugin_marketplace.id": n }
      })
    });
  }
  /**
   * Set the default installation setting of one of the organization's own plugin
   * marketplaces. Every Plugin in it without a setting of its own gets this default
   * as its organization-wide setting, including Plugins added later.
   *
   * Pass it as `default_installation_preference`. A member's personal marketplace
   * cannot be updated here (403).
   *
   * **Accepted credentials:** an Admin API key with the `write:plugins` scope.
   *
   * Every request must include the beta header
   * `anthropic-beta: ce-plugins-2026-09-01`. A request without it returns `404`,
   * exactly as if the endpoint did not exist. The Plugins API is in beta and is
   * available to Claude Enterprise organizations only. It is not available to Claude
   * Platform (Claude Console) organizations, or to organizations with HIPAA
   * readiness enabled.
   *
   * @example
   * ```ts
   * const betaPluginMarketplace =
   *   await client.beta.organization.pluginMarketplaces.update(
   *     'marketplace_id',
   *     { default_installation_preference: 'available' },
   *   );
   * ```
   */
  update(n, e, t) {
    const { betas: r, ...i } = e;
    return this._client.post(g`/v1/organizations/plugin_marketplaces/${n}?beta=true`, {
      body: i,
      ...t,
      headers: f([
        { "anthropic-beta": [...r ?? [], "ce-plugins-2026-09-01"].toString() },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.organization.plugin_marketplaces.update", t, {
        route: "/v1/organizations/plugin_marketplaces/{marketplace_id}",
        attributes: { "anthropic.organization.plugin_marketplace.id": n }
      })
    });
  }
  /**
   * List the plugin marketplaces Plugins live in, newest first: the organization's
   * own and its members' personal ones.
   *
   * Plugin marketplaces are created, connected to a repository and deleted in
   * claude.ai, not through this API. The organization's library marketplace, the
   * organization-owned `manual` marketplace that uploads go to when no marketplace
   * is named, is created the first time something is put in it and is listed from
   * then on.
   *
   * **Accepted credentials:** an Admin API key with the `read:plugins` or
   * `read:org_audit` scope, or a Compliance Access Key with the
   * `read:compliance_org_data` scope.
   *
   * Every request must include the beta header
   * `anthropic-beta: ce-plugins-2026-09-01`. A request without it returns `404`,
   * exactly as if the endpoint did not exist. The Plugins API is in beta and is
   * available to Claude Enterprise organizations only. It is not available to Claude
   * Platform (Claude Console) organizations, or to organizations with HIPAA
   * readiness enabled.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaPluginMarketplace of client.beta.organization.pluginMarketplaces.list()) {
   *   // ...
   * }
   * ```
   */
  list(n = {}, e) {
    const { betas: t, ...r } = n ?? {};
    return this._client.getAPIList("/v1/organizations/plugin_marketplaces?beta=true", z, {
      query: r,
      ...e,
      headers: f([
        { "anthropic-beta": [...t ?? [], "ce-plugins-2026-09-01"].toString() },
        e?.headers
      ]),
      __span: u(this._client, "anthropic.organization.plugin_marketplaces.list", e, {
        route: "/v1/organizations/plugin_marketplaces",
        queryParams: ["limit", "organization_id", "owner_type", "page", "source"]
      })
    });
  }
  /**
   * Check whether a plugin marketplace, uploaded as a `.zip` of the marketplace
   * directory, would synchronize into claude.ai, without connecting or storing it.
   *
   * To check a public GitHub repository instead, use Validate Plugin Marketplace
   * Repository.
   *
   * The report says whether `marketplace.json` is well-formed, which plugins a
   * synchronization would skip and why, and which plugins would synchronize only in
   * part, with some files left out. An archive that cannot be read as a marketplace
   * is reported, not refused: the response is a report with `valid: false`. Plugin
   * sources outside the marketplace are fetched anonymously from GitHub, so a
   * private one is reported as not found; a source on any other host is not fetched
   * here, and the report notes that it will be checked when the marketplace actually
   * synchronizes.
   *
   * Nothing is recorded on the Compliance API activity feed.
   *
   * For a worked example, see
   * [Validate marketplace content](/docs/en/manage-claude/plugins-api#validate-marketplace-content)
   * in the Plugins API guide.
   *
   * **Accepted credentials:** an Admin API key with the `read:plugins` or
   * `write:plugins` scope; `read:org_audit` and `read:compliance_org_data` do not
   * grant it.
   *
   * Every request must include the beta header
   * `anthropic-beta: ce-plugins-2026-09-01`. A request without it returns `404`,
   * exactly as if the endpoint did not exist. The Plugins API is in beta and is
   * available to Claude Enterprise organizations only. It is not available to Claude
   * Platform (Claude Console) organizations, or to organizations with HIPAA
   * readiness enabled.
   *
   * @example
   * ```ts
   * const betaPluginMarketplaceValidationReport =
   *   await client.beta.organization.pluginMarketplaces.validateArchive(
   *     { archive: fs.createReadStream('path/to/file') },
   *   );
   * ```
   */
  validateArchive(n, e) {
    const { betas: t, ...r } = n;
    return this._client.post("/v1/organizations/plugin_marketplaces/validate_archive?beta=true", Le({
      body: r,
      ...e,
      headers: f([
        { "anthropic-beta": [...t ?? [], "ce-plugins-2026-09-01"].toString() },
        e?.headers
      ]),
      __span: u(this._client, "anthropic.organization.plugin_marketplaces.validate_archive", e, { route: "/v1/organizations/plugin_marketplaces/validate_archive" })
    }, this._client));
  }
  /**
   * Check whether a plugin marketplace held in a public GitHub repository would
   * synchronize into claude.ai, without connecting or storing it.
   *
   * To check a `.zip` of the marketplace directory instead, use Validate Plugin
   * Marketplace Archive.
   *
   * The report says whether `marketplace.json` is well-formed, which plugins a
   * synchronization would skip and why, and which plugins would synchronize only in
   * part, with some files left out. A repository that is missing, private, or has no
   * such branch or commit is reported, not refused: the response is a report with
   * `valid: false`. Plugin sources outside the marketplace are fetched anonymously
   * from GitHub, so a private one is reported as not found; a source on any other
   * host is not fetched here, and the report notes that it will be checked when the
   * marketplace actually synchronizes.
   *
   * Nothing is recorded on the Compliance API activity feed.
   *
   * For a worked example, see
   * [Validate marketplace content](/docs/en/manage-claude/plugins-api#validate-marketplace-content)
   * in the Plugins API guide.
   *
   * **Accepted credentials:** an Admin API key with the `read:plugins` or
   * `write:plugins` scope; `read:org_audit` and `read:compliance_org_data` do not
   * grant it.
   *
   * Every request must include the beta header
   * `anthropic-beta: ce-plugins-2026-09-01`. A request without it returns `404`,
   * exactly as if the endpoint did not exist. The Plugins API is in beta and is
   * available to Claude Enterprise organizations only. It is not available to Claude
   * Platform (Claude Console) organizations, or to organizations with HIPAA
   * readiness enabled.
   *
   * @example
   * ```ts
   * const betaPluginMarketplaceValidationReport =
   *   await client.beta.organization.pluginMarketplaces.validateRepository(
   *     {
   *       repository_url:
   *         'https://github.com/example-org/example-marketplace',
   *     },
   *   );
   * ```
   */
  validateRepository(n, e) {
    const { betas: t, ...r } = n;
    return this._client.post("/v1/organizations/plugin_marketplaces/validate_repository?beta=true", {
      body: r,
      ...e,
      headers: f([
        { "anthropic-beta": [...t ?? [], "ce-plugins-2026-09-01"].toString() },
        e?.headers
      ]),
      __span: u(this._client, "anthropic.organization.plugin_marketplaces.validate_repository", e, { route: "/v1/organizations/plugin_marketplaces/validate_repository" })
    });
  }
}
let Co = class extends x {
  /**
   * List Messages API rate limits for your organization.
   *
   * Each entry corresponds to one rate-limit group (either a model family or an
   * API-surface category such as the Message Batches API or the web search tool) and
   * contains the set of limiter values that apply to it.
   *
   * When `limit` is omitted, every matching entry is returned in a single page; when
   * `limit` truncates the result, follow `next_page` to fetch the remaining entries.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaOrganizationRateLimit of client.beta.organization.rateLimits.list()) {
   *   // ...
   * }
   * ```
   */
  list(n = {}, e) {
    return this._client.getAPIList("/v1/organizations/rate_limits?beta=true", z, {
      query: n,
      ...e,
      __span: u(this._client, "anthropic.organization.rate_limits.list", e, {
        route: "/v1/organizations/rate_limits",
        queryParams: ["group_type", "limit", "model", "page"]
      })
    });
  }
}, Io = class extends x {
  /**
   * Retrieve a member of the organization by user ID.
   *
   * @example
   * ```ts
   * const betaOrganizationUser =
   *   await client.beta.organization.users.retrieve('user_id');
   * ```
   */
  retrieve(n, e) {
    return this._client.get(g`/v1/organizations/users/${n}?beta=true`, {
      ...e,
      __span: u(this._client, "anthropic.organization.users.retrieve", e, {
        route: "/v1/organizations/users/{user_id}",
        attributes: { "anthropic.organization.user.id": n }
      })
    });
  }
  /**
   * Update a member's organization role.
   *
   * @example
   * ```ts
   * const betaOrganizationUser =
   *   await client.beta.organization.users.update('user_id', {
   *     role: 'user',
   *   });
   * ```
   */
  update(n, e, t) {
    return this._client.post(g`/v1/organizations/users/${n}?beta=true`, {
      body: e,
      ...t,
      __span: u(this._client, "anthropic.organization.users.update", t, {
        route: "/v1/organizations/users/{user_id}",
        attributes: { "anthropic.organization.user.id": n }
      })
    });
  }
  /**
   * List the organization's members.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaOrganizationUser of client.beta.organization.users.list()) {
   *   // ...
   * }
   * ```
   */
  list(n = {}, e) {
    return this._client.getAPIList("/v1/organizations/users?beta=true", Y, {
      query: n,
      ...e,
      __span: u(this._client, "anthropic.organization.users.list", e, {
        route: "/v1/organizations/users",
        queryParams: ["after_id", "before_id", "email", "limit", "roles"]
      })
    });
  }
  /**
   * Remove a member from the organization.
   *
   * @example
   * ```ts
   * const user = await client.beta.organization.users.remove(
   *   'user_id',
   * );
   * ```
   */
  remove(n, e) {
    return this._client.delete(g`/v1/organizations/users/${n}?beta=true`, {
      ...e,
      __span: u(this._client, "anthropic.organization.users.remove", e, {
        route: "/v1/organizations/users/{user_id}",
        attributes: { "anthropic.organization.user.id": n }
      })
    });
  }
};
class $o extends x {
  /**
   * Create an organization webhook endpoint.
   *
   * An organization webhook endpoint belongs to the organization rather than to one
   * of its workspaces. An organization can have at most 32 organization webhook
   * endpoints, enabled or disabled.
   *
   * The response includes the endpoint's signing secret. No read returns it, so
   * store it when you receive it.
   *
   * Every request must include the beta header
   * `anthropic-beta: webhooks-2026-10-07`. A request without it returns `404`,
   * exactly as if this API did not exist. Anthropic turns organization webhook
   * endpoints on for each organization; until yours is on, requests also return
   * `404`. Organization webhook endpoints are in beta and are not available to
   * organizations with HIPAA readiness enabled.
   *
   * @example
   * ```ts
   * const betaNewOrganizationWebhookEndpoint =
   *   await client.beta.organization.webhooks.create({
   *     enabled_events: [
   *       'user_profile.enforcement_action_opened',
   *     ],
   *     url: 'x',
   *   });
   * ```
   */
  create(n, e) {
    const { betas: t, ...r } = n;
    return this._client.post("/v1/organizations/webhooks?beta=true", {
      body: r,
      ...e,
      headers: f([
        { "anthropic-beta": [...t ?? [], "webhooks-2026-10-07"].toString() },
        e?.headers
      ]),
      __span: u(this._client, "anthropic.organization.webhooks.create", e, {
        route: "/v1/organizations/webhooks",
        createdIDAttribute: "anthropic.organization.webhook.id"
      })
    });
  }
  /**
   * Retrieve an organization webhook endpoint by ID.
   *
   * Every request must include the beta header
   * `anthropic-beta: webhooks-2026-10-07`. A request without it returns `404`,
   * exactly as if this API did not exist. Anthropic turns organization webhook
   * endpoints on for each organization; until yours is on, requests also return
   * `404`. Organization webhook endpoints are in beta and are not available to
   * organizations with HIPAA readiness enabled.
   *
   * @example
   * ```ts
   * const betaOrganizationWebhookEndpoint =
   *   await client.beta.organization.webhooks.retrieve(
   *     'webhook_endpoint_id',
   *   );
   * ```
   */
  retrieve(n, e = {}, t) {
    const { betas: r } = e ?? {};
    return this._client.get(g`/v1/organizations/webhooks/${n}?beta=true`, {
      ...t,
      headers: f([
        { "anthropic-beta": [...r ?? [], "webhooks-2026-10-07"].toString() },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.organization.webhooks.retrieve", t, {
        route: "/v1/organizations/webhooks/{webhook_endpoint_id}",
        attributes: { "anthropic.organization.webhook.id": n }
      })
    });
  }
  /**
   * Update an organization webhook endpoint. Only the fields you send are changed.
   *
   * Every request must include the beta header
   * `anthropic-beta: webhooks-2026-10-07`. A request without it returns `404`,
   * exactly as if this API did not exist. Anthropic turns organization webhook
   * endpoints on for each organization; until yours is on, requests also return
   * `404`. Organization webhook endpoints are in beta and are not available to
   * organizations with HIPAA readiness enabled.
   *
   * @example
   * ```ts
   * const betaOrganizationWebhookEndpoint =
   *   await client.beta.organization.webhooks.update(
   *     'webhook_endpoint_id',
   *   );
   * ```
   */
  update(n, e, t) {
    const { betas: r, ...i } = e;
    return this._client.post(g`/v1/organizations/webhooks/${n}?beta=true`, {
      body: i,
      ...t,
      headers: f([
        { "anthropic-beta": [...r ?? [], "webhooks-2026-10-07"].toString() },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.organization.webhooks.update", t, {
        route: "/v1/organizations/webhooks/{webhook_endpoint_id}",
        attributes: { "anthropic.organization.webhook.id": n }
      })
    });
  }
  /**
   * List the organization's webhook endpoints.
   *
   * An organization webhook endpoint belongs to the organization rather than to one
   * of its workspaces. The list does not include webhook endpoints that belong to a
   * workspace.
   *
   * Every request must include the beta header
   * `anthropic-beta: webhooks-2026-10-07`. A request without it returns `404`,
   * exactly as if this API did not exist. Anthropic turns organization webhook
   * endpoints on for each organization; until yours is on, requests also return
   * `404`. Organization webhook endpoints are in beta and are not available to
   * organizations with HIPAA readiness enabled.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaOrganizationWebhookEndpoint of client.beta.organization.webhooks.list()) {
   *   // ...
   * }
   * ```
   */
  list(n = {}, e) {
    const { betas: t, ...r } = n ?? {};
    return this._client.getAPIList("/v1/organizations/webhooks?beta=true", Y, {
      query: r,
      ...e,
      headers: f([
        { "anthropic-beta": [...t ?? [], "webhooks-2026-10-07"].toString() },
        e?.headers
      ]),
      __span: u(this._client, "anthropic.organization.webhooks.list", e, {
        route: "/v1/organizations/webhooks",
        queryParams: ["after_id", "before_id", "limit", "order"]
      })
    });
  }
  /**
   * Delete an organization webhook endpoint.
   *
   * Every request must include the beta header
   * `anthropic-beta: webhooks-2026-10-07`. A request without it returns `404`,
   * exactly as if this API did not exist. Anthropic turns organization webhook
   * endpoints on for each organization; until yours is on, requests also return
   * `404`. Organization webhook endpoints are in beta and are not available to
   * organizations with HIPAA readiness enabled.
   *
   * @example
   * ```ts
   * const betaDeletedOrganizationWebhookEndpoint =
   *   await client.beta.organization.webhooks.delete(
   *     'webhook_endpoint_id',
   *   );
   * ```
   */
  delete(n, e = {}, t) {
    const { betas: r } = e ?? {};
    return this._client.delete(g`/v1/organizations/webhooks/${n}?beta=true`, {
      ...t,
      headers: f([
        { "anthropic-beta": [...r ?? [], "webhooks-2026-10-07"].toString() },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.organization.webhooks.delete", t, {
        route: "/v1/organizations/webhooks/{webhook_endpoint_id}",
        attributes: { "anthropic.organization.webhook.id": n }
      })
    });
  }
  /**
   * Replace an organization webhook endpoint's signing secret. The old secret stops
   * working immediately. The new secret is returned only in this response.
   *
   * Every request must include the beta header
   * `anthropic-beta: webhooks-2026-10-07`. A request without it returns `404`,
   * exactly as if this API did not exist. Anthropic turns organization webhook
   * endpoints on for each organization; until yours is on, requests also return
   * `404`. Organization webhook endpoints are in beta and are not available to
   * organizations with HIPAA readiness enabled.
   *
   * @example
   * ```ts
   * const betaOrganizationWebhookEndpointSigningSecret =
   *   await client.beta.organization.webhooks.regenerateSigningSecret(
   *     'webhook_endpoint_id',
   *   );
   * ```
   */
  regenerateSigningSecret(n, e = {}, t) {
    const { betas: r } = e ?? {};
    return this._client.post(g`/v1/organizations/webhooks/${n}/regenerate_signing_secret?beta=true`, {
      ...t,
      headers: f([
        { "anthropic-beta": [...r ?? [], "webhooks-2026-10-07"].toString() },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.organization.webhooks.regenerate_signing_secret", t, {
        route: "/v1/organizations/webhooks/{webhook_endpoint_id}/regenerate_signing_secret",
        attributes: { "anthropic.organization.webhook.id": n }
      })
    });
  }
}
class No extends x {
  /**
   * List an organization-owned Plugin's installation settings, which say which
   * members it is for, most recently created first.
   *
   * The list holds the Plugin's own organization-wide setting (absent while the
   * Plugin inherits its marketplace's default) and each RBAC Group's own setting. A
   * member-owned Plugin has shares instead, so this path returns 404 for one.
   *
   * **Accepted credentials:** an Admin API key with the `read:plugins` or
   * `read:org_audit` scope, or a Compliance Access Key with the
   * `read:compliance_org_data` scope.
   *
   * Every request must include the beta header
   * `anthropic-beta: ce-plugins-2026-09-01`. A request without it returns `404`,
   * exactly as if the endpoint did not exist. The Plugins API is in beta and is
   * available to Claude Enterprise organizations only. It is not available to Claude
   * Platform (Claude Console) organizations, or to organizations with HIPAA
   * readiness enabled.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaPluginInstallationSetting of client.beta.organization.plugins.installationSettings.list(
   *   'plugin_id',
   * )) {
   *   // ...
   * }
   * ```
   */
  list(n, e = {}, t) {
    const { betas: r, ...i } = e ?? {};
    return this._client.getAPIList(g`/v1/organizations/plugins/${n}/installation_settings?beta=true`, z, {
      query: i,
      ...t,
      headers: f([
        { "anthropic-beta": [...r ?? [], "ce-plugins-2026-09-01"].toString() },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.organization.plugins.installation_settings.list", t, {
        route: "/v1/organizations/plugins/{plugin_id}/installation_settings",
        queryParams: ["limit", "organization_id", "page", "target_type"],
        attributes: { "anthropic.organization.plugin.id": n }
      })
    });
  }
  /**
   * Remove an organization-owned Plugin's own installation setting for the whole
   * organization or for one RBAC Group.
   *
   * Removing the `organization` target returns the Plugin to its marketplace's
   * default installation setting and leaves the groups' settings in place. Removing
   * a group's setting makes the group's members fall back to the Plugin's
   * organization-wide setting or to the settings of their other groups.
   *
   * A target that holds no setting of its own returns 404 (a Plugin that already
   * inherits its marketplace's default holds no `organization` setting), and so does
   * a member-owned Plugin.
   *
   * A removal counts as one of the Plugin's installation-setting writes: send all of
   * those writes one at a time. If several arrive for the same Plugin at the same
   * time, the server handles them one after another and can answer some of them with
   * `503` and `x-should-retry: true` instead of applying them; wait a second or two
   * and send the removal again. A `404` on the repeat means the setting is already
   * gone.
   *
   * **Accepted credentials:** an Admin API key with the `write:plugins` scope.
   *
   * Every request must include the beta header
   * `anthropic-beta: ce-plugins-2026-09-01`. A request without it returns `404`,
   * exactly as if the endpoint did not exist. The Plugins API is in beta and is
   * available to Claude Enterprise organizations only. It is not available to Claude
   * Platform (Claude Console) organizations, or to organizations with HIPAA
   * readiness enabled.
   *
   * @example
   * ```ts
   * const betaDeletedPluginInstallationSetting =
   *   await client.beta.organization.plugins.installationSettings.remove(
   *     'target',
   *     { plugin_id: 'plugin_id' },
   *   );
   * ```
   */
  remove(n, e, t) {
    const { plugin_id: r, betas: i } = e;
    return this._client.delete(g`/v1/organizations/plugins/${r}/installation_settings/${n}?beta=true`, {
      ...t,
      headers: f([
        { "anthropic-beta": [...i ?? [], "ce-plugins-2026-09-01"].toString() },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.organization.plugins.installation_settings.remove", t, {
        route: "/v1/organizations/plugins/{plugin_id}/installation_settings/{target}",
        attributes: {
          "anthropic.organization.plugin.id": r,
          "anthropic.organization.plugin.installation_setting.id": n
        }
      })
    });
  }
  /**
   * Set or change an organization-owned Plugin's installation setting for the whole
   * organization or for one RBAC Group.
   *
   * Writing the value a target already holds of its own changes nothing.
   *
   * A member-owned Plugin has shares instead of installation settings, so this path
   * returns 404 for one.
   *
   * Send a Plugin's installation-setting writes one at a time. If several writes for
   * the same Plugin arrive at the same time, the server handles them one after
   * another and can answer some of them with `503` instead of applying them. That
   * `503` carries `x-should-retry: true`, and the write is safe to repeat: wait a
   * second or two, then send it again.
   *
   * **Accepted credentials:** an Admin API key with the `write:plugins` scope.
   *
   * Every request must include the beta header
   * `anthropic-beta: ce-plugins-2026-09-01`. A request without it returns `404`,
   * exactly as if the endpoint did not exist. The Plugins API is in beta and is
   * available to Claude Enterprise organizations only. It is not available to Claude
   * Platform (Claude Console) organizations, or to organizations with HIPAA
   * readiness enabled.
   *
   * @example
   * ```ts
   * const betaPluginInstallationSetting =
   *   await client.beta.organization.plugins.installationSettings.set(
   *     'target',
   *     {
   *       plugin_id: 'plugin_id',
   *       installation_preference: 'required',
   *     },
   *   );
   * ```
   */
  set(n, e, t) {
    const { plugin_id: r, betas: i, ...a } = e;
    return this._client.post(g`/v1/organizations/plugins/${r}/installation_settings/${n}?beta=true`, {
      body: a,
      ...t,
      headers: f([
        { "anthropic-beta": [...i ?? [], "ce-plugins-2026-09-01"].toString() },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.organization.plugins.installation_settings.set", t, {
        route: "/v1/organizations/plugins/{plugin_id}/installation_settings/{target}",
        attributes: {
          "anthropic.organization.plugin.id": r,
          "anthropic.organization.plugin.installation_setting.id": n
        }
      })
    });
  }
}
class Lo extends x {
  /**
   * List the shares the owner of a member-owned Plugin has given — to every member
   * of the organization, to an RBAC Group, or to one member — most recently granted
   * first.
   *
   * Shares are read-only in this API: members give and withdraw them in claude.ai,
   * and who gave a share is recorded on the Compliance API activity feed rather than
   * on the share. An organization-owned Plugin has installation settings instead, so
   * this path returns 404 for one.
   *
   * **Accepted credentials:** an Admin API key with the `read:plugins` or
   * `read:org_audit` scope, or a Compliance Access Key with the
   * `read:compliance_org_data` scope.
   *
   * Every request must include the beta header
   * `anthropic-beta: ce-plugins-2026-09-01`. A request without it returns `404`,
   * exactly as if the endpoint did not exist. The Plugins API is in beta and is
   * available to Claude Enterprise organizations only. It is not available to Claude
   * Platform (Claude Console) organizations, or to organizations with HIPAA
   * readiness enabled.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaPluginShare of client.beta.organization.plugins.shares.list(
   *   'plugin_id',
   * )) {
   *   // ...
   * }
   * ```
   */
  list(n, e = {}, t) {
    const { betas: r, ...i } = e ?? {};
    return this._client.getAPIList(g`/v1/organizations/plugins/${n}/shares?beta=true`, z, {
      query: i,
      ...t,
      headers: f([
        { "anthropic-beta": [...r ?? [], "ce-plugins-2026-09-01"].toString() },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.organization.plugins.shares.list", t, {
        route: "/v1/organizations/plugins/{plugin_id}/shares",
        queryParams: ["limit", "organization_id", "page", "target_type"],
        attributes: { "anthropic.organization.plugin.id": n }
      })
    });
  }
}
let qo = class extends x {
  /**
   * Add a version to an organization-owned Plugin by uploading the new version's
   * files; it becomes the version served to members unless the Plugin's served
   * version has been pinned.
   *
   * The upload is the same `multipart/form-data` as creating a Plugin: the version's
   * files (`files`, each part sent as `files[]`) and optional `release_notes`. The
   * uploaded manifest's `name` must equal the Plugin's `name`. Returns the stored
   * version; read the Plugin back to see which version it serves.
   *
   * Only a Plugin in a `manual` marketplace takes uploads; a Plugin synchronized
   * from a repository gets its versions from the repository. When the Plugin is in
   * the organization's library marketplace, a version that adds a skill with the
   * name of an organization skill (a skill an administrator uploaded for the whole
   * organization in claude.ai) is refused with a 409: `error_code`
   * `skill_name_taken`, with that name in `details.skill_name`. A 503 with
   * `error_code` `registration_pending` means the version was stored but is not yet
   * usable; a later version create on the Plugin completes it.
   *
   * For a worked example, see
   * [Create a version](/docs/en/manage-claude/plugins-api#create-a-version) in the
   * Plugins API guide.
   *
   * **Accepted credentials:** an Admin API key with the `write:plugins` scope.
   *
   * Every request must include the beta header
   * `anthropic-beta: ce-plugins-2026-09-01`. A request without it returns `404`,
   * exactly as if the endpoint did not exist. The Plugins API is in beta and is
   * available to Claude Enterprise organizations only. It is not available to Claude
   * Platform (Claude Console) organizations, or to organizations with HIPAA
   * readiness enabled.
   *
   * @example
   * ```ts
   * const betaPluginVersion =
   *   await client.beta.organization.plugins.versions.create(
   *     'plugin_id',
   *     { files: [fs.createReadStream('path/to/file')] },
   *   );
   * ```
   */
  create(n, e, t) {
    const { betas: r, ...i } = e;
    return this._client.post(g`/v1/organizations/plugins/${n}/versions?beta=true`, Le({
      body: i,
      ...t,
      headers: f([
        { "anthropic-beta": [...r ?? [], "ce-plugins-2026-09-01"].toString() },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.organization.plugins.versions.create", t, {
        route: "/v1/organizations/plugins/{plugin_id}/versions",
        attributes: { "anthropic.organization.plugin.id": n },
        createdIDAttribute: "anthropic.organization.plugin.version.id"
      })
    }, this._client));
  }
  /**
   * Retrieve one version of a Plugin by its ID, or the Plugin's newest version.
   *
   * **Accepted credentials:** an Admin API key with the `read:plugins` or
   * `read:org_audit` scope, or a Compliance Access Key with the
   * `read:compliance_org_data` scope.
   *
   * Every request must include the beta header
   * `anthropic-beta: ce-plugins-2026-09-01`. A request without it returns `404`,
   * exactly as if the endpoint did not exist. The Plugins API is in beta and is
   * available to Claude Enterprise organizations only. It is not available to Claude
   * Platform (Claude Console) organizations, or to organizations with HIPAA
   * readiness enabled.
   *
   * @example
   * ```ts
   * const betaPluginVersion =
   *   await client.beta.organization.plugins.versions.retrieve(
   *     'version',
   *     { plugin_id: 'plugin_id' },
   *   );
   * ```
   */
  retrieve(n, e, t) {
    const { plugin_id: r, betas: i, ...a } = e;
    return this._client.get(g`/v1/organizations/plugins/${r}/versions/${n}?beta=true`, {
      query: a,
      ...t,
      headers: f([
        { "anthropic-beta": [...i ?? [], "ce-plugins-2026-09-01"].toString() },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.organization.plugins.versions.retrieve", t, {
        route: "/v1/organizations/plugins/{plugin_id}/versions/{version}",
        queryParams: ["organization_id"],
        attributes: {
          "anthropic.organization.plugin.id": r,
          "anthropic.organization.plugin.version.id": n
        }
      })
    });
  }
  /**
   * List a Plugin's versions, newest first.
   *
   * The first item of the first page is the version the Plugin's `latest_version_id`
   * refers to.
   *
   * **Accepted credentials:** an Admin API key with the `read:plugins` or
   * `read:org_audit` scope, or a Compliance Access Key with the
   * `read:compliance_org_data` scope.
   *
   * Every request must include the beta header
   * `anthropic-beta: ce-plugins-2026-09-01`. A request without it returns `404`,
   * exactly as if the endpoint did not exist. The Plugins API is in beta and is
   * available to Claude Enterprise organizations only. It is not available to Claude
   * Platform (Claude Console) organizations, or to organizations with HIPAA
   * readiness enabled.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaPluginVersion of client.beta.organization.plugins.versions.list(
   *   'plugin_id',
   * )) {
   *   // ...
   * }
   * ```
   */
  list(n, e = {}, t) {
    const { betas: r, ...i } = e ?? {};
    return this._client.getAPIList(g`/v1/organizations/plugins/${n}/versions?beta=true`, z, {
      query: i,
      ...t,
      headers: f([
        { "anthropic-beta": [...r ?? [], "ce-plugins-2026-09-01"].toString() },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.organization.plugins.versions.list", t, {
        route: "/v1/organizations/plugins/{plugin_id}/versions",
        queryParams: ["limit", "organization_id", "page"],
        attributes: { "anthropic.organization.plugin.id": n }
      })
    });
  }
  /**
   * Download one version's `.zip` archive, exactly as stored. Each download of a
   * Plugin from a member's personal plugin marketplace is recorded on the Compliance
   * API activity feed.
   *
   * The response body is the archive (`Content-Type: application/zip`), sent as an
   * attachment whose filename is derived from the Plugin's name; name saved files
   * from the IDs in the request path, since that filename is not unique.
   *
   * **Accepted credentials:** an Admin API key with the `read:plugins` or
   * `read:org_audit` scope, or a Compliance Access Key with the
   * `read:compliance_org_data` scope.
   *
   * Every read scope above (`read:plugins`, `read:org_audit`, and
   * `read:compliance_org_data`) can download the files of plugins in members'
   * personal marketplaces, including files that claude.ai's admin settings do not
   * show, and a `read:org_audit` or `read:compliance_org_data` key created for all
   * of your parent organization's linked organizations can do this in any
   * organization under it that has access to this API, by passing `organization_id`.
   * Each such download records a `claude_plugin_archive_accessed` event on the
   * Compliance API activity feed, identifying the key, the plugin, the version, and
   * the member. Downloads of organization-owned plugins are not recorded.
   *
   * Every request must include the beta header
   * `anthropic-beta: ce-plugins-2026-09-01`. A request without it returns `404`,
   * exactly as if the endpoint did not exist. The Plugins API is in beta and is
   * available to Claude Enterprise organizations only. It is not available to Claude
   * Platform (Claude Console) organizations, or to organizations with HIPAA
   * readiness enabled.
   *
   * @example
   * ```ts
   * const response =
   *   await client.beta.organization.plugins.versions.download(
   *     'version',
   *     { plugin_id: 'plugin_id' },
   *   );
   *
   * const content = await response.blob();
   * console.log(content);
   * ```
   */
  download(n, e, t) {
    const { plugin_id: r, betas: i, ...a } = e;
    return this._client.get(g`/v1/organizations/plugins/${r}/versions/${n}/content?beta=true`, {
      query: a,
      ...t,
      headers: f([
        {
          "anthropic-beta": [...i ?? [], "ce-plugins-2026-09-01"].toString(),
          Accept: "application/binary"
        },
        t?.headers
      ]),
      __binaryResponse: !0,
      __span: u(this._client, "anthropic.organization.plugins.versions.download", t, {
        route: "/v1/organizations/plugins/{plugin_id}/versions/{version}/content",
        queryParams: ["organization_id"],
        attributes: {
          "anthropic.organization.plugin.id": r,
          "anthropic.organization.plugin.version.id": n
        }
      })
    });
  }
};
var Bo = /* @__PURE__ */ (() => {
  class s extends x {
    constructor() {
      super(...arguments), this.versions = new qo(this._client), this.installationSettings = new No(this._client), this.shares = new Lo(this._client);
    }
    /**
     * Create an organization-owned Plugin and its first version by uploading the
     * version's files.
     *
     * The upload is `multipart/form-data`: the version's files (`files`, each part
     * sent as `files[]`), with an optional `marketplace_id` and `release_notes`. The
     * manifest's `name` becomes the Plugin's `name`, and `display_name`, `description`
     * and `manifest_version` come from the manifest too.
     *
     * `name` may contain lowercase letters (from any alphabet), digits, and hyphens,
     * up to 64 characters. Uppercase letters, spaces, underscores, and other
     * punctuation are rejected.
     *
     * The `name` must be unique within the marketplace: a name already taken returns a
     * 409 with `error_code` `plugin_name_taken` and, when a Plugin holds it, that
     * Plugin's ID in `details.plugin_id`. A Plugin going into the organization's
     * library marketplace is also refused with a 409 when one of its skills has the
     * name of an organization skill (a skill an administrator uploaded for the whole
     * organization in claude.ai): `error_code` `skill_name_taken`, with that name in
     * `details.skill_name`; rename the skill, or remove the organization skill in
     * claude.ai. A 503 with `error_code` `registration_pending` means the Plugin and
     * its version were stored (their IDs are in `details`) but are not yet usable in
     * claude.ai: do not retry the create (the retry would return `plugin_name_taken`);
     * create a version on the stored Plugin instead, which completes it.
     *
     * For a worked example, see
     * [Create a plugin](/docs/en/manage-claude/plugins-api#create-a-plugin) in the
     * Plugins API guide.
     *
     * **Accepted credentials:** an Admin API key with the `write:plugins` scope.
     *
     * Every request must include the beta header
     * `anthropic-beta: ce-plugins-2026-09-01`. A request without it returns `404`,
     * exactly as if the endpoint did not exist. The Plugins API is in beta and is
     * available to Claude Enterprise organizations only. It is not available to Claude
     * Platform (Claude Console) organizations, or to organizations with HIPAA
     * readiness enabled.
     *
     * @example
     * ```ts
     * const betaPlugin =
     *   await client.beta.organization.plugins.create({
     *     files: [fs.createReadStream('path/to/file')],
     *   });
     * ```
     */
    create(e, t) {
      const { betas: r, ...i } = e;
      return this._client.post("/v1/organizations/plugins?beta=true", Le({
        body: i,
        ...t,
        headers: f([
          { "anthropic-beta": [...r ?? [], "ce-plugins-2026-09-01"].toString() },
          t?.headers
        ]),
        __span: u(this._client, "anthropic.organization.plugins.create", t, {
          route: "/v1/organizations/plugins",
          createdIDAttribute: "anthropic.organization.plugin.id"
        })
      }, this._client));
    }
    /**
     * Retrieve a Plugin by ID.
     *
     * **Accepted credentials:** an Admin API key with the `read:plugins` or
     * `read:org_audit` scope, or a Compliance Access Key with the
     * `read:compliance_org_data` scope.
     *
     * Every request must include the beta header
     * `anthropic-beta: ce-plugins-2026-09-01`. A request without it returns `404`,
     * exactly as if the endpoint did not exist. The Plugins API is in beta and is
     * available to Claude Enterprise organizations only. It is not available to Claude
     * Platform (Claude Console) organizations, or to organizations with HIPAA
     * readiness enabled.
     *
     * @example
     * ```ts
     * const betaPlugin =
     *   await client.beta.organization.plugins.retrieve(
     *     'plugin_id',
     *   );
     * ```
     */
    retrieve(e, t = {}, r) {
      const { betas: i, ...a } = t ?? {};
      return this._client.get(g`/v1/organizations/plugins/${e}?beta=true`, {
        query: a,
        ...r,
        headers: f([
          { "anthropic-beta": [...i ?? [], "ce-plugins-2026-09-01"].toString() },
          r?.headers
        ]),
        __span: u(this._client, "anthropic.organization.plugins.retrieve", r, {
          route: "/v1/organizations/plugins/{plugin_id}",
          queryParams: ["organization_id"],
          attributes: { "anthropic.organization.plugin.id": e }
        })
      });
    }
    /**
     * Change which stored version of an organization-owned Plugin is served to
     * members, for example to roll back to an earlier one. This pins the served
     * version: later uploads are stored but no longer change what is served, and
     * pinning cannot currently be undone, here or in claude.ai.
     *
     * Pass the version as `served_version_id`: an earlier one to roll back, a later
     * one to start serving a version that was stored without being served, or the one
     * already served to pin it without changing what is served. No new version is
     * created.
     *
     * When the organization has content scanning enabled, a version whose scan is
     * still running is refused with a 409 (`error_code` `scan_pending`; retry once the
     * scan finishes) and one whose scan failed, errored or reached no verdict with a
     * 400 (`scan_failed`; a `warn` is accepted). When the Plugin is in the
     * organization's library marketplace, a version other than the one served is also
     * refused with a 409 when one of its skills has a name that an organization skill
     * (one an administrator uploaded for the whole organization in claude.ai) has
     * since taken: `error_code` `skill_name_taken`, with that name in
     * `details.skill_name`. A member-owned Plugin cannot be updated here (403).
     *
     * This endpoint does not write installation settings; they are written at
     * `/v1/organizations/plugins/{plugin_id}/installation_settings/{target}`.
     *
     * **Accepted credentials:** an Admin API key with the `write:plugins` scope.
     *
     * Every request must include the beta header
     * `anthropic-beta: ce-plugins-2026-09-01`. A request without it returns `404`,
     * exactly as if the endpoint did not exist. The Plugins API is in beta and is
     * available to Claude Enterprise organizations only. It is not available to Claude
     * Platform (Claude Console) organizations, or to organizations with HIPAA
     * readiness enabled.
     *
     * @example
     * ```ts
     * const betaPlugin =
     *   await client.beta.organization.plugins.update(
     *     'plugin_id',
     *     {
     *       served_version_id:
     *         'pluginver_01KaZmQpRsTuVwXyZ2b4c6d8',
     *     },
     *   );
     * ```
     */
    update(e, t, r) {
      const { betas: i, ...a } = t;
      return this._client.post(g`/v1/organizations/plugins/${e}?beta=true`, {
        body: a,
        ...r,
        headers: f([
          { "anthropic-beta": [...i ?? [], "ce-plugins-2026-09-01"].toString() },
          r?.headers
        ]),
        __span: u(this._client, "anthropic.organization.plugins.update", r, {
          route: "/v1/organizations/plugins/{plugin_id}",
          attributes: { "anthropic.organization.plugin.id": e }
        })
      });
    }
    /**
     * List the Plugins created under the organization, newest first: those in the
     * organization's own plugin marketplaces and those in members' personal plugin
     * marketplaces.
     *
     * Plugins in members' personal marketplaces are listed with the same detail as the
     * organization's own, and their files can be downloaded through the version
     * archive endpoint, which records each such download on the Compliance API
     * activity feed.
     *
     * **Accepted credentials:** an Admin API key with the `read:plugins` or
     * `read:org_audit` scope, or a Compliance Access Key with the
     * `read:compliance_org_data` scope.
     *
     * Every request must include the beta header
     * `anthropic-beta: ce-plugins-2026-09-01`. A request without it returns `404`,
     * exactly as if the endpoint did not exist. The Plugins API is in beta and is
     * available to Claude Enterprise organizations only. It is not available to Claude
     * Platform (Claude Console) organizations, or to organizations with HIPAA
     * readiness enabled.
     *
     * @example
     * ```ts
     * // Automatically fetches more pages as needed.
     * for await (const betaPlugin of client.beta.organization.plugins.list()) {
     *   // ...
     * }
     * ```
     */
    list(e = {}, t) {
      const { betas: r, ...i } = e ?? {};
      return this._client.getAPIList("/v1/organizations/plugins?beta=true", z, {
        query: i,
        ...t,
        headers: f([
          { "anthropic-beta": [...r ?? [], "ce-plugins-2026-09-01"].toString() },
          t?.headers
        ]),
        __span: u(this._client, "anthropic.organization.plugins.list", t, {
          route: "/v1/organizations/plugins",
          queryParams: [
            "created_at[gt]",
            "created_at[gte]",
            "created_at[lt]",
            "created_at[lte]",
            "limit",
            "marketplace_id",
            "organization_id",
            "owner_type",
            "owner_user_id",
            "page"
          ]
        })
      });
    }
    /**
     * Permanently delete a Plugin and every version it holds, exactly as when an
     * administrator deletes it in claude.ai. The Plugin may belong to the organization
     * or to a member, including a member who has since left the organization.
     *
     * An organization-owned Plugin's installation settings go with it; a member-owned
     * Plugin's shares are withdrawn and its owner no longer has it.
     *
     * To take an organization-owned Plugin out of use reversibly, set its
     * organization-wide installation setting to `not_available` instead (and remove or
     * change any group settings, which override it for their members). Only a Plugin
     * in a `manual` marketplace can be deleted here; one synchronized from a
     * repository is removed by removing it from the repository (400).
     *
     * **Accepted credentials:** an Admin API key with the `write:plugins` scope.
     *
     * Every request must include the beta header
     * `anthropic-beta: ce-plugins-2026-09-01`. A request without it returns `404`,
     * exactly as if the endpoint did not exist. The Plugins API is in beta and is
     * available to Claude Enterprise organizations only. It is not available to Claude
     * Platform (Claude Console) organizations, or to organizations with HIPAA
     * readiness enabled.
     *
     * @example
     * ```ts
     * const betaDeletedPlugin =
     *   await client.beta.organization.plugins.delete(
     *     'plugin_id',
     *   );
     * ```
     */
    delete(e, t = {}, r) {
      const { betas: i } = t ?? {};
      return this._client.delete(g`/v1/organizations/plugins/${e}?beta=true`, {
        ...r,
        headers: f([
          { "anthropic-beta": [...i ?? [], "ce-plugins-2026-09-01"].toString() },
          r?.headers
        ]),
        __span: u(this._client, "anthropic.organization.plugins.delete", r, {
          route: "/v1/organizations/plugins/{plugin_id}",
          attributes: { "anthropic.organization.plugin.id": e }
        })
      });
    }
  }
  return s.Versions = qo, s.InstallationSettings = No, s.Shares = Lo, s;
})();
let Uo = class extends x {
  /**
   * List members of an RBAC Group.
   *
   * The RBAC Groups API is available to Claude Enterprise organizations only.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaRBACGroupMember of client.beta.organization.rbacGroups.members.list(
   *   'rbac_group_id',
   * )) {
   *   // ...
   * }
   * ```
   */
  list(n, e = {}, t) {
    return this._client.getAPIList(g`/v1/organizations/rbac_groups/${n}/members?beta=true`, z, {
      query: e,
      ...t,
      __span: u(this._client, "anthropic.organization.rbac_groups.members.list", t, {
        route: "/v1/organizations/rbac_groups/{rbac_group_id}/members",
        queryParams: ["limit", "page"],
        attributes: { "anthropic.organization.rbac_group.id": n }
      })
    });
  }
  /**
   * Add a User to an RBAC Group. Membership of groups provisioned by an identity
   * provider (source type `"scim"`) cannot be modified via the API while an
   * organization in the tenant uses SCIM provisioning.
   *
   * The RBAC Groups API is available to Claude Enterprise organizations only.
   *
   * @example
   * ```ts
   * const betaRBACGroupMember =
   *   await client.beta.organization.rbacGroups.members.add(
   *     'rbac_group_id',
   *     { user_id: 'user_01WCz1FkmYMm4gnmykNKUu3Q' },
   *   );
   * ```
   */
  add(n, e, t) {
    return this._client.post(g`/v1/organizations/rbac_groups/${n}/members?beta=true`, {
      body: e,
      ...t,
      __span: u(this._client, "anthropic.organization.rbac_groups.members.add", t, {
        route: "/v1/organizations/rbac_groups/{rbac_group_id}/members",
        attributes: { "anthropic.organization.rbac_group.id": n },
        createdIDAttribute: "anthropic.organization.rbac_group.member.id",
        createdIDField: "user_id"
      })
    });
  }
  /**
   * Remove a User from an RBAC Group. Membership of groups provisioned by an
   * identity provider (source type `"scim"`) cannot be modified via the API while an
   * organization in the tenant uses SCIM provisioning.
   *
   * The RBAC Groups API is available to Claude Enterprise organizations only.
   *
   * @example
   * ```ts
   * const member =
   *   await client.beta.organization.rbacGroups.members.remove(
   *     'user_id',
   *     { rbac_group_id: 'rbac_group_id' },
   *   );
   * ```
   */
  remove(n, e, t) {
    const { rbac_group_id: r } = e;
    return this._client.delete(g`/v1/organizations/rbac_groups/${r}/members/${n}?beta=true`, {
      ...t,
      __span: u(this._client, "anthropic.organization.rbac_groups.members.remove", t, {
        route: "/v1/organizations/rbac_groups/{rbac_group_id}/members/{user_id}",
        attributes: {
          "anthropic.organization.rbac_group.id": r,
          "anthropic.organization.rbac_group.member.id": n
        }
      })
    });
  }
};
var jo = /* @__PURE__ */ (() => {
  class s extends x {
    constructor() {
      super(...arguments), this.members = new Uo(this._client);
    }
    /**
     * Create an RBAC Group in the Claude Enterprise tenant. Groups created via the API
     * have source type `"direct"`.
     *
     * The RBAC Groups API is available to Claude Enterprise organizations only.
     *
     * @example
     * ```ts
     * const betaRBACGroup =
     *   await client.beta.organization.rbacGroups.create({
     *     name: 'Engineering',
     *   });
     * ```
     */
    create(e, t) {
      return this._client.post("/v1/organizations/rbac_groups?beta=true", {
        body: e,
        ...t,
        __span: u(this._client, "anthropic.organization.rbac_groups.create", t, {
          route: "/v1/organizations/rbac_groups",
          createdIDAttribute: "anthropic.organization.rbac_group.id"
        })
      });
    }
    /**
     * Retrieve an RBAC Group by ID.
     *
     * The RBAC Groups API is available to Claude Enterprise organizations only.
     *
     * @example
     * ```ts
     * const betaRBACGroup =
     *   await client.beta.organization.rbacGroups.retrieve(
     *     'rbac_group_id',
     *   );
     * ```
     */
    retrieve(e, t) {
      return this._client.get(g`/v1/organizations/rbac_groups/${e}?beta=true`, {
        ...t,
        __span: u(this._client, "anthropic.organization.rbac_groups.retrieve", t, {
          route: "/v1/organizations/rbac_groups/{rbac_group_id}",
          attributes: { "anthropic.organization.rbac_group.id": e }
        })
      });
    }
    /**
     * Update an RBAC Group's name. Groups provisioned by an identity provider (source
     * type `"scim"`) cannot be modified via the API while an organization in the
     * tenant uses SCIM provisioning.
     *
     * The RBAC Groups API is available to Claude Enterprise organizations only.
     *
     * @example
     * ```ts
     * const betaRBACGroup =
     *   await client.beta.organization.rbacGroups.update(
     *     'rbac_group_id',
     *   );
     * ```
     */
    update(e, t, r) {
      return this._client.post(g`/v1/organizations/rbac_groups/${e}?beta=true`, {
        body: t,
        ...r,
        __span: u(this._client, "anthropic.organization.rbac_groups.update", r, {
          route: "/v1/organizations/rbac_groups/{rbac_group_id}",
          attributes: { "anthropic.organization.rbac_group.id": e }
        })
      });
    }
    /**
     * List RBAC Groups in the Claude Enterprise tenant.
     *
     * The RBAC Groups API is available to Claude Enterprise organizations only.
     *
     * @example
     * ```ts
     * // Automatically fetches more pages as needed.
     * for await (const betaRBACGroup of client.beta.organization.rbacGroups.list()) {
     *   // ...
     * }
     * ```
     */
    list(e = {}, t) {
      return this._client.getAPIList("/v1/organizations/rbac_groups?beta=true", z, {
        query: e,
        ...t,
        __span: u(this._client, "anthropic.organization.rbac_groups.list", t, {
          route: "/v1/organizations/rbac_groups",
          queryParams: ["limit", "page"]
        })
      });
    }
    /**
     * Delete an RBAC Group. Groups provisioned by an identity provider (source type
     * `"scim"`) cannot be deleted via the API while an organization in the tenant uses
     * SCIM provisioning.
     *
     * The RBAC Groups API is available to Claude Enterprise organizations only.
     *
     * @example
     * ```ts
     * const rbacGroup =
     *   await client.beta.organization.rbacGroups.delete(
     *     'rbac_group_id',
     *   );
     * ```
     */
    delete(e, t) {
      return this._client.delete(g`/v1/organizations/rbac_groups/${e}?beta=true`, {
        ...t,
        __span: u(this._client, "anthropic.organization.rbac_groups.delete", t, {
          route: "/v1/organizations/rbac_groups/{rbac_group_id}",
          attributes: { "anthropic.organization.rbac_group.id": e }
        })
      });
    }
  }
  return s.Members = Uo, s;
})();
class Fo extends x {
  /**
   * List the permissions an RBAC Role grants.
   *
   * The RBAC Roles API is available to Claude Enterprise organizations only.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaRBACRolePermission of client.beta.organization.rbacRoles.permissions.list(
   *   'rbac_role_id',
   * )) {
   *   // ...
   * }
   * ```
   */
  list(n, e = {}, t) {
    return this._client.getAPIList(g`/v1/organizations/rbac_roles/${n}/permissions?beta=true`, z, {
      query: e,
      ...t,
      __span: u(this._client, "anthropic.organization.rbac_roles.permissions.list", t, {
        route: "/v1/organizations/rbac_roles/{rbac_role_id}/permissions",
        queryParams: ["limit", "page"],
        attributes: { "anthropic.organization.rbac_role.id": n }
      })
    });
  }
}
var Wo = /* @__PURE__ */ (() => {
  class s extends x {
    constructor() {
      super(...arguments), this.permissions = new Fo(this._client);
    }
    /**
     * Retrieve an RBAC Role by ID.
     *
     * The RBAC Roles API is available to Claude Enterprise organizations only.
     *
     * @example
     * ```ts
     * const betaRBACRole =
     *   await client.beta.organization.rbacRoles.retrieve(
     *     'rbac_role_id',
     *   );
     * ```
     */
    retrieve(e, t) {
      return this._client.get(g`/v1/organizations/rbac_roles/${e}?beta=true`, {
        ...t,
        __span: u(this._client, "anthropic.organization.rbac_roles.retrieve", t, {
          route: "/v1/organizations/rbac_roles/{rbac_role_id}",
          attributes: { "anthropic.organization.rbac_role.id": e }
        })
      });
    }
    /**
     * List RBAC Roles in the organization.
     *
     * The RBAC Roles API is available to Claude Enterprise organizations only.
     *
     * @example
     * ```ts
     * // Automatically fetches more pages as needed.
     * for await (const betaRBACRole of client.beta.organization.rbacRoles.list()) {
     *   // ...
     * }
     * ```
     */
    list(e = {}, t) {
      return this._client.getAPIList("/v1/organizations/rbac_roles?beta=true", z, {
        query: e,
        ...t,
        __span: u(this._client, "anthropic.organization.rbac_roles.list", t, {
          route: "/v1/organizations/rbac_roles",
          queryParams: ["limit", "page"]
        })
      });
    }
  }
  return s.Permissions = Fo, s;
})();
let Ho = class extends x {
  /**
   * **Requires an OAuth access token with the `org:admin` scope**, from
   * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
   * API keys are not accepted. See
   * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
   *
   * List the workspaces a service account is a member of.
   *
   * Each entry includes the service account's `workspace_role` in that workspace.
   * Use `limit` and the `next_page` cursor to paginate. When the service account has
   * no explicit default-workspace membership, the implicit (`implicit: true`)
   * membership is returned as the first entry on the first page; with `limit=1` the
   * first page may return up to 2 entries (the implicit entry plus one explicit
   * membership) so a pagination cursor can be derived. Memberships are returned only
   * while the service account is active. Without a `page` cursor, an archived
   * service account returns an empty list. A `page` cursor that does not match an
   * active membership returns a 400 invalid-request error. A cursor stops matching
   * when the membership is removed, the workspace is deleted, or the service account
   * is archived. Restart pagination from the first page to recover.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaServiceAccountWorkspaceMember of client.beta.organization.serviceAccounts.workspaces.list(
   *   'service_account_id',
   * )) {
   *   // ...
   * }
   * ```
   */
  list(n, e = {}, t) {
    const { betas: r, ...i } = e ?? {};
    return this._client.getAPIList(g`/v1/organizations/service_accounts/${n}/workspaces?beta=true`, z, {
      query: i,
      ...t,
      headers: f([
        { ...r?.toString() != null ? { "anthropic-beta": r?.toString() } : void 0 },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.organization.service_accounts.workspaces.list", t, {
        route: "/v1/organizations/service_accounts/{service_account_id}/workspaces",
        queryParams: ["limit", "page"],
        attributes: { "anthropic.organization.service_account.id": n }
      })
    });
  }
  /**
   * **Requires an OAuth access token with the `org:admin` scope**, from
   * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
   * API keys are not accepted. See
   * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
   *
   * Add a service account to a workspace with the given `workspace_role`.
   *
   * Mirror of `POST /workspaces/{workspace_id}/service_accounts`, addressed from the
   * service-account side; both create the same membership. If the service account is
   * already an explicit member of the workspace, its `workspace_role` is replaced
   * with the value supplied here. Archived workspaces return 400. Archived service
   * accounts cannot be added and are rejected.
   *
   * @example
   * ```ts
   * const betaServiceAccountWorkspaceMember =
   *   await client.beta.organization.serviceAccounts.workspaces.add(
   *     'service_account_id',
   *     {
   *       workspace_id: 'workspace_id',
   *       workspace_role: 'workspace_admin',
   *     },
   *   );
   * ```
   */
  add(n, e, t) {
    const { betas: r, ...i } = e;
    return this._client.post(g`/v1/organizations/service_accounts/${n}/workspaces?beta=true`, {
      body: i,
      ...t,
      headers: f([
        { ...r?.toString() != null ? { "anthropic-beta": r?.toString() } : void 0 },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.organization.service_accounts.workspaces.add", t, {
        route: "/v1/organizations/service_accounts/{service_account_id}/workspaces",
        attributes: { "anthropic.organization.service_account.id": n },
        createdIDAttribute: "anthropic.organization.service_account.workspace.id",
        createdIDField: "workspace_id"
      })
    });
  }
  /**
   * **Requires an OAuth access token with the `org:admin` scope**, from
   * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
   * API keys are not accepted. See
   * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
   *
   * Remove a service account from a workspace.
   *
   * Mirror of
   * `DELETE /workspaces/{workspace_id}/service_accounts/{service_account_id}`,
   * addressed from the service-account side. Removal is idempotent (returns 200 even
   * if the membership was already removed). A DELETE against the implicit
   * default-workspace membership returns 200 but is a no-op and the membership
   * persists; deleting an explicit default-workspace row reverts to the implicit
   * `workspace_user` membership. Archived workspaces return 400.
   *
   * @example
   * ```ts
   * const workspace =
   *   await client.beta.organization.serviceAccounts.workspaces.remove(
   *     'workspace_id',
   *     { service_account_id: 'service_account_id' },
   *   );
   * ```
   */
  remove(n, e, t) {
    const { service_account_id: r, betas: i } = e;
    return this._client.delete(g`/v1/organizations/service_accounts/${r}/workspaces/${n}?beta=true`, {
      ...t,
      headers: f([
        { ...i?.toString() != null ? { "anthropic-beta": i?.toString() } : void 0 },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.organization.service_accounts.workspaces.remove", t, {
        route: "/v1/organizations/service_accounts/{service_account_id}/workspaces/{workspace_id}",
        attributes: {
          "anthropic.organization.service_account.id": r,
          "anthropic.organization.service_account.workspace.id": n
        }
      })
    });
  }
};
var Do = /* @__PURE__ */ (() => {
  class s extends x {
    constructor() {
      super(...arguments), this.workspaces = new Ho(this._client);
    }
    /**
     * **Requires an OAuth access token with the `org:admin` scope**, from
     * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
     * API keys are not accepted. See
     * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
     *
     * Create a service account.
     *
     * A service account is a named workload identity that federation rules target.
     * `organization_role` is `developer` (default) or `admin`; a rule may only be
     * created or retargeted to grant `org:admin` scope when the target's
     * `organization_role` is `admin`. Creating an `admin`-role service account
     * requires an interactive credential (a user OAuth token or a Console session) — a
     * workload may only create `developer`-role service accounts.
     *
     * @example
     * ```ts
     * const betaServiceAccount =
     *   await client.beta.organization.serviceAccounts.create({
     *     name: 'ci-deploy-bot',
     *   });
     * ```
     */
    create(e, t) {
      const { betas: r, ...i } = e;
      return this._client.post("/v1/organizations/service_accounts?beta=true", {
        body: i,
        ...t,
        headers: f([
          { ...r?.toString() != null ? { "anthropic-beta": r?.toString() } : void 0 },
          t?.headers
        ]),
        __span: u(this._client, "anthropic.organization.service_accounts.create", t, {
          route: "/v1/organizations/service_accounts",
          createdIDAttribute: "anthropic.organization.service_account.id"
        })
      });
    }
    /**
     * **Requires an OAuth access token with the `org:admin` scope**, from
     * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
     * API keys are not accepted. See
     * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
     *
     * Retrieve a service account by its ID (`svac_...`).
     *
     * @example
     * ```ts
     * const betaServiceAccount =
     *   await client.beta.organization.serviceAccounts.retrieve(
     *     'service_account_id',
     *   );
     * ```
     */
    retrieve(e, t = {}, r) {
      const { betas: i } = t ?? {};
      return this._client.get(g`/v1/organizations/service_accounts/${e}?beta=true`, {
        ...r,
        headers: f([
          { ...i?.toString() != null ? { "anthropic-beta": i?.toString() } : void 0 },
          r?.headers
        ]),
        __span: u(this._client, "anthropic.organization.service_accounts.retrieve", r, {
          route: "/v1/organizations/service_accounts/{service_account_id}",
          attributes: { "anthropic.organization.service_account.id": e }
        })
      });
    }
    /**
     * **Requires an OAuth access token with the `org:admin` scope**, from
     * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
     * API keys are not accepted. See
     * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
     *
     * Update a service account.
     *
     * Only `description` and `organization_role` are mutable; `name` cannot be
     * changed. Archived service accounts cannot be updated; this returns 400. Setting
     * `organization_role` to `admin` (even when unchanged) requires an interactive
     * credential (a user OAuth token or a Console session).
     *
     * @example
     * ```ts
     * const betaServiceAccount =
     *   await client.beta.organization.serviceAccounts.update(
     *     'service_account_id',
     *   );
     * ```
     */
    update(e, t, r) {
      const { betas: i, ...a } = t;
      return this._client.post(g`/v1/organizations/service_accounts/${e}?beta=true`, {
        body: a,
        ...r,
        headers: f([
          { ...i?.toString() != null ? { "anthropic-beta": i?.toString() } : void 0 },
          r?.headers
        ]),
        __span: u(this._client, "anthropic.organization.service_accounts.update", r, {
          route: "/v1/organizations/service_accounts/{service_account_id}",
          attributes: { "anthropic.organization.service_account.id": e }
        })
      });
    }
    /**
     * **Requires an OAuth access token with the `org:admin` scope**, from
     * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
     * API keys are not accepted. See
     * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
     *
     * List service accounts in the caller's organization.
     *
     * Results are ordered by creation time, newest first. Use `limit` and the
     * `next_page` cursor to paginate; set `include_archived=true` to include archived
     * service accounts.
     *
     * @example
     * ```ts
     * // Automatically fetches more pages as needed.
     * for await (const betaServiceAccount of client.beta.organization.serviceAccounts.list()) {
     *   // ...
     * }
     * ```
     */
    list(e = {}, t) {
      const { betas: r, ...i } = e ?? {};
      return this._client.getAPIList("/v1/organizations/service_accounts?beta=true", z, {
        query: i,
        ...t,
        headers: f([
          { ...r?.toString() != null ? { "anthropic-beta": r?.toString() } : void 0 },
          t?.headers
        ]),
        __span: u(this._client, "anthropic.organization.service_accounts.list", t, {
          route: "/v1/organizations/service_accounts",
          queryParams: ["include_archived", "limit", "page"]
        })
      });
    }
    /**
     * **Requires an OAuth access token with the `org:admin` scope**, from
     * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
     * API keys are not accepted. See
     * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
     *
     * Archive a service account.
     *
     * Idempotent; re-archiving returns the service account with its original
     * `archived_at`. Rejected with 400 if any live (non-archived) federation rule
     * still targets this service account, same as issuer archival; archive those rules
     * first or change their target to another service account.
     *
     * @example
     * ```ts
     * const betaServiceAccount =
     *   await client.beta.organization.serviceAccounts.archive(
     *     'service_account_id',
     *   );
     * ```
     */
    archive(e, t = {}, r) {
      const { betas: i } = t ?? {};
      return this._client.post(g`/v1/organizations/service_accounts/${e}/archive?beta=true`, {
        ...r,
        headers: f([
          { ...i?.toString() != null ? { "anthropic-beta": i?.toString() } : void 0 },
          r?.headers
        ]),
        __span: u(this._client, "anthropic.organization.service_accounts.archive", r, {
          route: "/v1/organizations/service_accounts/{service_account_id}/archive",
          attributes: { "anthropic.organization.service_account.id": e }
        })
      });
    }
  }
  return s.Workspaces = Ho, s;
})();
class Ko extends x {
  /**
   * List each member's effective spend limit and period-to-date spend.
   *
   * Returns one row per (member, period) the member resolves a spend limit for, with
   * the `source` scope the spend limit was inherited from. Paginates by member, so a
   * member's periods never split across pages. Supported for Claude Enterprise
   * organizations only, not for Claude Console organizations.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaSpendSummary of client.beta.organization.spendLimits.effective.list()) {
   *   // ...
   * }
   * ```
   */
  list(n = {}, e) {
    return this._client.getAPIList("/v1/organizations/spend_limits/effective?beta=true", z, {
      query: n,
      ...e,
      __span: u(this._client, "anthropic.organization.spend_limits.effective.list", e, {
        route: "/v1/organizations/spend_limits/effective",
        queryParams: ["limit", "page", "period", "user_ids"]
      })
    });
  }
}
class Go extends x {
  /**
   * Retrieve a spend limit increase request.
   *
   * While `pending`, the response includes a live `spend_summary` for the requester
   * at the request's period.
   *
   * @example
   * ```ts
   * const betaSpendLimitIncreaseRequest =
   *   await client.beta.organization.spendLimits.increaseRequests.retrieve(
   *     'spend_limit_increase_request_id',
   *   );
   * ```
   */
  retrieve(n, e) {
    return this._client.get(g`/v1/organizations/spend_limit_increase_requests/${n}?beta=true`, {
      ...e,
      __span: u(this._client, "anthropic.organization.spend_limits.increase_requests.retrieve", e, {
        route: "/v1/organizations/spend_limit_increase_requests/{spend_limit_increase_request_id}",
        attributes: {
          "anthropic.organization.spend_limit_increase_request.id": n
        }
      })
    });
  }
  /**
   * List spend limit increase requests, most recent first.
   *
   * Pending requests include a live `spend_summary` for the requester. Requests
   * whose requester is no longer a member are excluded.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaSpendLimitIncreaseRequest of client.beta.organization.spendLimits.increaseRequests.list()) {
   *   // ...
   * }
   * ```
   */
  list(n = {}, e) {
    return this._client.getAPIList("/v1/organizations/spend_limit_increase_requests?beta=true", z, {
      query: n,
      ...e,
      __span: u(this._client, "anthropic.organization.spend_limits.increase_requests.list", e, {
        route: "/v1/organizations/spend_limit_increase_requests",
        queryParams: ["actor_ids", "limit", "page", "status"]
      })
    });
  }
  /**
   * Approve a pending spend limit increase request.
   *
   * Writes a per-user spend limit at `amount` for the requester and transitions the
   * request to `approved`. `period` defaults to the period the member was blocked
   * on. Anthropic emails the requester unless `suppress_notification` is set.
   *
   * @example
   * ```ts
   * const response =
   *   await client.beta.organization.spendLimits.increaseRequests.approve(
   *     'spend_limit_increase_request_id',
   *     { amount: '50000' },
   *   );
   * ```
   */
  approve(n, e, t) {
    return this._client.post(g`/v1/organizations/spend_limit_increase_requests/${n}/approve?beta=true`, {
      body: e,
      ...t,
      __span: u(this._client, "anthropic.organization.spend_limits.increase_requests.approve", t, {
        route: "/v1/organizations/spend_limit_increase_requests/{spend_limit_increase_request_id}/approve",
        attributes: {
          "anthropic.organization.spend_limit_increase_request.id": n
        }
      })
    });
  }
  /**
   * Deny a pending spend limit increase request.
   *
   * Idempotent on `denied`; denying an already-`approved` request returns 400.
   * Anthropic emails the requester unless `suppress_notification` is set.
   *
   * @example
   * ```ts
   * const betaSpendLimitIncreaseRequest =
   *   await client.beta.organization.spendLimits.increaseRequests.deny(
   *     'spend_limit_increase_request_id',
   *   );
   * ```
   */
  deny(n, e, t) {
    return this._client.post(g`/v1/organizations/spend_limit_increase_requests/${n}/deny?beta=true`, {
      body: e,
      ...t,
      __span: u(this._client, "anthropic.organization.spend_limits.increase_requests.deny", t, {
        route: "/v1/organizations/spend_limit_increase_requests/{spend_limit_increase_request_id}/deny",
        attributes: {
          "anthropic.organization.spend_limit_increase_request.id": n
        }
      })
    });
  }
}
var Vo = /* @__PURE__ */ (() => {
  class s extends x {
    constructor() {
      super(...arguments), this.effective = new Ko(this._client), this.increaseRequests = new Go(this._client);
    }
    /**
     * Retrieve a spend limit by ID.
     *
     * @example
     * ```ts
     * const betaSpendLimit =
     *   await client.beta.organization.spendLimits.retrieve(
     *     'spend_limit_id',
     *   );
     * ```
     */
    retrieve(e, t) {
      return this._client.get(g`/v1/organizations/spend_limits/${e}?beta=true`, {
        ...t,
        __span: u(this._client, "anthropic.organization.spend_limits.retrieve", t, {
          route: "/v1/organizations/spend_limits/{spend_limit_id}",
          attributes: { "anthropic.organization.spend_limit.id": e }
        })
      });
    }
    /**
     * List the organization's spend limits.
     *
     * Limits are grouped by scope type, in the order `organization`, `seat_tier`,
     * `rbac_group`, `organization_service`, `user`; within a type they come in a fixed
     * order that is not creation order. Supported for Claude Enterprise organizations
     * only, not for Claude Console organizations.
     *
     * @example
     * ```ts
     * // Automatically fetches more pages as needed.
     * for await (const betaSpendLimit of client.beta.organization.spendLimits.list()) {
     *   // ...
     * }
     * ```
     */
    list(e = {}, t) {
      const { betas: r, ...i } = e ?? {};
      return this._client.getAPIList("/v1/organizations/spend_limits?beta=true", z, {
        query: i,
        ...t,
        headers: f([
          { "anthropic-beta": [...r ?? [], "spend-limit-reads-2026-09-26"].toString() },
          t?.headers
        ]),
        __span: u(this._client, "anthropic.organization.spend_limits.list", t, {
          route: "/v1/organizations/spend_limits",
          queryParams: ["limit", "page", "scope_type"]
        })
      });
    }
    /**
     * Delete a spend limit.
     *
     * For a Claude Enterprise organization, this deletes a per-user override, and the
     * member falls back to any inherited spend limit at that period. Its seat-tier,
     * group, and organization-level rows cannot be deleted via this endpoint. A Claude
     * Console organization deletes its organization and workspace limits, but not its
     * `usage_tier` limit. Deleting organization and workspace limits through the API
     * is in an early access preview.
     *
     * @example
     * ```ts
     * const spendLimit =
     *   await client.beta.organization.spendLimits.delete(
     *     'spend_limit_id',
     *   );
     * ```
     */
    delete(e, t) {
      return this._client.delete(g`/v1/organizations/spend_limits/${e}?beta=true`, {
        ...t,
        __span: u(this._client, "anthropic.organization.spend_limits.delete", t, {
          route: "/v1/organizations/spend_limits/{spend_limit_id}",
          attributes: { "anthropic.organization.spend_limit.id": e }
        })
      });
    }
    /**
     * Set a spend limit.
     *
     * Upsert keyed on (scope, period): setting a limit that already exists overwrites
     * it in place. A Claude Enterprise organization sets `user` limits. Its seat-tier,
     * group, and organization-level defaults are configured in claude.ai. A Claude
     * Console organization sets `organization` and `workspace` limits, which are
     * monthly and always carry an amount. Setting those limits is in an early access
     * preview. To request access, contact your Anthropic account team.
     *
     * @example
     * ```ts
     * const betaSpendLimit =
     *   await client.beta.organization.spendLimits.set({
     *     amount: '50000',
     *     scope: {
     *       type: 'user',
     *       user_id: 'user_01WCz1FkmYMm4gnmykNKUu3Q',
     *     },
     *   });
     * ```
     */
    set(e, t) {
      const { betas: r, ...i } = e;
      return this._client.post("/v1/organizations/spend_limits?beta=true", {
        body: i,
        ...t,
        headers: f([
          { ...r?.toString() != null ? { "anthropic-beta": r?.toString() } : void 0 },
          t?.headers
        ]),
        __span: u(this._client, "anthropic.organization.spend_limits.set", t, {
          route: "/v1/organizations/spend_limits",
          createdIDAttribute: "anthropic.organization.spend_limit.id"
        })
      });
    }
  }
  return s.Effective = Ko, s.IncreaseRequests = Go, s;
})();
let Jo = class extends x {
  /**
   * List the workspaces on a destination's workspace list, newest entry first.
   *
   * A destination whose `workspaces.type` is `all` doesn't have a list, so its page
   * is empty. The list includes archived workspaces.
   *
   * See the
   * [OpenTelemetry export guide](https://platform.claude.com/docs/en/manage-claude/opentelemetry#choose-workspaces-for-a-destination)
   * to learn more about choosing the workspaces of a destination.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaTelemetryDestinationWorkspace of client.beta.organization.telemetryDestinations.workspaces.list(
   *   'destination_id',
   * )) {
   *   // ...
   * }
   * ```
   */
  list(n, e = {}, t) {
    const { betas: r, ...i } = e ?? {};
    return this._client.getAPIList(g`/v1/organizations/telemetry_destinations/${n}/workspaces?beta=true`, z, {
      query: i,
      ...t,
      headers: f([
        { "anthropic-beta": [...r ?? [], "telemetry-destinations-2026-08-11"].toString() },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.organization.telemetry_destinations.workspaces.list", t, {
        route: "/v1/organizations/telemetry_destinations/{destination_id}/workspaces",
        queryParams: ["limit", "page"],
        attributes: { "anthropic.organization.telemetry_destination.id": n }
      })
    });
  }
  /**
   * Add one workspace to a destination's workspace list.
   *
   * Under `include` the workspace's spans start going to the destination. Under
   * `exclude` they stop. A list holds at most 1,000 workspaces.
   *
   * Adding a workspace that is already on the list changes nothing and returns the
   * existing entry. An archived workspace that isn't on the list yet can't be added.
   * A destination whose `workspaces.type` is `all` doesn't have a list, so the API
   * returns 400. To change which workspaces such a destination covers, update its
   * `workspaces`.
   *
   * See the
   * [OpenTelemetry export guide](https://platform.claude.com/docs/en/manage-claude/opentelemetry#choose-workspaces-for-a-destination)
   * to learn more about choosing the workspaces of a destination.
   *
   * @example
   * ```ts
   * const betaTelemetryDestinationWorkspace =
   *   await client.beta.organization.telemetryDestinations.workspaces.add(
   *     'workspace_id',
   *     { destination_id: 'destination_id' },
   *   );
   * ```
   */
  add(n, e, t) {
    const { destination_id: r, betas: i } = e;
    return this._client.post(g`/v1/organizations/telemetry_destinations/${r}/workspaces/${n}?beta=true`, {
      ...t,
      headers: f([
        { "anthropic-beta": [...i ?? [], "telemetry-destinations-2026-08-11"].toString() },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.organization.telemetry_destinations.workspaces.add", t, {
        route: "/v1/organizations/telemetry_destinations/{destination_id}/workspaces/{workspace_id}",
        attributes: {
          "anthropic.organization.telemetry_destination.id": r,
          "anthropic.organization.telemetry_destination.workspace.id": n
        }
      })
    });
  }
  /**
   * Remove one workspace from a destination's workspace list.
   *
   * Under `include` the workspace's spans stop going to the destination. Under
   * `exclude` they start. An archived workspace can be removed too.
   *
   * The API returns 404 when the workspace isn't on the list. A destination whose
   * `workspaces.type` is `all` doesn't have a list, so the API returns 400.
   *
   * See the
   * [OpenTelemetry export guide](https://platform.claude.com/docs/en/manage-claude/opentelemetry#choose-workspaces-for-a-destination)
   * to learn more about choosing the workspaces of a destination.
   *
   * @example
   * ```ts
   * const betaDeletedTelemetryDestinationWorkspace =
   *   await client.beta.organization.telemetryDestinations.workspaces.remove(
   *     'workspace_id',
   *     { destination_id: 'destination_id' },
   *   );
   * ```
   */
  remove(n, e, t) {
    const { destination_id: r, betas: i } = e;
    return this._client.delete(g`/v1/organizations/telemetry_destinations/${r}/workspaces/${n}?beta=true`, {
      ...t,
      headers: f([
        { "anthropic-beta": [...i ?? [], "telemetry-destinations-2026-08-11"].toString() },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.organization.telemetry_destinations.workspaces.remove", t, {
        route: "/v1/organizations/telemetry_destinations/{destination_id}/workspaces/{workspace_id}",
        attributes: {
          "anthropic.organization.telemetry_destination.id": r,
          "anthropic.organization.telemetry_destination.workspace.id": n
        }
      })
    });
  }
};
var Yo = /* @__PURE__ */ (() => {
  class s extends x {
    constructor() {
      super(...arguments), this.workspaces = new Jo(this._client);
    }
    /**
     * Register an OpenTelemetry destination for the organization.
     *
     * The destination starts in state `enabled`. An organization can have at most 10
     * destinations, including disabled ones.
     *
     * See the
     * [OpenTelemetry export guide](https://platform.claude.com/docs/en/manage-claude/opentelemetry#add-a-destination)
     * to learn more about adding a destination.
     *
     * @example
     * ```ts
     * const betaTelemetryDestination =
     *   await client.beta.organization.telemetryDestinations.create(
     *     {
     *       endpoint_url: 'x',
     *       workspaces: { type: 'all' },
     *     },
     *   );
     * ```
     */
    create(e, t) {
      const { betas: r, ...i } = e;
      return this._client.post("/v1/organizations/telemetry_destinations?beta=true", {
        body: i,
        ...t,
        headers: f([
          { "anthropic-beta": [...r ?? [], "telemetry-destinations-2026-08-11"].toString() },
          t?.headers
        ]),
        __span: u(this._client, "anthropic.organization.telemetry_destinations.create", t, {
          route: "/v1/organizations/telemetry_destinations",
          createdIDAttribute: "anthropic.organization.telemetry_destination.id"
        })
      });
    }
    /**
     * Read a destination's configuration, state, and most recent delivery results.
     *
     * See the
     * [OpenTelemetry export guide](https://platform.claude.com/docs/en/manage-claude/opentelemetry#delivery-and-health)
     * to learn how the API delivers spans and when it disables a destination.
     *
     * @example
     * ```ts
     * const betaTelemetryDestination =
     *   await client.beta.organization.telemetryDestinations.retrieve(
     *     'destination_id',
     *   );
     * ```
     */
    retrieve(e, t = {}, r) {
      const { betas: i } = t ?? {};
      return this._client.get(g`/v1/organizations/telemetry_destinations/${e}?beta=true`, {
        ...r,
        headers: f([
          { "anthropic-beta": [...i ?? [], "telemetry-destinations-2026-08-11"].toString() },
          r?.headers
        ]),
        __span: u(this._client, "anthropic.organization.telemetry_destinations.retrieve", r, {
          route: "/v1/organizations/telemetry_destinations/{destination_id}",
          attributes: { "anthropic.organization.telemetry_destination.id": e }
        })
      });
    }
    /**
     * Change a telemetry destination's settings, its state, or which workspaces it
     * covers.
     *
     * Send at least one field. Omitted fields keep their stored values, except the
     * registered headers, which a change of the endpoint's hostname or port removes.
     * Only `display_name`, `traces`, `traces.endpoint_url`, `traces.content_mode`,
     * `traces.max_content_bytes`, and individual `headers` values accept `null`.
     *
     * If another request changes the destination while the update runs, the API
     * returns a 409 `conflict_error`. Read the destination again, then retry the
     * update.
     *
     * See the
     * [OpenTelemetry export guide](https://platform.claude.com/docs/en/manage-claude/opentelemetry#delivery-and-health)
     * to learn more about changing a destination.
     *
     * @example
     * ```ts
     * const betaTelemetryDestination =
     *   await client.beta.organization.telemetryDestinations.update(
     *     'destination_id',
     *   );
     * ```
     */
    update(e, t, r) {
      const { betas: i, ...a } = t;
      return this._client.post(g`/v1/organizations/telemetry_destinations/${e}?beta=true`, {
        body: a,
        ...r,
        headers: f([
          { "anthropic-beta": [...i ?? [], "telemetry-destinations-2026-08-11"].toString() },
          r?.headers
        ]),
        __span: u(this._client, "anthropic.organization.telemetry_destinations.update", r, {
          route: "/v1/organizations/telemetry_destinations/{destination_id}",
          attributes: { "anthropic.organization.telemetry_destination.id": e }
        })
      });
    }
    /**
     * List the organization's destinations, newest first, optionally only those that
     * cover given workspaces.
     *
     * See the
     * [OpenTelemetry export guide](https://platform.claude.com/docs/en/manage-claude/opentelemetry#set-up-api-tracing)
     * to learn more about destinations.
     *
     * @example
     * ```ts
     * // Automatically fetches more pages as needed.
     * for await (const betaTelemetryDestination of client.beta.organization.telemetryDestinations.list()) {
     *   // ...
     * }
     * ```
     */
    list(e = {}, t) {
      const { betas: r, ...i } = e ?? {};
      return this._client.getAPIList("/v1/organizations/telemetry_destinations?beta=true", z, {
        query: i,
        ...t,
        headers: f([
          { "anthropic-beta": [...r ?? [], "telemetry-destinations-2026-08-11"].toString() },
          t?.headers
        ]),
        __span: u(this._client, "anthropic.organization.telemetry_destinations.list", t, {
          route: "/v1/organizations/telemetry_destinations",
          queryParams: ["limit", "page", "workspace_ids"]
        })
      });
    }
    /**
     * Delete a destination and its workspace list.
     *
     * The API stops sending spans to the destination. The spans of the workspaces it
     * covered still go to the other destinations that cover them. A deleted
     * destination can't be read, listed, or restored.
     *
     * See the
     * [OpenTelemetry export guide](https://platform.claude.com/docs/en/manage-claude/opentelemetry#delivery-and-health)
     * to learn more about managing a destination.
     *
     * @example
     * ```ts
     * const betaDeletedTelemetryDestination =
     *   await client.beta.organization.telemetryDestinations.delete(
     *     'destination_id',
     *   );
     * ```
     */
    delete(e, t = {}, r) {
      const { betas: i } = t ?? {};
      return this._client.delete(g`/v1/organizations/telemetry_destinations/${e}?beta=true`, {
        ...r,
        headers: f([
          { "anthropic-beta": [...i ?? [], "telemetry-destinations-2026-08-11"].toString() },
          r?.headers
        ]),
        __span: u(this._client, "anthropic.organization.telemetry_destinations.delete", r, {
          route: "/v1/organizations/telemetry_destinations/{destination_id}",
          attributes: { "anthropic.organization.telemetry_destination.id": e }
        })
      });
    }
    /**
     * Send one test span, named `anthropic.test`, to the destination with its
     * registered headers, once and without retries, and report the destination's
     * answer. The response is 200 whether or not the destination answered with a 2xx
     * status: its `result` has the type `success`, or the type `failure` and the
     * reason in `error`. The destination's configuration, `state` and
     * `delivery_health` do not change. A disabled destination can be tested too. Wait
     * 10 seconds between tests of one destination; a request that comes sooner may be
     * answered with status 429.
     *
     * @example
     * ```ts
     * const betaTelemetryDestinationTestResponse =
     *   await client.beta.organization.telemetryDestinations.test(
     *     'destination_id',
     *   );
     * ```
     */
    test(e, t = {}, r) {
      const { betas: i } = t ?? {};
      return this._client.post(g`/v1/organizations/telemetry_destinations/${e}/test?beta=true`, {
        ...r,
        headers: f([
          { "anthropic-beta": [...i ?? [], "telemetry-destinations-2026-08-11"].toString() },
          r?.headers
        ]),
        __span: u(this._client, "anthropic.organization.telemetry_destinations.test", r, {
          route: "/v1/organizations/telemetry_destinations/{destination_id}/test",
          attributes: { "anthropic.organization.telemetry_destination.id": e }
        })
      });
    }
  }
  return s.Workspaces = Jo, s;
})();
let Xo = class extends x {
  /**
   * Get Workspace Member
   *
   * @example
   * ```ts
   * const betaWorkspaceMember =
   *   await client.beta.organization.workspaces.members.retrieve(
   *     'user_id',
   *     { workspace_id: 'workspace_id' },
   *   );
   * ```
   */
  retrieve(n, e, t) {
    const { workspace_id: r } = e;
    return this._client.get(g`/v1/organizations/workspaces/${r}/members/${n}?beta=true`, {
      ...t,
      __span: u(this._client, "anthropic.organization.workspaces.members.retrieve", t, {
        route: "/v1/organizations/workspaces/{workspace_id}/members/{user_id}",
        attributes: {
          "anthropic.organization.workspace.id": r,
          "anthropic.organization.workspace.member.id": n
        }
      })
    });
  }
  /**
   * Update Workspace Member
   *
   * @example
   * ```ts
   * const betaWorkspaceMember =
   *   await client.beta.organization.workspaces.members.update(
   *     'user_id',
   *     {
   *       workspace_id: 'workspace_id',
   *       workspace_role: 'workspace_admin',
   *     },
   *   );
   * ```
   */
  update(n, e, t) {
    const { workspace_id: r, ...i } = e;
    return this._client.post(g`/v1/organizations/workspaces/${r}/members/${n}?beta=true`, {
      body: i,
      ...t,
      __span: u(this._client, "anthropic.organization.workspaces.members.update", t, {
        route: "/v1/organizations/workspaces/{workspace_id}/members/{user_id}",
        attributes: {
          "anthropic.organization.workspace.id": r,
          "anthropic.organization.workspace.member.id": n
        }
      })
    });
  }
  /**
   * List Workspace Members
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaWorkspaceMember of client.beta.organization.workspaces.members.list(
   *   'workspace_id',
   * )) {
   *   // ...
   * }
   * ```
   */
  list(n, e = {}, t) {
    return this._client.getAPIList(g`/v1/organizations/workspaces/${n}/members?beta=true`, Y, {
      query: e,
      ...t,
      __span: u(this._client, "anthropic.organization.workspaces.members.list", t, {
        route: "/v1/organizations/workspaces/{workspace_id}/members",
        queryParams: ["after_id", "before_id", "limit"],
        attributes: { "anthropic.organization.workspace.id": n }
      })
    });
  }
  /**
   * Create Workspace Member
   *
   * @example
   * ```ts
   * const betaWorkspaceMember =
   *   await client.beta.organization.workspaces.members.add(
   *     'workspace_id',
   *     {
   *       user_id: 'user_01WCz1FkmYMm4gnmykNKUu3Q',
   *       workspace_role: 'workspace_admin',
   *     },
   *   );
   * ```
   */
  add(n, e, t) {
    return this._client.post(g`/v1/organizations/workspaces/${n}/members?beta=true`, {
      body: e,
      ...t,
      __span: u(this._client, "anthropic.organization.workspaces.members.add", t, {
        route: "/v1/organizations/workspaces/{workspace_id}/members",
        attributes: { "anthropic.organization.workspace.id": n },
        createdIDAttribute: "anthropic.organization.workspace.member.id",
        createdIDField: "user_id"
      })
    });
  }
  /**
   * Delete Workspace Member
   *
   * @example
   * ```ts
   * const member =
   *   await client.beta.organization.workspaces.members.remove(
   *     'user_id',
   *     { workspace_id: 'workspace_id' },
   *   );
   * ```
   */
  remove(n, e, t) {
    const { workspace_id: r } = e;
    return this._client.delete(g`/v1/organizations/workspaces/${r}/members/${n}?beta=true`, {
      ...t,
      __span: u(this._client, "anthropic.organization.workspaces.members.remove", t, {
        route: "/v1/organizations/workspaces/{workspace_id}/members/{user_id}",
        attributes: {
          "anthropic.organization.workspace.id": r,
          "anthropic.organization.workspace.member.id": n
        }
      })
    });
  }
}, Qo = class extends x {
  /**
   * Set or clear rate-limit overrides for one rate-limit group in a workspace.
   *
   * Only the limiter types named in `limits` change: an integer `value` sets that
   * type's override and `null` clears it. Types not named keep their current value.
   * A value above the organization's own limit is stored, but the organization limit
   * still applies, so the lower of the two is enforced.
   *
   * Returns the targeted group's entry with this request applied, in the shape
   * `GET /v1/organizations/workspaces/{workspace_id}/rate_limits` returns. Changes
   * take effect within about an hour.
   *
   * @example
   * ```ts
   * const betaWorkspaceRateLimit =
   *   await client.beta.organization.workspaces.rateLimits.update(
   *     'rate_limit_id',
   *     {
   *       workspace_id: 'workspace_id',
   *       limits: [{ type: 'fast_itpmca', value: 0 }],
   *     },
   *   );
   * ```
   */
  update(n, e, t) {
    const { workspace_id: r, ...i } = e;
    return this._client.post(g`/v1/organizations/workspaces/${r}/rate_limits/${n}?beta=true`, {
      body: i,
      ...t,
      __span: u(this._client, "anthropic.organization.workspaces.rate_limits.update", t, {
        route: "/v1/organizations/workspaces/{workspace_id}/rate_limits/{rate_limit_id}",
        attributes: {
          "anthropic.organization.workspace.id": r,
          "anthropic.organization.workspace.rate_limit.id": n
        }
      })
    });
  }
  /**
   * List a workspace's rate limits.
   *
   * By default, returns only the groups and limiter types that have a
   * workspace-level override. With `include_inherited=true`, returns every group
   * with organization-level limits the workspace can see, listing for each the
   * values it inherits from the organization as well as its own overrides. Each
   * value's `source` says which it is.
   *
   * When `limit` is omitted, every matching entry is returned in a single page; when
   * `limit` truncates the result, follow `next_page` to fetch the remaining entries.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaWorkspaceRateLimit of client.beta.organization.workspaces.rateLimits.list(
   *   'workspace_id',
   * )) {
   *   // ...
   * }
   * ```
   */
  list(n, e = {}, t) {
    return this._client.getAPIList(g`/v1/organizations/workspaces/${n}/rate_limits?beta=true`, z, {
      query: e,
      ...t,
      __span: u(this._client, "anthropic.organization.workspaces.rate_limits.list", t, {
        route: "/v1/organizations/workspaces/{workspace_id}/rate_limits",
        queryParams: ["group_type", "include_inherited", "limit", "page"],
        attributes: { "anthropic.organization.workspace.id": n }
      })
    });
  }
}, Zo = class extends x {
  /**
   * **Requires an OAuth access token with the `org:admin` scope**, from
   * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
   * API keys are not accepted. See
   * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
   *
   * Retrieve a service account's membership in a workspace.
   *
   * Returns the membership record, including the service account's `workspace_role`
   * in this workspace. Archived workspaces return 400. For the default workspace,
   * returns the implicit (`implicit: true`) membership when no explicit membership
   * exists; an explicitly added membership is returned with its assigned role. An
   * archived service account returns 404.
   *
   * @example
   * ```ts
   * const betaServiceAccountWorkspaceMember =
   *   await client.beta.organization.workspaces.serviceAccounts.retrieve(
   *     'service_account_id',
   *     { workspace_id: 'workspace_id' },
   *   );
   * ```
   */
  retrieve(n, e, t) {
    const { workspace_id: r, betas: i } = e;
    return this._client.get(g`/v1/organizations/workspaces/${r}/service_accounts/${n}?beta=true`, {
      ...t,
      headers: f([
        { ...i?.toString() != null ? { "anthropic-beta": i?.toString() } : void 0 },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.organization.workspaces.service_accounts.retrieve", t, {
        route: "/v1/organizations/workspaces/{workspace_id}/service_accounts/{service_account_id}",
        attributes: {
          "anthropic.organization.workspace.id": r,
          "anthropic.organization.workspace.service_account.id": n
        }
      })
    });
  }
  /**
   * **Requires an OAuth access token with the `org:admin` scope**, from
   * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
   * API keys are not accepted. See
   * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
   *
   * Change a service account's role in a workspace.
   *
   * The new `workspace_role` replaces the current one. Only explicit memberships can
   * be updated; to set a role on the implicit default-workspace membership, add the
   * service account explicitly with
   * `POST /workspaces/{workspace_id}/service_accounts`. Archived workspaces
   * return 400. Archived service accounts cannot be updated and are rejected.
   *
   * @example
   * ```ts
   * const betaServiceAccountWorkspaceMember =
   *   await client.beta.organization.workspaces.serviceAccounts.update(
   *     'service_account_id',
   *     {
   *       workspace_id: 'workspace_id',
   *       workspace_role: 'workspace_admin',
   *     },
   *   );
   * ```
   */
  update(n, e, t) {
    const { workspace_id: r, betas: i, ...a } = e;
    return this._client.post(g`/v1/organizations/workspaces/${r}/service_accounts/${n}?beta=true`, {
      body: a,
      ...t,
      headers: f([
        { ...i?.toString() != null ? { "anthropic-beta": i?.toString() } : void 0 },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.organization.workspaces.service_accounts.update", t, {
        route: "/v1/organizations/workspaces/{workspace_id}/service_accounts/{service_account_id}",
        attributes: {
          "anthropic.organization.workspace.id": r,
          "anthropic.organization.workspace.service_account.id": n
        }
      })
    });
  }
  /**
   * **Requires an OAuth access token with the `org:admin` scope**, from
   * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
   * API keys are not accepted. See
   * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
   *
   * List the service accounts that are members of a workspace.
   *
   * Each entry includes the service account's `workspace_role`. Use `limit` and the
   * `next_page` cursor to paginate. Archived workspaces return 400; use
   * `GET /service_accounts/{id}/workspaces` to audit memberships of an archived
   * workspace. The implicit default-workspace membership is not included in this
   * list. Memberships of archived service accounts are omitted from the results.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaServiceAccountWorkspaceMember of client.beta.organization.workspaces.serviceAccounts.list(
   *   'workspace_id',
   * )) {
   *   // ...
   * }
   * ```
   */
  list(n, e = {}, t) {
    const { betas: r, ...i } = e ?? {};
    return this._client.getAPIList(g`/v1/organizations/workspaces/${n}/service_accounts?beta=true`, z, {
      query: i,
      ...t,
      headers: f([
        { ...r?.toString() != null ? { "anthropic-beta": r?.toString() } : void 0 },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.organization.workspaces.service_accounts.list", t, {
        route: "/v1/organizations/workspaces/{workspace_id}/service_accounts",
        queryParams: ["limit", "page"],
        attributes: { "anthropic.organization.workspace.id": n }
      })
    });
  }
  /**
   * **Requires an OAuth access token with the `org:admin` scope**, from
   * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
   * API keys are not accepted. See
   * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
   *
   * Add a service account to a workspace with the given `workspace_role`.
   *
   * The role determines what the service account can do in the workspace and which
   * workspace-scoped permissions it can be granted when authenticating through
   * federation. Every service account is already an implicit `workspace_user` member
   * of the default workspace; adding it explicitly assigns a chosen role. If the
   * service account is already an explicit member of the workspace, its
   * `workspace_role` is replaced with the value supplied here. Archived workspaces
   * return 400. Archived service accounts cannot be added and are rejected.
   *
   * @example
   * ```ts
   * const betaServiceAccountWorkspaceMember =
   *   await client.beta.organization.workspaces.serviceAccounts.add(
   *     'workspace_id',
   *     {
   *       service_account_id: 'service_account_id',
   *       workspace_role: 'workspace_admin',
   *     },
   *   );
   * ```
   */
  add(n, e, t) {
    const { betas: r, ...i } = e;
    return this._client.post(g`/v1/organizations/workspaces/${n}/service_accounts?beta=true`, {
      body: i,
      ...t,
      headers: f([
        { ...r?.toString() != null ? { "anthropic-beta": r?.toString() } : void 0 },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.organization.workspaces.service_accounts.add", t, {
        route: "/v1/organizations/workspaces/{workspace_id}/service_accounts",
        attributes: { "anthropic.organization.workspace.id": n },
        createdIDAttribute: "anthropic.organization.workspace.service_account.id",
        createdIDField: "service_account_id"
      })
    });
  }
  /**
   * **Requires an OAuth access token with the `org:admin` scope**, from
   * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
   * API keys are not accepted. See
   * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
   *
   * Remove a service account from a workspace.
   *
   * Removal is idempotent (returns 200 even if the membership was already removed).
   * A DELETE against the implicit default-workspace membership returns 200 but is a
   * no-op and the membership persists; deleting an explicit default-workspace row
   * reverts to the implicit `workspace_user` membership. Archived workspaces
   * return 400.
   *
   * @example
   * ```ts
   * const serviceAccount =
   *   await client.beta.organization.workspaces.serviceAccounts.remove(
   *     'service_account_id',
   *     { workspace_id: 'workspace_id' },
   *   );
   * ```
   */
  remove(n, e, t) {
    const { workspace_id: r, betas: i } = e;
    return this._client.delete(g`/v1/organizations/workspaces/${r}/service_accounts/${n}?beta=true`, {
      ...t,
      headers: f([
        { ...i?.toString() != null ? { "anthropic-beta": i?.toString() } : void 0 },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.organization.workspaces.service_accounts.remove", t, {
        route: "/v1/organizations/workspaces/{workspace_id}/service_accounts/{service_account_id}",
        attributes: {
          "anthropic.organization.workspace.id": r,
          "anthropic.organization.workspace.service_account.id": n
        }
      })
    });
  }
};
var ec = /* @__PURE__ */ (() => {
  class s extends x {
    constructor() {
      super(...arguments), this.rateLimits = new Qo(this._client), this.members = new Xo(this._client), this.serviceAccounts = new Zo(this._client);
    }
    /**
     * Create Workspace
     *
     * @example
     * ```ts
     * const betaWorkspace =
     *   await client.beta.organization.workspaces.create({
     *     name: 'x',
     *   });
     * ```
     */
    create(e, t) {
      const { betas: r, ...i } = e;
      return this._client.post("/v1/organizations/workspaces?beta=true", {
        body: i,
        ...t,
        headers: f([
          { ...r?.toString() != null ? { "anthropic-beta": r?.toString() } : void 0 },
          t?.headers
        ]),
        __span: u(this._client, "anthropic.organization.workspaces.create", t, {
          route: "/v1/organizations/workspaces",
          createdIDAttribute: "anthropic.organization.workspace.id"
        })
      });
    }
    /**
     * Get Workspace
     *
     * @example
     * ```ts
     * const betaWorkspace =
     *   await client.beta.organization.workspaces.retrieve(
     *     'workspace_id',
     *   );
     * ```
     */
    retrieve(e, t) {
      return this._client.get(g`/v1/organizations/workspaces/${e}?beta=true`, {
        ...t,
        __span: u(this._client, "anthropic.organization.workspaces.retrieve", t, {
          route: "/v1/organizations/workspaces/{workspace_id}",
          attributes: { "anthropic.organization.workspace.id": e }
        })
      });
    }
    /**
     * Update Workspace
     *
     * @example
     * ```ts
     * const betaWorkspace =
     *   await client.beta.organization.workspaces.update(
     *     'workspace_id',
     *   );
     * ```
     */
    update(e, t, r) {
      return this._client.post(g`/v1/organizations/workspaces/${e}?beta=true`, {
        body: t,
        ...r,
        __span: u(this._client, "anthropic.organization.workspaces.update", r, {
          route: "/v1/organizations/workspaces/{workspace_id}",
          attributes: { "anthropic.organization.workspace.id": e }
        })
      });
    }
    /**
     * List Workspaces
     *
     * @example
     * ```ts
     * // Automatically fetches more pages as needed.
     * for await (const betaWorkspace of client.beta.organization.workspaces.list()) {
     *   // ...
     * }
     * ```
     */
    list(e = {}, t) {
      return this._client.getAPIList("/v1/organizations/workspaces?beta=true", Y, {
        query: e,
        ...t,
        __span: u(this._client, "anthropic.organization.workspaces.list", t, {
          route: "/v1/organizations/workspaces",
          queryParams: ["after_id", "before_id", "include_archived", "include_default", "limit"]
        })
      });
    }
    /**
     * Archive Workspace
     *
     * @example
     * ```ts
     * const betaWorkspace =
     *   await client.beta.organization.workspaces.archive(
     *     'workspace_id',
     *   );
     * ```
     */
    archive(e, t) {
      return this._client.post(g`/v1/organizations/workspaces/${e}/archive?beta=true`, {
        ...t,
        __span: u(this._client, "anthropic.organization.workspaces.archive", t, {
          route: "/v1/organizations/workspaces/{workspace_id}/archive",
          attributes: { "anthropic.organization.workspace.id": e }
        })
      });
    }
  }
  return s.RateLimits = Qo, s.Members = Xo, s.ServiceAccounts = Zo, s;
})(), tc = /* @__PURE__ */ (() => {
  class s extends x {
    constructor() {
      super(...arguments), this.apiKeys = new lo(this._client), this.externalKeys = new xo(this._client), this.federation = new zo(this._client), this.invites = new Mo(this._client), this.serviceAccounts = new Do(this._client), this.users = new Io(this._client), this.workspaces = new ec(this._client), this.rateLimits = new Co(this._client), this.complianceSettings = new Ao(this._client), this.analytics = new To(this._client), this.spendLimits = new Vo(this._client), this.rbacGroups = new jo(this._client), this.rbacRoles = new Wo(this._client), this.plugins = new Bo(this._client), this.pluginMarketplaces = new Oo(this._client), this.telemetryDestinations = new Yo(this._client), this.webhooks = new $o(this._client);
    }
    /**
     * Retrieve information about the organization associated with the authenticated
     * API key.
     *
     * @example
     * ```ts
     * const betaOrganization =
     *   await client.beta.organization.retrieve();
     * ```
     */
    retrieve(e) {
      return this._client.get("/v1/organizations/me?beta=true", {
        ...e,
        __span: u(this._client, "anthropic.organization.retrieve", e, {
          route: "/v1/organizations/me"
        })
      });
    }
  }
  return s.APIKeys = lo, s.ExternalKeys = xo, s.Federation = zo, s.Invites = Mo, s.ServiceAccounts = Do, s.Users = Io, s.Workspaces = ec, s.RateLimits = Co, s.ComplianceSettings = Ao, s.Analytics = To, s.SpendLimits = Vo, s.RBACGroups = jo, s.RBACRoles = Wo, s.Plugins = Bo, s.PluginMarketplaces = Oo, s.TelemetryDestinations = Yo, s.Webhooks = $o, s;
})(), nc = /* @__PURE__ */ (() => {
  class s extends x {
    /**
     * List Events
     *
     * @example
     * ```ts
     * // Automatically fetches more pages as needed.
     * for await (const betaManagedAgentsSessionEvent of client.beta.sessions.events.list(
     *   'sesn_011CZkZAtmR3yMPDzynEDxu7',
     * )) {
     *   // ...
     * }
     * ```
     */
    list(e, t = {}, r) {
      const { betas: i, workspace_id: a, ...o } = t ?? {};
      return this._client.getAPIList(g`/v1/sessions/${e}/events?beta=true`, z, {
        query: o,
        ...r,
        headers: f([
          {
            "anthropic-beta": [...i ?? [], "managed-agents-2026-04-01"].toString(),
            ...a != null ? { "anthropic-workspace-id": a } : void 0
          },
          r?.headers
        ]),
        __span: u(this._client, "anthropic.sessions.events.list", r, {
          route: "/v1/sessions/{session_id}/events",
          queryParams: [
            "created_at[gt]",
            "created_at[gte]",
            "created_at[lt]",
            "created_at[lte]",
            "limit",
            "order",
            "page",
            "types"
          ],
          attributes: { "anthropic.session.id": e }
        })
      });
    }
    /**
     * Send Events
     *
     * @example
     * ```ts
     * const betaManagedAgentsSendSessionEvents =
     *   await client.beta.sessions.events.send(
     *     'sesn_011CZkZAtmR3yMPDzynEDxu7',
     *     {
     *       events: [
     *         {
     *           content: [
     *             {
     *               text: 'Where is my order #1234?',
     *               type: 'text',
     *             },
     *           ],
     *           type: 'user.message',
     *         },
     *       ],
     *     },
     *   );
     * ```
     */
    send(e, t, r) {
      const { betas: i, workspace_id: a, ...o } = t;
      return this._client.post(g`/v1/sessions/${e}/events?beta=true`, {
        body: o,
        ...r,
        headers: f([
          {
            "anthropic-beta": [...i ?? [], "managed-agents-2026-04-01"].toString(),
            ...a != null ? { "anthropic-workspace-id": a } : void 0
          },
          r?.headers
        ]),
        __span: u(this._client, "anthropic.sessions.events.send", r, {
          route: "/v1/sessions/{session_id}/events",
          attributes: { "anthropic.session.id": e }
        })
      });
    }
    /**
     * Stream Events
     *
     * @example
     * ```ts
     * const stream = await client.beta.sessions.events.stream(
     *   'sesn_011CZkZAtmR3yMPDzynEDxu7',
     * );
     * for await (const betaManagedAgentsStreamSessionEvents of stream) {
     *   // ...
     * }
     * ```
     */
    stream(e, t = {}, r) {
      const { betas: i, workspace_id: a, ...o } = t ?? {};
      return this._client.get(g`/v1/sessions/${e}/events/stream?beta=true`, {
        query: o,
        ...r,
        headers: f([
          {
            "anthropic-beta": [...i ?? [], "managed-agents-2026-04-01"].toString(),
            ...a != null ? { "anthropic-workspace-id": a } : void 0
          },
          r?.headers
        ]),
        stream: !0,
        __span: u(this._client, "anthropic.sessions.events.stream", r, {
          route: "/v1/sessions/{session_id}/events/stream",
          queryParams: ["event_deltas"],
          attributes: { "anthropic.session.id": e }
        })
      });
    }
    /**
     * Attach to a session and dispatch every incoming `agent.tool_use` and
     * `agent.custom_tool_use` event to a local tool registry, sending the matching
     * result back (`user.tool_result` / `user.custom_tool_result`). The
     * sessions-side counterpart to `client.beta.messages.toolRunner`: yields one
     * entry per completed tool call so callers can observe each dispatch (and
     * `break` to abort cleanly).
     *
     * @example
     * ```ts
     * import { betaAgentToolset20260401 } from '@anthropic-ai/sdk/tools/agent-toolset/node';
     *
     * for await (const call of client.beta.sessions.events.toolRunner(work.data.id, {
     *   tools: [...betaAgentToolset20260401({ workdir }), myTool],
     * })) {
     *   console.log(`${call.name} -> ${call.isError ? 'error' : 'ok'}`);
     * }
     * ```
     */
    toolRunner(e, t) {
      return new _i(e, { ...t, client: this._client });
    }
  }
  return s.SessionToolRunner = _i, s;
})();
class sc extends x {
  /**
   * Get Session Resource
   *
   * @example
   * ```ts
   * const resource =
   *   await client.beta.sessions.resources.retrieve(
   *     'sesrsc_011CZkZBJq5dWxk9fVLNcPht',
   *     { session_id: 'sesn_011CZkZAtmR3yMPDzynEDxu7' },
   *   );
   * ```
   */
  retrieve(n, e, t) {
    const { session_id: r, betas: i, workspace_id: a } = e;
    return this._client.get(g`/v1/sessions/${r}/resources/${n}?beta=true`, {
      ...t,
      headers: f([
        {
          "anthropic-beta": [...i ?? [], "managed-agents-2026-04-01"].toString(),
          ...a != null ? { "anthropic-workspace-id": a } : void 0
        },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.sessions.resources.retrieve", t, {
        route: "/v1/sessions/{session_id}/resources/{resource_id}",
        attributes: { "anthropic.session.id": r, "anthropic.session.resource.id": n }
      })
    });
  }
  /**
   * Update Session Resource
   *
   * @example
   * ```ts
   * const resource =
   *   await client.beta.sessions.resources.update(
   *     'sesrsc_011CZkZBJq5dWxk9fVLNcPht',
   *     {
   *       session_id: 'sesn_011CZkZAtmR3yMPDzynEDxu7',
   *       authorization_token: 'ghp_exampletoken',
   *     },
   *   );
   * ```
   */
  update(n, e, t) {
    const { session_id: r, betas: i, workspace_id: a, ...o } = e;
    return this._client.post(g`/v1/sessions/${r}/resources/${n}?beta=true`, {
      body: o,
      ...t,
      headers: f([
        {
          "anthropic-beta": [...i ?? [], "managed-agents-2026-04-01"].toString(),
          ...a != null ? { "anthropic-workspace-id": a } : void 0
        },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.sessions.resources.update", t, {
        route: "/v1/sessions/{session_id}/resources/{resource_id}",
        attributes: { "anthropic.session.id": r, "anthropic.session.resource.id": n }
      })
    });
  }
  /**
   * List Session Resources
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaManagedAgentsSessionResource of client.beta.sessions.resources.list(
   *   'sesn_011CZkZAtmR3yMPDzynEDxu7',
   * )) {
   *   // ...
   * }
   * ```
   */
  list(n, e = {}, t) {
    const { betas: r, workspace_id: i, ...a } = e ?? {};
    return this._client.getAPIList(g`/v1/sessions/${n}/resources?beta=true`, z, {
      query: a,
      ...t,
      headers: f([
        {
          "anthropic-beta": [...r ?? [], "managed-agents-2026-04-01"].toString(),
          ...i != null ? { "anthropic-workspace-id": i } : void 0
        },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.sessions.resources.list", t, {
        route: "/v1/sessions/{session_id}/resources",
        queryParams: ["limit", "page"],
        attributes: { "anthropic.session.id": n }
      })
    });
  }
  /**
   * Delete Session Resource
   *
   * @example
   * ```ts
   * const betaManagedAgentsDeleteSessionResource =
   *   await client.beta.sessions.resources.delete(
   *     'sesrsc_011CZkZBJq5dWxk9fVLNcPht',
   *     { session_id: 'sesn_011CZkZAtmR3yMPDzynEDxu7' },
   *   );
   * ```
   */
  delete(n, e, t) {
    const { session_id: r, betas: i, workspace_id: a } = e;
    return this._client.delete(g`/v1/sessions/${r}/resources/${n}?beta=true`, {
      ...t,
      headers: f([
        {
          "anthropic-beta": [...i ?? [], "managed-agents-2026-04-01"].toString(),
          ...a != null ? { "anthropic-workspace-id": a } : void 0
        },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.sessions.resources.delete", t, {
        route: "/v1/sessions/{session_id}/resources/{resource_id}",
        attributes: { "anthropic.session.id": r, "anthropic.session.resource.id": n }
      })
    });
  }
  /**
   * Add Session Resource
   *
   * @example
   * ```ts
   * const betaManagedAgentsFileResource =
   *   await client.beta.sessions.resources.add(
   *     'sesn_011CZkZAtmR3yMPDzynEDxu7',
   *     {
   *       file_id: 'file_011CNha8iCJcU1wXNR6q4V8w',
   *       type: 'file',
   *     },
   *   );
   * ```
   */
  add(n, e, t) {
    const { betas: r, workspace_id: i, ...a } = e;
    return this._client.post(g`/v1/sessions/${n}/resources?beta=true`, {
      body: a,
      ...t,
      headers: f([
        {
          "anthropic-beta": [...r ?? [], "managed-agents-2026-04-01"].toString(),
          ...i != null ? { "anthropic-workspace-id": i } : void 0
        },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.sessions.resources.add", t, {
        route: "/v1/sessions/{session_id}/resources",
        attributes: { "anthropic.session.id": n },
        createdIDAttribute: "anthropic.session.resource.id"
      })
    });
  }
}
class rc extends x {
  /**
   * List Session Thread Events
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaManagedAgentsSessionEvent of client.beta.sessions.threads.events.list(
   *   'sthr_011CZkZVWa6oJjw1rgXZpnBt',
   *   { session_id: 'sesn_011CZkZAtmR3yMPDzynEDxu7' },
   * )) {
   *   // ...
   * }
   * ```
   */
  list(n, e, t) {
    const { session_id: r, betas: i, workspace_id: a, ...o } = e;
    return this._client.getAPIList(g`/v1/sessions/${r}/threads/${n}/events?beta=true`, z, {
      query: o,
      ...t,
      headers: f([
        {
          "anthropic-beta": [...i ?? [], "managed-agents-2026-04-01"].toString(),
          ...a != null ? { "anthropic-workspace-id": a } : void 0
        },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.sessions.threads.events.list", t, {
        route: "/v1/sessions/{session_id}/threads/{thread_id}/events",
        queryParams: ["limit", "page"],
        attributes: { "anthropic.session.id": r, "anthropic.session.thread.id": n }
      })
    });
  }
  /**
   * Stream Session Thread Events
   *
   * @example
   * ```ts
   * const stream =
   *   await client.beta.sessions.threads.events.stream(
   *     'sthr_011CZkZVWa6oJjw1rgXZpnBt',
   *     { session_id: 'sesn_011CZkZAtmR3yMPDzynEDxu7' },
   *   );
   * for await (const betaManagedAgentsStreamSessionThreadEvents of stream) {
   *   // ...
   * }
   * ```
   */
  stream(n, e, t) {
    const { session_id: r, betas: i, workspace_id: a, ...o } = e;
    return this._client.get(g`/v1/sessions/${r}/threads/${n}/stream?beta=true`, {
      query: o,
      ...t,
      headers: f([
        {
          "anthropic-beta": [...i ?? [], "managed-agents-2026-04-01"].toString(),
          ...a != null ? { "anthropic-workspace-id": a } : void 0
        },
        t?.headers
      ]),
      stream: !0,
      __span: u(this._client, "anthropic.sessions.threads.events.stream", t, {
        route: "/v1/sessions/{session_id}/threads/{thread_id}/stream",
        queryParams: ["event_deltas"],
        attributes: { "anthropic.session.id": r, "anthropic.session.thread.id": n }
      })
    });
  }
}
var ic = /* @__PURE__ */ (() => {
  class s extends x {
    constructor() {
      super(...arguments), this.events = new rc(this._client);
    }
    /**
     * Get Session Thread
     *
     * @example
     * ```ts
     * const betaManagedAgentsSessionThread =
     *   await client.beta.sessions.threads.retrieve(
     *     'sthr_011CZkZVWa6oJjw1rgXZpnBt',
     *     { session_id: 'sesn_011CZkZAtmR3yMPDzynEDxu7' },
     *   );
     * ```
     */
    retrieve(e, t, r) {
      const { session_id: i, betas: a, workspace_id: o } = t;
      return this._client.get(g`/v1/sessions/${i}/threads/${e}?beta=true`, {
        ...r,
        headers: f([
          {
            "anthropic-beta": [...a ?? [], "managed-agents-2026-04-01"].toString(),
            ...o != null ? { "anthropic-workspace-id": o } : void 0
          },
          r?.headers
        ]),
        __span: u(this._client, "anthropic.sessions.threads.retrieve", r, {
          route: "/v1/sessions/{session_id}/threads/{thread_id}",
          attributes: { "anthropic.session.id": i, "anthropic.session.thread.id": e }
        })
      });
    }
    /**
     * List Session Threads
     *
     * @example
     * ```ts
     * // Automatically fetches more pages as needed.
     * for await (const betaManagedAgentsSessionThread of client.beta.sessions.threads.list(
     *   'sesn_011CZkZAtmR3yMPDzynEDxu7',
     * )) {
     *   // ...
     * }
     * ```
     */
    list(e, t = {}, r) {
      const { betas: i, workspace_id: a, ...o } = t ?? {};
      return this._client.getAPIList(g`/v1/sessions/${e}/threads?beta=true`, z, {
        query: o,
        ...r,
        headers: f([
          {
            "anthropic-beta": [...i ?? [], "managed-agents-2026-04-01"].toString(),
            ...a != null ? { "anthropic-workspace-id": a } : void 0
          },
          r?.headers
        ]),
        __span: u(this._client, "anthropic.sessions.threads.list", r, {
          route: "/v1/sessions/{session_id}/threads",
          queryParams: ["limit", "page", "statuses"],
          attributes: { "anthropic.session.id": e }
        })
      });
    }
    /**
     * Archive Session Thread
     *
     * @example
     * ```ts
     * const betaManagedAgentsSessionThread =
     *   await client.beta.sessions.threads.archive(
     *     'sthr_011CZkZVWa6oJjw1rgXZpnBt',
     *     { session_id: 'sesn_011CZkZAtmR3yMPDzynEDxu7' },
     *   );
     * ```
     */
    archive(e, t, r) {
      const { session_id: i, betas: a, workspace_id: o } = t;
      return this._client.post(g`/v1/sessions/${i}/threads/${e}/archive?beta=true`, {
        ...r,
        headers: f([
          {
            "anthropic-beta": [...a ?? [], "managed-agents-2026-04-01"].toString(),
            ...o != null ? { "anthropic-workspace-id": o } : void 0
          },
          r?.headers
        ]),
        __span: u(this._client, "anthropic.sessions.threads.archive", r, {
          route: "/v1/sessions/{session_id}/threads/{thread_id}/archive",
          attributes: { "anthropic.session.id": i, "anthropic.session.thread.id": e }
        })
      });
    }
  }
  return s.Events = rc, s;
})(), ac = /* @__PURE__ */ (() => {
  class s extends x {
    constructor() {
      super(...arguments), this.events = new nc(this._client), this.resources = new sc(this._client), this.threads = new ic(this._client);
    }
    /**
     * Create Session
     *
     * @example
     * ```ts
     * const betaManagedAgentsSession =
     *   await client.beta.sessions.create({
     *     agent: 'agent_011CZkYpogX7uDKUyvBTophP',
     *     environment_id: 'env_011CZkZ9X2dpNyB7HsEFoRfW',
     *     initial_events: [
     *       {
     *         type: 'user.message',
     *         content: [
     *           {
     *             type: 'text',
     *             text: 'Where is my order #1234?',
     *           },
     *         ],
     *       },
     *     ],
     *   });
     * ```
     */
    create(e, t) {
      const { betas: r, workspace_id: i, ...a } = e, o = f([
        {
          "anthropic-beta": [...r ?? [], "managed-agents-2026-04-01"].toString(),
          ...i != null ? { "anthropic-workspace-id": i } : void 0
        },
        t?.headers
      ]), l = u(this._client, "anthropic.sessions.create", t, {
        route: "/v1/sessions",
        attributes: {
          // An `agent` that is no agent is for the API to refuse, not for this line to throw on.
          "gen_ai.agent.id": typeof a.agent == "object" ? a.agent?.id : a.agent,
          "anthropic.session.environment.id": a.environment_id
        },
        createdIDAttribute: "anthropic.session.id"
      }), d = this._client.post("/v1/sessions?beta=true", {
        body: a,
        ...t,
        headers: o,
        __span: l
      });
      return l ? d._thenUnwrap((p) => (U_(this._client, l, p), p)) : d;
    }
    /**
     * Get Session
     *
     * @example
     * ```ts
     * const betaManagedAgentsSession =
     *   await client.beta.sessions.retrieve(
     *     'sesn_011CZkZAtmR3yMPDzynEDxu7',
     *   );
     * ```
     */
    retrieve(e, t = {}, r) {
      const { betas: i, workspace_id: a } = t ?? {};
      return this._client.get(g`/v1/sessions/${e}?beta=true`, {
        ...r,
        headers: f([
          {
            "anthropic-beta": [...i ?? [], "managed-agents-2026-04-01"].toString(),
            ...a != null ? { "anthropic-workspace-id": a } : void 0
          },
          r?.headers
        ]),
        __span: u(this._client, "anthropic.sessions.retrieve", r, {
          route: "/v1/sessions/{session_id}",
          attributes: { "anthropic.session.id": e }
        })
      });
    }
    /**
     * Update Session
     *
     * @example
     * ```ts
     * const betaManagedAgentsSession =
     *   await client.beta.sessions.update(
     *     'sesn_011CZkZAtmR3yMPDzynEDxu7',
     *   );
     * ```
     */
    update(e, t, r) {
      const { betas: i, workspace_id: a, ...o } = t;
      return this._client.post(g`/v1/sessions/${e}?beta=true`, {
        body: o,
        ...r,
        headers: f([
          {
            "anthropic-beta": [...i ?? [], "managed-agents-2026-04-01"].toString(),
            ...a != null ? { "anthropic-workspace-id": a } : void 0
          },
          r?.headers
        ]),
        __span: u(this._client, "anthropic.sessions.update", r, {
          route: "/v1/sessions/{session_id}",
          attributes: { "anthropic.session.id": e }
        })
      });
    }
    /**
     * List Sessions
     *
     * @example
     * ```ts
     * // Automatically fetches more pages as needed.
     * for await (const betaManagedAgentsSession of client.beta.sessions.list()) {
     *   // ...
     * }
     * ```
     */
    list(e = {}, t) {
      const { betas: r, workspace_id: i, ...a } = e ?? {};
      return this._client.getAPIList("/v1/sessions?beta=true", hf, {
        query: a,
        ...t,
        headers: f([
          {
            "anthropic-beta": [...r ?? [], "managed-agents-2026-04-01"].toString(),
            ...i != null ? { "anthropic-workspace-id": i } : void 0
          },
          t?.headers
        ]),
        __span: u(this._client, "anthropic.sessions.list", t, {
          route: "/v1/sessions",
          queryParams: [
            "agent_id",
            "agent_version",
            "created_at[gt]",
            "created_at[gte]",
            "created_at[lt]",
            "created_at[lte]",
            "deployment_id",
            "include_archived",
            "limit",
            "memory_store_id",
            "order",
            "page",
            "statuses"
          ]
        })
      });
    }
    /**
     * Delete Session
     *
     * @example
     * ```ts
     * const betaManagedAgentsDeletedSession =
     *   await client.beta.sessions.delete(
     *     'sesn_011CZkZAtmR3yMPDzynEDxu7',
     *   );
     * ```
     */
    delete(e, t = {}, r) {
      const { betas: i, workspace_id: a } = t ?? {};
      return this._client.delete(g`/v1/sessions/${e}?beta=true`, {
        ...r,
        headers: f([
          {
            "anthropic-beta": [...i ?? [], "managed-agents-2026-04-01"].toString(),
            ...a != null ? { "anthropic-workspace-id": a } : void 0
          },
          r?.headers
        ]),
        __span: u(this._client, "anthropic.sessions.delete", r, {
          route: "/v1/sessions/{session_id}",
          attributes: { "anthropic.session.id": e }
        })
      });
    }
    /**
     * Archive Session
     *
     * @example
     * ```ts
     * const betaManagedAgentsSession =
     *   await client.beta.sessions.archive(
     *     'sesn_011CZkZAtmR3yMPDzynEDxu7',
     *   );
     * ```
     */
    archive(e, t = {}, r) {
      const { betas: i, workspace_id: a } = t ?? {};
      return this._client.post(g`/v1/sessions/${e}/archive?beta=true`, {
        ...r,
        headers: f([
          {
            "anthropic-beta": [...i ?? [], "managed-agents-2026-04-01"].toString(),
            ...a != null ? { "anthropic-workspace-id": a } : void 0
          },
          r?.headers
        ]),
        __span: u(this._client, "anthropic.sessions.archive", r, {
          route: "/v1/sessions/{session_id}/archive",
          attributes: { "anthropic.session.id": e }
        })
      });
    }
  }
  return s.Events = nc, s.Resources = sc, s.Threads = ic, s;
})();
let oc = class extends x {
  /**
   * Create Skill Version
   *
   * @example
   * ```ts
   * const betaSkillVersion =
   *   await client.beta.skills.versions.create('skill_id', {
   *     files: [fs.createReadStream('path/to/file')],
   *   });
   * ```
   */
  create(n, e, t) {
    const { betas: r, workspace_id: i, ...a } = e;
    return this._client.post(g`/v1/skills/${n}/versions?beta=true`, Le({
      body: a,
      ...t,
      headers: f([
        {
          ...r?.toString() != null ? { "anthropic-beta": r?.toString() } : void 0,
          ...i != null ? { "anthropic-workspace-id": i } : void 0
        },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.skills.versions.create", t, {
        route: "/v1/skills/{skill_id}/versions",
        attributes: { "anthropic.skill.id": n },
        createdIDAttribute: "anthropic.skill.version.id"
      })
    }, this._client, !1));
  }
  /**
   * Get Skill Version
   *
   * @example
   * ```ts
   * const betaSkillVersion =
   *   await client.beta.skills.versions.retrieve('version', {
   *     skill_id: 'skill_id',
   *   });
   * ```
   */
  retrieve(n, e, t) {
    const { skill_id: r, betas: i, workspace_id: a } = e;
    return this._client.get(g`/v1/skills/${r}/versions/${n}?beta=true`, {
      ...t,
      headers: f([
        {
          ...i?.toString() != null ? { "anthropic-beta": i?.toString() } : void 0,
          ...a != null ? { "anthropic-workspace-id": a } : void 0
        },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.skills.versions.retrieve", t, {
        route: "/v1/skills/{skill_id}/versions/{version}",
        attributes: { "anthropic.skill.id": r, "anthropic.skill.version.id": n }
      })
    });
  }
  /**
   * List Skill Versions
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaSkillVersion of client.beta.skills.versions.list(
   *   'skill_id',
   * )) {
   *   // ...
   * }
   * ```
   */
  list(n, e = {}, t) {
    const { betas: r, workspace_id: i, ...a } = e ?? {};
    return this._client.getAPIList(g`/v1/skills/${n}/versions?beta=true`, z, {
      query: a,
      ...t,
      headers: f([
        {
          ...r?.toString() != null ? { "anthropic-beta": r?.toString() } : void 0,
          ...i != null ? { "anthropic-workspace-id": i } : void 0
        },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.skills.versions.list", t, {
        route: "/v1/skills/{skill_id}/versions",
        queryParams: ["limit", "page"],
        attributes: { "anthropic.skill.id": n }
      })
    });
  }
  /**
   * Delete Skill Version
   *
   * @example
   * ```ts
   * const betaDeletedSkillVersion =
   *   await client.beta.skills.versions.delete('version', {
   *     skill_id: 'skill_id',
   *   });
   * ```
   */
  delete(n, e, t) {
    const { skill_id: r, betas: i, workspace_id: a } = e;
    return this._client.delete(g`/v1/skills/${r}/versions/${n}?beta=true`, {
      ...t,
      headers: f([
        {
          ...i?.toString() != null ? { "anthropic-beta": i?.toString() } : void 0,
          ...a != null ? { "anthropic-workspace-id": a } : void 0
        },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.skills.versions.delete", t, {
        route: "/v1/skills/{skill_id}/versions/{version}",
        attributes: { "anthropic.skill.id": r, "anthropic.skill.version.id": n }
      })
    });
  }
  /**
   * Download a skill version's content as a zip archive.
   *
   * @example
   * ```ts
   * const response = await client.beta.skills.versions.download(
   *   'version',
   *   { skill_id: 'skill_id' },
   * );
   *
   * const content = await response.blob();
   * console.log(content);
   * ```
   */
  download(n, e, t) {
    const { skill_id: r, betas: i, workspace_id: a } = e;
    return this._client.get(g`/v1/skills/${r}/versions/${n}/content?beta=true`, {
      ...t,
      headers: f([
        {
          Accept: "application/binary",
          ...i?.toString() != null ? { "anthropic-beta": i?.toString() } : void 0,
          ...a != null ? { "anthropic-workspace-id": a } : void 0
        },
        t?.headers
      ]),
      __binaryResponse: !0,
      __span: u(this._client, "anthropic.skills.versions.download", t, {
        route: "/v1/skills/{skill_id}/versions/{version}/content",
        attributes: { "anthropic.skill.id": r, "anthropic.skill.version.id": n }
      })
    });
  }
};
var cc = /* @__PURE__ */ (() => {
  class s extends x {
    constructor() {
      super(...arguments), this.versions = new oc(this._client);
    }
    /**
     * Create Skill
     *
     * @example
     * ```ts
     * const betaSkill = await client.beta.skills.create({
     *   files: [fs.createReadStream('path/to/file')],
     * });
     * ```
     */
    create(e, t) {
      const { betas: r, workspace_id: i, ...a } = e;
      return this._client.post("/v1/skills?beta=true", Le({
        body: a,
        ...t,
        headers: f([
          {
            ...r?.toString() != null ? { "anthropic-beta": r?.toString() } : void 0,
            ...i != null ? { "anthropic-workspace-id": i } : void 0
          },
          t?.headers
        ]),
        __span: u(this._client, "anthropic.skills.create", t, {
          route: "/v1/skills",
          createdIDAttribute: "anthropic.skill.id"
        })
      }, this._client, !1));
    }
    /**
     * Get Skill
     *
     * @example
     * ```ts
     * const betaSkill = await client.beta.skills.retrieve(
     *   'skill_id',
     * );
     * ```
     */
    retrieve(e, t = {}, r) {
      const { betas: i, workspace_id: a } = t ?? {};
      return this._client.get(g`/v1/skills/${e}?beta=true`, {
        ...r,
        headers: f([
          {
            ...i?.toString() != null ? { "anthropic-beta": i?.toString() } : void 0,
            ...a != null ? { "anthropic-workspace-id": a } : void 0
          },
          r?.headers
        ]),
        __span: u(this._client, "anthropic.skills.retrieve", r, {
          route: "/v1/skills/{skill_id}",
          attributes: { "anthropic.skill.id": e }
        })
      });
    }
    /**
     * List Skills
     *
     * @example
     * ```ts
     * // Automatically fetches more pages as needed.
     * for await (const betaSkill of client.beta.skills.list()) {
     *   // ...
     * }
     * ```
     */
    list(e = {}, t) {
      const { betas: r, workspace_id: i, ...a } = e ?? {};
      return this._client.getAPIList("/v1/skills?beta=true", z, {
        query: a,
        ...t,
        headers: f([
          {
            ...r?.toString() != null ? { "anthropic-beta": r?.toString() } : void 0,
            ...i != null ? { "anthropic-workspace-id": i } : void 0
          },
          t?.headers
        ]),
        __span: u(this._client, "anthropic.skills.list", t, {
          route: "/v1/skills",
          queryParams: ["limit", "page", "source"]
        })
      });
    }
    /**
     * Delete Skill
     *
     * @example
     * ```ts
     * const betaDeletedSkill = await client.beta.skills.delete(
     *   'skill_id',
     * );
     * ```
     */
    delete(e, t = {}, r) {
      const { betas: i, workspace_id: a } = t ?? {};
      return this._client.delete(g`/v1/skills/${e}?beta=true`, {
        ...r,
        headers: f([
          {
            ...i?.toString() != null ? { "anthropic-beta": i?.toString() } : void 0,
            ...a != null ? { "anthropic-workspace-id": a } : void 0
          },
          r?.headers
        ]),
        __span: u(this._client, "anthropic.skills.delete", r, {
          route: "/v1/skills/{skill_id}",
          attributes: { "anthropic.skill.id": e }
        })
      });
    }
  }
  return s.Versions = oc, s;
})();
class lc extends x {
  /**
   * The Tunnels API is in research preview. It requires the
   * `anthropic-beta: mcp-tunnels-2026-06-22` header and may change without a
   * deprecation period. It supersedes the Admin API endpoints at
   * `/v1/organizations/tunnels`, which remain available during a migration window.
   *
   * Registers a public CA certificate on a tunnel. Anthropic verifies the gateway's
   * server certificate against this CA when it terminates the inner TLS session. A
   * tunnel holds at most two non-archived certificates.
   *
   * @example
   * ```ts
   * const betaTunnelCertificate =
   *   await client.beta.tunnels.certificates.create(
   *     'tunnel_id',
   *     { ca_certificate_pem: 'ca_certificate_pem' },
   *   );
   * ```
   */
  create(n, e, t) {
    const { betas: r, workspace_id: i, ...a } = e;
    return this._client.post(g`/v1/tunnels/${n}/certificates?beta=true`, {
      body: a,
      ...t,
      headers: f([
        {
          "anthropic-beta": [...r ?? [], "mcp-tunnels-2026-06-22"].toString(),
          ...i != null ? { "anthropic-workspace-id": i } : void 0
        },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.tunnels.certificates.create", t, {
        route: "/v1/tunnels/{tunnel_id}/certificates",
        attributes: { "anthropic.tunnel.id": n },
        createdIDAttribute: "anthropic.tunnel.certificate.id"
      })
    });
  }
  /**
   * The Tunnels API is in research preview. It requires the
   * `anthropic-beta: mcp-tunnels-2026-06-22` header and may change without a
   * deprecation period. It supersedes the Admin API endpoints at
   * `/v1/organizations/tunnels`, which remain available during a migration window.
   *
   * Fetches a tunnel certificate by ID.
   *
   * @example
   * ```ts
   * const betaTunnelCertificate =
   *   await client.beta.tunnels.certificates.retrieve(
   *     'certificate_id',
   *     { tunnel_id: 'tunnel_id' },
   *   );
   * ```
   */
  retrieve(n, e, t) {
    const { tunnel_id: r, betas: i, workspace_id: a } = e;
    return this._client.get(g`/v1/tunnels/${r}/certificates/${n}?beta=true`, {
      ...t,
      headers: f([
        {
          "anthropic-beta": [...i ?? [], "mcp-tunnels-2026-06-22"].toString(),
          ...a != null ? { "anthropic-workspace-id": a } : void 0
        },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.tunnels.certificates.retrieve", t, {
        route: "/v1/tunnels/{tunnel_id}/certificates/{certificate_id}",
        attributes: { "anthropic.tunnel.id": r, "anthropic.tunnel.certificate.id": n }
      })
    });
  }
  /**
   * The Tunnels API is in research preview. It requires the
   * `anthropic-beta: mcp-tunnels-2026-06-22` header and may change without a
   * deprecation period. It supersedes the Admin API endpoints at
   * `/v1/organizations/tunnels`, which remain available during a migration window.
   *
   * Lists the certificates registered on a tunnel. Archived certificates are
   * excluded unless include_archived is set.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaTunnelCertificate of client.beta.tunnels.certificates.list(
   *   'tunnel_id',
   * )) {
   *   // ...
   * }
   * ```
   */
  list(n, e = {}, t) {
    const { betas: r, workspace_id: i, ...a } = e ?? {};
    return this._client.getAPIList(g`/v1/tunnels/${n}/certificates?beta=true`, z, {
      query: a,
      ...t,
      headers: f([
        {
          "anthropic-beta": [...r ?? [], "mcp-tunnels-2026-06-22"].toString(),
          ...i != null ? { "anthropic-workspace-id": i } : void 0
        },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.tunnels.certificates.list", t, {
        route: "/v1/tunnels/{tunnel_id}/certificates",
        queryParams: ["include_archived", "limit", "page"],
        attributes: { "anthropic.tunnel.id": n }
      })
    });
  }
  /**
   * The Tunnels API is in research preview. It requires the
   * `anthropic-beta: mcp-tunnels-2026-06-22` header and may change without a
   * deprecation period. It supersedes the Admin API endpoints at
   * `/v1/organizations/tunnels`, which remain available during a migration window.
   *
   * Archives a tunnel certificate, removing it from the set Anthropic trusts for the
   * tunnel. The certificate record is retained. Archiving the last non-archived
   * certificate is permitted; the tunnel rejects MCP traffic until a new certificate
   * is added.
   *
   * @example
   * ```ts
   * const betaTunnelCertificate =
   *   await client.beta.tunnels.certificates.archive(
   *     'certificate_id',
   *     { tunnel_id: 'tunnel_id' },
   *   );
   * ```
   */
  archive(n, e, t) {
    const { tunnel_id: r, betas: i, workspace_id: a } = e;
    return this._client.post(g`/v1/tunnels/${r}/certificates/${n}/archive?beta=true`, {
      ...t,
      headers: f([
        {
          "anthropic-beta": [...i ?? [], "mcp-tunnels-2026-06-22"].toString(),
          ...a != null ? { "anthropic-workspace-id": a } : void 0
        },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.tunnels.certificates.archive", t, {
        route: "/v1/tunnels/{tunnel_id}/certificates/{certificate_id}/archive",
        attributes: { "anthropic.tunnel.id": r, "anthropic.tunnel.certificate.id": n }
      })
    });
  }
}
var uc = /* @__PURE__ */ (() => {
  class s extends x {
    constructor() {
      super(...arguments), this.certificates = new lc(this._client);
    }
    /**
     * The Tunnels API is in research preview. It requires the
     * `anthropic-beta: mcp-tunnels-2026-06-22` header and may change without a
     * deprecation period. It supersedes the Admin API endpoints at
     * `/v1/organizations/tunnels`, which remain available during a migration window.
     *
     * Creates a tunnel. Creation allocates a fresh hostname and provisions the tunnel;
     * it is not idempotent. The new tunnel rejects MCP traffic until at least one CA
     * certificate is added.
     *
     * @example
     * ```ts
     * const betaTunnel = await client.beta.tunnels.create();
     * ```
     */
    create(e, t) {
      const { betas: r, workspace_id: i, ...a } = e;
      return this._client.post("/v1/tunnels?beta=true", {
        body: a,
        ...t,
        headers: f([
          {
            "anthropic-beta": [...r ?? [], "mcp-tunnels-2026-06-22"].toString(),
            ...i != null ? { "anthropic-workspace-id": i } : void 0
          },
          t?.headers
        ]),
        __span: u(this._client, "anthropic.tunnels.create", t, {
          route: "/v1/tunnels",
          createdIDAttribute: "anthropic.tunnel.id"
        })
      });
    }
    /**
     * The Tunnels API is in research preview. It requires the
     * `anthropic-beta: mcp-tunnels-2026-06-22` header and may change without a
     * deprecation period. It supersedes the Admin API endpoints at
     * `/v1/organizations/tunnels`, which remain available during a migration window.
     *
     * Fetches a tunnel by ID.
     *
     * @example
     * ```ts
     * const betaTunnel = await client.beta.tunnels.retrieve(
     *   'tunnel_id',
     * );
     * ```
     */
    retrieve(e, t = {}, r) {
      const { betas: i, workspace_id: a } = t ?? {};
      return this._client.get(g`/v1/tunnels/${e}?beta=true`, {
        ...r,
        headers: f([
          {
            "anthropic-beta": [...i ?? [], "mcp-tunnels-2026-06-22"].toString(),
            ...a != null ? { "anthropic-workspace-id": a } : void 0
          },
          r?.headers
        ]),
        __span: u(this._client, "anthropic.tunnels.retrieve", r, {
          route: "/v1/tunnels/{tunnel_id}",
          attributes: { "anthropic.tunnel.id": e }
        })
      });
    }
    /**
     * The Tunnels API is in research preview. It requires the
     * `anthropic-beta: mcp-tunnels-2026-06-22` header and may change without a
     * deprecation period. It supersedes the Admin API endpoints at
     * `/v1/organizations/tunnels`, which remain available during a migration window.
     *
     * Lists tunnels. Results are ordered by creation time, newest first; archived
     * tunnels are excluded unless include_archived is set.
     *
     * @example
     * ```ts
     * // Automatically fetches more pages as needed.
     * for await (const betaTunnel of client.beta.tunnels.list()) {
     *   // ...
     * }
     * ```
     */
    list(e = {}, t) {
      const { betas: r, workspace_id: i, ...a } = e ?? {};
      return this._client.getAPIList("/v1/tunnels?beta=true", z, {
        query: a,
        ...t,
        headers: f([
          {
            "anthropic-beta": [...r ?? [], "mcp-tunnels-2026-06-22"].toString(),
            ...i != null ? { "anthropic-workspace-id": i } : void 0
          },
          t?.headers
        ]),
        __span: u(this._client, "anthropic.tunnels.list", t, {
          route: "/v1/tunnels",
          queryParams: ["include_archived", "limit", "page"]
        })
      });
    }
    /**
     * The Tunnels API is in research preview. It requires the
     * `anthropic-beta: mcp-tunnels-2026-06-22` header and may change without a
     * deprecation period. It supersedes the Admin API endpoints at
     * `/v1/organizations/tunnels`, which remain available during a migration window.
     *
     * Archives a tunnel. Archival is irreversible: every non-archived certificate on
     * the tunnel is archived in the same operation, the hostname is retired and never
     * re-allocated, and the tunnel token is invalidated. Retrying against an
     * already-archived tunnel returns the existing record unchanged.
     *
     * @example
     * ```ts
     * const betaTunnel = await client.beta.tunnels.archive(
     *   'tunnel_id',
     * );
     * ```
     */
    archive(e, t = {}, r) {
      const { betas: i, workspace_id: a } = t ?? {};
      return this._client.post(g`/v1/tunnels/${e}/archive?beta=true`, {
        ...r,
        headers: f([
          {
            "anthropic-beta": [...i ?? [], "mcp-tunnels-2026-06-22"].toString(),
            ...a != null ? { "anthropic-workspace-id": a } : void 0
          },
          r?.headers
        ]),
        __span: u(this._client, "anthropic.tunnels.archive", r, {
          route: "/v1/tunnels/{tunnel_id}/archive",
          attributes: { "anthropic.tunnel.id": e }
        })
      });
    }
    /**
     * The Tunnels API is in research preview. It requires the
     * `anthropic-beta: mcp-tunnels-2026-06-22` header and may change without a
     * deprecation period. It supersedes the Admin API endpoints at
     * `/v1/organizations/tunnels`, which remain available during a migration window.
     *
     * Reveals a tunnel's connector token. The value is fetched live on each call;
     * Anthropic does not store it. Repeated calls return the same value until the
     * token is rotated. Exposed as POST so the token does not appear in intermediary
     * access logs.
     *
     * @example
     * ```ts
     * const betaTunnelToken =
     *   await client.beta.tunnels.revealToken('tunnel_id');
     * ```
     */
    revealToken(e, t = {}, r) {
      const { betas: i, workspace_id: a } = t ?? {};
      return this._client.post(g`/v1/tunnels/${e}/reveal_token?beta=true`, {
        ...r,
        headers: f([
          {
            "anthropic-beta": [...i ?? [], "mcp-tunnels-2026-06-22"].toString(),
            ...a != null ? { "anthropic-workspace-id": a } : void 0
          },
          r?.headers
        ]),
        __span: u(this._client, "anthropic.tunnels.reveal_token", r, {
          route: "/v1/tunnels/{tunnel_id}/reveal_token",
          attributes: { "anthropic.tunnel.id": e }
        })
      });
    }
    /**
     * The Tunnels API is in research preview. It requires the
     * `anthropic-beta: mcp-tunnels-2026-06-22` header and may change without a
     * deprecation period. It supersedes the Admin API endpoints at
     * `/v1/organizations/tunnels`, which remain available during a migration window.
     *
     * Rotates a tunnel's connector token. Rotation invalidates the current token for
     * new connections and returns a fresh value; established connections are not
     * severed. A connector restarted after rotation must use the new value.
     *
     * @example
     * ```ts
     * const betaTunnelToken =
     *   await client.beta.tunnels.rotateToken('tunnel_id');
     * ```
     */
    rotateToken(e, t, r) {
      const { betas: i, workspace_id: a, ...o } = t;
      return this._client.post(g`/v1/tunnels/${e}/rotate_token?beta=true`, {
        body: o,
        ...r,
        headers: f([
          {
            "anthropic-beta": [...i ?? [], "mcp-tunnels-2026-06-22"].toString(),
            ...a != null ? { "anthropic-workspace-id": a } : void 0
          },
          r?.headers
        ]),
        __span: u(this._client, "anthropic.tunnels.rotate_token", r, {
          route: "/v1/tunnels/{tunnel_id}/rotate_token",
          attributes: { "anthropic.tunnel.id": e }
        })
      });
    }
  }
  return s.Certificates = lc, s;
})();
let dc = class extends x {
  /**
   * Create Action URL
   *
   * @example
   * ```ts
   * const betaUserProfileActionURL =
   *   await client.beta.userProfiles.actionURLs.create(
   *     'uprof_011CZkZCu8hGbp5mYRQgUmz9',
   *     { action: { type: 'enroll_end_user' } },
   *   );
   * ```
   */
  create(n, e, t) {
    const { betas: r, workspace_id: i, ...a } = e;
    return this._client.post(g`/v1/user_profiles/${n}/action_urls?beta=true`, {
      body: a,
      ...t,
      headers: f([
        {
          "anthropic-beta": [...r ?? [], "user-profiles-2026-08-18"].toString(),
          ...i != null ? { "anthropic-workspace-id": i } : void 0
        },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.user_profiles.action_urls.create", t, {
        route: "/v1/user_profiles/{user_profile_id}/action_urls",
        attributes: { "anthropic.user_profile.id": n }
      })
    });
  }
};
var hc = /* @__PURE__ */ (() => {
  class s extends x {
    constructor() {
      super(...arguments), this.actionURLs = new dc(this._client);
    }
    /**
     * Create User Profile
     *
     * @example
     * ```ts
     * const betaUserProfile =
     *   await client.beta.userProfiles.create();
     * ```
     */
    create(e, t) {
      const { betas: r, workspace_id: i, ...a } = e;
      return this._client.post("/v1/user_profiles?beta=true", {
        body: a,
        ...t,
        headers: f([
          {
            "anthropic-beta": [...r ?? [], "user-profiles-2026-08-18"].toString(),
            ...i != null ? { "anthropic-workspace-id": i } : void 0
          },
          t?.headers
        ]),
        __span: u(this._client, "anthropic.user_profiles.create", t, {
          route: "/v1/user_profiles",
          createdIDAttribute: "anthropic.user_profile.id"
        })
      });
    }
    /**
     * Get User Profile
     *
     * @example
     * ```ts
     * const betaUserProfile =
     *   await client.beta.userProfiles.retrieve(
     *     'uprof_011CZkZCu8hGbp5mYRQgUmz9',
     *   );
     * ```
     */
    retrieve(e, t = {}, r) {
      const { betas: i, workspace_id: a } = t ?? {};
      return this._client.get(g`/v1/user_profiles/${e}?beta=true`, {
        ...r,
        headers: f([
          {
            "anthropic-beta": [...i ?? [], "user-profiles-2026-08-18"].toString(),
            ...a != null ? { "anthropic-workspace-id": a } : void 0
          },
          r?.headers
        ]),
        __span: u(this._client, "anthropic.user_profiles.retrieve", r, {
          route: "/v1/user_profiles/{user_profile_id}",
          attributes: { "anthropic.user_profile.id": e }
        })
      });
    }
    /**
     * Update User Profile
     *
     * @example
     * ```ts
     * const betaUserProfile =
     *   await client.beta.userProfiles.update(
     *     'uprof_011CZkZCu8hGbp5mYRQgUmz9',
     *   );
     * ```
     */
    update(e, t, r) {
      const { betas: i, workspace_id: a, ...o } = t;
      return this._client.post(g`/v1/user_profiles/${e}?beta=true`, {
        body: o,
        ...r,
        headers: f([
          {
            "anthropic-beta": [...i ?? [], "user-profiles-2026-08-18"].toString(),
            ...a != null ? { "anthropic-workspace-id": a } : void 0
          },
          r?.headers
        ]),
        __span: u(this._client, "anthropic.user_profiles.update", r, {
          route: "/v1/user_profiles/{user_profile_id}",
          attributes: { "anthropic.user_profile.id": e }
        })
      });
    }
    /**
     * List User Profiles
     *
     * @example
     * ```ts
     * // Automatically fetches more pages as needed.
     * for await (const betaUserProfile of client.beta.userProfiles.list()) {
     *   // ...
     * }
     * ```
     */
    list(e = {}, t) {
      const { betas: r, workspace_id: i, ...a } = e ?? {};
      return this._client.getAPIList("/v1/user_profiles?beta=true", z, {
        query: a,
        ...t,
        headers: f([
          {
            "anthropic-beta": [...r ?? [], "user-profiles-2026-08-18"].toString(),
            ...i != null ? { "anthropic-workspace-id": i } : void 0
          },
          t?.headers
        ]),
        __span: u(this._client, "anthropic.user_profiles.list", t, {
          route: "/v1/user_profiles",
          queryParams: ["limit", "order", "order_by", "page"]
        })
      });
    }
    /**
     * Delete User Profile
     *
     * @example
     * ```ts
     * const betaDeletedUserProfile =
     *   await client.beta.userProfiles.delete(
     *     'uprof_011CZkZCu8hGbp5mYRQgUmz9',
     *   );
     * ```
     */
    delete(e, t = {}, r) {
      const { betas: i, workspace_id: a } = t ?? {};
      return this._client.delete(g`/v1/user_profiles/${e}?beta=true`, {
        ...r,
        headers: f([
          {
            "anthropic-beta": [...i ?? [], "user-profiles-2026-08-18"].toString(),
            ...a != null ? { "anthropic-workspace-id": a } : void 0
          },
          r?.headers
        ]),
        __span: u(this._client, "anthropic.user_profiles.delete", r, {
          route: "/v1/user_profiles/{user_profile_id}",
          attributes: { "anthropic.user_profile.id": e }
        })
      });
    }
    /**
     * Create Enrollment URL
     *
     * @example
     * ```ts
     * const betaUserProfileEnrollmentURL =
     *   await client.beta.userProfiles.createEnrollmentURL(
     *     'uprof_011CZkZCu8hGbp5mYRQgUmz9',
     *   );
     * ```
     */
    createEnrollmentURL(e, t = {}, r) {
      const { betas: i, workspace_id: a } = t ?? {};
      return this._client.post(g`/v1/user_profiles/${e}/enrollment_url?beta=true`, {
        ...r,
        headers: f([
          {
            "anthropic-beta": [...i ?? [], "user-profiles-2026-08-18"].toString(),
            ...a != null ? { "anthropic-workspace-id": a } : void 0
          },
          r?.headers
        ]),
        __span: u(this._client, "anthropic.user_profiles.create_enrollment_url", r, {
          route: "/v1/user_profiles/{user_profile_id}/enrollment_url",
          attributes: { "anthropic.user_profile.id": e }
        })
      });
    }
  }
  return s.ActionURLs = dc, s;
})();
class pc extends x {
  /**
   * Create a Credential
   *
   * @example
   * ```ts
   * const betaManagedAgentsCredential =
   *   await client.beta.vaults.credentials.create(
   *     'vlt_011CZkZDLs7fYzm1hXNPeRjv',
   *     {
   *       auth: {
   *         token: 'bearer_exampletoken',
   *         mcp_server_url:
   *           'https://example-server.modelcontextprotocol.io/sse',
   *         type: 'static_bearer',
   *       },
   *     },
   *   );
   * ```
   */
  create(n, e, t) {
    const { betas: r, workspace_id: i, ...a } = e;
    return this._client.post(g`/v1/vaults/${n}/credentials?beta=true`, {
      body: a,
      ...t,
      headers: f([
        {
          "anthropic-beta": [...r ?? [], "managed-agents-2026-04-01"].toString(),
          ...i != null ? { "anthropic-workspace-id": i } : void 0
        },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.vaults.credentials.create", t, {
        route: "/v1/vaults/{vault_id}/credentials",
        attributes: { "anthropic.vault.id": n },
        createdIDAttribute: "anthropic.vault.credential.id"
      })
    });
  }
  /**
   * Retrieve a Credential
   *
   * @example
   * ```ts
   * const betaManagedAgentsCredential =
   *   await client.beta.vaults.credentials.retrieve(
   *     'vcrd_011CZkZEMt8gZan2iYPQfSkw',
   *     { vault_id: 'vlt_011CZkZDLs7fYzm1hXNPeRjv' },
   *   );
   * ```
   */
  retrieve(n, e, t) {
    const { vault_id: r, betas: i, workspace_id: a } = e;
    return this._client.get(g`/v1/vaults/${r}/credentials/${n}?beta=true`, {
      ...t,
      headers: f([
        {
          "anthropic-beta": [...i ?? [], "managed-agents-2026-04-01"].toString(),
          ...a != null ? { "anthropic-workspace-id": a } : void 0
        },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.vaults.credentials.retrieve", t, {
        route: "/v1/vaults/{vault_id}/credentials/{credential_id}",
        attributes: { "anthropic.vault.id": r, "anthropic.vault.credential.id": n }
      })
    });
  }
  /**
   * Update a Credential
   *
   * @example
   * ```ts
   * const betaManagedAgentsCredential =
   *   await client.beta.vaults.credentials.update(
   *     'vcrd_011CZkZEMt8gZan2iYPQfSkw',
   *     { vault_id: 'vlt_011CZkZDLs7fYzm1hXNPeRjv' },
   *   );
   * ```
   */
  update(n, e, t) {
    const { vault_id: r, betas: i, workspace_id: a, ...o } = e;
    return this._client.post(g`/v1/vaults/${r}/credentials/${n}?beta=true`, {
      body: o,
      ...t,
      headers: f([
        {
          "anthropic-beta": [...i ?? [], "managed-agents-2026-04-01"].toString(),
          ...a != null ? { "anthropic-workspace-id": a } : void 0
        },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.vaults.credentials.update", t, {
        route: "/v1/vaults/{vault_id}/credentials/{credential_id}",
        attributes: { "anthropic.vault.id": r, "anthropic.vault.credential.id": n }
      })
    });
  }
  /**
   * List Credentials
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaManagedAgentsCredential of client.beta.vaults.credentials.list(
   *   'vlt_011CZkZDLs7fYzm1hXNPeRjv',
   * )) {
   *   // ...
   * }
   * ```
   */
  list(n, e = {}, t) {
    const { betas: r, workspace_id: i, ...a } = e ?? {};
    return this._client.getAPIList(g`/v1/vaults/${n}/credentials?beta=true`, z, {
      query: a,
      ...t,
      headers: f([
        {
          "anthropic-beta": [...r ?? [], "managed-agents-2026-04-01"].toString(),
          ...i != null ? { "anthropic-workspace-id": i } : void 0
        },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.vaults.credentials.list", t, {
        route: "/v1/vaults/{vault_id}/credentials",
        queryParams: ["include_archived", "limit", "page"],
        attributes: { "anthropic.vault.id": n }
      })
    });
  }
  /**
   * Delete a Credential
   *
   * @example
   * ```ts
   * const betaManagedAgentsDeletedCredential =
   *   await client.beta.vaults.credentials.delete(
   *     'vcrd_011CZkZEMt8gZan2iYPQfSkw',
   *     { vault_id: 'vlt_011CZkZDLs7fYzm1hXNPeRjv' },
   *   );
   * ```
   */
  delete(n, e, t) {
    const { vault_id: r, betas: i, workspace_id: a } = e;
    return this._client.delete(g`/v1/vaults/${r}/credentials/${n}?beta=true`, {
      ...t,
      headers: f([
        {
          "anthropic-beta": [...i ?? [], "managed-agents-2026-04-01"].toString(),
          ...a != null ? { "anthropic-workspace-id": a } : void 0
        },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.vaults.credentials.delete", t, {
        route: "/v1/vaults/{vault_id}/credentials/{credential_id}",
        attributes: { "anthropic.vault.id": r, "anthropic.vault.credential.id": n }
      })
    });
  }
  /**
   * Archive a Credential
   *
   * @example
   * ```ts
   * const betaManagedAgentsCredential =
   *   await client.beta.vaults.credentials.archive(
   *     'vcrd_011CZkZEMt8gZan2iYPQfSkw',
   *     { vault_id: 'vlt_011CZkZDLs7fYzm1hXNPeRjv' },
   *   );
   * ```
   */
  archive(n, e, t) {
    const { vault_id: r, betas: i, workspace_id: a } = e;
    return this._client.post(g`/v1/vaults/${r}/credentials/${n}/archive?beta=true`, {
      ...t,
      headers: f([
        {
          "anthropic-beta": [...i ?? [], "managed-agents-2026-04-01"].toString(),
          ...a != null ? { "anthropic-workspace-id": a } : void 0
        },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.vaults.credentials.archive", t, {
        route: "/v1/vaults/{vault_id}/credentials/{credential_id}/archive",
        attributes: { "anthropic.vault.id": r, "anthropic.vault.credential.id": n }
      })
    });
  }
  /**
   * Validate an MCP OAuth Credential
   *
   * @example
   * ```ts
   * const betaManagedAgentsCredentialValidation =
   *   await client.beta.vaults.credentials.mcpOAuthValidate(
   *     'vcrd_011CZkZEMt8gZan2iYPQfSkw',
   *     { vault_id: 'vlt_011CZkZDLs7fYzm1hXNPeRjv' },
   *   );
   * ```
   */
  mcpOAuthValidate(n, e, t) {
    const { vault_id: r, betas: i, workspace_id: a } = e;
    return this._client.post(g`/v1/vaults/${r}/credentials/${n}/mcp_oauth_validate?beta=true`, {
      ...t,
      headers: f([
        {
          "anthropic-beta": [...i ?? [], "managed-agents-2026-04-01"].toString(),
          ...a != null ? { "anthropic-workspace-id": a } : void 0
        },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.vaults.credentials.mcp_oauth_validate", t, {
        route: "/v1/vaults/{vault_id}/credentials/{credential_id}/mcp_oauth_validate",
        attributes: { "anthropic.vault.id": r, "anthropic.vault.credential.id": n }
      })
    });
  }
}
var _c = /* @__PURE__ */ (() => {
  class s extends x {
    constructor() {
      super(...arguments), this.credentials = new pc(this._client);
    }
    /**
     * Create a Vault
     *
     * @example
     * ```ts
     * const betaManagedAgentsVault =
     *   await client.beta.vaults.create({
     *     display_name: 'Example vault',
     *   });
     * ```
     */
    create(e, t) {
      const { betas: r, workspace_id: i, ...a } = e;
      return this._client.post("/v1/vaults?beta=true", {
        body: a,
        ...t,
        headers: f([
          {
            "anthropic-beta": [...r ?? [], "managed-agents-2026-04-01"].toString(),
            ...i != null ? { "anthropic-workspace-id": i } : void 0
          },
          t?.headers
        ]),
        __span: u(this._client, "anthropic.vaults.create", t, {
          route: "/v1/vaults",
          createdIDAttribute: "anthropic.vault.id"
        })
      });
    }
    /**
     * Retrieve a Vault
     *
     * @example
     * ```ts
     * const betaManagedAgentsVault =
     *   await client.beta.vaults.retrieve(
     *     'vlt_011CZkZDLs7fYzm1hXNPeRjv',
     *   );
     * ```
     */
    retrieve(e, t = {}, r) {
      const { betas: i, workspace_id: a } = t ?? {};
      return this._client.get(g`/v1/vaults/${e}?beta=true`, {
        ...r,
        headers: f([
          {
            "anthropic-beta": [...i ?? [], "managed-agents-2026-04-01"].toString(),
            ...a != null ? { "anthropic-workspace-id": a } : void 0
          },
          r?.headers
        ]),
        __span: u(this._client, "anthropic.vaults.retrieve", r, {
          route: "/v1/vaults/{vault_id}",
          attributes: { "anthropic.vault.id": e }
        })
      });
    }
    /**
     * Update a Vault
     *
     * @example
     * ```ts
     * const betaManagedAgentsVault =
     *   await client.beta.vaults.update(
     *     'vlt_011CZkZDLs7fYzm1hXNPeRjv',
     *   );
     * ```
     */
    update(e, t, r) {
      const { betas: i, workspace_id: a, ...o } = t;
      return this._client.post(g`/v1/vaults/${e}?beta=true`, {
        body: o,
        ...r,
        headers: f([
          {
            "anthropic-beta": [...i ?? [], "managed-agents-2026-04-01"].toString(),
            ...a != null ? { "anthropic-workspace-id": a } : void 0
          },
          r?.headers
        ]),
        __span: u(this._client, "anthropic.vaults.update", r, {
          route: "/v1/vaults/{vault_id}",
          attributes: { "anthropic.vault.id": e }
        })
      });
    }
    /**
     * List Vaults
     *
     * @example
     * ```ts
     * // Automatically fetches more pages as needed.
     * for await (const betaManagedAgentsVault of client.beta.vaults.list()) {
     *   // ...
     * }
     * ```
     */
    list(e = {}, t) {
      const { betas: r, workspace_id: i, ...a } = e ?? {};
      return this._client.getAPIList("/v1/vaults?beta=true", z, {
        query: a,
        ...t,
        headers: f([
          {
            "anthropic-beta": [...r ?? [], "managed-agents-2026-04-01"].toString(),
            ...i != null ? { "anthropic-workspace-id": i } : void 0
          },
          t?.headers
        ]),
        __span: u(this._client, "anthropic.vaults.list", t, {
          route: "/v1/vaults",
          queryParams: ["include_archived", "limit", "page"]
        })
      });
    }
    /**
     * Delete a Vault
     *
     * @example
     * ```ts
     * const betaManagedAgentsDeletedVault =
     *   await client.beta.vaults.delete(
     *     'vlt_011CZkZDLs7fYzm1hXNPeRjv',
     *   );
     * ```
     */
    delete(e, t = {}, r) {
      const { betas: i, workspace_id: a } = t ?? {};
      return this._client.delete(g`/v1/vaults/${e}?beta=true`, {
        ...r,
        headers: f([
          {
            "anthropic-beta": [...i ?? [], "managed-agents-2026-04-01"].toString(),
            ...a != null ? { "anthropic-workspace-id": a } : void 0
          },
          r?.headers
        ]),
        __span: u(this._client, "anthropic.vaults.delete", r, {
          route: "/v1/vaults/{vault_id}",
          attributes: { "anthropic.vault.id": e }
        })
      });
    }
    /**
     * Archive a Vault
     *
     * @example
     * ```ts
     * const betaManagedAgentsVault =
     *   await client.beta.vaults.archive(
     *     'vlt_011CZkZDLs7fYzm1hXNPeRjv',
     *   );
     * ```
     */
    archive(e, t = {}, r) {
      const { betas: i, workspace_id: a } = t ?? {};
      return this._client.post(g`/v1/vaults/${e}/archive?beta=true`, {
        ...r,
        headers: f([
          {
            "anthropic-beta": [...i ?? [], "managed-agents-2026-04-01"].toString(),
            ...a != null ? { "anthropic-workspace-id": a } : void 0
          },
          r?.headers
        ]),
        __span: u(this._client, "anthropic.vaults.archive", r, {
          route: "/v1/vaults/{vault_id}/archive",
          attributes: { "anthropic.vault.id": e }
        })
      });
    }
  }
  return s.Credentials = pc, s;
})(), Re, ws, ot, Ot, vs, ct, Ct, ks, fc, Ss, Ts, gc = /* @__PURE__ */ (() => {
  class s extends Zu {
    constructor(e, t, r) {
      super(e, { client: r }), Re.add(this), ws.set(this, void 0), ot.set(this, 0), Ot.set(this, []), vs.set(this, []), ct.set(this, void 0), Ct.set(this, []), ks.set(this, !1), w(this, ws, t);
    }
    /** The `tool_use` blocks that have finished streaming, in the model's order */
    get toolCalls() {
      return c(this, vs, "f");
    }
    /** Sends the request as `client.beta.messages.stream()` does. */
    static start(e, t, r, i) {
      const a = new s({ ...t, stream: !0 }, i, e);
      for (const o of t.messages)
        a._addMessageParam(o);
      return a._run(() => a._createMessage(e.beta.messages, { ...t, stream: !0 }, { ...r, headers: { ...r?.headers, [qi]: "stream" } })), a;
    }
    _deliverEvent(e, t) {
      var r;
      w(this, ot, (r = c(this, ot, "f"), r++, r));
      const i = e.type === "content_block_stop" ? t?.content[e.index] : void 0, a = i?.type === "tool_use" ? i : void 0;
      a && c(this, vs, "f").push(a), super._deliverEvent(e, t), c(this, Re, "m", fc).call(this, e, a), c(this, Re, "m", Ss).call(this);
    }
    [(ws = /* @__PURE__ */ new WeakMap(), ot = /* @__PURE__ */ new WeakMap(), Ot = /* @__PURE__ */ new WeakMap(), vs = /* @__PURE__ */ new WeakMap(), ct = /* @__PURE__ */ new WeakMap(), Ct = /* @__PURE__ */ new WeakMap(), ks = /* @__PURE__ */ new WeakMap(), Re = /* @__PURE__ */ new WeakSet(), Symbol.asyncIterator)]() {
      const e = super[Symbol.asyncIterator](), t = { handled: c(this, ot, "f") };
      c(this, Ot, "f").push(t);
      let r = !1;
      return {
        next: async () => {
          r && (r = !1, t.handled++, c(this, Re, "m", Ss).call(this));
          try {
            const i = await e.next();
            return r = !i.done, i.done && c(this, Re, "m", Ts).call(this, t), i;
          } catch (i) {
            throw c(this, Re, "m", Ts).call(this, t), i;
          }
        },
        return: async () => {
          const i = e.return?.();
          return c(this, Re, "m", Ts).call(this, t), await i ?? { value: void 0, done: !0 };
        }
      };
    }
  }
  return fc = function(e, t) {
    if (c(this, ks, "f"))
      return;
    if (e.type === "content_block_start" && e.content_block.type === "fallback") {
      w(this, ks, !0), w(this, ct, void 0);
      return;
    }
    const r = e.type === "content_block_start" || e.type === "message_delta" && e.delta.stop_reason === "tool_use";
    c(this, ct, "f") && r && (c(this, Ct, "f").push({ toolUse: c(this, ct, "f"), event: c(this, ot, "f") }), w(this, ct, void 0)), t && w(this, ct, t);
  }, Ss = function() {
    if (this.errored || this.controller.signal.aborted)
      return;
    const e = Math.min(c(this, ot, "f"), ...c(this, Ot, "f").map((t) => t.handled));
    for (; c(this, Ct, "f")[0] && c(this, Ct, "f")[0].event <= e; )
      c(this, ws, "f").call(this, c(this, Ct, "f").shift().toolUse);
  }, Ts = function(e) {
    const t = c(this, Ot, "f").indexOf(e);
    t >= 0 && (c(this, Ot, "f").splice(t, 1), c(this, Re, "m", Ss).call(this));
  }, s;
})();
function mc() {
  let s, n;
  return { promise: new Promise((t, r) => {
    s = t, n = r;
  }), resolve: s, reject: n };
}
var L, It, lt, q, G, ne, De, Te, Ke, Sn, Pe, ue, Ae, $t, Nt, ut, Tn, Ur, yc, jr, Fr, An, As, bc, wc, Wr, xs, vc, Hr;
const kc = "a tool runner's toolsets come only from its tools param; change them with setMessagesParams(), or build a new runner", Tg = "a tool runner's toolsets come only from its tools param; remove it there with setMessagesParams(), or build a new runner without it";
var Sc = /* @__PURE__ */ (() => {
  class s {
    constructor(e, t, r) {
      L.add(this), this.client = e, It.set(this, !1), lt.set(this, !1), q.set(this, void 0), G.set(this, void 0), ne.set(this, void 0), De.set(this, void 0), Te.set(this, void 0), Ke.set(this, void 0), Sn.set(this, 0), Pe.set(this, void 0), ue.set(this, { status: "idle" }), Ae.set(this, void 0), $t.set(this, null), Nt.set(this, /* @__PURE__ */ new Map()), ut.set(this, []), Tc(t), Ag(t), Ac(t), w(this, q, {
        params: {
          // You can't clone the entire params since there are functions as handlers.
          // You also don't really need to clone params.messages, but it probably will prevent a foot gun
          // somewhere.
          ...t,
          // Not structuredClone(): it throws on a function, and a runnable tool written by value into a
          // `tool_addition` block has `run`. A JSON copy is the messages as they are sent, which drops it.
          messages: JSON.parse(JSON.stringify(xc(t.messages)))
        }
      });
      const i = Su(t.tools, t.messages);
      w(this, G, {
        ...r,
        headers: f([
          ku("BetaToolRunner"),
          i.length ? { [qn]: i.join(", ") } : void 0,
          r?.headers
        ])
      }), w(this, Ke, mc());
    }
    async *[(It = /* @__PURE__ */ new WeakMap(), lt = /* @__PURE__ */ new WeakMap(), q = /* @__PURE__ */ new WeakMap(), G = /* @__PURE__ */ new WeakMap(), ne = /* @__PURE__ */ new WeakMap(), De = /* @__PURE__ */ new WeakMap(), Te = /* @__PURE__ */ new WeakMap(), Ke = /* @__PURE__ */ new WeakMap(), Sn = /* @__PURE__ */ new WeakMap(), Pe = /* @__PURE__ */ new WeakMap(), ue = /* @__PURE__ */ new WeakMap(), Ae = /* @__PURE__ */ new WeakMap(), $t = /* @__PURE__ */ new WeakMap(), Nt = /* @__PURE__ */ new WeakMap(), ut = /* @__PURE__ */ new WeakMap(), L = /* @__PURE__ */ new WeakSet(), Tn = function(t) {
      return c(this, Pe, "f") ? _e.with(c(this, Pe, "f"), t) : t();
    }, Symbol.asyncIterator)]() {
      var e;
      if (c(this, It, "f"))
        throw new R("Cannot iterate over a consumed stream");
      w(this, It, !0), w(this, lt, !0), w(this, Te, void 0);
      const t = j(this.client, () => G_(this.client, c(this, q, "f").params, c(this, G, "f").openTelemetry?.conversationId));
      w(this, Pe, t && wt.setSpan(_e.active(), t));
      try {
        for (; ; )
          try {
            if (c(this, q, "f").params.max_iterations && c(this, Sn, "f") >= c(this, q, "f").params.max_iterations)
              break;
            if (c(this, L, "m", vc).call(this), c(this, ue, "f").status === "scheduled" && Rc(c(this, $t, "f")) !== "resume") {
              yield* c(this, L, "m", Fr).call(this, c(this, ue, "f").config);
              continue;
            }
            w(this, lt, !1, "f"), w(this, Te, void 0, "f"), w(this, Sn, (e = c(this, Sn, "f"), e++, e), "f"), w(this, ne, void 0, "f");
            const { max_iterations: r, runToolsEagerly: i, ...a } = c(this, q, "f").params;
            if (yield* c(this, L, "m", Ur).call(this, a), await c(this, L, "m", Tn).call(this, async () => {
              if (c(this, lt, "f"))
                w(this, $t, null, "f");
              else {
                const d = await c(this, ne, "f"), p = Rc(d.stop_reason);
                w(this, $t, d.stop_reason, "f"), c(this, q, "f").params.messages.push({
                  role: d.role,
                  content: d.content
                });
                const { container: h } = c(this, q, "f").params;
                if (d.container && (h == null ? c(this, q, "f").params.container = d.container.id : typeof h == "object" && h.id == null && (c(this, q, "f").params.container = { ...h, id: d.container.id })), p === "stop")
                  return "stop";
                if (p === "resume")
                  return "continue";
              }
              const l = await c(this, L, "m", Wr).call(this, c(this, q, "f").params.messages.at(-1), c(this, G, "f").signal, c(this, Pe, "f"));
              if (l)
                c(this, q, "f").params.messages.push(l);
              else if (!c(this, lt, "f"))
                return "stop";
              return "continue";
            }) === "stop") {
              yield* c(this, L, "m", wc).call(this);
              break;
            }
          } finally {
            c(this, De, "f")?.abort(), w(this, De, void 0, "f");
          }
        if (await c(this, L, "m", jr).call(this), !c(this, ne, "f"))
          throw new R("ToolRunner concluded without a message from the server");
        c(this, Ke, "f").resolve(await c(this, ne, "f")), j(this.client, () => t?.setStatus({ code: bt.OK }));
      } catch (r) {
        throw t && j(this.client, () => Ye(t, r)), w(this, It, !1), c(this, Ke, "f").promise.catch(() => {
        }), c(this, Ke, "f").reject(r), w(this, Ke, mc()), r;
      } finally {
        j(this.client, () => t?.end()), w(this, Pe, void 0);
      }
    }
    setMessagesParams(e) {
      const t = typeof e == "function" ? e(c(this, q, "f").params) : e;
      if (Tc(t), Ac(t), c(this, ue, "f").status !== "idle" && Dr(t), c(this, ue, "f").status === "in_flight" && t.messages !== c(this, q, "f").params.messages)
        throw new R("Message params can't be changed while the conversation is being compacted, because the compaction response is about to replace them. Change them after this iteration instead.");
      c(this, q, "f").params = t, w(this, lt, !0), w(this, Te, void 0);
    }
    setRequestOptions(e) {
      typeof e == "function" ? w(this, G, e(c(this, G, "f"))) : w(this, G, { ...c(this, G, "f"), ...e });
    }
    /**
     * Get the tool response for the last message from the assistant.
     * Avoids redundant tool executions by caching results. With `runToolsEagerly`, it reuses the calls of
     * the reply that have started and runs the rest, including the ones `deferToolCall()` is holding, so that no
     * call runs twice.
     *
     * @returns A promise that resolves to a BetaMessageParam containing tool results, or null if no tools need to be executed
     *
     * @example
     * const toolResponse = await runner.generateToolResponse();
     * if (toolResponse) {
     *   console.log('Tool results:', toolResponse.content);
     * }
     */
    async generateToolResponse(e = c(this, G, "f").signal) {
      const t = this.client._tracer ? _e.active() : void 0, r = await c(this, ne, "f") ?? this.params.messages.at(-1);
      return r ? c(this, L, "m", Wr).call(this, r, e, t) : null;
    }
    /**
     * Hold a tool call of the current reply until you are done with the reply, which is when it runs without
     * streaming: at the end of the loop body, or when you call `generateToolResponse()`.
     *
     * With `runToolsEagerly` the runner otherwise starts each call while the reply streams, as soon as
     * the model has moved on from it: when the next block starts, or the reply stops with `tool_use`. A call
     * never starts before your stream listeners and any `for await` over the stream have handled that event, so
     * you can call this from either once you have seen the call. The other calls of the reply still start early,
     * except the later calls of the same toolset, which a toolset runs in order.
     * It does nothing for a call that has started, outside the loop body, and without `runToolsEagerly`.
     *
     * @param toolUse - The `tool_use` block of the call, or its id
     *
     * @example
     * for await (const stream of runner) {
     *   stream.on('contentBlock', (block) => {
     *     if (block.type === 'tool_use' && block.name === 'delete_file') {
     *       runner.deferToolCall(block);
     *     }
     *   });
     *   await stream.finalMessage();
     *   // No `delete_file` call has started yet.
     * }
     */
    deferToolCall(e) {
      const t = typeof e == "string" ? e : e.id;
      c(this, Ae, "f") && !c(this, Ae, "f").has(t) && c(this, Ae, "f").set(t, { status: "held" });
    }
    /**
     * The tool calls of the current reply that `deferToolCall()` is holding, in the model's order, as their
     * `tool_use` blocks. A call is in the list once its block has finished streaming, so read the list when you
     * are done with the stream. A call that has started is not in it. It is empty without
     * `runToolsEagerly`.
     *
     * Held calls are listed whatever the reply's `stop_reason`, because `generateToolResponse()` runs them
     * whatever it is. After `max_tokens` the input of the last call can be cut off.
     *
     * @example
     * for await (const stream of runner) {
     *   stream.on('contentBlock', (block) => {
     *     if (block.type === 'tool_use' && block.name === 'delete_file') {
     *       runner.deferToolCall(block);
     *     }
     *   });
     *   await stream.finalMessage();
     *
     *   const held = runner.deferredToolCalls;
     *   if (held.length > 0 && !(await confirm(held))) break;
     * }
     */
    get deferredToolCalls() {
      const e = c(this, De, "f"), t = c(this, Ae, "f");
      return !(e instanceof gc) || !t ? [] : e.toolCalls.filter((r) => t.get(r.id)?.status === "held");
    }
    /**
     * Wait for the async iterator to complete. This works even if the async iterator hasn't yet started, and
     * will wait for an instance to start and go to completion.
     *
     * @returns A promise that resolves to the final BetaMessage when the iterator completes
     *
     * @example
     * // Start consuming the iterator
     * for await (const message of runner) {
     *   console.log('Message:', message.content);
     * }
     *
     * // Meanwhile, wait for completion from another part of the code
     * const finalMessage = await runner.done();
     * console.log('Final response:', finalMessage.content);
     */
    done() {
      return c(this, Ke, "f").promise;
    }
    /**
     * Returns a promise indicating that the stream is done. Unlike .done(), this will eagerly read the stream:
     * * If the iterator has not been consumed, consume the entire iterator and return the final message from the
     * assistant.
     * * If the iterator has been consumed, waits for it to complete and returns the final message.
     *
     * @returns A promise that resolves to the final BetaMessage from the conversation
     * @throws {AnthropicError} If no messages were processed during the conversation
     *
     * @example
     * const finalMessage = await runner.runUntilDone();
     * console.log('Final response:', finalMessage.content);
     */
    async runUntilDone() {
      if (!c(this, It, "f"))
        for await (const e of this)
          ;
      return this.done();
    }
    /**
     * Get the current parameters being used by the ToolRunner.
     *
     * @returns A readonly view of the current ToolRunnerParams
     *
     * @example
     * const currentParams = runner.params;
     * console.log('Current model:', currentParams.model);
     * console.log('Message count:', currentParams.messages.length);
     */
    get params() {
      return c(this, q, "f").params;
    }
    /**
     * Add one or more messages to the conversation history.
     *
     * @param messages - One or more BetaMessageParam objects to add to the conversation
     *
     * @example
     * runner.pushMessages(
     *   { role: 'user', content: 'Also, what about the weather in NYC?' }
     * );
     *
     * @example
     * // Adding multiple messages
     * runner.pushMessages(
     *   { role: 'user', content: 'What about NYC?' },
     *   { role: 'user', content: 'And Boston?' }
     * );
     */
    pushMessages(...e) {
      this.setMessagesParams((t) => ({
        ...t,
        messages: [...t.messages, ...e]
      }));
    }
    /**
     * Schedule a compaction of the conversation. Once the current turn has finished, including any tool
     * calls, the runner requests a summary and replaces the message history with the compaction response,
     * which is yielded like any other message. Requires the `compact-2026-09-04` beta.
     *
     * @param compaction - The config to send, as `messages.create()` takes it. Defaults to `{ type: 'summarize' }`
     *
     * @example
     * for await (const message of runner) {
     *   if (message.usage.input_tokens > 100_000) {
     *     runner.compactBeforeNextTurn();
     *   }
     * }
     */
    compactBeforeNextTurn(e) {
      c(this, ue, "f").status !== "in_flight" && (Dr(c(this, q, "f").params), w(this, ue, { status: "scheduled", config: e ?? { type: "summarize" } }));
    }
    /**
     * Give the model more tools without changing `params.tools`, which would miss the prompt cache.
     *
     * Each tool's whole definition is sent in a `tool_addition` block with the next request, and a
     * runnable tool replaces a runnable tool of the same name straight away, even for a call already in
     * the message being handled. A call that started while the reply streamed keeps the old one. A raw definition
     * is only sent: the runner never runs it, and stops running a tool of the same name. Passing a runnable toolset,
     * or a raw definition of a toolset the runner has, throws `ToolsetContractError` and adds nothing: a runner's
     * toolsets come only from `params.tools`. A tool named like one of its toolsets is left to the API, which rejects
     * it with the next request. Requires the `inline-tools-2026-09-15` beta, which the runner does not add for you.
     *
     * @param tools - Runnable tools (for example from `betaZodTool()`) or raw tool definitions
     *
     * @example
     * runner.addTools(queryDatabaseTool);
     */
    addTools(...e) {
      const t = c(this, L, "m", xs).call(this);
      for (const r of e) {
        if (Nn(r))
          throw new Bs(`addTools() can't add the '${Xe(Gt(r))}' toolset: ${kc}`);
        const i = Rg(r);
        if (t.has(i))
          throw new Bs(`addTools() can't replace the '${Xe(i)}' toolset: ${kc}`);
      }
      for (const r of e)
        "name" in r && c(this, Nt, "f").set(r.name, "run" in r ? r : null), c(this, ut, "f").push({ type: "addition", tool: r });
    }
    /**
     * Take tools away from the model without changing `params.tools`, which would miss the prompt cache.
     *
     * The tools stop being run straight away: a call to one of them, even one in the message being
     * handled, gets the same "not found" error result as a call to an unknown tool. A call that started while the
     * reply streamed finishes as usual. The model is told in a `tool_removal` block with the next request. Use
     * {@link addTools} to bring a tool back. Passing the name of one of the runner's toolsets throws
     * `ToolsetContractError` and removes nothing. Requires the `inline-tools-2026-09-15` beta, which the runner does
     * not add for you.
     *
     * @param tools - The tools to remove, or their names
     *
     * @example
     * runner.removeTools('query_database');
     */
    removeTools(...e) {
      const t = c(this, L, "m", xs).call(this);
      for (const r of e) {
        const i = typeof r == "string" ? r : r.name;
        if (t.has(i))
          throw new Bs(`removeTools() can't remove the '${Xe(i)}' toolset: ${Tg}`);
      }
      for (const r of e) {
        const i = typeof r == "string" ? r : r.name;
        c(this, Nt, "f").set(i, null), c(this, ut, "f").push({ type: "removal", name: i });
      }
    }
    /**
     * Makes the ToolRunner directly awaitable, equivalent to calling .runUntilDone()
     * This allows using `await runner` instead of `await runner.runUntilDone()`
     */
    then(e, t) {
      return this.runUntilDone().then(e, t);
    }
  }
  return Ur = /**
   * Sends one request and yields its message, or its stream when streaming. `#message` and `#stream` are set
   * before the yield, so they are there while the caller handles the item; the loop aborts the stream at the
   * end of the iteration.
   */
  async function* (e) {
    await c(this, L, "m", jr).call(this), w(this, Ae, void 0), e = c(this, L, "m", Tn).call(this, () => ({
      ...e,
      ...e.tools && { tools: e.tools.map(mi) },
      messages: xc(e.messages)
    })), e.stream ? (w(this, De, c(this, L, "m", Tn).call(this, () => c(this, q, "f").params.runToolsEagerly ? c(this, L, "m", yc).call(this, e) : this.client.beta.messages.stream({ ...e }, c(this, G, "f")))), w(this, ne, c(this, De, "f").finalMessage()), c(this, ne, "f").catch(() => {
    }), yield c(this, De, "f")) : (w(this, ne, c(this, L, "m", Tn).call(this, () => this.client.beta.messages.create({ ...e, stream: !1 }, c(this, G, "f")))), yield c(this, ne, "f"));
  }, yc = function(e) {
    const t = /* @__PURE__ */ new Map();
    w(this, Ae, t);
    const r = /* @__PURE__ */ new Map();
    return gc.start(this.client, e, c(this, G, "f"), (i) => {
      const a = t.has(i.id), o = !i.toolset_name && c(this, L, "m", xs).call(this).has(i.name), l = o ? i.name : i.toolset_name;
      if (l) {
        if (a || o || r.has(l)) {
          r.set(l, "waiting");
          return;
        }
        r.set(l, "running");
        const p = sd(c(this, q, "f").params, l, i, c(this, G, "f"), this.client, c(this, Pe, "f"));
        t.set(i.id, { status: "started", result: p }), p.then(({ is_error: h }) => {
          h || r.get(l) === "waiting" ? r.set(l, "waiting") : r.delete(l);
        }, () => r.set(l, "waiting"));
        return;
      }
      if (a)
        return;
      const d = rd(c(this, L, "m", An).call(this), c(this, L, "m", As).call(this), i, c(this, G, "f"), this.client, c(this, Pe, "f"));
      d.catch(() => {
      }), t.set(i.id, { status: "started", result: d });
    });
  }, jr = /** Waits for the calls of the last streamed reply that have started, whether or not their results were sent. */
  async function() {
    const e = [...c(this, Ae, "f")?.values() ?? []].filter((t) => t.status === "started");
    await Promise.allSettled(e.map((t) => t.result));
  }, Fr = async function* (e) {
    Dr(c(this, q, "f").params);
    const { max_iterations: t, runToolsEagerly: r, ...i } = c(this, q, "f").params, a = xg(i);
    w(this, ue, { status: "in_flight" }), w(this, Te, void 0);
    const o = c(this, ne, "f");
    try {
      yield* c(this, L, "m", Ur).call(this, { ...a, compaction: e });
      const l = await c(this, ne, "f");
      l.content.some((d) => d.type === "compaction" && d.content) ? (c(this, L, "m", bc).call(this), c(this, q, "f").params.messages = [{ role: l.role, content: l.content }]) : (M(this.client).warn("Compaction produced no summary; keeping the conversation as it is."), w(this, ne, o, "f"));
    } finally {
      w(this, ue, { status: "idle" });
    }
  }, An = function() {
    const e = /* @__PURE__ */ new Map();
    for (const t of c(this, q, "f").params.tools)
      "run" in t && "name" in t && e.set(t.name, t);
    for (const [t, r] of c(this, Nt, "f"))
      r ? e.set(t, r) : e.delete(t);
    return e;
  }, As = function() {
    const e = new Set(c(this, L, "m", An).call(this).keys());
    for (const t of [...c(this, q, "f").params.messages, c(this, L, "m", Hr).call(this)])
      if (typeof t.content != "string") {
        for (const r of t.content)
          if (t.role === "system")
            Ec(r, e);
          else if (t.role === "assistant" && r.type === "compaction")
            for (const i of r.tool_changes ?? [])
              Ec(i, e);
      }
    return e;
  }, bc = function() {
    const e = c(this, L, "m", As).call(this);
    for (const t of c(this, L, "m", An).call(this).keys())
      e.has(t) || c(this, Nt, "f").set(t, null);
  }, wc = async function* () {
    if (c(this, ue, "f").status !== "scheduled")
      return;
    const e = c(this, q, "f").params.messages.at(-1)?.content;
    if (Array.isArray(e) && e.some((t) => t.type === "tool_use")) {
      M(this.client).warn("The pending compaction was skipped because the last turn ended with tool calls that were not run. Call `compactBeforeNextTurn()` again if you continue the conversation."), w(this, ue, { status: "idle" });
      return;
    }
    yield* c(this, L, "m", Fr).call(this, c(this, ue, "f").config);
  }, Wr = async function(e, t, r) {
    return c(this, Te, "f") !== void 0 ? c(this, Te, "f") : (w(this, Te, Eg(c(this, q, "f").params, c(this, L, "m", An).call(this), c(this, L, "m", As).call(this), e, { ...c(this, G, "f"), signal: t }, c(this, Ae, "f"), this.client, r)), c(this, Te, "f"));
  }, xs = function() {
    return new Set(c(this, q, "f").params.tools.filter(Nn).map(Gt));
  }, vc = function() {
    c(this, $t, "f") === "pause_turn" || c(this, ut, "f").length === 0 || (c(this, q, "f").params.messages.push(c(this, L, "m", Hr).call(this)), w(this, ut, []));
  }, Hr = function() {
    const e = [];
    for (const t of c(this, ut, "f")) {
      if (t.type === "removal") {
        e.push({ type: "tool_removal", tool: { type: "tool_reference", name: t.name } });
        continue;
      }
      const r = mi(t.tool);
      e.push({ type: "tool_addition", tool: { type: "tool_definition", definition: r } });
    }
    return { role: "system", content: e };
  }, s;
})();
function Tc(s) {
  if ("compaction" in s && s.compaction != null)
    throw new R("`compaction` cannot be set on a tool runner: every request in the loop would compact again. Call `runner.compactBeforeNextTurn()` when the conversation should be compacted instead.");
}
function Ag(s) {
  if ("compactionControl" in s && s.compactionControl != null)
    throw new R("`compactionControl` has been removed from the tool runner. Use server-side compaction instead: call `runner.compactBeforeNextTurn()` when the conversation should be compacted.");
}
function Ac(s) {
  if (s.runToolsEagerly && !s.stream)
    throw new TypeError("`runToolsEagerly: true` needs `stream: true` in the tool runner's params, because a reply that isn't streamed arrives whole.");
}
function Dr(s) {
  if (s.context_management?.edits?.some((n) => n.type.startsWith("compact_")))
    throw new R("`compactBeforeNextTurn()` can't be used while `context_management` has a compaction edit, because the API doesn't accept a compaction block together with one. Remove the edit first.");
}
function xg(s) {
  const { context_management: n, stop_sequences: e, output_format: t, ...r } = s, i = ({ format: a, ...o }) => o;
  return (r.tool_choice?.type === "any" || r.tool_choice?.type === "tool") && delete r.tool_choice, r.output_config && (r.output_config = i(r.output_config)), Array.isArray(r.fallbacks) && (r.fallbacks = r.fallbacks.map((a) => a.output_config ? { ...a, output_config: i(a.output_config) } : a)), r;
}
function mi(s) {
  if (!("run" in s))
    return s;
  const n = $g, e = "toJSON" in s && typeof s.toJSON == "function" ? s.toJSON() : s;
  return {
    ...Object.fromEntries(Object.entries(e).filter(([t]) => n.includes(t))),
    ...pt(s) && { [$e]: s[$e] }
  };
}
function xc(s) {
  return s.map((n) => {
    if (n.role !== "system" || typeof n.content == "string")
      return n;
    const e = n.content.map((t) => t.type === "tool_addition" && t.tool.type === "tool_definition" ? { ...t, tool: { ...t.tool, definition: mi(t.tool.definition) } } : t);
    return { ...n, content: e };
  });
}
async function Eg(s, n, e, t, r, i, a, o) {
  if (!t || t.role !== "assistant" || !t.content || typeof t.content == "string")
    return null;
  const l = t.content.filter((h) => h.type === "tool_use");
  if (l.length === 0)
    return null;
  const d = /* @__PURE__ */ new Map();
  return {
    role: "user",
    content: await Promise.all(l.map(async (h) => {
      const m = i?.get(h.id), _ = m?.status === "started" ? m.result : void 0;
      if (h.toolset_name) {
        const k = h.toolset_name, E = d.get(k) ?? { tail: Promise.resolve(), failed: !1 };
        d.set(k, E);
        const A = s.tools.some((v) => Nn(v) && Gt(v) === k), T = _ ?? E.tail.then(() => E.failed ? Qs(h, wg(k), !0) : sd(s, k, h, r, a, o));
        return E.tail = T.then(({ is_error: v }) => {
          v && A && (E.failed = !0);
        }, () => {
          E.failed = !0;
        }), i?.set(h.id, { status: "started", result: T }), T;
      }
      if (_)
        return _;
      if (!(e.has(h.name) ? n.get(h.name) : void 0) && s.tools.some((k) => Nn(k) && Gt(k) === h.name)) {
        const k = d.get(h.name) ?? { tail: Promise.resolve(), failed: !1 };
        return d.set(h.name, k), k.tail = k.tail.then(() => {
          k.failed = !0;
        }), zg(h);
      }
      const y = rd(n, e, h, r, a, o);
      return i?.set(h.id, { status: "started", result: y }), y;
    }))
  };
}
async function sd(s, n, e, t, r, i) {
  const a = s.tools.find((d) => Nn(d) && Gt(d) === n);
  if (!a)
    return Qs(e, `Error: Toolset '${Xe(n)}' member '${Xe(e.name)}' not found`, !0);
  const o = {
    signal: t?.signal,
    conversationId: t?.openTelemetry?.conversationId,
    parentContext: i
  };
  return (await Bi(r, a, e, o, async () => {
    const d = await Sg(a, e, { signal: t?.signal });
    return { block: d, content: d.content ?? [], isError: d.is_error === !0 };
  })).block;
}
async function rd(s, n, e, t, r, i) {
  const a = n.has(e.name) ? s.get(e.name) : void 0;
  if (!a)
    return Pg(e);
  const o = {
    signal: t?.signal,
    conversationId: t?.openTelemetry?.conversationId,
    parentContext: i
  }, l = await Bi(r, a, e, o, () => Vu(a, e.input, {
    toolUse: e,
    toolUseBlock: e,
    signal: t?.signal
  }));
  return {
    type: "tool_result",
    tool_use_id: e.id,
    content: l.content,
    ...l.isError ? { is_error: !0 } : void 0
  };
}
function Rg(s) {
  return (s.type ?? "custom").replace(/_\d{8}$/, "").replace(/_toolset$/, "");
}
function Pg(s) {
  return {
    type: "tool_result",
    tool_use_id: s.id,
    content: `Error: Tool '${s.name}' not found`,
    is_error: !0
  };
}
function zg(s) {
  return {
    type: "tool_result",
    tool_use_id: s.id,
    content: `Error: the '${Xe(s.name)}' toolset could not run this call${Mg(s.input)}; nothing in the batch was executed`,
    is_error: !0
  };
}
function Mg(s) {
  const n = typeof s == "object" && s !== null ? s : {};
  if (!("actions" in n)) {
    const i = "action" in n ? n.action : void 0;
    return typeof i == "string" ? `: the call has no 'actions' list (action: '${Xe(i)}')` : ": the call has no 'actions' list";
  }
  const { actions: e } = n;
  if (typeof e == "string")
    return ": 'actions' is text, not a list of actions";
  if (!Array.isArray(e))
    return ": 'actions' is not a list of actions";
  if (e.length === 0)
    return ": the 'actions' list is empty";
  const t = [];
  for (const [i, a] of e.entries()) {
    const o = typeof a == "object" && a !== null && "action" in a ? a.action : void 0;
    if (typeof o != "string")
      return `: action ${i} must be an object with a string 'action' field`;
    t.push(`'${Xe(o)}'`);
  }
  const r = t.length > 10 ? `, and ${t.length - 10} more` : "";
  return `: its actions could not be run as sent (actions: ${t.slice(0, 10).join(", ")}${r})`;
}
function Ec(s, n) {
  switch (s.type) {
    case "tool_removal":
    case "tool_addition":
      Og(s, n);
      break;
  }
}
function Og(s, n) {
  const e = Cg(s.tool);
  e !== void 0 && (s.type === "tool_removal" ? n.delete(e) : n.add(e));
}
function Cg(s) {
  switch (s.type) {
    case "tool_reference":
      return s.name;
    case "tool_definition":
      return "name" in s.definition ? s.definition.name : void 0;
    default:
      return;
  }
}
function Rc(s) {
  if (s === null)
    return "stop";
  switch (s) {
    case "tool_use":
      return "run_tools";
    case "pause_turn":
    // pause_after_compaction hands the turn back before the model answers; sending it back
    // unchanged continues it.
    case "compaction":
      return "resume";
    case "end_turn":
    case "stop_sequence":
    case "max_tokens":
    case "model_context_window_exceeded":
    case "refusal":
      return "stop";
    default:
      return "stop";
  }
}
const Pc = {
  "claude-sonnet-4-5": "November 30th, 2026",
  "claude-sonnet-4-5-20250929": "November 30th, 2026"
}, Ig = ["claude-mythos-preview", "claude-opus-4-6"];
var zc = /* @__PURE__ */ (() => {
  class s extends x {
    constructor() {
      super(...arguments), this.batches = new ro(this._client);
    }
    create(e, t) {
      const r = gi(e), { betas: i, user_profile_id: a, workspace_id: o, ...l } = r;
      l.model in Pc && console.warn(`The model '${l.model}' is deprecated and will reach end-of-life on ${Pc[l.model]}
Please migrate to a newer model. Visit https://docs.anthropic.com/en/docs/resources/model-deprecations for more information.`), Ig.includes(l.model) && l.thinking && l.thinking.type === "enabled" && console.warn(`Using Claude with ${l.model} and 'thinking.type=enabled' is deprecated. Use 'thinking.type=adaptive' instead which results in better model performance in our testing: https://platform.claude.com/docs/en/build-with-claude/adaptive-thinking`);
      let d = t?.timeout ?? this._client._options.timeout;
      if (!l.stream && d == null) {
        const _ = ju[l.model] ?? void 0;
        d = this._client.calculateNonstreamingTimeout(l.max_tokens, _);
      }
      const p = Qu(r, t), h = this._client._tracer && u(this._client, "anthropic.messages.create", t, or(this._client, l, p));
      gu(this._client, h, l);
      const m = this._client.post("/v1/messages?beta=true", {
        body: l,
        timeout: d ?? 6e5,
        ...t,
        __span: h,
        headers: p,
        stream: r.stream ?? !1
      });
      return h ? m._thenUnwrap((_) => (mu(this._client, h, l, _), _)) : m;
    }
    /**
     * Send a structured list of input messages with text and/or image content, along with an expected `output_format` and
     * the response will be automatically parsed and available in the `parsed_output` property of the message.
     *
     * @example
     * ```ts
     * const message = await client.beta.messages.parse({
     *   model: 'claude-3-5-sonnet-20241022',
     *   max_tokens: 1024,
     *   messages: [{ role: 'user', content: 'What is 2+2?' }],
     *   output_format: zodOutputFormat(z.object({ answer: z.number() }), 'math'),
     * });
     *
     * console.log(message.parsed_output?.answer); // 4
     * ```
     */
    parse(e, t) {
      return t = {
        ...t,
        headers: f([
          { "anthropic-beta": [...e.betas ?? [], "structured-outputs-2025-12-15"].toString() },
          t?.headers
        ])
      }, this.create(e, t).then((r) => Xu(r, e, { logger: this._client.logger ?? console }));
    }
    /**
     * Create a Message stream
     */
    stream(e, t) {
      return Zu.createMessage(this, e, t, { client: this._client });
    }
    /**
     * Count the number of tokens in a Message.
     *
     * The Token Count API can be used to count the number of tokens in a Message,
     * including tools, images, and documents, without creating it.
     *
     * Learn more about token counting in our
     * [user guide](https://platform.claude.com/docs/en/build-with-claude/token-counting)
     *
     * @example
     * ```ts
     * const betaMessageTokensCount =
     *   await client.beta.messages.countTokens({
     *     messages: [{ content: 'Hello, world', role: 'user' }],
     *     model: 'claude-opus-5-5',
     *   });
     * ```
     */
    countTokens(e, t) {
      const r = gi(e), { betas: i, user_profile_id: a, workspace_id: o, ...l } = r, d = f([
        {
          "anthropic-beta": [...i ?? [], "token-counting-2024-11-01"].toString(),
          ...a != null ? { "anthropic-user-profile-id": a } : void 0,
          ...o != null ? { "anthropic-workspace-id": o } : void 0
        },
        t?.headers
      ]), p = u(this._client, "anthropic.messages.count_tokens", t, {
        route: "/v1/messages/count_tokens",
        attributes: { [Ln]: l.model }
      }), h = this._client.post("/v1/messages/count_tokens?beta=true", {
        body: l,
        ...t,
        __span: p,
        headers: d
      });
      return p ? h._thenUnwrap((m) => (yu(this._client, p, m), m)) : h;
    }
    toolRunner(e, t) {
      return new Sc(this._client, e, t);
    }
  }
  return s.Batches = ro, s.BetaToolRunner = Sc, s.ToolError = Wi, s;
})();
const $g = [
  "input_schema",
  "name",
  "allowed_callers",
  "cache_control",
  "defer_loading",
  "description",
  "eager_input_streaming",
  "input_examples",
  "strict",
  "type",
  "configs",
  "display_height_px",
  "display_width_px",
  "display_number",
  "enable_zoom",
  "max_characters"
];
var Mc = /* @__PURE__ */ (() => {
  class s extends x {
    constructor() {
      super(...arguments), this.models = new Ca(this._client), this.messages = new zc(this._client), this.agents = new Ua(this._client), this.environments = new eo(this._client), this.sessions = new ac(this._client), this.deployments = new za(this._client), this.deploymentRuns = new Pa(this._client), this.vaults = new _c(this._client), this.memoryStores = new so(this._client), this.files = new Oa(this._client), this.skills = new cc(this._client), this.webhooks = new qa(this._client), this.userProfiles = new hc(this._client), this.dreams = new Ma(this._client), this.tunnels = new uc(this._client), this.organization = new tc(this._client);
    }
  }
  return s.Models = Ca, s.Messages = zc, s.Agents = Ua, s.Environments = eo, s.Sessions = ac, s.Deployments = za, s.DeploymentRuns = Pa, s.Vaults = _c, s.MemoryStores = so, s.Files = Oa, s.Skills = cc, s.Webhooks = qa, s.UserProfiles = hc, s.Dreams = Ma, s.Tunnels = uc, s.Organization = tc, s;
})();
class Oc extends x {
  create(n, e) {
    const { betas: t, workspace_id: r, ...i } = n;
    return this._client.post("/v1/complete", {
      body: i,
      timeout: this._client._options.timeout ?? 6e5,
      ...e,
      headers: f([
        {
          ...t?.toString() != null ? { "anthropic-beta": t?.toString() } : void 0,
          ...r != null ? { "anthropic-workspace-id": r } : void 0
        },
        e?.headers
      ]),
      stream: n.stream ?? !1,
      __span: u(this._client, "anthropic.completions.create", e, {
        route: "/v1/complete"
      })
    });
  }
}
class Cc extends x {
  /**
   * List Files
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const fileMetadata of client.files.list()) {
   *   // ...
   * }
   * ```
   */
  list(n = {}, e) {
    const { workspace_id: t, ...r } = n ?? {};
    return this._client.getAPIList("/v1/files", z, {
      query: r,
      ...e,
      headers: f([
        { ...t != null ? { "anthropic-workspace-id": t } : void 0 },
        e?.headers
      ]),
      __span: u(this._client, "anthropic.files.list", e, {
        route: "/v1/files",
        queryParams: ["ids", "limit", "page"]
      })
    });
  }
  /**
   * Delete File
   *
   * @example
   * ```ts
   * const deletedFile = await client.files.delete('file_id');
   * ```
   */
  delete(n, e = {}, t) {
    const { workspace_id: r } = e ?? {};
    return this._client.delete(g`/v1/files/${n}`, {
      ...t,
      headers: f([
        { ...r != null ? { "anthropic-workspace-id": r } : void 0 },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.files.delete", t, {
        route: "/v1/files/{file_id}",
        attributes: { "anthropic.file.id": n }
      })
    });
  }
  /**
   * Download File
   *
   * @example
   * ```ts
   * const response = await client.files.download('file_id');
   *
   * const content = await response.blob();
   * console.log(content);
   * ```
   */
  download(n, e = {}, t) {
    const { workspace_id: r } = e ?? {};
    return this._client.get(g`/v1/files/${n}/content`, {
      ...t,
      headers: f([
        {
          Accept: "application/binary",
          ...r != null ? { "anthropic-workspace-id": r } : void 0
        },
        t?.headers
      ]),
      __binaryResponse: !0,
      __span: u(this._client, "anthropic.files.download", t, {
        route: "/v1/files/{file_id}/content",
        attributes: { "anthropic.file.id": n }
      })
    });
  }
  /**
   * Get File Metadata
   *
   * @example
   * ```ts
   * const fileMetadata = await client.files.retrieveMetadata(
   *   'file_id',
   * );
   * ```
   */
  retrieveMetadata(n, e = {}, t) {
    const { workspace_id: r } = e ?? {};
    return this._client.get(g`/v1/files/${n}`, {
      ...t,
      headers: f([
        { ...r != null ? { "anthropic-workspace-id": r } : void 0 },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.files.retrieve_metadata", t, {
        route: "/v1/files/{file_id}",
        attributes: { "anthropic.file.id": n }
      })
    });
  }
  /**
   * Upload File
   *
   * @example
   * ```ts
   * const fileMetadata = await client.files.upload({
   *   file: fs.createReadStream('path/to/file'),
   * });
   * ```
   */
  upload(n, e) {
    const { workspace_id: t, ...r } = n;
    return this._client.post("/v1/files", Le({
      body: r,
      ...e,
      headers: f([
        { ...t != null ? { "anthropic-workspace-id": t } : void 0 },
        Au(r.file),
        e?.headers
      ]),
      __span: u(this._client, "anthropic.files.upload", e, {
        route: "/v1/files",
        createdIDAttribute: "anthropic.file.id"
      })
    }, this._client));
  }
}
class Ic extends x {
  /**
   * Get a specific model.
   *
   * The Models API response can be used to determine information about a specific
   * model or resolve a model alias to a model ID.
   *
   * @example
   * ```ts
   * const modelInfo = await client.models.retrieve('model_id');
   * ```
   */
  retrieve(n, e = {}, t) {
    const { betas: r, workspace_id: i } = e ?? {};
    return this._client.get(g`/v1/models/${n}`, {
      ...t,
      headers: f([
        {
          ...r?.toString() != null ? { "anthropic-beta": r?.toString() } : void 0,
          ...i != null ? { "anthropic-workspace-id": i } : void 0
        },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.models.retrieve", t, {
        route: "/v1/models/{model_id}",
        attributes: { "anthropic.model.id": n }
      })
    });
  }
  /**
   * List available models.
   *
   * The Models API response can be used to determine which models are available for
   * use in the API. More recently released models are listed first.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const modelInfo of client.models.list()) {
   *   // ...
   * }
   * ```
   */
  list(n = {}, e) {
    const { betas: t, workspace_id: r, ...i } = n ?? {};
    return this._client.getAPIList("/v1/models", Y, {
      query: i,
      ...e,
      headers: f([
        {
          ...t?.toString() != null ? { "anthropic-beta": t?.toString() } : void 0,
          ...r != null ? { "anthropic-workspace-id": r } : void 0
        },
        e?.headers
      ]),
      __span: u(this._client, "anthropic.models.list", e, {
        route: "/v1/models",
        queryParams: ["after_id", "before_id", "lifecycle", "limit"]
      })
    });
  }
}
class $c extends x {
  /**
   * Get API Key
   *
   * @example
   * ```ts
   * const apiKey = await client.organization.apiKeys.retrieve(
   *   'api_key_id',
   * );
   * ```
   */
  retrieve(n, e) {
    return this._client.get(g`/v1/organizations/api_keys/${n}`, {
      ...e,
      __span: u(this._client, "anthropic.organization.api_keys.retrieve", e, {
        route: "/v1/organizations/api_keys/{api_key_id}",
        attributes: { "anthropic.organization.api_key.id": n }
      })
    });
  }
  /**
   * Update API Key
   *
   * @example
   * ```ts
   * const apiKey = await client.organization.apiKeys.update(
   *   'api_key_id',
   * );
   * ```
   */
  update(n, e, t) {
    return this._client.post(g`/v1/organizations/api_keys/${n}`, {
      body: e,
      ...t,
      __span: u(this._client, "anthropic.organization.api_keys.update", t, {
        route: "/v1/organizations/api_keys/{api_key_id}",
        attributes: { "anthropic.organization.api_key.id": n }
      })
    });
  }
  /**
   * List API Keys
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const apiKey of client.organization.apiKeys.list()) {
   *   // ...
   * }
   * ```
   */
  list(n = {}, e) {
    return this._client.getAPIList("/v1/organizations/api_keys", Y, {
      query: n,
      ...e,
      __span: u(this._client, "anthropic.organization.api_keys.list", e, {
        route: "/v1/organizations/api_keys",
        queryParams: ["after_id", "before_id", "created_by_user_id", "limit", "status", "workspace_id"]
      })
    });
  }
}
class Nc extends x {
  /**
   * Retrieve your organization's Compliance Settings.
   *
   * Compliance Settings is a singleton resource: there is exactly one per
   * organization, addressed without an identifier. The `state` field reflects
   * whether the Compliance API is enabled. An organization with a parent
   * organization reads the state inherited from the parent's configuration.
   *
   * @example
   * ```ts
   * const organizationComplianceSettings =
   *   await client.organization.complianceSettings.retrieve();
   * ```
   */
  retrieve(n) {
    return this._client.get("/v1/organizations/compliance_settings", {
      ...n,
      __span: u(this._client, "anthropic.organization.compliance_settings.retrieve", n, {
        route: "/v1/organizations/compliance_settings"
      })
    });
  }
  /**
   * Update your organization's Compliance Settings.
   *
   * Setting `state` to `enabled` turns on the Compliance API and begins capturing
   * organization activity events. Setting it to `disabled` turns both off. `state`
   * reflects whether the Compliance API is enabled.
   *
   * A request that sets `state` to its current value succeeds and leaves the
   * resource unchanged. A `disabled` request stays in effect until a later `enabled`
   * request or the organization's next provisioning action that enables Access
   * Transparency: enabling Access Transparency also enables the Compliance API,
   * which serves its activity events, so such provisioning (including re-runs)
   * re-enables the Compliance API even after a `disabled` request. Automated
   * provisioning never disables compliance settings.
   *
   * @example
   * ```ts
   * const organizationComplianceSettings =
   *   await client.organization.complianceSettings.update({
   *     state: { type: 'enabled' },
   *   });
   * ```
   */
  update(n, e) {
    return this._client.post("/v1/organizations/compliance_settings", {
      body: n,
      ...e,
      __span: u(this._client, "anthropic.organization.compliance_settings.update", e, {
        route: "/v1/organizations/compliance_settings"
      })
    });
  }
}
class Lc extends x {
  /**
   * Create an external key config owned by the caller's organization.
   *
   * @example
   * ```ts
   * const externalKey =
   *   await client.organization.externalKeys.create({
   *     provider_config: {
   *       kms_arn:
   *         'arn:aws:kms:us-east-1:111122223333:key/abcd1234-5678-90ab-cdef-000011112222',
   *       type: 'aws',
   *     },
   *   });
   * ```
   */
  create(n, e) {
    return this._client.post("/v1/organizations/external_keys", {
      body: n,
      ...e,
      __span: u(this._client, "anthropic.organization.external_keys.create", e, {
        route: "/v1/organizations/external_keys",
        createdIDAttribute: "anthropic.organization.external_key.id"
      })
    });
  }
  /**
   * Retrieve a single external key config in the caller's organization by ID.
   *
   * @example
   * ```ts
   * const externalKey =
   *   await client.organization.externalKeys.retrieve(
   *     'external_key_id',
   *   );
   * ```
   */
  retrieve(n, e) {
    return this._client.get(g`/v1/organizations/external_keys/${n}`, {
      ...e,
      __span: u(this._client, "anthropic.organization.external_keys.retrieve", e, {
        route: "/v1/organizations/external_keys/{external_key_id}",
        attributes: { "anthropic.organization.external_key.id": n }
      })
    });
  }
  /**
   * Partially update an external key config. Omitted fields are left unchanged.
   *
   * `display_name` is always editable. `geo` and `provider_config` cannot be changed
   * once any workspace references this config, because previously encrypted data
   * requires the original key identity to decrypt.
   *
   * @example
   * ```ts
   * const externalKey =
   *   await client.organization.externalKeys.update(
   *     'external_key_id',
   *   );
   * ```
   */
  update(n, e, t) {
    return this._client.post(g`/v1/organizations/external_keys/${n}`, {
      body: e,
      ...t,
      __span: u(this._client, "anthropic.organization.external_keys.update", t, {
        route: "/v1/organizations/external_keys/{external_key_id}",
        attributes: { "anthropic.organization.external_key.id": n }
      })
    });
  }
  /**
   * List external key configs in the caller's organization.
   *
   * Results are ordered by creation time (newest first). Use the `next_page` cursor
   * from the response to fetch subsequent pages.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const externalKey of client.organization.externalKeys.list()) {
   *   // ...
   * }
   * ```
   */
  list(n = {}, e) {
    return this._client.getAPIList("/v1/organizations/external_keys", z, {
      query: n,
      ...e,
      __span: u(this._client, "anthropic.organization.external_keys.list", e, {
        route: "/v1/organizations/external_keys",
        queryParams: ["limit", "page"]
      })
    });
  }
  /**
   * Delete an external key config.
   *
   * The request is rejected if any workspace still references this config.
   *
   * @example
   * ```ts
   * const externalKey =
   *   await client.organization.externalKeys.delete(
   *     'external_key_id',
   *   );
   * ```
   */
  delete(n, e) {
    return this._client.delete(g`/v1/organizations/external_keys/${n}`, {
      ...e,
      __span: u(this._client, "anthropic.organization.external_keys.delete", e, {
        route: "/v1/organizations/external_keys/{external_key_id}",
        attributes: { "anthropic.organization.external_key.id": n }
      })
    });
  }
  /**
   * Validate an external key config against the customer's KMS.
   *
   * Anthropic performs an encrypt/decrypt roundtrip against the configured KMS key
   * and waits up to 30 seconds for the result. The response status is `success` if
   * the roundtrip succeeded, or `failure` with an error message if it failed or
   * timed out.
   *
   * @example
   * ```ts
   * const response =
   *   await client.organization.externalKeys.validate(
   *     'external_key_id',
   *   );
   * ```
   */
  validate(n, e) {
    return this._client.post(g`/v1/organizations/external_keys/${n}/validate`, {
      ...e,
      __span: u(this._client, "anthropic.organization.external_keys.validate", e, {
        route: "/v1/organizations/external_keys/{external_key_id}/validate",
        attributes: { "anthropic.organization.external_key.id": n }
      })
    });
  }
}
class qc extends x {
  /**
   * Invite a user to join the organization by email.
   *
   * On plans that draw members from a finite pool of purchased seats, the invite
   * automatically consumes a seat from the lowest tier with availability; there is
   * no seat-tier parameter. When no seat is free the request fails with a 400 error
   * rather than purchasing a seat.
   *
   * @example
   * ```ts
   * const organizationInvite =
   *   await client.organization.invites.create({
   *     email: 'user@emaildomain.com',
   *     role: 'user',
   *   });
   * ```
   */
  create(n, e) {
    return this._client.post("/v1/organizations/invites", {
      body: n,
      ...e,
      __span: u(this._client, "anthropic.organization.invites.create", e, {
        route: "/v1/organizations/invites",
        createdIDAttribute: "anthropic.organization.invite.id"
      })
    });
  }
  /**
   * Retrieve an invite by ID.
   *
   * @example
   * ```ts
   * const organizationInvite =
   *   await client.organization.invites.retrieve('invite_id');
   * ```
   */
  retrieve(n, e) {
    return this._client.get(g`/v1/organizations/invites/${n}`, {
      ...e,
      __span: u(this._client, "anthropic.organization.invites.retrieve", e, {
        route: "/v1/organizations/invites/{invite_id}",
        attributes: { "anthropic.organization.invite.id": n }
      })
    });
  }
  /**
   * List the organization's invites.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const organizationInvite of client.organization.invites.list()) {
   *   // ...
   * }
   * ```
   */
  list(n = {}, e) {
    return this._client.getAPIList("/v1/organizations/invites", Y, {
      query: n,
      ...e,
      __span: u(this._client, "anthropic.organization.invites.list", e, {
        route: "/v1/organizations/invites",
        queryParams: ["after_id", "before_id", "email", "limit", "roles", "statuses"]
      })
    });
  }
  /**
   * Delete a pending invite.
   *
   * @example
   * ```ts
   * const invite = await client.organization.invites.delete(
   *   'invite_id',
   * );
   * ```
   */
  delete(n, e) {
    return this._client.delete(g`/v1/organizations/invites/${n}`, {
      ...e,
      __span: u(this._client, "anthropic.organization.invites.delete", e, {
        route: "/v1/organizations/invites/{invite_id}",
        attributes: { "anthropic.organization.invite.id": n }
      })
    });
  }
}
let Bc = class extends x {
  /**
   * List Messages API rate limits for your organization.
   *
   * Each entry corresponds to one rate-limit group (either a model family or an
   * API-surface category such as the Message Batches API or the web search tool) and
   * contains the set of limiter values that apply to it.
   *
   * When `limit` is omitted, every matching entry is returned in a single page; when
   * `limit` truncates the result, follow `next_page` to fetch the remaining entries.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const organizationRateLimit of client.organization.rateLimits.list()) {
   *   // ...
   * }
   * ```
   */
  list(n = {}, e) {
    return this._client.getAPIList("/v1/organizations/rate_limits", z, {
      query: n,
      ...e,
      __span: u(this._client, "anthropic.organization.rate_limits.list", e, {
        route: "/v1/organizations/rate_limits",
        queryParams: ["group_type", "limit", "model", "page"]
      })
    });
  }
};
class Uc extends x {
  /**
   * Retrieve a member of the organization by user ID.
   *
   * @example
   * ```ts
   * const organizationUser =
   *   await client.organization.users.retrieve('user_id');
   * ```
   */
  retrieve(n, e) {
    return this._client.get(g`/v1/organizations/users/${n}`, {
      ...e,
      __span: u(this._client, "anthropic.organization.users.retrieve", e, {
        route: "/v1/organizations/users/{user_id}",
        attributes: { "anthropic.organization.user.id": n }
      })
    });
  }
  /**
   * Update a member's organization role.
   *
   * @example
   * ```ts
   * const organizationUser =
   *   await client.organization.users.update('user_id', {
   *     role: 'user',
   *   });
   * ```
   */
  update(n, e, t) {
    return this._client.post(g`/v1/organizations/users/${n}`, {
      body: e,
      ...t,
      __span: u(this._client, "anthropic.organization.users.update", t, {
        route: "/v1/organizations/users/{user_id}",
        attributes: { "anthropic.organization.user.id": n }
      })
    });
  }
  /**
   * List the organization's members.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const organizationUser of client.organization.users.list()) {
   *   // ...
   * }
   * ```
   */
  list(n = {}, e) {
    return this._client.getAPIList("/v1/organizations/users", Y, {
      query: n,
      ...e,
      __span: u(this._client, "anthropic.organization.users.list", e, {
        route: "/v1/organizations/users",
        queryParams: ["after_id", "before_id", "email", "limit", "roles"]
      })
    });
  }
  /**
   * Remove a member from the organization.
   *
   * @example
   * ```ts
   * const user = await client.organization.users.remove(
   *   'user_id',
   * );
   * ```
   */
  remove(n, e) {
    return this._client.delete(g`/v1/organizations/users/${n}`, {
      ...e,
      __span: u(this._client, "anthropic.organization.users.remove", e, {
        route: "/v1/organizations/users/{user_id}",
        attributes: { "anthropic.organization.user.id": n }
      })
    });
  }
}
class jc extends x {
  /**
   * **Requires an OAuth access token with the `org:admin` scope**, from
   * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
   * API keys are not accepted. See
   * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
   *
   * Register an OIDC issuer that Anthropic will trust for workload identity
   * federation in your organization.
   *
   * The `jwks` field controls how the issuer's signing keys are obtained and takes
   * one of three shapes selected by `type`: `discovery` (resolve keys through OIDC
   * discovery), `explicit_url` (fetch keys from a fixed JWKS URL), or `inline`
   * (provide a static key set). When `jwks.type` is `discovery` and no
   * `discovery_base` is set, the issuer URL must be publicly reachable over HTTPS so
   * Anthropic can fetch the discovery document; for `explicit_url` and `inline`
   * modes the issuer URL is only matched as the JWT's `iss` claim and is not
   * fetched.
   *
   * @example
   * ```ts
   * const federationIssuer =
   *   await client.organization.federation.issuers.create({
   *     issuer_url: 'x',
   *     name: 'x',
   *   });
   * ```
   */
  create(n, e) {
    return this._client.post("/v1/organizations/federation_issuers", {
      body: n,
      ...e,
      __span: u(this._client, "anthropic.organization.federation.issuers.create", e, {
        route: "/v1/organizations/federation_issuers",
        createdIDAttribute: "anthropic.organization.federation_issuer.id"
      })
    });
  }
  /**
   * **Requires an OAuth access token with the `org:admin` scope**, from
   * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
   * API keys are not accepted. See
   * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
   *
   * Retrieve a federation issuer by its ID (`fdis_...`).
   *
   * @example
   * ```ts
   * const federationIssuer =
   *   await client.organization.federation.issuers.retrieve(
   *     'federation_issuer_id',
   *   );
   * ```
   */
  retrieve(n, e) {
    return this._client.get(g`/v1/organizations/federation_issuers/${n}`, {
      ...e,
      __span: u(this._client, "anthropic.organization.federation.issuers.retrieve", e, {
        route: "/v1/organizations/federation_issuers/{federation_issuer_id}",
        attributes: { "anthropic.organization.federation_issuer.id": n }
      })
    });
  }
  /**
   * **Requires an OAuth access token with the `org:admin` scope**, from
   * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
   * API keys are not accepted. See
   * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
   *
   * Partially update a federation issuer.
   *
   * Setting `jwks` replaces the full JWKS shape at once. Archived issuers cannot be
   * updated; this returns 400. Create a new issuer instead.
   *
   * Updating an issuer that backs a rule with a scope outside `workspace:developer`
   * or `workspace:inference` requires a Console session.
   *
   * @example
   * ```ts
   * const federationIssuer =
   *   await client.organization.federation.issuers.update(
   *     'federation_issuer_id',
   *   );
   * ```
   */
  update(n, e, t) {
    return this._client.post(g`/v1/organizations/federation_issuers/${n}`, {
      body: e,
      ...t,
      __span: u(this._client, "anthropic.organization.federation.issuers.update", t, {
        route: "/v1/organizations/federation_issuers/{federation_issuer_id}",
        attributes: { "anthropic.organization.federation_issuer.id": n }
      })
    });
  }
  /**
   * **Requires an OAuth access token with the `org:admin` scope**, from
   * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
   * API keys are not accepted. See
   * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
   *
   * List federation issuers in your organization.
   *
   * Archived issuers are excluded unless `include_archived=true`.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const federationIssuer of client.organization.federation.issuers.list()) {
   *   // ...
   * }
   * ```
   */
  list(n = {}, e) {
    return this._client.getAPIList("/v1/organizations/federation_issuers", z, {
      query: n,
      ...e,
      __span: u(this._client, "anthropic.organization.federation.issuers.list", e, {
        route: "/v1/organizations/federation_issuers",
        queryParams: ["include_archived", "limit", "page"]
      })
    });
  }
  /**
   * **Requires an OAuth access token with the `org:admin` scope**, from
   * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
   * API keys are not accepted. See
   * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
   *
   * Archive a federation issuer.
   *
   * Idempotent; re-archiving returns the issuer with its original `archived_at`.
   * Rejected with 400 if any live (non-archived) federation rule still references
   * the issuer; archive those rules first (a rule's issuer cannot be changed), or
   * recreate them against another issuer.
   *
   * @example
   * ```ts
   * const federationIssuer =
   *   await client.organization.federation.issuers.archive(
   *     'federation_issuer_id',
   *   );
   * ```
   */
  archive(n, e) {
    return this._client.post(g`/v1/organizations/federation_issuers/${n}/archive`, {
      ...e,
      __span: u(this._client, "anthropic.organization.federation.issuers.archive", e, {
        route: "/v1/organizations/federation_issuers/{federation_issuer_id}/archive",
        attributes: { "anthropic.organization.federation_issuer.id": n }
      })
    });
  }
}
let Fc = class extends x {
  /**
   * **Requires an OAuth access token with the `org:admin` scope**, from
   * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
   * API keys are not accepted. See
   * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
   *
   * List workspaces where this federation rule is enabled.
   *
   * Returns all workspace enablements in a single response; the `limit` and `page`
   * parameters are accepted but have no effect, and `next_page` is always `null`.
   * Returns explicit per-workspace enablements only; for rules with
   * `applies_to_all_workspaces` or a legacy single `workspace_id`, check those
   * fields on the rule itself.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const federationRuleWorkspace of client.organization.federation.rules.workspaces.list(
   *   'federation_rule_id',
   * )) {
   *   // ...
   * }
   * ```
   */
  list(n, e = {}, t) {
    return this._client.getAPIList(g`/v1/organizations/federation_rules/${n}/workspaces`, z, {
      query: e,
      ...t,
      __span: u(this._client, "anthropic.organization.federation.rules.workspaces.list", t, {
        route: "/v1/organizations/federation_rules/{federation_rule_id}/workspaces",
        queryParams: ["limit", "page"],
        attributes: { "anthropic.organization.federation_rule.id": n }
      })
    });
  }
  /**
   * **Requires an OAuth access token with the `org:admin` scope**, from
   * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
   * API keys are not accepted. See
   * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
   *
   * Enable a federation rule for a workspace.
   *
   * Idempotent; re-enabling returns the existing enablement. The rule and workspace
   * must both belong to your organization. Membership of the rule's target service
   * account in this workspace is not checked at enablement: token exchange into this
   * workspace is rejected unless the target is a member (it is implicitly a member
   * of the default workspace). Archived rules are rejected with 400. OAuth callers
   * may only manage rules whose `oauth_scope` is `workspace:developer` or
   * `workspace:inference`; other scopes require a Console session.
   *
   * @example
   * ```ts
   * const federationRuleWorkspace =
   *   await client.organization.federation.rules.workspaces.add(
   *     'federation_rule_id',
   *     { workspace_id: 'workspace_id' },
   *   );
   * ```
   */
  add(n, e, t) {
    return this._client.post(g`/v1/organizations/federation_rules/${n}/workspaces`, {
      body: e,
      ...t,
      __span: u(this._client, "anthropic.organization.federation.rules.workspaces.add", t, {
        route: "/v1/organizations/federation_rules/{federation_rule_id}/workspaces",
        attributes: { "anthropic.organization.federation_rule.id": n },
        createdIDAttribute: "anthropic.organization.federation_rule.workspace.id",
        createdIDField: "workspace_id"
      })
    });
  }
  /**
   * **Requires an OAuth access token with the `org:admin` scope**, from
   * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
   * API keys are not accepted. See
   * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
   *
   * Disable a federation rule for a workspace.
   *
   * Idempotent; succeeds even if the enablement was already removed. OAuth callers
   * may only manage rules whose `oauth_scope` is `workspace:developer` or
   * `workspace:inference`; other scopes require a Console session.
   *
   * @example
   * ```ts
   * const workspace =
   *   await client.organization.federation.rules.workspaces.remove(
   *     'workspace_id',
   *     { federation_rule_id: 'federation_rule_id' },
   *   );
   * ```
   */
  remove(n, e, t) {
    const { federation_rule_id: r } = e;
    return this._client.delete(g`/v1/organizations/federation_rules/${r}/workspaces/${n}`, {
      ...t,
      __span: u(this._client, "anthropic.organization.federation.rules.workspaces.remove", t, {
        route: "/v1/organizations/federation_rules/{federation_rule_id}/workspaces/{workspace_id}",
        attributes: {
          "anthropic.organization.federation_rule.id": r,
          "anthropic.organization.federation_rule.workspace.id": n
        }
      })
    });
  }
};
var Wc = /* @__PURE__ */ (() => {
  class s extends x {
    constructor() {
      super(...arguments), this.workspaces = new Fc(this._client);
    }
    /**
     * **Requires an OAuth access token with the `org:admin` scope**, from
     * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
     * API keys are not accepted. See
     * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
     *
     * Create a federation rule owned by your organization.
     *
     * The referenced issuer and the target service account must already exist in the
     * same organization; invalid references are rejected with a 400 error. The
     * workspace reference is validated. Membership is not checked at rule creation:
     * token exchange resolves a single enabled workspace per call and is rejected
     * unless the target service account is a member of that workspace (it is
     * implicitly a member of the default workspace). Rules on well-known shared
     * issuers (GitHub Actions, GitLab, Buildkite, Terraform Cloud, Google) must
     * constrain tenant identity via an identity-bearing claim, a tenant-pinning
     * subject prefix (such as `repo:YOUR_ORG/...`), or a CEL condition referencing one
     * of those identity claims (e.g. `claims.repository_owner`). OAuth callers may
     * only manage rules whose `oauth_scope` is `workspace:developer` or
     * `workspace:inference`; other scopes require a Console session.
     *
     * @example
     * ```ts
     * const federationRule =
     *   await client.organization.federation.rules.create({
     *     issuer_id: 'issuer_id',
     *     match: {},
     *     name: 'x',
     *     oauth_scope: 'x',
     *     target: {
     *       service_account_id: 'svac_01SDCCSbTxrXDpWc1phhtcfK',
     *       type: 'service_account',
     *     },
     *   });
     * ```
     */
    create(e, t) {
      return this._client.post("/v1/organizations/federation_rules", {
        body: e,
        ...t,
        __span: u(this._client, "anthropic.organization.federation.rules.create", t, {
          route: "/v1/organizations/federation_rules",
          createdIDAttribute: "anthropic.organization.federation_rule.id"
        })
      });
    }
    /**
     * **Requires an OAuth access token with the `org:admin` scope**, from
     * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
     * API keys are not accepted. See
     * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
     *
     * Retrieve a federation rule by its ID (`fdrl_...`).
     *
     * @example
     * ```ts
     * const federationRule =
     *   await client.organization.federation.rules.retrieve(
     *     'federation_rule_id',
     *   );
     * ```
     */
    retrieve(e, t) {
      return this._client.get(g`/v1/organizations/federation_rules/${e}`, {
        ...t,
        __span: u(this._client, "anthropic.organization.federation.rules.retrieve", t, {
          route: "/v1/organizations/federation_rules/{federation_rule_id}",
          attributes: { "anthropic.organization.federation_rule.id": e }
        })
      });
    }
    /**
     * **Requires an OAuth access token with the `org:admin` scope**, from
     * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
     * API keys are not accepted. See
     * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
     *
     * Partially update a federation rule.
     *
     * `issuer_id` is immutable. `match` and `target` are replaced as whole objects
     * when set. Referenced service accounts and workspaces must exist in your
     * organization; invalid references are rejected with a 400 error. Archived rules
     * cannot be updated; this returns 400. Create a new rule instead. Rules on
     * well-known shared issuers (GitHub Actions, GitLab, Buildkite, Terraform Cloud,
     * Google) must constrain tenant identity via an identity-bearing claim, a
     * tenant-pinning subject prefix (such as `repo:YOUR_ORG/...`), or a CEL condition
     * referencing one of those identity claims (e.g. `claims.repository_owner`). On
     * these issuers the requirement is re-checked on every update; if an existing
     * rule's stored match does not yet constrain tenant identity, any update (even a
     * rename or description change) must also supply a conforming `match` in the same
     * request. OAuth callers may only manage rules whose `oauth_scope` is
     * `workspace:developer` or `workspace:inference`; other scopes require a Console
     * session.
     *
     * @example
     * ```ts
     * const federationRule =
     *   await client.organization.federation.rules.update(
     *     'federation_rule_id',
     *   );
     * ```
     */
    update(e, t, r) {
      return this._client.post(g`/v1/organizations/federation_rules/${e}`, {
        body: t,
        ...r,
        __span: u(this._client, "anthropic.organization.federation.rules.update", r, {
          route: "/v1/organizations/federation_rules/{federation_rule_id}",
          attributes: { "anthropic.organization.federation_rule.id": e }
        })
      });
    }
    /**
     * **Requires an OAuth access token with the `org:admin` scope**, from
     * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
     * API keys are not accepted. See
     * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
     *
     * List federation rules in your organization.
     *
     * Optionally filter by issuer with `issuer_id`. Archived rules are excluded unless
     * `include_archived=true`.
     *
     * @example
     * ```ts
     * // Automatically fetches more pages as needed.
     * for await (const federationRule of client.organization.federation.rules.list()) {
     *   // ...
     * }
     * ```
     */
    list(e = {}, t) {
      return this._client.getAPIList("/v1/organizations/federation_rules", z, {
        query: e,
        ...t,
        __span: u(this._client, "anthropic.organization.federation.rules.list", t, {
          route: "/v1/organizations/federation_rules",
          queryParams: ["include_archived", "issuer_id", "limit", "page"]
        })
      });
    }
    /**
     * **Requires an OAuth access token with the `org:admin` scope**, from
     * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
     * API keys are not accepted. See
     * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
     *
     * Archive a federation rule.
     *
     * Token exchange through this rule stops immediately. Idempotent; re-archiving
     * returns the rule with its original `archived_at`. Archiving clears the rule's
     * workspace targeting (`workspace_id` and `workspace_ids` are emptied). Tokens
     * already minted before archive remain valid until they expire. OAuth callers may
     * only manage rules whose `oauth_scope` is `workspace:developer` or
     * `workspace:inference`; other scopes require a Console session.
     *
     * @example
     * ```ts
     * const federationRule =
     *   await client.organization.federation.rules.archive(
     *     'federation_rule_id',
     *   );
     * ```
     */
    archive(e, t) {
      return this._client.post(g`/v1/organizations/federation_rules/${e}/archive`, {
        ...t,
        __span: u(this._client, "anthropic.organization.federation.rules.archive", t, {
          route: "/v1/organizations/federation_rules/{federation_rule_id}/archive",
          attributes: { "anthropic.organization.federation_rule.id": e }
        })
      });
    }
  }
  return s.Workspaces = Fc, s;
})(), Hc = /* @__PURE__ */ (() => {
  class s extends x {
    constructor() {
      super(...arguments), this.issuers = new jc(this._client), this.rules = new Wc(this._client);
    }
  }
  return s.Issuers = jc, s.Rules = Wc, s;
})();
let Dc = class extends x {
  /**
   * **Requires an OAuth access token with the `org:admin` scope**, from
   * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
   * API keys are not accepted. See
   * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
   *
   * List the workspaces a service account is a member of.
   *
   * Each entry includes the service account's `workspace_role` in that workspace.
   * Use `limit` and the `next_page` cursor to paginate. When the service account has
   * no explicit default-workspace membership, the implicit (`implicit: true`)
   * membership is returned as the first entry on the first page; with `limit=1` the
   * first page may return up to 2 entries (the implicit entry plus one explicit
   * membership) so a pagination cursor can be derived. Memberships are returned only
   * while the service account is active. Without a `page` cursor, an archived
   * service account returns an empty list. A `page` cursor that does not match an
   * active membership returns a 400 invalid-request error. A cursor stops matching
   * when the membership is removed, the workspace is deleted, or the service account
   * is archived. Restart pagination from the first page to recover.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const serviceAccountWorkspaceMember of client.organization.serviceAccounts.workspaces.list(
   *   'service_account_id',
   * )) {
   *   // ...
   * }
   * ```
   */
  list(n, e = {}, t) {
    return this._client.getAPIList(g`/v1/organizations/service_accounts/${n}/workspaces`, z, {
      query: e,
      ...t,
      __span: u(this._client, "anthropic.organization.service_accounts.workspaces.list", t, {
        route: "/v1/organizations/service_accounts/{service_account_id}/workspaces",
        queryParams: ["limit", "page"],
        attributes: { "anthropic.organization.service_account.id": n }
      })
    });
  }
  /**
   * **Requires an OAuth access token with the `org:admin` scope**, from
   * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
   * API keys are not accepted. See
   * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
   *
   * Add a service account to a workspace with the given `workspace_role`.
   *
   * Mirror of `POST /workspaces/{workspace_id}/service_accounts`, addressed from the
   * service-account side; both create the same membership. If the service account is
   * already an explicit member of the workspace, its `workspace_role` is replaced
   * with the value supplied here. Archived workspaces return 400. Archived service
   * accounts cannot be added and are rejected.
   *
   * @example
   * ```ts
   * const serviceAccountWorkspaceMember =
   *   await client.organization.serviceAccounts.workspaces.add(
   *     'service_account_id',
   *     {
   *       workspace_id: 'workspace_id',
   *       workspace_role: 'workspace_admin',
   *     },
   *   );
   * ```
   */
  add(n, e, t) {
    return this._client.post(g`/v1/organizations/service_accounts/${n}/workspaces`, {
      body: e,
      ...t,
      __span: u(this._client, "anthropic.organization.service_accounts.workspaces.add", t, {
        route: "/v1/organizations/service_accounts/{service_account_id}/workspaces",
        attributes: { "anthropic.organization.service_account.id": n },
        createdIDAttribute: "anthropic.organization.service_account.workspace.id",
        createdIDField: "workspace_id"
      })
    });
  }
  /**
   * **Requires an OAuth access token with the `org:admin` scope**, from
   * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
   * API keys are not accepted. See
   * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
   *
   * Remove a service account from a workspace.
   *
   * Mirror of
   * `DELETE /workspaces/{workspace_id}/service_accounts/{service_account_id}`,
   * addressed from the service-account side. Removal is idempotent (returns 200 even
   * if the membership was already removed). A DELETE against the implicit
   * default-workspace membership returns 200 but is a no-op and the membership
   * persists; deleting an explicit default-workspace row reverts to the implicit
   * `workspace_user` membership. Archived workspaces return 400.
   *
   * @example
   * ```ts
   * const workspace =
   *   await client.organization.serviceAccounts.workspaces.remove(
   *     'workspace_id',
   *     { service_account_id: 'service_account_id' },
   *   );
   * ```
   */
  remove(n, e, t) {
    const { service_account_id: r } = e;
    return this._client.delete(g`/v1/organizations/service_accounts/${r}/workspaces/${n}`, {
      ...t,
      __span: u(this._client, "anthropic.organization.service_accounts.workspaces.remove", t, {
        route: "/v1/organizations/service_accounts/{service_account_id}/workspaces/{workspace_id}",
        attributes: {
          "anthropic.organization.service_account.id": r,
          "anthropic.organization.service_account.workspace.id": n
        }
      })
    });
  }
};
var Kc = /* @__PURE__ */ (() => {
  class s extends x {
    constructor() {
      super(...arguments), this.workspaces = new Dc(this._client);
    }
    /**
     * **Requires an OAuth access token with the `org:admin` scope**, from
     * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
     * API keys are not accepted. See
     * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
     *
     * Create a service account.
     *
     * A service account is a named workload identity that federation rules target.
     * `organization_role` is `developer` (default) or `admin`; a rule may only be
     * created or retargeted to grant `org:admin` scope when the target's
     * `organization_role` is `admin`. Creating an `admin`-role service account
     * requires an interactive credential (a user OAuth token or a Console session) — a
     * workload may only create `developer`-role service accounts.
     *
     * @example
     * ```ts
     * const serviceAccount =
     *   await client.organization.serviceAccounts.create({
     *     name: 'ci-deploy-bot',
     *   });
     * ```
     */
    create(e, t) {
      return this._client.post("/v1/organizations/service_accounts", {
        body: e,
        ...t,
        __span: u(this._client, "anthropic.organization.service_accounts.create", t, {
          route: "/v1/organizations/service_accounts",
          createdIDAttribute: "anthropic.organization.service_account.id"
        })
      });
    }
    /**
     * **Requires an OAuth access token with the `org:admin` scope**, from
     * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
     * API keys are not accepted. See
     * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
     *
     * Retrieve a service account by its ID (`svac_...`).
     *
     * @example
     * ```ts
     * const serviceAccount =
     *   await client.organization.serviceAccounts.retrieve(
     *     'service_account_id',
     *   );
     * ```
     */
    retrieve(e, t) {
      return this._client.get(g`/v1/organizations/service_accounts/${e}`, {
        ...t,
        __span: u(this._client, "anthropic.organization.service_accounts.retrieve", t, {
          route: "/v1/organizations/service_accounts/{service_account_id}",
          attributes: { "anthropic.organization.service_account.id": e }
        })
      });
    }
    /**
     * **Requires an OAuth access token with the `org:admin` scope**, from
     * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
     * API keys are not accepted. See
     * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
     *
     * Update a service account.
     *
     * Only `description` and `organization_role` are mutable; `name` cannot be
     * changed. Archived service accounts cannot be updated; this returns 400. Setting
     * `organization_role` to `admin` (even when unchanged) requires an interactive
     * credential (a user OAuth token or a Console session).
     *
     * @example
     * ```ts
     * const serviceAccount =
     *   await client.organization.serviceAccounts.update(
     *     'service_account_id',
     *   );
     * ```
     */
    update(e, t, r) {
      return this._client.post(g`/v1/organizations/service_accounts/${e}`, {
        body: t,
        ...r,
        __span: u(this._client, "anthropic.organization.service_accounts.update", r, {
          route: "/v1/organizations/service_accounts/{service_account_id}",
          attributes: { "anthropic.organization.service_account.id": e }
        })
      });
    }
    /**
     * **Requires an OAuth access token with the `org:admin` scope**, from
     * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
     * API keys are not accepted. See
     * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
     *
     * List service accounts in the caller's organization.
     *
     * Results are ordered by creation time, newest first. Use `limit` and the
     * `next_page` cursor to paginate; set `include_archived=true` to include archived
     * service accounts.
     *
     * @example
     * ```ts
     * // Automatically fetches more pages as needed.
     * for await (const serviceAccount of client.organization.serviceAccounts.list()) {
     *   // ...
     * }
     * ```
     */
    list(e = {}, t) {
      return this._client.getAPIList("/v1/organizations/service_accounts", z, {
        query: e,
        ...t,
        __span: u(this._client, "anthropic.organization.service_accounts.list", t, {
          route: "/v1/organizations/service_accounts",
          queryParams: ["include_archived", "limit", "page"]
        })
      });
    }
    /**
     * **Requires an OAuth access token with the `org:admin` scope**, from
     * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
     * API keys are not accepted. See
     * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
     *
     * Archive a service account.
     *
     * Idempotent; re-archiving returns the service account with its original
     * `archived_at`. Rejected with 400 if any live (non-archived) federation rule
     * still targets this service account, same as issuer archival; archive those rules
     * first or change their target to another service account.
     *
     * @example
     * ```ts
     * const serviceAccount =
     *   await client.organization.serviceAccounts.archive(
     *     'service_account_id',
     *   );
     * ```
     */
    archive(e, t) {
      return this._client.post(g`/v1/organizations/service_accounts/${e}/archive`, {
        ...t,
        __span: u(this._client, "anthropic.organization.service_accounts.archive", t, {
          route: "/v1/organizations/service_accounts/{service_account_id}/archive",
          attributes: { "anthropic.organization.service_account.id": e }
        })
      });
    }
  }
  return s.Workspaces = Dc, s;
})();
class Gc extends x {
  /**
   * Get Workspace Member
   *
   * @example
   * ```ts
   * const workspaceMember =
   *   await client.organization.workspaces.members.retrieve(
   *     'user_id',
   *     { workspace_id: 'workspace_id' },
   *   );
   * ```
   */
  retrieve(n, e, t) {
    const { workspace_id: r } = e;
    return this._client.get(g`/v1/organizations/workspaces/${r}/members/${n}`, {
      ...t,
      __span: u(this._client, "anthropic.organization.workspaces.members.retrieve", t, {
        route: "/v1/organizations/workspaces/{workspace_id}/members/{user_id}",
        attributes: {
          "anthropic.organization.workspace.id": r,
          "anthropic.organization.workspace.member.id": n
        }
      })
    });
  }
  /**
   * Update Workspace Member
   *
   * @example
   * ```ts
   * const workspaceMember =
   *   await client.organization.workspaces.members.update(
   *     'user_id',
   *     {
   *       workspace_id: 'workspace_id',
   *       workspace_role: 'workspace_admin',
   *     },
   *   );
   * ```
   */
  update(n, e, t) {
    const { workspace_id: r, ...i } = e;
    return this._client.post(g`/v1/organizations/workspaces/${r}/members/${n}`, {
      body: i,
      ...t,
      __span: u(this._client, "anthropic.organization.workspaces.members.update", t, {
        route: "/v1/organizations/workspaces/{workspace_id}/members/{user_id}",
        attributes: {
          "anthropic.organization.workspace.id": r,
          "anthropic.organization.workspace.member.id": n
        }
      })
    });
  }
  /**
   * List Workspace Members
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const workspaceMember of client.organization.workspaces.members.list(
   *   'workspace_id',
   * )) {
   *   // ...
   * }
   * ```
   */
  list(n, e = {}, t) {
    return this._client.getAPIList(g`/v1/organizations/workspaces/${n}/members`, Y, {
      query: e,
      ...t,
      __span: u(this._client, "anthropic.organization.workspaces.members.list", t, {
        route: "/v1/organizations/workspaces/{workspace_id}/members",
        queryParams: ["after_id", "before_id", "limit"],
        attributes: { "anthropic.organization.workspace.id": n }
      })
    });
  }
  /**
   * Create Workspace Member
   *
   * @example
   * ```ts
   * const workspaceMember =
   *   await client.organization.workspaces.members.add(
   *     'workspace_id',
   *     {
   *       user_id: 'user_01WCz1FkmYMm4gnmykNKUu3Q',
   *       workspace_role: 'workspace_admin',
   *     },
   *   );
   * ```
   */
  add(n, e, t) {
    return this._client.post(g`/v1/organizations/workspaces/${n}/members`, {
      body: e,
      ...t,
      __span: u(this._client, "anthropic.organization.workspaces.members.add", t, {
        route: "/v1/organizations/workspaces/{workspace_id}/members",
        attributes: { "anthropic.organization.workspace.id": n },
        createdIDAttribute: "anthropic.organization.workspace.member.id",
        createdIDField: "user_id"
      })
    });
  }
  /**
   * Delete Workspace Member
   *
   * @example
   * ```ts
   * const member =
   *   await client.organization.workspaces.members.remove(
   *     'user_id',
   *     { workspace_id: 'workspace_id' },
   *   );
   * ```
   */
  remove(n, e, t) {
    const { workspace_id: r } = e;
    return this._client.delete(g`/v1/organizations/workspaces/${r}/members/${n}`, {
      ...t,
      __span: u(this._client, "anthropic.organization.workspaces.members.remove", t, {
        route: "/v1/organizations/workspaces/{workspace_id}/members/{user_id}",
        attributes: {
          "anthropic.organization.workspace.id": r,
          "anthropic.organization.workspace.member.id": n
        }
      })
    });
  }
}
class Vc extends x {
  /**
   * Set or clear rate-limit overrides for one rate-limit group in a workspace.
   *
   * Only the limiter types named in `limits` change: an integer `value` sets that
   * type's override and `null` clears it. Types not named keep their current value.
   * A value above the organization's own limit is stored, but the organization limit
   * still applies, so the lower of the two is enforced.
   *
   * Returns the targeted group's entry with this request applied, in the shape
   * `GET /v1/organizations/workspaces/{workspace_id}/rate_limits` returns. Changes
   * take effect within about an hour.
   *
   * @example
   * ```ts
   * const workspaceRateLimit =
   *   await client.organization.workspaces.rateLimits.update(
   *     'rate_limit_id',
   *     {
   *       workspace_id: 'workspace_id',
   *       limits: [{ type: 'fast_itpmca', value: 0 }],
   *     },
   *   );
   * ```
   */
  update(n, e, t) {
    const { workspace_id: r, ...i } = e;
    return this._client.post(g`/v1/organizations/workspaces/${r}/rate_limits/${n}`, {
      body: i,
      ...t,
      __span: u(this._client, "anthropic.organization.workspaces.rate_limits.update", t, {
        route: "/v1/organizations/workspaces/{workspace_id}/rate_limits/{rate_limit_id}",
        attributes: {
          "anthropic.organization.workspace.id": r,
          "anthropic.organization.workspace.rate_limit.id": n
        }
      })
    });
  }
  /**
   * List a workspace's rate limits.
   *
   * By default, returns only the groups and limiter types that have a
   * workspace-level override. With `include_inherited=true`, returns every group
   * with organization-level limits the workspace can see, listing for each the
   * values it inherits from the organization as well as its own overrides. Each
   * value's `source` says which it is.
   *
   * When `limit` is omitted, every matching entry is returned in a single page; when
   * `limit` truncates the result, follow `next_page` to fetch the remaining entries.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const workspaceRateLimit of client.organization.workspaces.rateLimits.list(
   *   'workspace_id',
   * )) {
   *   // ...
   * }
   * ```
   */
  list(n, e = {}, t) {
    return this._client.getAPIList(g`/v1/organizations/workspaces/${n}/rate_limits`, z, {
      query: e,
      ...t,
      __span: u(this._client, "anthropic.organization.workspaces.rate_limits.list", t, {
        route: "/v1/organizations/workspaces/{workspace_id}/rate_limits",
        queryParams: ["group_type", "include_inherited", "limit", "page"],
        attributes: { "anthropic.organization.workspace.id": n }
      })
    });
  }
}
class Jc extends x {
  /**
   * **Requires an OAuth access token with the `org:admin` scope**, from
   * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
   * API keys are not accepted. See
   * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
   *
   * Retrieve a service account's membership in a workspace.
   *
   * Returns the membership record, including the service account's `workspace_role`
   * in this workspace. Archived workspaces return 400. For the default workspace,
   * returns the implicit (`implicit: true`) membership when no explicit membership
   * exists; an explicitly added membership is returned with its assigned role. An
   * archived service account returns 404.
   *
   * @example
   * ```ts
   * const serviceAccountWorkspaceMember =
   *   await client.organization.workspaces.serviceAccounts.retrieve(
   *     'service_account_id',
   *     { workspace_id: 'workspace_id' },
   *   );
   * ```
   */
  retrieve(n, e, t) {
    const { workspace_id: r } = e;
    return this._client.get(g`/v1/organizations/workspaces/${r}/service_accounts/${n}`, {
      ...t,
      __span: u(this._client, "anthropic.organization.workspaces.service_accounts.retrieve", t, {
        route: "/v1/organizations/workspaces/{workspace_id}/service_accounts/{service_account_id}",
        attributes: {
          "anthropic.organization.workspace.id": r,
          "anthropic.organization.workspace.service_account.id": n
        }
      })
    });
  }
  /**
   * **Requires an OAuth access token with the `org:admin` scope**, from
   * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
   * API keys are not accepted. See
   * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
   *
   * Change a service account's role in a workspace.
   *
   * The new `workspace_role` replaces the current one. Only explicit memberships can
   * be updated; to set a role on the implicit default-workspace membership, add the
   * service account explicitly with
   * `POST /workspaces/{workspace_id}/service_accounts`. Archived workspaces
   * return 400. Archived service accounts cannot be updated and are rejected.
   *
   * @example
   * ```ts
   * const serviceAccountWorkspaceMember =
   *   await client.organization.workspaces.serviceAccounts.update(
   *     'service_account_id',
   *     {
   *       workspace_id: 'workspace_id',
   *       workspace_role: 'workspace_admin',
   *     },
   *   );
   * ```
   */
  update(n, e, t) {
    const { workspace_id: r, ...i } = e;
    return this._client.post(g`/v1/organizations/workspaces/${r}/service_accounts/${n}`, {
      body: i,
      ...t,
      __span: u(this._client, "anthropic.organization.workspaces.service_accounts.update", t, {
        route: "/v1/organizations/workspaces/{workspace_id}/service_accounts/{service_account_id}",
        attributes: {
          "anthropic.organization.workspace.id": r,
          "anthropic.organization.workspace.service_account.id": n
        }
      })
    });
  }
  /**
   * **Requires an OAuth access token with the `org:admin` scope**, from
   * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
   * API keys are not accepted. See
   * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
   *
   * List the service accounts that are members of a workspace.
   *
   * Each entry includes the service account's `workspace_role`. Use `limit` and the
   * `next_page` cursor to paginate. Archived workspaces return 400; use
   * `GET /service_accounts/{id}/workspaces` to audit memberships of an archived
   * workspace. The implicit default-workspace membership is not included in this
   * list. Memberships of archived service accounts are omitted from the results.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const serviceAccountWorkspaceMember of client.organization.workspaces.serviceAccounts.list(
   *   'workspace_id',
   * )) {
   *   // ...
   * }
   * ```
   */
  list(n, e = {}, t) {
    return this._client.getAPIList(g`/v1/organizations/workspaces/${n}/service_accounts`, z, {
      query: e,
      ...t,
      __span: u(this._client, "anthropic.organization.workspaces.service_accounts.list", t, {
        route: "/v1/organizations/workspaces/{workspace_id}/service_accounts",
        queryParams: ["limit", "page"],
        attributes: { "anthropic.organization.workspace.id": n }
      })
    });
  }
  /**
   * **Requires an OAuth access token with the `org:admin` scope**, from
   * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
   * API keys are not accepted. See
   * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
   *
   * Add a service account to a workspace with the given `workspace_role`.
   *
   * The role determines what the service account can do in the workspace and which
   * workspace-scoped permissions it can be granted when authenticating through
   * federation. Every service account is already an implicit `workspace_user` member
   * of the default workspace; adding it explicitly assigns a chosen role. If the
   * service account is already an explicit member of the workspace, its
   * `workspace_role` is replaced with the value supplied here. Archived workspaces
   * return 400. Archived service accounts cannot be added and are rejected.
   *
   * @example
   * ```ts
   * const serviceAccountWorkspaceMember =
   *   await client.organization.workspaces.serviceAccounts.add(
   *     'workspace_id',
   *     {
   *       service_account_id: 'service_account_id',
   *       workspace_role: 'workspace_admin',
   *     },
   *   );
   * ```
   */
  add(n, e, t) {
    return this._client.post(g`/v1/organizations/workspaces/${n}/service_accounts`, {
      body: e,
      ...t,
      __span: u(this._client, "anthropic.organization.workspaces.service_accounts.add", t, {
        route: "/v1/organizations/workspaces/{workspace_id}/service_accounts",
        attributes: { "anthropic.organization.workspace.id": n },
        createdIDAttribute: "anthropic.organization.workspace.service_account.id",
        createdIDField: "service_account_id"
      })
    });
  }
  /**
   * **Requires an OAuth access token with the `org:admin` scope**, from
   * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
   * API keys are not accepted. See
   * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
   *
   * Remove a service account from a workspace.
   *
   * Removal is idempotent (returns 200 even if the membership was already removed).
   * A DELETE against the implicit default-workspace membership returns 200 but is a
   * no-op and the membership persists; deleting an explicit default-workspace row
   * reverts to the implicit `workspace_user` membership. Archived workspaces
   * return 400.
   *
   * @example
   * ```ts
   * const serviceAccount =
   *   await client.organization.workspaces.serviceAccounts.remove(
   *     'service_account_id',
   *     { workspace_id: 'workspace_id' },
   *   );
   * ```
   */
  remove(n, e, t) {
    const { workspace_id: r } = e;
    return this._client.delete(g`/v1/organizations/workspaces/${r}/service_accounts/${n}`, {
      ...t,
      __span: u(this._client, "anthropic.organization.workspaces.service_accounts.remove", t, {
        route: "/v1/organizations/workspaces/{workspace_id}/service_accounts/{service_account_id}",
        attributes: {
          "anthropic.organization.workspace.id": r,
          "anthropic.organization.workspace.service_account.id": n
        }
      })
    });
  }
}
var Yc = /* @__PURE__ */ (() => {
  class s extends x {
    constructor() {
      super(...arguments), this.rateLimits = new Vc(this._client), this.members = new Gc(this._client), this.serviceAccounts = new Jc(this._client);
    }
    /**
     * Create Workspace
     *
     * @example
     * ```ts
     * const workspace =
     *   await client.organization.workspaces.create({
     *     name: 'x',
     *   });
     * ```
     */
    create(e, t) {
      return this._client.post("/v1/organizations/workspaces", {
        body: e,
        ...t,
        __span: u(this._client, "anthropic.organization.workspaces.create", t, {
          route: "/v1/organizations/workspaces",
          createdIDAttribute: "anthropic.organization.workspace.id"
        })
      });
    }
    /**
     * Get Workspace
     *
     * @example
     * ```ts
     * const workspace =
     *   await client.organization.workspaces.retrieve(
     *     'workspace_id',
     *   );
     * ```
     */
    retrieve(e, t) {
      return this._client.get(g`/v1/organizations/workspaces/${e}`, {
        ...t,
        __span: u(this._client, "anthropic.organization.workspaces.retrieve", t, {
          route: "/v1/organizations/workspaces/{workspace_id}",
          attributes: { "anthropic.organization.workspace.id": e }
        })
      });
    }
    /**
     * Update Workspace
     *
     * @example
     * ```ts
     * const workspace =
     *   await client.organization.workspaces.update(
     *     'workspace_id',
     *   );
     * ```
     */
    update(e, t, r) {
      return this._client.post(g`/v1/organizations/workspaces/${e}`, {
        body: t,
        ...r,
        __span: u(this._client, "anthropic.organization.workspaces.update", r, {
          route: "/v1/organizations/workspaces/{workspace_id}",
          attributes: { "anthropic.organization.workspace.id": e }
        })
      });
    }
    /**
     * List Workspaces
     *
     * @example
     * ```ts
     * // Automatically fetches more pages as needed.
     * for await (const workspace of client.organization.workspaces.list()) {
     *   // ...
     * }
     * ```
     */
    list(e = {}, t) {
      return this._client.getAPIList("/v1/organizations/workspaces", Y, {
        query: e,
        ...t,
        __span: u(this._client, "anthropic.organization.workspaces.list", t, {
          route: "/v1/organizations/workspaces",
          queryParams: ["after_id", "before_id", "include_archived", "include_default", "limit"]
        })
      });
    }
    /**
     * Archive Workspace
     *
     * @example
     * ```ts
     * const workspace =
     *   await client.organization.workspaces.archive(
     *     'workspace_id',
     *   );
     * ```
     */
    archive(e, t) {
      return this._client.post(g`/v1/organizations/workspaces/${e}/archive`, {
        ...t,
        __span: u(this._client, "anthropic.organization.workspaces.archive", t, {
          route: "/v1/organizations/workspaces/{workspace_id}/archive",
          attributes: { "anthropic.organization.workspace.id": e }
        })
      });
    }
  }
  return s.RateLimits = Vc, s.Members = Gc, s.ServiceAccounts = Jc, s;
})(), Xc = /* @__PURE__ */ (() => {
  class s extends x {
    constructor() {
      super(...arguments), this.apiKeys = new $c(this._client), this.externalKeys = new Lc(this._client), this.federation = new Hc(this._client), this.invites = new qc(this._client), this.serviceAccounts = new Kc(this._client), this.users = new Uc(this._client), this.workspaces = new Yc(this._client), this.rateLimits = new Bc(this._client), this.complianceSettings = new Nc(this._client);
    }
    /**
     * Retrieve information about the organization associated with the authenticated
     * API key.
     *
     * @example
     * ```ts
     * const organizationInfo =
     *   await client.organization.retrieve();
     * ```
     */
    retrieve(e) {
      return this._client.get("/v1/organizations/me", {
        ...e,
        __span: u(this._client, "anthropic.organization.retrieve", e, {
          route: "/v1/organizations/me"
        })
      });
    }
  }
  return s.APIKeys = $c, s.ExternalKeys = Lc, s.Federation = Hc, s.Invites = qc, s.ServiceAccounts = Kc, s.Users = Uc, s.Workspaces = Yc, s.RateLimits = Bc, s.ComplianceSettings = Nc, s;
})();
class Qc extends x {
  /**
   * Create Skill Version
   *
   * @example
   * ```ts
   * const skillVersion = await client.skills.versions.create(
   *   'skill_id',
   *   { files: [fs.createReadStream('path/to/file')] },
   * );
   * ```
   */
  create(n, e, t) {
    const { workspace_id: r, ...i } = e;
    return this._client.post(g`/v1/skills/${n}/versions`, Le({
      body: i,
      ...t,
      headers: f([
        { ...r != null ? { "anthropic-workspace-id": r } : void 0 },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.skills.versions.create", t, {
        route: "/v1/skills/{skill_id}/versions",
        attributes: { "anthropic.skill.id": n },
        createdIDAttribute: "anthropic.skill.version.id"
      })
    }, this._client, !1));
  }
  /**
   * Get Skill Version
   *
   * @example
   * ```ts
   * const skillVersion = await client.skills.versions.retrieve(
   *   'version',
   *   { skill_id: 'skill_id' },
   * );
   * ```
   */
  retrieve(n, e, t) {
    const { skill_id: r, workspace_id: i } = e;
    return this._client.get(g`/v1/skills/${r}/versions/${n}`, {
      ...t,
      headers: f([
        { ...i != null ? { "anthropic-workspace-id": i } : void 0 },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.skills.versions.retrieve", t, {
        route: "/v1/skills/{skill_id}/versions/{version}",
        attributes: { "anthropic.skill.id": r, "anthropic.skill.version.id": n }
      })
    });
  }
  /**
   * List Skill Versions
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const skillVersion of client.skills.versions.list(
   *   'skill_id',
   * )) {
   *   // ...
   * }
   * ```
   */
  list(n, e = {}, t) {
    const { workspace_id: r, ...i } = e ?? {};
    return this._client.getAPIList(g`/v1/skills/${n}/versions`, z, {
      query: i,
      ...t,
      headers: f([
        { ...r != null ? { "anthropic-workspace-id": r } : void 0 },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.skills.versions.list", t, {
        route: "/v1/skills/{skill_id}/versions",
        queryParams: ["limit", "page"],
        attributes: { "anthropic.skill.id": n }
      })
    });
  }
  /**
   * Delete Skill Version
   *
   * @example
   * ```ts
   * const deletedSkillVersion =
   *   await client.skills.versions.delete('version', {
   *     skill_id: 'skill_id',
   *   });
   * ```
   */
  delete(n, e, t) {
    const { skill_id: r, workspace_id: i } = e;
    return this._client.delete(g`/v1/skills/${r}/versions/${n}`, {
      ...t,
      headers: f([
        { ...i != null ? { "anthropic-workspace-id": i } : void 0 },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.skills.versions.delete", t, {
        route: "/v1/skills/{skill_id}/versions/{version}",
        attributes: { "anthropic.skill.id": r, "anthropic.skill.version.id": n }
      })
    });
  }
}
var Zc = /* @__PURE__ */ (() => {
  class s extends x {
    constructor() {
      super(...arguments), this.versions = new Qc(this._client);
    }
    /**
     * Create Skill
     *
     * @example
     * ```ts
     * const skill = await client.skills.create({
     *   files: [fs.createReadStream('path/to/file')],
     * });
     * ```
     */
    create(e, t) {
      const { workspace_id: r, ...i } = e;
      return this._client.post("/v1/skills", Le({
        body: i,
        ...t,
        headers: f([
          { ...r != null ? { "anthropic-workspace-id": r } : void 0 },
          t?.headers
        ]),
        __span: u(this._client, "anthropic.skills.create", t, {
          route: "/v1/skills",
          createdIDAttribute: "anthropic.skill.id"
        })
      }, this._client, !1));
    }
    /**
     * Get Skill
     *
     * @example
     * ```ts
     * const skill = await client.skills.retrieve('skill_id');
     * ```
     */
    retrieve(e, t = {}, r) {
      const { workspace_id: i } = t ?? {};
      return this._client.get(g`/v1/skills/${e}`, {
        ...r,
        headers: f([
          { ...i != null ? { "anthropic-workspace-id": i } : void 0 },
          r?.headers
        ]),
        __span: u(this._client, "anthropic.skills.retrieve", r, {
          route: "/v1/skills/{skill_id}",
          attributes: { "anthropic.skill.id": e }
        })
      });
    }
    /**
     * List Skills
     *
     * @example
     * ```ts
     * // Automatically fetches more pages as needed.
     * for await (const skill of client.skills.list()) {
     *   // ...
     * }
     * ```
     */
    list(e = {}, t) {
      const { workspace_id: r, ...i } = e ?? {};
      return this._client.getAPIList("/v1/skills", z, {
        query: i,
        ...t,
        headers: f([
          { ...r != null ? { "anthropic-workspace-id": r } : void 0 },
          t?.headers
        ]),
        __span: u(this._client, "anthropic.skills.list", t, {
          route: "/v1/skills",
          queryParams: ["limit", "page", "source"]
        })
      });
    }
    /**
     * Delete Skill
     *
     * @example
     * ```ts
     * const deletedSkill = await client.skills.delete('skill_id');
     * ```
     */
    delete(e, t = {}, r) {
      const { workspace_id: i } = t ?? {};
      return this._client.delete(g`/v1/skills/${e}`, {
        ...r,
        headers: f([
          { ...i != null ? { "anthropic-workspace-id": i } : void 0 },
          r?.headers
        ]),
        __span: u(this._client, "anthropic.skills.delete", r, {
          route: "/v1/skills/{skill_id}",
          attributes: { "anthropic.skill.id": e }
        })
      });
    }
  }
  return s.Versions = Qc, s;
})();
class el extends x {
  /**
   * Create Action URL
   *
   * @example
   * ```ts
   * const userProfileActionURL =
   *   await client.userProfiles.actionURLs.create(
   *     'uprof_011CZkZCu8hGbp5mYRQgUmz9',
   *     { action: { type: 'enroll_end_user' } },
   *   );
   * ```
   */
  create(n, e, t) {
    const { workspace_id: r, ...i } = e;
    return this._client.post(g`/v1/user_profiles/${n}/action_urls`, {
      body: i,
      ...t,
      headers: f([
        { ...r != null ? { "anthropic-workspace-id": r } : void 0 },
        t?.headers
      ]),
      __span: u(this._client, "anthropic.user_profiles.action_urls.create", t, {
        route: "/v1/user_profiles/{user_profile_id}/action_urls",
        attributes: { "anthropic.user_profile.id": n }
      })
    });
  }
}
var tl = /* @__PURE__ */ (() => {
  class s extends x {
    constructor() {
      super(...arguments), this.actionURLs = new el(this._client);
    }
    /**
     * Create User Profile
     *
     * @example
     * ```ts
     * const userProfile = await client.userProfiles.create();
     * ```
     */
    create(e, t) {
      const { workspace_id: r, ...i } = e;
      return this._client.post("/v1/user_profiles", {
        body: i,
        ...t,
        headers: f([
          { ...r != null ? { "anthropic-workspace-id": r } : void 0 },
          t?.headers
        ]),
        __span: u(this._client, "anthropic.user_profiles.create", t, {
          route: "/v1/user_profiles",
          createdIDAttribute: "anthropic.user_profile.id"
        })
      });
    }
    /**
     * Get User Profile
     *
     * @example
     * ```ts
     * const userProfile = await client.userProfiles.retrieve(
     *   'uprof_011CZkZCu8hGbp5mYRQgUmz9',
     * );
     * ```
     */
    retrieve(e, t = {}, r) {
      const { workspace_id: i } = t ?? {};
      return this._client.get(g`/v1/user_profiles/${e}`, {
        ...r,
        headers: f([
          { ...i != null ? { "anthropic-workspace-id": i } : void 0 },
          r?.headers
        ]),
        __span: u(this._client, "anthropic.user_profiles.retrieve", r, {
          route: "/v1/user_profiles/{user_profile_id}",
          attributes: { "anthropic.user_profile.id": e }
        })
      });
    }
    /**
     * Update User Profile
     *
     * @example
     * ```ts
     * const userProfile = await client.userProfiles.update(
     *   'uprof_011CZkZCu8hGbp5mYRQgUmz9',
     * );
     * ```
     */
    update(e, t, r) {
      const { workspace_id: i, ...a } = t;
      return this._client.post(g`/v1/user_profiles/${e}`, {
        body: a,
        ...r,
        headers: f([
          { ...i != null ? { "anthropic-workspace-id": i } : void 0 },
          r?.headers
        ]),
        __span: u(this._client, "anthropic.user_profiles.update", r, {
          route: "/v1/user_profiles/{user_profile_id}",
          attributes: { "anthropic.user_profile.id": e }
        })
      });
    }
    /**
     * List User Profiles
     *
     * @example
     * ```ts
     * // Automatically fetches more pages as needed.
     * for await (const userProfile of client.userProfiles.list()) {
     *   // ...
     * }
     * ```
     */
    list(e = {}, t) {
      const { workspace_id: r, ...i } = e ?? {};
      return this._client.getAPIList("/v1/user_profiles", z, {
        query: i,
        ...t,
        headers: f([
          { ...r != null ? { "anthropic-workspace-id": r } : void 0 },
          t?.headers
        ]),
        __span: u(this._client, "anthropic.user_profiles.list", t, {
          route: "/v1/user_profiles",
          queryParams: ["limit", "order", "order_by", "page"]
        })
      });
    }
    /**
     * Delete User Profile
     *
     * @example
     * ```ts
     * const deletedUserProfile = await client.userProfiles.delete(
     *   'uprof_011CZkZCu8hGbp5mYRQgUmz9',
     * );
     * ```
     */
    delete(e, t = {}, r) {
      const { workspace_id: i } = t ?? {};
      return this._client.delete(g`/v1/user_profiles/${e}`, {
        ...r,
        headers: f([
          { ...i != null ? { "anthropic-workspace-id": i } : void 0 },
          r?.headers
        ]),
        __span: u(this._client, "anthropic.user_profiles.delete", r, {
          route: "/v1/user_profiles/{user_profile_id}",
          attributes: { "anthropic.user_profile.id": e }
        })
      });
    }
  }
  return s.ActionURLs = el, s;
})(), Kr, Gr, Es, dt, nl;
const Ng = "\\n\\nHuman:", Lg = "\\n\\nAssistant:";
var qg = /* @__PURE__ */ (() => {
  class s {
    /**
     * The active credential provider. Default credential resolution runs once
     * at construction time. If it fails, the error is surfaced on every
     * request and the client must be reconstructed — there is no retry path.
     *
     * Clones returned by {@link withOptions} share the parent's auth state
     * (provider, token cache, pending resolution, and any resolution error)
     * unless the caller passes an explicit `apiKey`, `authToken`,
     * `credentials`, `config`, or `profile` override.
     */
    get credentials() {
      return this._authState.provider;
    }
    /**
     * The `openTelemetry` option as this client settled it when it was constructed: `propagation` and
     * each field of `traces` from the option, or else its default. A client constructed without the
     * option has what the environment variables said. One constructed with `openTelemetry: false` has
     * `traces.enabled: false` here.
     *
     * The value is frozen. It is a valid `openTelemetry` option, so a copy of this client can change
     * one setting and keep the others:
     *
     * ```ts
     * const { openTelemetry } = client;
     * client.withOptions({
     *   openTelemetry: { ...openTelemetry, traces: { ...openTelemetry.traces, contentMode: 'content' } },
     * });
     * ```
     */
    get openTelemetry() {
      return c(this, dt, "f");
    }
    /**
     * The instrumentation scope of this client's spans: the version of the package that the client
     * is from, and for the client of another platform the platform's name, which the scope's name
     * ends with. The clients for other platforms override it. The constructor calls it.
     * @internal
     */
    _instrumentationScope() {
      return { version: Ie };
    }
    /**
     * API Client for interfacing with the Anthropic API.
     *
     * @param {string | null | undefined} [opts.apiKey=process.env['ANTHROPIC_API_KEY'] ?? null]
     * @param {string | null | undefined} [opts.authToken=process.env['ANTHROPIC_AUTH_TOKEN'] ?? null]
     * @param {string | null | undefined} [opts.webhookKey=process.env['ANTHROPIC_WEBHOOK_SIGNING_KEY'] ?? null]
     * @param {string} [opts.baseURL=process.env['ANTHROPIC_BASE_URL'] ?? https://api.anthropic.com] - Override the default base URL for the API.
     * @param {number} [opts.timeout=10 minutes] - The maximum amount of time (in milliseconds) the client will wait for a response before timing out.
     * @param {MergedRequestInit} [opts.fetchOptions] - Additional `RequestInit` options to be passed to `fetch` calls.
     * @param {Fetch} [opts.fetch] - Specify a custom `fetch` function implementation.
     * @param {number} [opts.maxRetries=2] - The maximum number of times the client will retry a request.
     * @param {HeadersLike} opts.defaultHeaders - Default headers to include with every request to the API.
     * @param {Record<string, string | undefined>} opts.defaultQuery - Default query parameters to include with every request to the API.
     * @param {boolean} [opts.dangerouslyAllowBrowser=false] - By default, client-side use of this library is not allowed, as it risks exposing your secret API credentials to attackers.
     */
    constructor({ baseURL: e = O("ANTHROPIC_BASE_URL"), apiKey: t, authToken: r, webhookKey: i = O("ANTHROPIC_WEBHOOK_SIGNING_KEY") ?? null, ...a } = {}) {
      if (Kr.add(this), this._requestAuthFlags = /* @__PURE__ */ new WeakMap(), Es.set(this, void 0), dt.set(this, void 0), this._genAIProviderName = "anthropic", t === void 0 && (t = a.profile != null ? null : O("ANTHROPIC_API_KEY") ?? null), r === void 0 && (r = a.profile != null ? null : O("ANTHROPIC_AUTH_TOKEN") ?? null), a.profile != null && (a.credentials != null || a.config != null))
        throw new TypeError("Pass at most one of `profile`, `credentials`, or `config`.");
      const o = {
        apiKey: t,
        authToken: r,
        webhookKey: i,
        ...a,
        baseURL: e || "https://api.anthropic.com"
      };
      if (!o.dangerouslyAllowBrowser && Ld())
        throw new R(`It looks like you're running in a browser-like environment.

This is disabled by default, as it risks exposing your secret API credentials to attackers.
If you understand the risks and have appropriate mitigations in place,
you can set the \`dangerouslyAllowBrowser\` option to \`true\`, e.g.,

new Anthropic({ apiKey, dangerouslyAllowBrowser: true });
`);
      this.baseURL = o.baseURL, this._baseURLIsExplicit = a.__baseURLIsExplicit ?? !!e, this.timeout = o.timeout ?? Gr.DEFAULT_TIMEOUT, this.logger = o.logger ?? console, this.logLevel = Gs, this.logLevel = ri(o.logLevel, "ClientOptions.logLevel", M(this)) ?? ri(O("ANTHROPIC_LOG"), "process.env['ANTHROPIC_LOG']", M(this)) ?? Gs, this.fetchOptions = o.fetchOptions, this.maxRetries = hr("maxRetries", o.maxRetries ?? 2);
      const l = this._instrumentationScope();
      w(this, dt, vp(o.openTelemetry)), o.openTelemetry = c(this, dt, "f"), this._tracer = j(this, () => Sp(c(this, dt, "f"), l.version, l.platform)), this.fetch = o.fetch ?? Hd(), w(this, Es, Gd), this.middleware = [...o.middleware ?? []];
      const d = O("ANTHROPIC_CUSTOM_HEADERS");
      if (d) {
        const h = {};
        for (const m of d.split(`
`)) {
          const _ = m.indexOf(":");
          _ >= 0 && (h[m.substring(0, _).trim()] = m.substring(_ + 1).trim());
        }
        o.defaultHeaders = { ...h, ...o.defaultHeaders };
      }
      const p = a.__auth;
      if (delete o.__auth, delete o.__baseURLIsExplicit, this._options = o, this.apiKey = typeof t == "string" ? t : null, this.authToken = r, this.webhookKey = i, p)
        this._authState = p, !this._baseURLIsExplicit && p.baseURL && (this.baseURL = p.baseURL);
      else if (this._authState = { provider: null, tokenCache: null, resolution: null, error: null, extraHeaders: {} }, this.apiKey == null && this.authToken == null) {
        const h = o.credentials ?? null;
        if (h)
          this._authState.provider = h, this._authState.tokenCache = this._makeTokenCache(h);
        else if (o.config != null) {
          const m = Pu(o.config, this._credentialResolverOptions());
          this._authState.provider = m.provider, this._authState.tokenCache = this._makeTokenCache(m.provider), this._authState.extraHeaders = m.extraHeaders, this._applyCredentialBaseURL(m.baseURL);
        } else o.profile != null ? this._authState.resolution = this._resolveDefaultCredentials(o.profile) : this._shouldResolveDefaultCredentials() && (this._authState.resolution = this._resolveDefaultCredentials());
      }
    }
    /**
     * Whether to lazily resolve auth from the default credential chain when no
     * explicit auth is configured. Called once from the constructor, so
     * overrides must not depend on subclass instance state. Subclasses that
     * bring their own auth scheme return false so unrelated local credentials
     * are never resolved or allowed to supply a base URL.
     */
    _shouldResolveDefaultCredentials() {
      return !0;
    }
    /**
     * Stores a profile/config-supplied base URL on the shared auth state and, if
     * the caller did not pin `baseURL` via constructor option or env, adopts it
     * as this client's outbound API host. Precedence: ctor opt > env > profile >
     * hardcoded default.
     */
    _applyCredentialBaseURL(e) {
      if (!e)
        return;
      const t = e.replace(/\/+$/, "");
      this._authState.baseURL = t, this._baseURLIsExplicit || (this.baseURL = t);
    }
    /**
     * Options bag passed into the credential chain. `baseURL` here is only the
     * fallback host for the token-exchange POST when the config itself omits
     * `base_url`; the chain returns the config's own `base_url` (if any) on
     * {@link CredentialResult.baseURL}, which {@link _applyCredentialBaseURL}
     * then adopts for outbound API requests. The two are deliberately decoupled
     * so this fallback never round-trips into precedence.
     */
    _credentialResolverOptions() {
      return {
        baseURL: this.baseURL,
        fetch: this._credentialsFetch(),
        userAgent: this.getUserAgent(),
        onCacheWriteError: (e) => {
          M(this).debug("credential cache write failed (best-effort)", e);
        },
        onSafetyWarning: (e) => {
          M(this).warn(e);
        }
      };
    }
    /**
     * A `Fetch` for first-party credential token-exchange requests (OIDC
     * federation jwt-bearer grants, user-OAuth refresh grants) that routes
     * through this client's middleware chain, so middleware observes token
     * traffic like any other request. Only client-level middleware applies:
     * a minted token is shared across requests, so attributing the exchange
     * to any one request's per-request middleware would be arbitrary. For the
     * same reason, `ctx.options` is undefined for these requests.
     */
    _credentialsFetch() {
      return ya(this.fetch, this.middleware, void 0, this);
    }
    _makeTokenCache(e) {
      return new Gp(e, (t) => {
        M(this).debug("advisory token refresh failed; serving cached token", t);
      });
    }
    /**
     * Create a new client instance re-using the same options given to the
     * current client with optional overriding.
     */
    withOptions(e) {
      const t = "credentials" in e || "config" in e || "profile" in e, r = "apiKey" in e || "authToken" in e || t, i = {
        ...this._options,
        // Only forward baseURL when the caller (or env) explicitly chose it.
        // For a non-explicit parent, this.baseURL may have been mutated to the
        // profile-resolved host; pinning that as the clone's options.baseURL
        // would make _options on the clone misreport caller intent and would
        // leave the clone stuck on the parent's host across an auth override.
        // The clone instead receives the construction-time value via
        // ...this._options above and re-adopts the profile host through the
        // shared _authState.baseURL + __baseURLIsExplicit=false path.
        ...this._baseURLIsExplicit ? { baseURL: this.baseURL } : {},
        maxRetries: this.maxRetries,
        timeout: this.timeout,
        logger: this.logger,
        logLevel: this.logLevel,
        fetch: this.fetch,
        fetchOptions: this.fetchOptions,
        middleware: this.middleware,
        apiKey: this.apiKey,
        authToken: this.authToken,
        webhookKey: this.webhookKey,
        // credentials: this.credentials is a no-op when __auth is shared (the
        // ctor takes the inherited path and ignores options.credentials); when
        // overridesAuth is true via apiKey/authToken only, it lets the clone
        // build a fresh TokenCache around the parent's provider.
        credentials: this.credentials,
        // When the caller passes a structured-credential override, drop inherited
        // structured-credential options so only `...options` supplies them —
        // otherwise an inherited `credentials`/`config`/`profile` would trip the
        // mutual-exclusion check or precedence over the override.
        ...t ? { credentials: void 0, config: void 0, profile: void 0 } : {},
        ...e,
        openTelemetry: e.openTelemetry ?? c(this, dt, "f"),
        // Always set __auth so any stale value from ...this._options is
        // overwritten. undefined means "build fresh auth from these options".
        __auth: r ? void 0 : this._authState,
        __baseURLIsExplicit: "baseURL" in e ? !0 : this._baseURLIsExplicit
      };
      return new this.constructor(i);
    }
    /**
     * Lazily resolves credentials from config files or environment variables.
     * Called once from the constructor when no explicit auth is provided, or
     * when an explicit `profile` was passed (in which case a missing/unresolved
     * profile is surfaced as an error instead of falling through to "no auth").
     * The returned promise is stored and awaited on the first request.
     */
    async _resolveDefaultCredentials(e) {
      try {
        const t = await nf(this._credentialResolverOptions(), e);
        if (t)
          this._authState.provider = t.provider, this._authState.tokenCache = this._makeTokenCache(t.provider), this._authState.extraHeaders = t.extraHeaders, this._applyCredentialBaseURL(t.baseURL);
        else if (e != null)
          throw new R(`Profile "${e}" could not be resolved (no <config_dir>/configs/${e}.json found).`);
      } catch (t) {
        this._authState.error = t;
      } finally {
        this._authState.resolution = null;
      }
    }
    defaultQuery() {
      return this._options.defaultQuery;
    }
    validateHeaders({ values: e, nulls: t }) {
      if (!(e.get("x-api-key") || e.get("authorization"))) {
        if (this._authState.error)
          throw this._authState.error;
        if (!(this._authState.tokenCache || this._authState.resolution) && !(this.apiKey && e.get("x-api-key")) && !t.has("x-api-key") && !(this.authToken && e.get("authorization")) && !t.has("authorization"))
          throw new Error('Could not resolve authentication method. Expected one of apiKey, authToken, credentials, config, or profile to be set. Or for one of the "X-Api-Key" or "Authorization" headers to be explicitly omitted');
      }
    }
    _authFlags(e) {
      let t = this._requestAuthFlags.get(e);
      return t || (t = { usedTokenCache: !1, didRefreshFor401: !1 }, this._requestAuthFlags.set(e, t)), t;
    }
    async authHeaders(e) {
      if (this._authState.resolution && await this._authState.resolution, !this._authState.error) {
        if (this._authState.tokenCache && this.apiKey == null) {
          const t = await this._authState.tokenCache.getToken();
          return this._authFlags(e).usedTokenCache = !0, f([{ Authorization: `Bearer ${t}` }]);
        }
        return f([await this.apiKeyAuth(e), await this.bearerAuth(e)]);
      }
    }
    async apiKeyAuth(e) {
      if (this.apiKey != null)
        return f([{ "X-Api-Key": this.apiKey }]);
    }
    async bearerAuth(e) {
      if (this.authToken != null)
        return f([{ Authorization: `Bearer ${this.authToken}` }]);
    }
    stringifyQuery(e) {
      return Bp(e);
    }
    getUserAgent() {
      return `Anthropic/JS ${Ie}`;
    }
    makeStatusError(e, t, r, i) {
      return W.generate(e, t, r, i);
    }
    buildURL(e, t, r) {
      const i = !c(this, Kr, "m", nl).call(this) && r || this.baseURL, a = $d(e) ? new URL(e) : new URL(i + (i.endsWith("/") && e.startsWith("/") ? e.slice(1) : e)), o = this.defaultQuery(), l = Object.fromEntries(a.searchParams);
      return (!Xi(o) || !Xi(l)) && (t = { ...l, ...o, ...t }), typeof t == "object" && t && !Array.isArray(t) && (a.search = this.stringifyQuery(t)), a.toString();
    }
    _calculateNonstreamingTimeout(e) {
      if (3600 * e / 128e3 > 600)
        throw new R("Streaming is required for operations that may take longer than 10 minutes. See https://github.com/anthropics/anthropic-sdk-typescript#streaming-responses for more details");
      return 600 * 1e3;
    }
    /**
     * Used as a callback for mutating the given `FinalRequestOptions` object.
     */
    async prepareOptions(e) {
    }
    /**
     * Used as a callback for mutating the given `RequestInit` object.
     *
     * This is useful for cases where you want to add certain headers based off of
     * the request properties, e.g. `method` or `url`.
     *
     * Runs after all middleware (including {@link backendMiddleware}),
     * immediately before each underlying fetch call, so it sees exactly what
     * goes over the wire, except the trace-context headers of a traced call
     * (`traceparent`, `tracestate`, `baggage`, and any other that the registered
     * propagator writes): the client sets them again after this hook, so that a
     * signature does not cover them. Middleware may replay a request by calling
     * `next()` more than once, so this hook can run multiple times per attempt:
     * overrides must be idempotent and overwrite headers from a previous
     * invocation rather than append to them.
     */
    async prepareRequest(e, { url: t, options: r }) {
      if (this._authState.tokenCache && this.apiKey == null) {
        const i = e.headers instanceof Headers ? e.headers : new Headers(e.headers);
        for (const [o, l] of Object.entries(this._authState.extraHeaders))
          i.has(o) || i.set(o, l);
        const a = i.get("anthropic-beta")?.split(",").map((o) => o.trim());
        a?.includes(Js) || i.set("anthropic-beta", [...a ?? [], Js].join(",")), e.headers = i;
      }
    }
    /**
     * Internal {@link Middleware} composed innermost in the chain — inside both
     * client-level and per-request middleware, immediately around the underlying
     * `fetch`. Subclasses for third-party backends override this to adapt the
     * canonical Anthropic-shaped request to the backend's wire shape (URL/body
     * rewriting, request signing) and to normalize the wire response back to the
     * canonical shape (e.g. AWS EventStream to SSE).
     *
     * Running inside the user's middleware means user middleware always observes
     * canonical Anthropic-shaped traffic, and the adaptation re-runs (e.g.
     * re-signs) on every `next()` invocation, covering whatever the middleware
     * mutated. It does not see the trace-context headers of a traced call: see
     * {@link prepareRequest}.
     *
     * Errors thrown here follow the middleware error policy: they propagate to
     * the caller as-is — no retries, no `APIConnectionError` wrapping — unless
     * retryable (see {@link Middleware}); throw a `RetryableError` to opt into
     * the retry path.
     */
    backendMiddleware() {
      return [];
    }
    get(e, t) {
      return this.methodRequest("get", e, t);
    }
    post(e, t) {
      return this.methodRequest("post", e, t);
    }
    patch(e, t) {
      return this.methodRequest("patch", e, t);
    }
    put(e, t) {
      return this.methodRequest("put", e, t);
    }
    delete(e, t) {
      return this.methodRequest("delete", e, t);
    }
    methodRequest(e, t, r) {
      return this.request(Promise.resolve(r).then((i) => ({ method: e, path: t, ...i })));
    }
    request(e, t = null) {
      return this._tracer ? new di(this, this.makeTracedRequest(e, t)) : new di(this, this.makeRequest(e, t, void 0));
    }
    /**
     * Makes the request inside the call span that the SDK method started and passed in the options
     * (`__span`). The span ends here when the call fails, and otherwise when the application has
     * read the response body: see `APIPromise`.
     */
    async makeTracedRequest(e, t) {
      const r = await e, i = r.__span?.span;
      if (!i)
        return this.makeRequest(r, t, void 0);
      try {
        return await _e.with(wt.setSpan(_e.active(), i), () => this.makeRequest(r, t, void 0, i));
      } catch (a) {
        const o = { status: "error", options: r, error: a };
        throw Ns(this, i, o), j(this, () => zn(i, o)), a;
      }
    }
    async makeRequest(e, t, r, i) {
      const a = await e;
      let o = hr("maxRetries", a.maxRetries ?? this.maxRetries);
      this.isStreamBody(a.body) && (o = 0), t == null && (t = o, this._requestAuthFlags.delete(a)), await this.prepareOptions(a);
      const { req: l, url: d, timeout: p } = await this.buildRequest(a, {
        retryCount: o - t
      }), h = "log_" + (Math.random() * (1 << 24) | 0).toString(16).padStart(6, "0"), m = r === void 0 ? "" : `, retryOf: ${r}`;
      i && this.openTelemetry.propagation && (l.headers = j(this, () => Pp(i, l.headers)) ?? l.headers);
      const _ = Date.now();
      if (a.signal?.aborted)
        throw new he();
      const b = new AbortController(), y = await this.fetchWithTimeout(d, l, p, b, a, {
        requestLogID: h,
        retryOfRequestLogID: r
      }).catch(Ws), k = Date.now();
      if (y instanceof globalThis.Error) {
        ft(b);
        const T = `retrying, ${t} attempts remaining`;
        if (a.signal?.aborted)
          throw new he();
        const v = yt(y) || /timed? ?out/i.test(String(y) + ("cause" in y ? String(y.cause) : "")), S = this.middleware.length > 0 || !!a.middleware?.length || this.backendMiddleware().length > 0;
        if (S && !v && !of(y))
          throw M(this).info(`[${h}] middleware error (not retryable)`), Ve(M(this), `[${h}] middleware error (not retryable)`, {
            retryOfRequestLogID: r,
            url: d,
            durationMs: k - _,
            message: y.message
          }), y;
        if (t)
          return M(this).info(`[${h}] connection ${v ? "timed out" : "failed"} - ${T}`), Ve(M(this), `[${h}] connection ${v ? "timed out" : "failed"} (${T})`, {
            retryOfRequestLogID: r,
            url: d,
            durationMs: k - _,
            message: y.message
          }), this.retryRequest(a, t, r ?? h, i);
        throw M(this).info(`[${h}] connection ${v ? "timed out" : "failed"} - error; no more retries left`), Ve(M(this), `[${h}] connection ${v ? "timed out" : "failed"} (error; no more retries left)`, {
          retryOfRequestLogID: r,
          url: d,
          durationMs: k - _,
          message: y.message
        }), v ? new ti() : S && !Ou(y) ? y : new Ht({ cause: y });
      }
      const E = [...y.headers.entries()].filter(([T]) => T === "request-id" || T === "anthropic-workspace-id").map(([T, v]) => ", " + T + ": " + JSON.stringify(v)).join(""), A = `[${h}${m}${E}] ${l.method} ${d} ${y.ok ? "succeeded" : "failed"} with status ${y.status} in ${k - _}ms`;
      if (!y.ok) {
        const T = await this.shouldRetry(y, a);
        if (t && T) {
          const N = `retrying, ${t} attempts remaining`;
          return await Kd(y.body), ft(b), M(this).info(`${A} - ${N}`), Ve(M(this), `[${h}] response error (${N})`, {
            retryOfRequestLogID: r,
            url: y.url,
            status: y.status,
            headers: y.headers,
            durationMs: k - _
          }), this.retryRequest(a, t, r ?? h, i, y.headers);
        }
        const v = T ? "error; no more retries left" : "error; not retryable";
        M(this).info(`${A} - ${v}`);
        const S = await y.text().catch((N) => Ws(N).message), P = Ol(S), C = P ? void 0 : S;
        throw Ve(M(this), `[${h}] response error (${v})`, {
          retryOfRequestLogID: r,
          url: y.url,
          status: y.status,
          headers: y.headers,
          message: C,
          durationMs: Date.now() - _
        }), ft(b), this.makeStatusError(y.status, P, C, y.headers);
      }
      return M(this).info(A), Ve(M(this), `[${h}] response start`, {
        retryOfRequestLogID: r,
        url: y.url,
        status: y.status,
        headers: y.headers,
        durationMs: k - _
      }), Wd(y.body ?? y, b), { response: y, options: a, controller: b, requestLogID: h, retryOfRequestLogID: r, startTime: _ };
    }
    getAPIList(e, t, r) {
      return this.requestAPIList(t, r && "then" in r ? r.then((i) => ({ method: "get", path: e, ...i })) : { method: "get", path: e, ...r });
    }
    requestAPIList(e, t) {
      if (!this._tracer) {
        const i = this.makeRequest(t, null, void 0);
        return new va(this, i, e);
      }
      const r = this.makeTracedRequest(t, null);
      return new va(this, r, e);
    }
    async fetchWithTimeout(e, t, r, i, a, o) {
      const { signal: l, method: d, ...p } = t || {}, h = this._makeAbort(i);
      l && (l.addEventListener("abort", h, { once: !0 }), Fd(i, l, h));
      const m = globalThis.ReadableStream && p.body instanceof globalThis.ReadableStream || typeof p.body == "object" && p.body !== null && Symbol.asyncIterator in p.body, _ = {
        signal: i.signal,
        ...m ? { duplex: "half" } : {},
        method: "GET",
        ...p
      };
      d && (_.method = d.toUpperCase());
      const b = this.fetch, y = async (v, S) => {
        const P = setTimeout(h, r);
        try {
          return await b.call(void 0, v, S);
        } finally {
          clearTimeout(P);
        }
      }, k = a === void 0 ? y : (async (v, S = {}) => {
        const P = typeof v == "string" ? v : v instanceof URL ? v.href : v.url;
        S.headers = S.headers instanceof Headers ? S.headers : new Headers(S.headers);
        let C = [];
        a.__span && (S.headers = new Headers(S.headers), C = bu(S.headers)), await this.prepareRequest(S, { url: P, options: a }), C.length && (S.headers = f([S.headers, C]).values);
        const $ = a.__span;
        return $ && j(this, () => xp($, S.method ?? "GET", P, this.openTelemetry.traces.contentMode === "content")), o && Ve(M(this), `[${o.requestLogID}] sending request`, {
          retryOfRequestLogID: o.retryOfRequestLogID,
          method: S.method,
          url: P,
          options: a,
          headers: S.headers
        }), y(v, S);
      }), E = a?.middleware, A = a?.__span ? this.backendMiddleware().map(F_) : this.backendMiddleware(), T = E?.length || A.length ? [...this.middleware, ...E ?? [], ...A] : this.middleware;
      return await ya(k, T, a, this)(e, _);
    }
    async shouldRetry(e, t) {
      const r = this._authFlags(t);
      if (e.status === 401 && this._authState.tokenCache && r.usedTokenCache && !r.didRefreshFor401)
        return r.didRefreshFor401 = !0, this._authState.tokenCache.invalidate(), !0;
      const i = e.headers.get("x-should-retry");
      return i === "true" ? !0 : i === "false" ? !1 : e.status === 408 || e.status === 409 || e.status === 429 || e.status >= 500;
    }
    async retryRequest(e, t, r, i, a) {
      let o;
      const l = a?.get("retry-after-ms");
      if (l) {
        const p = parseFloat(l);
        Number.isNaN(p) || (o = p);
      }
      const d = a?.get("retry-after");
      if (d && !o) {
        const p = parseFloat(d);
        Number.isNaN(p) ? o = Date.parse(d) - Date.now() : o = p * 1e3;
      }
      if (o === void 0 || !(o > 0 && o <= 2 ** 31 - 1)) {
        const p = e.maxRetries ?? this.maxRetries;
        o = this.calculateDefaultRetryTimeoutMillis(t, p);
      }
      return await _t(o, e.signal ?? void 0), this.makeRequest(e, t - 1, r, i);
    }
    calculateDefaultRetryTimeoutMillis(e, t) {
      const a = t - e, o = Math.min(0.5 * Math.pow(2, a), 8), l = 1 - Math.random() * 0.25;
      return o * l * 1e3;
    }
    calculateNonstreamingTimeout(e, t) {
      if (36e5 * e / 128e3 > 6e5 || t != null && e > t)
        throw new R("Streaming is required for operations that may take longer than 10 minutes. See https://github.com/anthropics/anthropic-sdk-typescript#long-requests for more details");
      return 6e5;
    }
    async buildRequest(e, { retryCount: t = 0 } = {}) {
      const r = { ...e }, { method: i, path: a, query: o, defaultBaseURL: l } = r;
      this._authState.resolution && await this._authState.resolution, !this._baseURLIsExplicit && this._authState.baseURL && this.baseURL !== this._authState.baseURL && (this.baseURL = this._authState.baseURL);
      const d = this.buildURL(a, o, l);
      "timeout" in r && hr("timeout", r.timeout), r.timeout = r.timeout ?? this.timeout;
      const { bodyHeaders: p, body: h } = this.buildBody({ options: r }), m = await this.buildHeaders({
        options: e,
        method: i,
        bodyHeaders: p,
        retryCount: t,
        timeout: r.timeout
      });
      return { req: {
        method: i,
        headers: m,
        ...r.signal && { signal: r.signal },
        ...globalThis.ReadableStream && h instanceof globalThis.ReadableStream && { duplex: "half" },
        ...h && { body: h },
        ...this.fetchOptions ?? {},
        ...r.fetchOptions ?? {}
      }, url: d, timeout: r.timeout };
    }
    async buildHeaders({ options: e, method: t, bodyHeaders: r, retryCount: i, timeout: a }) {
      const o = f([
        {
          Accept: "application/json",
          "User-Agent": this.getUserAgent(),
          "X-Stainless-Retry-Count": String(i),
          "X-Stainless-Timeout": String(Math.trunc(a / 1e3)),
          ...Ti(),
          ...this._options.dangerouslyAllowBrowser ? { "anthropic-dangerous-direct-browser-access": "true" } : void 0,
          "anthropic-version": "2023-06-01"
        },
        await this.authHeaders(e),
        this._options.defaultHeaders,
        r,
        e.headers
      ]);
      return this.validateHeaders(o), o.values;
    }
    _makeAbort(e) {
      return () => e.abort();
    }
    buildBody({ options: { body: e, headers: t } }) {
      if (!e)
        return { bodyHeaders: void 0, body: void 0 };
      const r = f([t]);
      return (
        // Pass raw type verbatim
        ArrayBuffer.isView(e) || e instanceof ArrayBuffer || e instanceof DataView || typeof e == "string" && // Preserve legacy string encoding behavior for now
        r.values.has("content-type") || // `Blob` is superset of `File`
        globalThis.Blob && e instanceof globalThis.Blob || // `FormData` -> `multipart/form-data`
        e instanceof FormData || // `URLSearchParams` -> `application/x-www-form-urlencoded`
        e instanceof URLSearchParams || // Send chunked stream (each chunk has own `length`)
        globalThis.ReadableStream && e instanceof globalThis.ReadableStream ? { bodyHeaders: void 0, body: e } : this.isStreamBody(e) ? { bodyHeaders: void 0, body: $l(e) } : typeof e == "object" && r.values.get("content-type") === "application/x-www-form-urlencoded" ? {
          bodyHeaders: { "content-type": "application/x-www-form-urlencoded" },
          body: this.stringifyQuery(e)
        } : c(this, Es, "f").call(this, { body: e, headers: r })
      );
    }
    /**
     * Whether `body` is sent as a stream, which can be read only once:
     * a `ReadableStream`, an async iterable or an iterator.
     */
    isStreamBody(e) {
      return globalThis.ReadableStream && e instanceof globalThis.ReadableStream ? !0 : typeof e == "object" && e !== null && (Symbol.asyncIterator in e || Symbol.iterator in e && "next" in e && typeof e.next == "function");
    }
  }
  return Gr = s, Es = /* @__PURE__ */ new WeakMap(), dt = /* @__PURE__ */ new WeakMap(), Kr = /* @__PURE__ */ new WeakSet(), nl = function() {
    return this.baseURL !== "https://api.anthropic.com";
  }, s.Anthropic = Gr, s.DEFAULT_TIMEOUT = 6e5, s.AnthropicError = R, s.APIError = W, s.APIConnectionError = Ht, s.APIConnectionTimeoutError = ti, s.APIUserAbortError = he, s.NotFoundError = El, s.ConflictError = Rl, s.RateLimitError = zl, s.BadRequestError = Tl, s.AuthenticationError = Al, s.InternalServerError = Ml, s.PermissionDeniedError = xl, s.UnprocessableEntityError = Pl, s.toFile = ff, s.HUMAN_PROMPT = Ng, s.AI_PROMPT = Lg, s;
})(), Vr = /* @__PURE__ */ (() => {
  class s extends qg {
    constructor() {
      super(...arguments), this.completions = new Oc(this), this.messages = new Ea(this), this.models = new Ic(this), this.files = new Cc(this), this.skills = new Zc(this), this.userProfiles = new tl(this), this.organization = new Xc(this), this.beta = new Mc(this);
    }
  }
  return s.Completions = Oc, s.Messages = Ea, s.Models = Ic, s.Files = Cc, s.Skills = Zc, s.UserProfiles = tl, s.Organization = Xc, s.Beta = Mc, s;
})();
const Bg = {
  type: "object",
  properties: {
    translations: {
      type: "array",
      items: {
        type: "object",
        properties: { subtitle_id: { type: "string" }, translated_text: { type: "string" } },
        required: ["subtitle_id", "translated_text"],
        additionalProperties: !1
      }
    }
  },
  required: ["translations"],
  additionalProperties: !1
}, sl = (s) => /^claude-(opus|sonnet|haiku|fable|mythos)-5/.test(s), rl = (s) => /^claude-(opus-5|sonnet-5-5|fable-5)/.test(s);
class Ug {
  constructor(n) {
    if (this.o = n, !n.apiKey) throw new re("Thiếu API key Anthropic (Cài đặt → Anthropic Claude).");
    this.client = new Vr({
      apiKey: n.apiKey,
      baseURL: n.endpoint.replace(/\/+$/, "") || void 0,
      dangerouslyAllowBrowser: !0,
      maxRetries: 0,
      ...n.fetchImpl ? { fetch: n.fetchImpl } : {}
    });
  }
  id = "anthropic";
  client;
  /** Structured generation (AI Study Notes): same model, strict JSON schema output. */
  async complete(n) {
    const e = this.o.model, t = await this.call(
      {
        model: e,
        max_tokens: n.maxTokens,
        system: n.system,
        messages: [{ role: "user", content: n.user }],
        output_config: {
          ...sl(e) ? { effort: "low" } : {},
          format: { type: "json_schema", schema: n.schema }
        },
        ...rl(e) ? { betas: ["server-side-fallback-2026-07-01"], fallbacks: "default" } : {}
      },
      n.signal,
      n.onUsage
    );
    if (t.stop_reason === "refusal") throw new xe("Claude declined this request");
    return t.content.map((r) => r.type === "text" ? r.text : "").join("");
  }
  async call(n, e, t) {
    let r;
    try {
      r = await this.client.beta.messages.create(n, { signal: e });
    } catch (o) {
      if (o instanceof Vr.APIError && typeof o.status == "number") {
        const l = o.headers, d = o.status === 401 || o.status === 403 ? " (check the API key / permissions)" : o.status === 429 ? " (rate limited)" : "";
        throw new de(o.status, `Anthropic HTTP ${o.status}${d}: ${o.message.slice(0, 300)}`, Zr(l?.get?.("retry-after") ?? null));
      }
      throw o;
    }
    const i = r.usage.cache_read_input_tokens ?? 0, a = r.usage.cache_creation_input_tokens ?? 0;
    return t?.({
      inputTokens: (r.usage.input_tokens ?? 0) + i + a,
      outputTokens: r.usage.output_tokens ?? 0,
      cachedInputTokens: i || void 0,
      cacheWriteTokens: a || void 0
    }), r;
  }
  async translateBatch(n) {
    const e = this.o.model;
    let t;
    try {
      t = await this.client.beta.messages.create(
        {
          model: e,
          max_tokens: 16e3,
          system: ki,
          messages: [{ role: "user", content: Si(n) }],
          output_config: {
            ...sl(e) ? { effort: "low" } : {},
            // speed-first
            format: { type: "json_schema", schema: Bg }
          },
          ...rl(e) ? { betas: ["server-side-fallback-2026-07-01"], fallbacks: "default" } : {}
        },
        { signal: n.signal }
      );
    } catch (o) {
      if (o instanceof Vr.APIError && typeof o.status == "number") {
        const l = o.headers, d = o.status === 401 || o.status === 403 ? " (check the API key / permissions)" : o.status === 429 ? " (rate limited)" : "";
        throw new de(o.status, `Anthropic HTTP ${o.status}${d}: ${o.message.slice(0, 300)}`, Zr(l?.get?.("retry-after") ?? null));
      }
      throw o;
    }
    const r = t.usage.cache_read_input_tokens ?? 0, i = t.usage.cache_creation_input_tokens ?? 0;
    if (n.onUsage?.({
      inputTokens: (t.usage.input_tokens ?? 0) + r + i,
      outputTokens: t.usage.output_tokens ?? 0,
      cachedInputTokens: r || void 0,
      cacheWriteTokens: i || void 0
    }), t.stop_reason === "refusal") throw new xe("Claude declined this batch");
    const a = t.content.map((o) => o.type === "text" ? o.text : "").join("");
    return tr(er(a), n.segments.map((o) => o.id));
  }
}
function il(s, n, e) {
  const t = yl(n, s.kind, s.kind);
  switch (s.kind) {
    case "anthropic":
      return new Ug({ endpoint: s.endpoint, model: s.model, apiKey: t, fetchImpl: e });
    case "openai":
      return new Od({ endpoint: s.endpoint, model: s.model, apiKey: t, temperature: s.temperature, fetchImpl: e });
    case "gemini":
      return new xd({ endpoint: s.endpoint, model: s.model, apiKey: t, temperature: s.temperature, fetchImpl: e });
    case "local":
      return new zd({ endpoint: s.endpoint, model: s.model, apiKey: t, fetchImpl: e });
    case "mock":
    default:
      return new Md(150);
  }
}
const jg = (s) => typeof s?.complete == "function", al = {
  fast: { firstBatchSize: 3, batchSize: 8, backgroundBatchSize: 12, lookAheadSec: 45, contextSize: 1 },
  balanced: { firstBatchSize: 4, batchSize: 10, backgroundBatchSize: 16, lookAheadSec: 90, contextSize: 3 },
  quality: { firstBatchSize: 4, batchSize: 12, backgroundBatchSize: 20, lookAheadSec: 120, contextSize: 6 }
};
function Fg(s) {
  return al[s ?? "balanced"] ?? al.balanced;
}
function Wg(s) {
  return mt(
    [
      s.provider.kind,
      s.provider.endpoint,
      s.provider.model,
      s.provider.temperature,
      s.provider.kind === "gemini" && ei(s.provider.model) ? "think:minimal" : "",
      Sd,
      yd(s.glossary),
      "en",
      "vi",
      s.mergeFragments ? "merge" : "nomerge"
    ].join("|")
  );
}
function Hg(s, n, e) {
  return `${s}|${mt(n)}|${mt(e.trim().toLowerCase())}:${e.length}`;
}
class Dg {
  requests = 0;
  failedRequests = 0;
  retries = 0;
  rateLimited = 0;
  segmentsTranslated = 0;
  cacheHits = 0;
  cacheMisses = 0;
  inputTokens = 0;
  outputTokens = 0;
  /** Cost of tokens with a known model price (USD). */
  estimatedCostUsd = 0;
  pricedModel = !0;
  latencies = [];
  recordUsage(n, e, t) {
    this.inputTokens += e, this.outputTokens += t;
    const r = Rd(n, e, t);
    r === null ? this.pricedModel = !1 : this.estimatedCostUsd += r;
  }
  recordLatency(n) {
    this.latencies.push(n), this.latencies.length > 200 && this.latencies.shift();
  }
  snapshot() {
    const n = this.latencies.length ? this.latencies.reduce((e, t) => e + t, 0) / this.latencies.length : 0;
    return {
      requests: this.requests,
      failedRequests: this.failedRequests,
      retries: this.retries,
      rateLimited: this.rateLimited,
      segmentsTranslated: this.segmentsTranslated,
      cacheHits: this.cacheHits,
      cacheMisses: this.cacheMisses,
      avgLatencyMs: Math.round(n),
      medianLatencyMs: Math.round(Qr(this.latencies, 50)),
      p95LatencyMs: Math.round(Qr(this.latencies, 95)),
      inputTokens: this.inputTokens,
      outputTokens: this.outputTokens,
      estimatedCostUsd: this.pricedModel ? Math.round(this.estimatedCostUsd * 1e6) / 1e6 : null
    };
  }
}
class Kg {
  constructor(n) {
    this.deps = n, this.queue = new kd({
      ...n.queueOptions,
      onEvent: (e, t) => {
        t && n.onAccounting?.(e, t), e.type === "request" ? this.metrics.requests++ : e.type === "success" ? (this.metrics.segmentsTranslated += e.size, this.metrics.recordLatency(e.latencyMs)) : e.type === "retry" ? this.metrics.retries++ : e.type === "rate-limited" ? this.metrics.rateLimited++ : e.type === "failure" ? this.metrics.failedRequests++ : e.type === "usage" && this.metrics.recordUsage(t?.model ?? this.currentModel, e.usage.inputTokens, e.usage.outputTokens), n.queueOptions?.onEvent?.(e);
      }
    });
  }
  metrics = new Dg();
  queue;
  currentModel = "";
  writesSincePrune = 0;
  async checkConfig(n) {
    if (gl(n) && !n.consent.remoteTranslation)
      throw new re(
        'Chưa cho phép gửi phụ đề tới dịch vụ dịch từ xa. Mở Cài đặt → bật "Cho phép gửi phụ đề" (remote translation consent required).'
      );
    if (n.provider.kind !== "mock" && this.deps.hasEndpointPermission && !await this.deps.hasEndpointPermission(n.provider.endpoint))
      throw new re('Chưa cấp quyền truy cập endpoint dịch. Mở Cài đặt và bấm "Lưu" để cấp quyền (host permission missing).');
  }
  async translateUnits(n, e, t, r = 2, i = "subtitle") {
    const a = await this.deps.getSettings(), o = this.deps.getGlossaryText ? await this.deps.getGlossaryText(a).catch(() => a.glossary) : a.glossary, l = { ...a, glossary: o, provider: ur(a) };
    this.currentModel = l.provider.kind === "mock" ? "mock" : l.provider.model;
    try {
      await this.checkConfig(l);
    } catch (y) {
      return e.map((k) => ({ id: k.id, error: y.message, fatal: !0 }));
    }
    const d = Wg(l), p = e.map((y) => ({ ...y, key: Hg(d, n, y.text) }));
    let h = /* @__PURE__ */ new Map();
    try {
      h = await this.deps.cache.getMany(p.map((y) => y.key));
    } catch {
    }
    const m = /* @__PURE__ */ new Map(), _ = p.filter((y) => {
      const k = h.get(y.key);
      return k !== void 0 ? (m.set(y.id, { id: y.id, vi: k, cached: !0 }), !1) : !0;
    });
    this.metrics.cacheHits += p.length - _.length, this.metrics.cacheMisses += _.length;
    const b = { provider: l.provider.kind, model: this.currentModel, lesson: mt(n) };
    if (this.deps.onAccounting?.({ type: "cache", hits: p.length - _.length, misses: _.length }, b), _.length) {
      const y = await this.deps.getSecrets();
      let k;
      try {
        k = this.deps.providerFactory ? this.deps.providerFactory(l, y) : il(l.provider, y);
      } catch (T) {
        for (const v of _) m.set(v.id, { id: v.id, error: T.message, fatal: !0 });
        return e.map((v) => m.get(v.id));
      }
      const E = await this.queue.translate(
        _.map((T) => ({ key: T.key, text: T.text })),
        {
          provider: k,
          context: t.slice(-Math.max(0, Fg(l.translationMode).contextSize)),
          glossary: vl(l.glossary),
          group: n,
          priority: r,
          meta: b,
          format: i
        }
      ), A = [];
      for (const T of _) {
        const v = E.get(T.key);
        if (v?.vi !== void 0)
          m.set(T.id, { id: T.id, vi: v.vi }), A.push({ key: T.key, videoKey: n, vi: v.vi });
        else {
          const S = v?.error, P = S instanceof re || S instanceof de && (S.status === 401 || S.status === 403 || S.status === 404 || S.status === 400);
          m.set(T.id, { id: T.id, error: S?.message ?? "Translation failed", fatal: P });
        }
      }
      this.deps.cache.putMany(A).catch(() => {
      }), this.writesSincePrune += A.length, this.writesSincePrune >= 500 && (this.writesSincePrune = 0, this.deps.cache.prune().catch(() => {
      }));
    }
    return e.map((y) => m.get(y.id));
  }
  /** Provider/model the next request would use (shown before generating notes). */
  async activeModel() {
    const n = await this.deps.getSettings(), e = ur(n);
    return { provider: e.kind, model: e.kind === "mock" ? "mock" : e.model };
  }
  /**
   * One structured generation request with the CURRENT provider/model (never switched),
   * the same consent + host-permission checks as subtitles, low queue priority and
   * ledger accounting. Used by AI Study Notes.
   */
  async complete(n, e) {
    const t = await this.deps.getSettings(), r = { ...t, provider: ur(t) };
    await this.checkConfig(r);
    const i = await this.deps.getSecrets(), a = this.deps.providerFactory ? this.deps.providerFactory(r, i) : il(r.provider, i);
    if (!jg(a)) throw new re("Nhà cung cấp hiện tại không hỗ trợ tạo ghi chú.");
    const o = r.provider.kind === "mock" ? "mock" : r.provider.model, l = { provider: r.provider.kind, model: o, lesson: e.lesson, kind: "notes" };
    return this.queue.runTask((d, p) => a.complete({ ...n, signal: d, onUsage: p }), {
      priority: e.priority ?? 9,
      signal: e.signal,
      meta: l,
      estimate: (d) => ({ inputTokens: Math.ceil((n.system.length + n.user.length) / 4), outputTokens: Math.ceil(d.length / 3), estimated: !0 })
    });
  }
  cancel(n) {
    this.queue.cancelGroup(n);
  }
}
const Rs = "tabRegistry", ol = () => ({ active: !1, chunks: 0, droppedChunks: 0 });
class Gg {
  constructor(n) {
    this.store = n, this.loaded = this.load();
  }
  tabs = /* @__PURE__ */ new Map();
  loaded;
  saveTimer;
  async load() {
    try {
      const e = (await this.store.get(Rs))[Rs] ?? {};
      for (const [t, r] of Object.entries(e)) this.tabs.set(Number(t), r);
    } catch {
    }
  }
  ready() {
    return this.loaded;
  }
  persist() {
    clearTimeout(this.saveTimer), this.saveTimer = setTimeout(() => {
      const n = {};
      for (const [e, t] of this.tabs) n[e] = t;
      this.store.set({ [Rs]: n }).catch(() => {
      });
    }, 100);
  }
  /** Flush pending writes immediately (tests / shutdown). */
  async flush() {
    clearTimeout(this.saveTimer);
    const n = {};
    for (const [e, t] of this.tabs) n[e] = t;
    await this.store.set({ [Rs]: n });
  }
  rec(n) {
    let e = this.tabs.get(n);
    return e || (e = { isSkool: !1, frames: {}, audio: ol() }, this.tabs.set(n, e)), e;
  }
  setSkool(n, e) {
    this.rec(n).isSkool = e, this.persist();
  }
  updateFrame(n, e, t) {
    this.rec(n).frames[e] = { ...t, frameId: e }, this.persist();
  }
  removeFrame(n, e) {
    const t = this.tabs.get(n);
    t && (delete t.frames[e], e === 0 && (t.frames = {}), this.persist());
  }
  setAudio(n, e) {
    const t = this.rec(n);
    return t.audio = { ...t.audio, ...e }, this.persist(), t.audio;
  }
  removeTab(n) {
    this.tabs.delete(n), this.persist();
  }
  tabIds() {
    return [...this.tabs.keys()];
  }
  /** Frame that should display subtitles: largest real <video>, else the top frame. */
  primaryFrame(n) {
    const e = this.tabs.get(n);
    if (!e) return null;
    const t = Object.values(e.frames), r = t.filter((o) => o.targetKind === "video").sort((o, l) => l.targetArea - o.targetArea);
    if (r.length) return r[0].frameId;
    const i = t.find((o) => o.targetKind === "media");
    if (i) return i.frameId;
    const a = t.find((o) => o.targetKind === "iframe");
    return a ? a.frameId : t.length ? 0 : null;
  }
  get(n) {
    const e = this.tabs.get(n) ?? { isSkool: !1, frames: {}, audio: ol() };
    return {
      tabId: n,
      isSkool: e.isSkool,
      frames: Object.values(e.frames).sort((t, r) => t.frameId - r.frameId),
      primaryFrameId: this.primaryFrame(n),
      audio: e.audio
    };
  }
}
class Vg {
  constructor(n, e, t, r = fetch) {
    if (this.endpoint = n, this.model = e, this.apiKey = t, this.fetchImpl = r, !n) throw new re("STT endpoint is not configured");
  }
  id = "openai-stt";
  async transcribe(n) {
    const e = new FormData();
    e.append("file", new Blob([n.wav], { type: "audio/wav" }), "chunk.wav"), e.append("model", this.model), e.append("language", n.language), e.append("response_format", "json"), e.append("temperature", "0"), n.prompt && e.append("prompt", n.prompt.slice(-200));
    const t = {};
    this.apiKey && (t.Authorization = `Bearer ${this.apiKey}`);
    const r = await this.fetchImpl(this.endpoint.replace(/\/+$/, "") + "/audio/transcriptions", {
      method: "POST",
      headers: t,
      body: e,
      signal: n.signal
    });
    await Qe(r, "STT");
    const i = await r.json();
    return { text: (i.text ?? "").trim(), segments: i.segments };
  }
}
class Jg {
  constructor(n, e, t = fetch) {
    if (this.endpoint = n, this.apiKey = e, this.fetchImpl = t, !n) throw new re("Local STT endpoint is not configured");
  }
  id = "local-stt";
  async transcribe(n) {
    const e = { "Content-Type": "audio/wav", "X-Language": n.language };
    n.prompt && (e["X-Prompt"] = encodeURIComponent(n.prompt.slice(-200))), this.apiKey && (e.Authorization = `Bearer ${this.apiKey}`);
    const t = await this.fetchImpl(this.endpoint.replace(/\/+$/, "") + "/transcribe", {
      method: "POST",
      headers: e,
      body: n.wav,
      signal: n.signal
    });
    return await Qe(t, "Local STT"), { text: ((await t.json()).text ?? "").trim() };
  }
}
class Yg {
  id = "mock-stt";
  n = 0;
  async transcribe() {
    return this.n++, { text: `This is mock speech segment number ${this.n}.` };
  }
}
function Xg(s, n, e) {
  switch (s.kind) {
    case "openai":
      return new Vg(s.endpoint, s.model, n.sttApiKey, e);
    case "local":
      return new Jg(s.endpoint, n.sttApiKey, e);
    default:
      return new Yg();
  }
}
const Qg = [
  /^thanks? (you )?for watching[.!]*$/i,
  /^thank you[.!]*$/i,
  /^please subscribe.*$/i,
  /^subtitles? by .*$/i,
  /^\[?(music|applause|silence|blank_audio)\]?$/i,
  /^you$/i,
  /^\.+$/
];
function Zg(s, n) {
  const e = s.trim();
  return e ? n < 0.02 && Qg.some((t) => t.test(e)) : !0;
}
class em {
  constructor(n = 4, e = 3) {
    this.minWords = n, this.maxHoldSec = e;
  }
  seq = 0;
  pending = null;
  lastWords = [];
  push(n, e, t, r = 1) {
    let i = n.replace(/\s+/g, " ").trim();
    if (Zg(i, r)) return this.pending && t - this.pending.startSec > this.maxHoldSec ? this.flush() : [];
    if (i = this.dropOverlap(i), !i) return [];
    const a = [];
    let o;
    this.pending ? (o = { ...this.pending, text: `${this.pending.text} ${i}`, endSec: t }, this.pending = null) : o = { id: "", text: i, startSec: e, endSec: t };
    const l = o.text.split(" ").length;
    return !/[.!?…]["')\]]?$/.test(o.text) && l < this.minWords && t - o.startSec < this.maxHoldSec ? (this.pending = o, a) : (o.id = `live-${++this.seq}`, this.remember(o.text), a.push(o), a);
  }
  /** Emit any held fragment (on timeout or stop). */
  flush() {
    if (!this.pending) return [];
    const n = { ...this.pending, id: `live-${++this.seq}` };
    return this.pending = null, this.remember(n.text), [n];
  }
  get hasPending() {
    return !!this.pending;
  }
  remember(n) {
    this.lastWords = n.split(" ").slice(-8);
  }
  dropOverlap(n) {
    const e = n.split(" "), t = (r) => r.toLowerCase().replace(/[^\p{L}\p{N}']/gu, "");
    for (let r = Math.min(6, this.lastWords.length, e.length - 1); r >= 2; r--) {
      const i = this.lastWords.slice(-r).map(t).join(" "), a = e.slice(0, r).map(t).join(" ");
      if (i === a) return e.slice(r).join(" ");
    }
    return n;
  }
}
const tm = 2, nm = 3, Ps = "audioSession";
class sm {
  constructor(n) {
    this.d = n, this.restored = this.restore();
  }
  session = null;
  restored;
  now() {
    return (this.d.now ?? Date.now)();
  }
  /** After a service-worker restart, re-attach to a session the offscreen doc still runs. */
  async restore() {
    const e = (await this.d.sessionStore?.get(Ps).catch(() => ({})))?.[Ps];
    e && (this.session = this.newSession(e.id, e.tabId, e.startedAt));
  }
  newSession(n, e, t) {
    return {
      id: n,
      tabId: e,
      startedAt: t,
      assembler: new em(),
      context: [],
      sttInFlight: 0,
      consecutiveFailures: 0,
      abort: new AbortController(),
      sttLatencies: [],
      totalLatencies: [],
      nextSeqToEmit: 0,
      readyBySeq: /* @__PURE__ */ new Map(),
      seenAny: !1
    };
  }
  get active() {
    return this.session ? { id: this.session.id, tabId: this.session.tabId } : null;
  }
  async start(n, e) {
    await this.restored;
    const t = await this.d.getSettings();
    if (ml(t) && !t.consent.remoteAudio)
      throw new Error("Chưa cho phép gửi âm thanh tới dịch vụ STT từ xa. Bật trong Cài đặt → Quyền riêng tư (remote audio consent required).");
    if (t.stt.kind !== "mock" && this.d.hasEndpointPermission && !await this.d.hasEndpointPermission(t.stt.endpoint))
      throw new Error('Chưa cấp quyền truy cập endpoint STT. Mở Cài đặt và bấm "Lưu".');
    this.session && await this.stop(this.session.tabId, "replaced");
    const r = `a${this.now().toString(36)}${Math.random().toString(36).slice(2, 6)}`;
    this.session = this.newSession(r, n, this.now()), await this.d.sessionStore?.set({ [Ps]: { id: r, tabId: n, startedAt: this.session.startedAt } }), this.d.registry.setAudio(n, { active: !0, sessionId: r, startedAt: this.session.startedAt, error: void 0, chunks: 0, droppedChunks: 0 }), this.d.setBadge(n, "REC"), await this.d.ensureOffscreen(), await this.d.sendOffscreen({ type: "start", streamId: e, sessionId: r }), await this.notifyState(n, !0);
  }
  async stop(n, e = "user", t) {
    await this.restored;
    const r = this.session;
    !r || n !== void 0 && r.tabId !== n || (this.session = null, r.abort.abort(), clearTimeout(r.holdTimer), await this.d.sessionStore?.set({ [Ps]: null }).catch(() => {
    }), await this.d.sendOffscreen({ type: "stop" }).catch(() => {
    }), await this.d.closeOffscreen().catch(() => {
    }), this.d.setBadge(r.tabId, ""), this.d.registry.setAudio(r.tabId, { active: !1, error: t }), await this.notifyState(r.tabId, !1, t));
  }
  async notifyState(n, e, t) {
    const r = this.d.registry.primaryFrame(n), i = this.d.registry.get(n);
    await Promise.all(
      (i.frames.length ? i.frames : [{ frameId: 0 }]).map(
        (a) => this.d.sendToFrame(n, a.frameId, { type: "audio:state", active: e, primary: a.frameId === (r ?? 0), error: t })
      )
    );
  }
  async onOffscreenError(n, e) {
    await this.restored, this.session?.id === n && await this.stop(this.session.tabId, "error", e);
  }
  async onOffscreenStopped(n, e) {
    await this.restored, this.session?.id === n && await this.stop(this.session.tabId, e, e === "ended" ? "Âm thanh tab đã dừng (tab đóng hoặc điều hướng)." : void 0);
  }
  async onChunk(n) {
    await this.restored;
    const e = this.session;
    if (!e || e.id !== n.sessionId) return;
    const t = this.d.registry.setAudio(e.tabId, {});
    if (this.d.registry.setAudio(e.tabId, { chunks: t.chunks + 1 }), !e.seenAny && n.seq > e.nextSeqToEmit && (e.nextSeqToEmit = n.seq), e.seenAny = !0, e.sttInFlight >= tm + 1) {
      this.d.registry.setAudio(e.tabId, { droppedChunks: t.droppedChunks + 1 }), e.readyBySeq.set(n.seq, null), this.drain(e);
      return;
    }
    e.sttInFlight++;
    const r = await this.d.getSettings(), i = await this.d.getSecrets();
    let a = "";
    try {
      const o = (this.d.sttFactory ?? ((d, p) => Xg(d.stt, p)))(r, i);
      a = await this.transcribeWithRetry(o, hd(n.wavBase64), e), e.consecutiveFailures = 0;
      const l = this.now() - n.endedAt;
      e.sttLatencies.push(l), e.sttLatencies.length > 30 && e.sttLatencies.shift(), this.d.registry.setAudio(e.tabId, { sttLatencyMs: cl(e.sttLatencies), error: void 0 });
    } catch (o) {
      if (e.abort.signal.aborted) return;
      e.consecutiveFailures++;
      const l = `Lỗi nhận dạng giọng nói (STT): ${o.message}`;
      if (this.d.registry.setAudio(e.tabId, { error: l }), e.consecutiveFailures >= nm || o instanceof de && (o.status === 401 || o.status === 403)) {
        await this.stop(e.tabId, "error", l + " — Audio Mode đã dừng. Kiểm tra backend STT trong Cài đặt.");
        return;
      }
    } finally {
      e.sttInFlight--;
    }
    e.readyBySeq.set(n.seq, a ? { text: a, startSec: n.startSec, endSec: n.endSec, rms: n.rms, endedAt: n.endedAt } : null), this.drain(e);
  }
  async transcribeWithRetry(n, e, t) {
    let r;
    for (let i = 0; i < 2; i++)
      try {
        return (await n.transcribe({ wav: e, language: "en", prompt: t.context.slice(-2).join(" "), signal: t.abort.signal })).text;
      } catch (a) {
        if (r = a, t.abort.signal.aborted || a instanceof de && !a.retryable) throw a;
        await new Promise((o) => setTimeout(o, a instanceof de && a.retryAfterMs ? Math.min(a.retryAfterMs, 3e3) : 600));
      }
    throw r;
  }
  /** Emit transcripts strictly in capture order. */
  drain(n) {
    for (; n.readyBySeq.has(n.nextSeqToEmit); ) {
      const e = n.readyBySeq.get(n.nextSeqToEmit);
      if (n.readyBySeq.delete(n.nextSeqToEmit), n.nextSeqToEmit++, !e) continue;
      const t = n.assembler.push(e.text, e.startSec, e.endSec, e.rms);
      for (const r of t) this.emitSegment(n, r, e.endedAt);
      clearTimeout(n.holdTimer), n.assembler.hasPending && (n.holdTimer = setTimeout(() => {
        for (const r of n.assembler.flush()) this.emitSegment(n, r, e.endedAt);
      }, 2500));
    }
  }
  async emitSegment(n, e, t) {
    const r = this.d.registry.primaryFrame(n.tabId);
    await this.d.sendToFrame(n.tabId, r, { type: "live:segment", id: e.id, en: e.text, final: !1 });
    const i = n.context.slice(-3);
    n.context.push(e.text), n.context.length > 10 && n.context.shift();
    const a = await this.d.translate(`audio:${n.id}`, e.text, e.id, i);
    this.session === n && (a.vi ? (n.totalLatencies.push(this.now() - t), n.totalLatencies.length > 30 && n.totalLatencies.shift(), this.d.registry.setAudio(n.tabId, { totalLatencyMs: cl(n.totalLatencies) }), await this.d.sendToFrame(n.tabId, r, { type: "live:segment", id: e.id, en: e.text, vi: a.vi, final: !0 })) : a.error && this.d.registry.setAudio(n.tabId, { error: `Lỗi dịch: ${a.error}` }));
  }
}
const cl = (s) => s.length ? Math.round(s.reduce((n, e) => n + e, 0) / s.length) : void 0;
async function ll(s, n) {
  const e = new AbortController(), t = setTimeout(() => e.abort(), n.timeoutMs ?? 2500);
  try {
    return (await (n.fetchImpl ?? fetch)(s, { signal: e.signal })).ok;
  } catch {
    return !1;
  } finally {
    clearTimeout(t);
  }
}
async function ul(s, n, e, t, r, i) {
  if (s === "mock") return { state: "mock" };
  if (e && !t) return { state: "no-consent" };
  if (!await i.hasPermission(n)) return { state: "no-permission" };
  const a = n.replace(/\/+$/, "");
  return s === "local" ? await ll(a + "/health", i) ? { state: "ready" } : { state: "unreachable", detail: a } : wi(n) ? await ll(a + "/models", i) ? { state: "ready" } : { state: "unreachable", detail: a } : r ? { state: "configured" } : { state: "no-key" };
}
async function rm(s, n, e) {
  const [t, r] = await Promise.all([
    ul(s.provider.kind, s.provider.endpoint, gl(s), s.consent.remoteTranslation, !!yl(n, s.provider.kind, s.provider.kind), e),
    ul(s.stt.kind, s.stt.endpoint, ml(s), s.consent.remoteAudio, !!n.sttApiKey, e)
  ]);
  return { translation: t, stt: r };
}
const Jr = "glossaryCompiled";
async function id(s) {
  try {
    const n = await chrome.storage.local.get(Jr);
    return typeof n[Jr] == "string" ? n[Jr] : s;
  } catch {
    return s;
  }
}
const Ge = () => ({
  requests: 0,
  failed: 0,
  retries: 0,
  rateLimited: 0,
  segments: 0,
  inputTokens: 0,
  outputTokens: 0,
  cachedInputTokens: 0,
  cacheWriteTokens: 0,
  reasoningTokens: 0,
  estimatedInputTokens: 0,
  estimatedOutputTokens: 0,
  unpricedTokens: 0,
  costUsd: 0,
  estimatedCostUsd: 0,
  cacheHits: 0,
  cacheMisses: 0,
  latencyMsTotal: 0,
  latencyCount: 0
}), zs = "usageLedger", Ms = "usageSession", dl = 300, im = 120;
class am {
  constructor(n, e, t, r = Date.now) {
    this.local = n, this.sessionArea = e, this.getPricing = t, this.now = r, this.loaded = this.load();
  }
  data = { version: 1, total: Ge(), days: {}, models: {}, lessons: {} };
  session = { bucket: Ge(), latencies: [], lastError: null, lastErrorAt: null };
  loaded;
  timer;
  async load() {
    try {
      const [n, e] = await Promise.all([this.local.get(zs), this.sessionArea.get(Ms)]);
      n[zs] && (this.data = n[zs]), e[Ms] && (this.session = e[Ms]);
    } catch {
    }
  }
  ready() {
    return this.loaded;
  }
  day() {
    return new Date(this.now()).toISOString().slice(0, 10);
  }
  buckets(n = {}) {
    const e = this.day(), t = [this.data.total, this.data.days[e] ??= Ge(), this.session.bucket];
    if (n.provider && n.model && t.push(this.data.models[`${n.provider}:${n.model}`] ??= Ge()), n.lesson) {
      const r = this.data.lessons[n.lesson] ??= { ...Ge(), lastSeen: 0 };
      r.lastSeen = this.now(), t.push(r);
    }
    return t;
  }
  async record(n, e = {}) {
    await this.loaded;
    const t = n.type === "usage" ? await this.getPricing() : [], r = this.buckets(e);
    for (const i of r)
      switch (n.type) {
        case "request":
          i.requests++;
          break;
        case "success":
          i.segments += n.size, i.latencyMsTotal += n.latencyMs, i.latencyCount++;
          break;
        case "retry":
          i.retries++;
          break;
        case "rate-limited":
          i.rateLimited++;
          break;
        case "failure":
          i.failed++;
          break;
        case "cache":
          i.cacheHits += n.hits, i.cacheMisses += n.misses;
          break;
        case "usage": {
          const a = n.usage, o = kl(e.model ?? "", a, t);
          a.estimated ? (i.estimatedInputTokens += a.inputTokens, i.estimatedOutputTokens += a.outputTokens, o !== null && (i.estimatedCostUsd += o)) : (i.inputTokens += a.inputTokens, i.outputTokens += a.outputTokens, i.cachedInputTokens += a.cachedInputTokens ?? 0, i.cacheWriteTokens += a.cacheWriteTokens ?? 0, i.reasoningTokens += a.reasoningTokens ?? 0, o !== null && (i.costUsd += o)), o === null && (i.unpricedTokens += a.inputTokens + a.outputTokens);
          break;
        }
      }
    n.type === "success" && (this.session.latencies.push(n.latencyMs), this.session.latencies.length > 200 && this.session.latencies.shift()), n.type === "failure" && (this.session.lastError = n.reason.slice(0, 200), this.session.lastErrorAt = this.now()), this.persistSoon();
  }
  prune() {
    const n = Object.entries(this.data.lessons);
    if (n.length > dl) {
      n.sort((t, r) => t[1].lastSeen - r[1].lastSeen);
      for (const [t] of n.slice(0, n.length - dl)) delete this.data.lessons[t];
    }
    const e = Object.keys(this.data.days).sort();
    for (const t of e.slice(0, Math.max(0, e.length - im))) delete this.data.days[t];
  }
  persistSoon() {
    clearTimeout(this.timer), this.timer = setTimeout(() => void this.flush(), 1e3);
  }
  async flush() {
    clearTimeout(this.timer), this.prune(), await Promise.all([this.local.set({ [zs]: this.data }), this.sessionArea.set({ [Ms]: this.session })]).catch(() => {
    });
  }
  async snapshot() {
    await this.loaded;
    const n = this.session.latencies;
    return {
      total: this.data.total,
      today: this.data.days[this.day()] ?? Ge(),
      session: this.session.bucket,
      models: this.data.models,
      lessons: this.data.lessons,
      sessionP95LatencyMs: Math.round(Qr(n, 95)),
      sessionAvgLatencyMs: n.length ? Math.round(n.reduce((e, t) => e + t, 0) / n.length) : 0,
      lastError: this.session.lastError
    };
  }
  async reset() {
    await this.loaded, this.data = { version: 1, total: Ge(), days: {}, models: {}, lessons: {} }, this.session = { bucket: Ge(), latencies: [], lastError: null, lastErrorAt: null }, await this.flush();
  }
}
function yi(s) {
  const n = Math.max(0, Math.floor(s)), e = Math.floor(n / 3600), t = Math.floor(n % 3600 / 60), r = String(n % 60).padStart(2, "0");
  return e ? `${e}:${String(t).padStart(2, "0")}:${r}` : `${t}:${r}`;
}
const om = "n1", Me = { type: "string" }, Us = { type: "array", items: Me }, js = (s) => ({ type: "object", properties: s, required: Object.keys(s), additionalProperties: !1 }), Os = js({ text: Me, refs: Us }), cm = js({
  title: Me,
  summary: Me,
  objectives: Us,
  concepts: { type: "array", items: js({ term: Me, explanation: Me, refs: Us }) },
  insights: { type: "array", items: Os },
  steps: { type: "array", items: Os },
  terminology: { type: "array", items: js({ term: Me, vi: Me, explanation: Me }) },
  takeaways: { type: "array", items: Os },
  checklist: Us,
  moments: { type: "array", items: Os }
}), lm = (s = "") => ({
  title: s,
  summary: "",
  objectives: [],
  concepts: [],
  insights: [],
  steps: [],
  terminology: [],
  takeaways: [],
  checklist: [],
  moments: []
}), ze = (s, n = 2e3) => typeof s == "string" ? s.trim().slice(0, n) : "", xn = (s, n) => Array.isArray(s) ? s.slice(0, n) : [];
function hl(s, n, e) {
  const t = s && typeof s == "object" ? s : {}, r = (o) => {
    const l = [];
    for (const d of xn(o, 6)) {
      const p = typeof d == "string" ? n(d.trim().replace(/^\[|\]$/g, "").split(/\s+/)[0]) : null;
      p && !l.includes(p) && l.push(p);
    }
    return l;
  }, i = (o, l = 40) => xn(o, l).map((d) => {
    const p = d && typeof d == "object" ? d : { text: d };
    return { text: ze(p.text), refs: r(p.refs) };
  }).filter((d) => d.text), a = (o, l = 30) => xn(o, l).map((d) => ze(d, 600)).filter(Boolean);
  return {
    title: ze(t.title, 200) || e,
    summary: ze(t.summary, 4e3),
    objectives: a(t.objectives),
    concepts: xn(t.concepts, 40).map((o) => {
      const l = o ?? {};
      return { term: ze(l.term, 200), explanation: ze(l.explanation), refs: r(l.refs) };
    }).filter((o) => o.term && o.explanation),
    insights: i(t.insights),
    steps: i(t.steps, 60),
    terminology: xn(t.terminology, 60).map((o) => {
      const l = o ?? {};
      return { term: ze(l.term, 200), vi: ze(l.vi, 300), explanation: ze(l.explanation, 1e3) };
    }).filter((o) => o.term),
    takeaways: i(t.takeaways),
    checklist: a(t.checklist, 40),
    moments: i(t.moments, 40)
  };
}
const um = {
  singleCallChars: 24e3,
  chunkChars: 14e3,
  maxChunks: 16,
  maxTotalChars: 4e5,
  mergeFanIn: 6,
  chunkOutputTokens: 3e3,
  finalOutputTokens: 8e3
}, dm = `You write study notes for ONE lesson of an online course the learner is enrolled in (marketing, digital advertising, e-commerce, software, business, AI and automation).

Rules:
- Write every note in natural, clear Vietnamese.
- Use ONLY information stated in the provided lesson content. Never add facts, numbers, tools, examples, opinions or claims that are not in it. If a section has no supporting content, return an empty string or empty array for it.
- Keep technical names, product names, code, URLs, commands and meaningful English terms exactly as written (e.g. Mass Desire, Market Awareness, VOC, Psychographics, Research Framework, Hook, MSL, Ad Creative, AI Agent, Workflow) and explain them in Vietnamese as the instructor uses them.
- "refs": cite 1–3 labels (like "S12") copied EXACTLY from the lesson lines that support the item. Never invent labels. Use [] when unsure.
- "terminology": term as written, "vi" = short Vietnamese equivalent (or the same term if it is normally kept in English), "explanation" in Vietnamese.
- "moments": the most important points in lesson order, each with refs.
- Return ONLY a JSON object with exactly these keys: title, summary, objectives[], concepts[{term,explanation,refs[]}], insights[{text,refs[]}], steps[{text,refs[]}], terminology[{term,vi,explanation}], takeaways[{text,refs[]}], checklist[], moments[{text,refs[]}].`;
function hm(s) {
  const n = s.kind === "video";
  return [...s.segments].sort((e, t) => e.start - t.start).filter((e) => e.en.trim()).map((e, t) => ({ label: `${n ? "S" : "P"}${t + 1}`, id: e.id, start: n ? e.start : null, text: e.en.replace(/\s+/g, " ").trim() }));
}
const pm = (s) => `[${s.label}${s.start !== null ? " " + yi(s.start) : ""}] ${s.text}`;
function _m(s, n) {
  let e = 0, t = !1;
  const r = [];
  for (const d of s) {
    const p = d.text.length + 14;
    if (e + p > n.maxTotalChars) {
      t = !0;
      break;
    }
    e += p, r.push(d);
  }
  if (e <= n.singleCallChars) return { chunks: r.length ? [r] : [], truncated: t };
  const i = Math.max(n.chunkChars, Math.ceil(e / n.maxChunks)), a = [];
  let o = [], l = 0;
  for (const d of r) {
    const p = d.text.length + 14;
    o.length && l + p > i && (a.push(o), o = [], l = 0), o.push(d), l += p;
  }
  return o.length && a.push(o), { chunks: a, truncated: t };
}
function ad(s) {
  const n = s.coverage;
  return n.state === "complete" ? "" : s.kind === "video" ? `IMPORTANT: only part of the lesson transcript is available (up to ${yi(n.sourceUntilSec)}${n.durationSec ? ` of ${yi(n.durationSec)}` : ""}). Describe ONLY what is covered; do not present it as the whole lesson.` : "IMPORTANT: only part of the lesson text is available. Describe ONLY what is covered.";
}
const od = (s) => s.trim() ? `
Preferred Vietnamese terminology (term = Vietnamese; "=" alone keeps the English term):
${s.trim().slice(0, 3e3)}
` : "";
function pl(s, n, e, t, r) {
  return [
    `Lesson title: ${s.title}`,
    ad(s),
    od(r),
    t > 1 ? `Lesson content, part ${e + 1} of ${t} (extract notes for THIS part only; the summary covers this part only):` : "Lesson content:",
    ...n.map(pm)
  ].filter(Boolean).join(`
`);
}
const fm = "<<PARTIAL_NOTES_JSON>>";
function gm(s, n, e) {
  return [
    `Lesson title: ${s.title}`,
    ad(s),
    od(e),
    "Below are study notes extracted from consecutive parts of the SAME lesson, in lesson order (JSON array).",
    "Merge them into ONE coherent learning document: deduplicate repeated points, keep the practical steps in order with their technical details, write a concise summary of all the available content, and keep the refs of the items you use (only labels that appear below). Do not add anything that is not in these notes.",
    fm,
    JSON.stringify(n)
  ].filter(Boolean).join(`
`);
}
async function mm(s) {
  const n = { ...um, ...s.budget }, e = s.transcript, t = hm(e);
  if (!t.length) throw new Error("Không có nội dung bài học để tạo ghi chú.");
  const r = new Map(t.map((v) => [v.label, v])), i = (v) => r.has(v) ? v : null, { chunks: a, truncated: o } = _m(t, n), l = {};
  let d = 0, p = 0;
  const h = a.length > 1 ? a.length + Math.ceil(a.length / n.mergeFanIn) + (a.length > n.mergeFanIn ? 1 : 0) : 1;
  let m = 0;
  const _ = (v) => s.onProgress?.(++m, h, v), b = async (v, S, P) => {
    d++;
    const C = await s.complete({ system: dm, user: v, schema: cm, maxTokens: S, label: P });
    return hl(er(C), i, e.title);
  };
  let y;
  if (a.length === 1)
    y = [await b(pl(e, a[0], 0, 1, s.glossary), n.finalOutputTokens, "notes")], _("chunk");
  else {
    y = [];
    for (let v = 0; v < a.length; v++) {
      const S = pl(e, a[v], v, a.length, s.glossary), P = mt([s.fingerprint, om, e.coverage.state, S].join("|"));
      let C = s.previousChunks?.[P];
      C ? p++ : C = await b(S, n.chunkOutputTokens, `chunk ${v + 1}/${a.length}`), l[P] = C, y.push(C), _("chunk");
    }
    for (; y.length > 1; ) {
      const v = [];
      for (let S = 0; S < y.length; S += n.mergeFanIn) {
        const P = y.slice(S, S + n.mergeFanIn);
        v.push(P.length === 1 ? P[0] : await b(gm(e, P, s.glossary), n.finalOutputTokens, "merge")), _("merge");
      }
      y = v;
    }
  }
  const k = y[0] ?? lm(e.title), E = {};
  return { notes: hl(k, (v) => {
    const S = r.get(v);
    return S ? (S.start !== null && (E[S.id] = S.start), S.id) : null;
  }, e.title), refStarts: E, chunks: l, calls: d, reusedChunks: p, truncated: o, coverage: e.coverage, transcriptVersion: e.version };
}
const Cs = (s) => `notes:${s}`, ym = 2e4;
class bm {
  constructor(n) {
    this.d = n;
  }
  running = /* @__PURE__ */ new Map();
  async get(n) {
    const e = Cs(n), t = (await this.d.storage.get(e))[e];
    if (!t) return null;
    const { chunks: r, ...i } = t;
    return i;
  }
  async saveEdit(n, e) {
    const t = Cs(n), r = (await this.d.storage.get(t))[t];
    return r ? (e && e.trim() ? (r.editedMarkdown = e.slice(0, 2e5), r.editedAt = (this.d.now ?? Date.now)()) : (delete r.editedMarkdown, delete r.editedAt), await this.d.storage.set({ [t]: r }), this.get(n)) : null;
  }
  async remove(n) {
    await this.d.storage.remove(Cs(n));
  }
  isRunning(n) {
    return this.running.has(n);
  }
  cancel(n) {
    this.running.get(n)?.abort();
  }
  /** Generate (or regenerate) notes. Only ever called on an explicit user request. */
  async generate(n, e) {
    if (!n || !Array.isArray(n.segments) || !n.lessonId) throw new Error("Thiếu bản ghi bài học.");
    if (this.running.has(n.lessonId)) throw new Error("Đang tạo ghi chú cho bài này.");
    const t = { ...n, segments: n.segments.slice(0, ym) }, r = new AbortController();
    this.running.set(n.lessonId, r);
    try {
      const i = Cs(n.lessonId), a = (await this.d.storage.get(i))[i], { provider: o, model: l } = await this.d.activeModel(), d = await mm({
        transcript: t,
        glossary: await this.d.glossary().catch(() => ""),
        fingerprint: `${o}|${l}`,
        previousChunks: a?.chunks,
        budget: this.d.budget,
        onProgress: (_, b) => e?.(Math.min(_, b), b),
        complete: (_) => this.d.complete(_, { signal: r.signal, lesson: mt(n.lessonId) })
      }), p = {
        lessonId: n.lessonId,
        title: n.title,
        kind: n.kind,
        notes: d.notes,
        refStarts: d.refStarts,
        transcriptVersion: d.transcriptVersion,
        coverage: d.coverage,
        provider: o,
        model: l,
        createdAt: (this.d.now ?? Date.now)(),
        calls: d.calls,
        truncated: d.truncated,
        chunks: d.chunks
      };
      await this.d.storage.set({ [i]: p });
      const { chunks: h, ...m } = p;
      return m;
    } finally {
      this.running.delete(n.lessonId);
    }
  }
}
const _l = "audio/offscreen.html", Ft = new md(), bi = new am(chrome.storage.local, chrome.storage.session, Sl), V = new Gg(chrome.storage.session);
async function Hi(s) {
  const n = dd(s);
  if (!n) return !1;
  try {
    return await chrome.permissions.contains({ origins: [n] });
  } catch {
    return !1;
  }
}
const Ce = new Kg({
  cache: Ft,
  getSettings: Zs,
  getSecrets: vi,
  getGlossaryText: (s) => id(s.glossary),
  onAccounting: (s, n) => void bi.record(s, n),
  hasEndpointPermission: Hi
}), En = new bm({
  storage: chrome.storage.local,
  complete: (s, n) => Ce.complete(s, n),
  activeModel: () => Ce.activeModel(),
  glossary: async () => id((await Zs()).glossary)
});
async function Je(s, n, e) {
  try {
    await chrome.tabs.sendMessage(s, e, { frameId: n ?? 0 });
  } catch {
  }
}
let Is = null;
async function wm() {
  (await chrome.runtime.getContexts({
    contextTypes: [chrome.runtime.ContextType.OFFSCREEN_DOCUMENT],
    documentUrls: [chrome.runtime.getURL(_l)]
  })).length || (Is || (Is = chrome.offscreen.createDocument({
    url: _l,
    reasons: [chrome.offscreen.Reason.USER_MEDIA],
    justification: "Process user-approved tab audio for live speech-to-text subtitles."
  }).then(() => new Promise((n) => setTimeout(n, 50))).finally(() => Is = null)), await Is);
}
async function vm() {
  (await chrome.runtime.getContexts({ contextTypes: [chrome.runtime.ContextType.OFFSCREEN_DOCUMENT] })).length && await chrome.offscreen.closeDocument();
}
const Oe = new sm({
  registry: V,
  getSettings: Zs,
  getSecrets: vi,
  ensureOffscreen: wm,
  closeOffscreen: vm,
  sendOffscreen: async (s) => {
    await chrome.runtime.sendMessage({ target: "offscreen", ...s });
  },
  sendToFrame: Je,
  broadcast: (s, n) => Je(s, 0, n),
  translate: async (s, n, e, t) => {
    const [r] = await Ce.translateUnits(s, [{ id: e, text: n }], t);
    return r;
  },
  setBadge: (s, n) => {
    chrome.action.setBadgeText({ tabId: s, text: n }), n && chrome.action.setBadgeBackgroundColor({ tabId: s, color: "#d1242f" });
  },
  hasEndpointPermission: Hi,
  sessionStore: chrome.storage.session
}), Yr = /* @__PURE__ */ new Map();
function Lt(s) {
  clearTimeout(Yr.get(s)), Yr.set(
    s,
    setTimeout(() => {
      Yr.delete(s), Je(s, 0, { type: "tab:status:changed", status: V.get(s) });
    }, 200)
  );
}
async function fl(s) {
  const n = V.get(s);
  await Promise.all(
    n.frames.map(async (e) => {
      try {
        await Promise.race([
          chrome.tabs.sendMessage(s, { type: "frame:ping" }, { frameId: e.frameId }),
          new Promise((t, r) => setTimeout(() => r(new Error("timeout")), 400))
        ]);
      } catch {
        V.removeFrame(s, e.frameId);
      }
    })
  );
}
async function km(s, n) {
  await V.ready();
  const e = n.tab?.id, t = n.frameId ?? 0;
  switch (s.type) {
    case "frame:hello": {
      if (e === void 0) return { active: !1, frameId: t };
      const r = wl(n.tab?.url ?? (t === 0 ? n.url : void 0)), i = !!r && bl(r);
      return t === 0 && V.setSkool(e, i), { active: i, frameId: t };
    }
    case "frame:status":
      return e === void 0 ? null : (V.updateFrame(e, t, s.status), Lt(e), { ok: !0 });
    case "frame:gone":
      return e !== void 0 && (V.removeFrame(e, t), Lt(e)), { ok: !0 };
    case "translate:units":
      return { results: await Ce.translateUnits(s.videoKey, s.units, s.context, s.priority, s.format === "markup" ? "markup" : "subtitle") };
    case "translate:cancel":
      return Ce.cancel(s.videoKey), { ok: !0 };
    case "translate:test": {
      const [r] = await Ce.translateUnits(`test:${Date.now()}`, [{ id: "t", text: "Welcome back! Today we will set up our first Facebook Ads campaign with a $50 daily budget." }], []);
      return r;
    }
    case "tab:status":
      return await fl(s.tabId), {
        status: V.get(s.tabId),
        metrics: Ce.metrics.snapshot(),
        cache: await Ft.stats().catch(() => ({ entries: 0, approxBytes: 0 }))
      };
    case "backend:check":
      return rm(await Zs(), await vi(), { hasPermission: Hi });
    case "diag:run": {
      await fl(s.tabId);
      const r = /* @__PURE__ */ new Set([0, ...V.get(s.tabId).frames.map((a) => a.frameId)]), i = await Promise.all(
        [...r].map(async (a) => {
          try {
            return { frameId: a, report: await chrome.tabs.sendMessage(s.tabId, { type: "diag:collect" }, { frameId: a }) };
          } catch (o) {
            return { frameId: a, error: o.message };
          }
        })
      );
      return { collectedAt: (/* @__PURE__ */ new Date()).toISOString(), extensionVersion: chrome.runtime.getManifest().version, frames: i };
    }
    case "usage:get":
      return { usage: await bi.snapshot(), pricing: await Sl(), defaultPricing: Wt };
    case "usage:reset":
      return await bi.reset(), { ok: !0 };
    case "pricing:set":
      return await Pd(s.rows), { ok: !0 };
    case "metrics:get":
      return Ce.metrics.snapshot();
    case "cache:stats":
      return Ft.stats();
    case "cache:clear":
      return await Ft.clear(), { ok: !0 };
    case "audio:start":
      try {
        return await Oe.start(s.tabId, s.streamId), Lt(s.tabId), { ok: !0 };
      } catch (r) {
        return V.setAudio(s.tabId, { active: !1, error: r.message }), { ok: !1, error: r.message };
      }
    case "audio:stop": {
      const r = s.tabId ?? e;
      return await Oe.stop(r), r !== void 0 && Lt(r), { ok: !0 };
    }
    case "manual:cues": {
      const r = V.primaryFrame(s.tabId);
      return await Je(s.tabId, r, { type: "manual:cues", cues: s.cues, label: s.label }), { ok: !0, frameId: r };
    }
    case "session:start": {
      if (e === void 0) return { ok: !1 };
      const r = V.get(e);
      return await Promise.all([0, ...r.frames.map((i) => i.frameId)].map((i) => Je(e, i, { type: "session:start" }))), { ok: !0 };
    }
    case "learning:remote": {
      if (e === void 0 || t !== 0) return { ok: !1 };
      const r = V.primaryFrame(e);
      if (r === null || r === 0) return { ok: !1 };
      try {
        return await chrome.tabs.sendMessage(e, { type: "learning:op", op: s.op }, { frameId: r });
      } catch {
        return { ok: !1 };
      }
    }
    case "notes:get":
      return { record: await En.get(s.lessonId), running: En.isRunning(s.lessonId) };
    case "notes:model":
      return Ce.activeModel();
    case "notes:cancel":
      return En.cancel(s.lessonId), { ok: !0 };
    case "notes:save":
      return { record: await En.saveEdit(s.lessonId, s.editedMarkdown) };
    case "notes:generate": {
      if (e === void 0) return { ok: !1 };
      const r = s.transcript?.lessonId;
      return { record: await En.generate(
        s.transcript,
        (a, o) => void Je(e, 0, { type: "notes:progress", lessonId: r, done: a, total: o })
      ) };
    }
    case "learning:open":
      return await Je(s.tabId, 0, { type: "learning:open", tab: s.tab }), { ok: !0 };
    case "offscreen:ready":
      return { ok: !0 };
    case "offscreen:started": {
      const r = Oe.active;
      return r && Lt(r.tabId), { ok: !0 };
    }
    case "offscreen:chunk":
      return Oe.onChunk(s).then(() => {
        const r = Oe.active;
        r && Lt(r.tabId);
      }), { ok: !0 };
    case "offscreen:error":
      return await Oe.onOffscreenError(s.sessionId, s.error), { ok: !0 };
    case "offscreen:stopped":
      return await Oe.onOffscreenStopped(s.sessionId, s.reason), { ok: !0 };
  }
  return null;
}
chrome.runtime.onMessage.addListener((s, n, e) => !s || typeof s != "object" || s.target === "offscreen" || n.id !== chrome.runtime.id ? !1 : (km(s, n).then(e, (t) => e({ __error: t.message })), !0));
chrome.tabs.onRemoved.addListener((s) => {
  Oe.stop(s, "tab-closed"), V.removeTab(s);
});
chrome.tabs.onUpdated.addListener((s, n) => {
  n.url && (bl(wl(n.url) ?? new URL("about:blank")) ? Je(s, 0, { type: "nav:check" }) : (Oe.stop(s, "navigated"), V.removeTab(s)));
});
chrome.runtime.onInstalled.addListener((s) => {
  Ft.prune().catch(() => {
  }), s.reason === "install" && chrome.runtime.openOptionsPage();
});
chrome.runtime.onStartup.addListener(() => {
  Ft.prune().catch(() => {
  });
});
function cd(s) {
  return new Proxy({}, {
    get(n, e) {
      if (typeof e != "symbol")
        throw new R(`\`${s}.${e}\` is not available in this environment; it needs a Node.js-compatible runtime`);
    }
  });
}
const Sm = /* @__PURE__ */ cd("fs"), Tm = /* @__PURE__ */ cd("path"), qe = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  fs: Sm,
  path: Tm
}, Symbol.toStringTag, { value: "Module" }));
function F(s) {
  throw new R(`${s} requires Node.js or a Node-compatible runtime`);
}
const Am = 3e4, xm = ".anthropic-memory-store";
class Em extends R {
  constructor(n, e) {
    super(n), this.name = "SessionMemoryError", e !== void 0 && (this.cause = e);
  }
}
class Rm {
  constructor(n, e) {
    F("SessionMemoryStores");
  }
  get roots() {
    return F("SessionMemoryStores");
  }
  get readOnlyRoots() {
    return F("SessionMemoryStores");
  }
  download(n) {
    return F("SessionMemoryStores");
  }
  finish() {
    return F("SessionMemoryStores");
  }
  /** @internal */
  syncAll(n) {
    return F("SessionMemoryStores");
  }
  syncIfDue() {
    return F("SessionMemoryStores");
  }
  flushWrites(n) {
    return F("SessionMemoryStores");
  }
  dispose() {
    return F("SessionMemoryStores");
  }
}
function Pm(s) {
  return F("setupSkills");
}
function zm(s, n) {
  return F("extractSkillArchive");
}
function Mm(s) {
  return F("betaAgentToolset20260401");
}
function Om(s, n) {
  return F("resolvePath");
}
class Cm extends R {
  constructor(n) {
    super(`bash command timed out after ${n}ms`), this.name = "BashTimeoutError", this.timeoutMs = n;
  }
}
class Im {
  constructor(n, e) {
    F("BashSession");
  }
  get closed() {
    return F("BashSession");
  }
  exec(n, e = {}) {
    return F("BashSession");
  }
  close() {
    F("BashSession");
  }
}
function $m(s) {
  return F("betaBashTool");
}
function Nm(s) {
  return F("betaReadTool");
}
function Lm(s) {
  return F("betaWriteTool");
}
function qm(s) {
  return F("betaEditTool");
}
function Bm(s) {
  return F("betaGlobTool");
}
function Um(s) {
  return F("betaGrepTool");
}
const jm = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  BashSession: Im,
  BashTimeoutError: Cm,
  DEFAULT_MEMORY_SYNC_INTERVAL_MS: cg,
  MARKER_PATH: xm,
  MEMORY_FLUSH_TIMEOUT_MS: Am,
  MIN_MEMORY_SYNC_INTERVAL_MS: fi,
  SessionMemoryError: Em,
  SessionMemoryStores: Rm,
  betaAgentToolset20260401: Mm,
  betaBashTool: $m,
  betaEditTool: qm,
  betaGlobTool: Bm,
  betaGrepTool: Um,
  betaReadTool: Nm,
  betaWriteTool: Lm,
  extractSkillArchive: zm,
  resolvePath: Om,
  setupSkills: Pm
}, Symbol.toStringTag, { value: "Module" }));
