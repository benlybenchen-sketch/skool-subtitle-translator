import{i as p}from"./util-DRO3HpUb.js";const g=["Receiving end does not exist","message port closed","Could not establish connection","The message port closed before a response was received"];function m(e){const t=e instanceof Error?e.message:String(e);return g.some(o=>t.includes(o))}function h(e){try{if(!chrome?.runtime?.id)return!0}catch{return!0}return(e instanceof Error?e.message:String(e??"")).includes("Extension context invalidated")}async function k(e,t={}){const o=t.retries??4,i=t.baseDelayMs??150;let d;for(let l=0;l<=o;l++)try{const n=await chrome.runtime.sendMessage(e);if(n&&typeof n=="object"&&"__error"in n&&n.__error)throw new Error(n.__error);return n}catch(n){if(d=n,h(n)||!m(n)||l===o)throw n;await new Promise(u=>setTimeout(u,i*2**l))}throw d}const f=`# One entry per line. "English => Vietnamese" forces a translation,
# a bare term is kept exactly as written. Lines starting with # are ignored.
Skool
dropshipping
Shopify
Facebook Ads
Google Ads
TikTok Ads
ROAS
CTR
CPC
CPM
CPA
KPI
SEO
API
SaaS
AI
ChatGPT
prompt
landing page => landing page (trang đích)
funnel => phễu bán hàng (funnel)
sales funnel => phễu bán hàng
conversion rate => tỷ lệ chuyển đổi
ad set => nhóm quảng cáo (ad set)
ad account => tài khoản quảng cáo
lead => khách hàng tiềm năng (lead)
retargeting => tiếp thị lại (retargeting)
upsell => bán thêm (upsell)
cross-sell => bán chéo
niche => thị trường ngách
supplier => nhà cung cấp
fulfillment => xử lý đơn hàng (fulfillment)
workflow => quy trình (workflow)
automation => tự động hóa
deploy => triển khai (deploy)
repository => repository (kho mã)
`,a={enabled:!0,modePreference:"auto",displayMode:"vi",fontScale:1,bottomOffsetPct:14,background:!0,backgroundOpacity:.55,outline:!1,shadow:!0,showPanel:!0,provider:{kind:"local",endpoint:"http://localhost:8787",model:"default",temperature:.2},providerProfiles:{},stt:{kind:"local",endpoint:"http://localhost:8787",model:"whisper-1"},consent:{remoteTranslation:!1,remoteAudio:!1},glossary:f,contextWindow:3,translationMode:"balanced",modeModels:{},pretranslateAll:!0,autoStart:!0,autoEnableCaptions:!1,autoEnableCaptionsAsked:!1,autoInitOnNavigation:!0,autoTranslateTextLessons:!1,dubbing:{enabled:!1,provider:"chrome",voice:"",gender:"female",rate:1,volume:1,originalVolume:.15,listenMode:"vi",lookaheadSec:60,latePolicy:"skip",maxDelaySec:2.5,maxSpeedup:1.35,restoreOnFailure:!0,showSubtitles:!0,googleEndpoint:"https://texttospeech.googleapis.com/v1"},textDisplayMode:"vi",sourceLanguage:"en",targetLanguage:"vi",mergeFragments:!0,customCaptionSelectors:"",costWarningUsd:0},s="settings",r="secrets";function c(e){const t=e??{};return{...a,...t,provider:{...a.provider,...t.provider??{}},providerProfiles:{...t.providerProfiles??{}},modeModels:{...t.modeModels??{}},stt:{...a.stt,...t.stt??{}},consent:{...a.consent,...t.consent??{}},dubbing:{...a.dubbing,...t.dubbing??{}}}}async function v(){const e=await chrome.storage.sync.get(s);return c(e[s])}async function w(e){const t=await v(),o=c({...t,...e});return await chrome.storage.sync.set({[s]:o}),o}function P(e){const t=(o,i)=>{i==="sync"&&o[s]&&e(c(o[s].newValue))};return chrome.storage.onChanged.addListener(t),()=>{try{chrome.storage?.onChanged?.removeListener(t)}catch{}}}async function E(){const[e,t]=await Promise.all([chrome.storage.local.get(r),chrome.storage.session.get(r)]);return{...e[r]??{},...t[r]??{}}}async function T(e,t){const o=t?chrome.storage.session:chrome.storage.local;await(t?chrome.storage.local:chrome.storage.session).remove(r),await o.set({[r]:e})}async function A(){await Promise.all([chrome.storage.local.remove(r),chrome.storage.session.remove(r)])}function C(e){return e.provider.kind!=="mock"&&!p(e.provider.endpoint)}function x(e){return e.stt.kind!=="mock"&&!p(e.stt.endpoint)}const b={gemini:{endpoint:"https://generativelanguage.googleapis.com/v1beta",model:"gemini-3.5-flash-lite",label:"Google Gemini"},openai:{endpoint:"https://api.openai.com/v1",model:"gpt-4o-mini",label:"OpenAI GPT"},anthropic:{endpoint:"https://api.anthropic.com",model:"claude-opus-5-5",label:"Anthropic Claude"},local:{endpoint:"http://localhost:8787",model:"default",label:"Backend cục bộ"},mock:{endpoint:"mock://",model:"mock",label:"Mock (thử nghiệm)"}},I=["gemini","openai","anthropic","local","mock"];function S(e,t){if(e.provider.kind===t)return e.provider;const o=b[t];return e.providerProfiles[t]??{kind:t,endpoint:o.endpoint,model:o.model,temperature:.2}}function M(e){const t=e.modeModels?.[e.translationMode]?.[e.provider.kind]?.trim();return t?{...e.provider,model:t}:e.provider}function R(e,t){const o={...e.providerProfiles,[e.provider.kind]:e.provider};return{...e,providerProfiles:o,provider:{...S({...e,providerProfiles:o},t),kind:t}}}function _(e,t,o){return e.translationApiKeys?.[t]??(t===o?e.translationApiKey:void 0)}export{b as P,w as a,R as b,E as c,I as d,M as e,_ as f,A as g,T as h,x as i,v as l,P as o,S as p,k as s,C as t};
