const Z = (s, t) => new Promise((e, n) => {
  if (t?.aborted) return n(I());
  const r = setTimeout(() => {
    t?.removeEventListener("abort", i), e();
  }, s), i = () => {
    clearTimeout(r), n(I());
  };
  t?.addEventListener("abort", i, { once: !0 });
});
function I(s = "Aborted") {
  const t = new Error(s);
  return t.name = "AbortError", t;
}
const ct = (s) => s instanceof Error && (s.name === "AbortError" || s.name === "TimeoutError");
function N(s) {
  try {
    const t = new URL(s);
    return ["localhost", "127.0.0.1", "[::1]", "::1"].includes(t.hostname);
  } catch {
    return !1;
  }
}
function lt(s) {
  try {
    const t = new URL(s);
    return t.protocol !== "https:" && t.protocol !== "http:" ? null : `${t.protocol}//${t.hostname}/*`;
  } catch {
    return null;
  }
}
function dt(s) {
  const t = atob(s), e = new Uint8Array(t.length);
  for (let n = 0; n < t.length; n++) e[n] = t.charCodeAt(n);
  return e;
}
function ht(s, t) {
  if (!s.length) return 0;
  const e = [...s].sort((r, i) => r - i), n = Math.min(e.length - 1, Math.ceil(t / 100 * e.length) - 1);
  return e[Math.max(0, n)];
}
const ut = `# One entry per line. "English => Vietnamese" forces a translation,
# a bare term is kept exactly as written. Lines starting with # are ignored.
Skool
dropshipping
Shopify
Facebook Ads
Google Ads
TikTok Ads
ROAS
CTR
CPC
CPM
CPA
KPI
SEO
API
SaaS
AI
ChatGPT
prompt
landing page => landing page (trang đích)
funnel => phễu bán hàng (funnel)
sales funnel => phễu bán hàng
conversion rate => tỷ lệ chuyển đổi
ad set => nhóm quảng cáo (ad set)
ad account => tài khoản quảng cáo
lead => khách hàng tiềm năng (lead)
retargeting => tiếp thị lại (retargeting)
upsell => bán thêm (upsell)
cross-sell => bán chéo
niche => thị trường ngách
supplier => nhà cung cấp
fulfillment => xử lý đơn hàng (fulfillment)
workflow => quy trình (workflow)
automation => tự động hóa
deploy => triển khai (deploy)
repository => repository (kho mã)
`, C = {
  enabled: !0,
  modePreference: "auto",
  displayMode: "vi",
  fontScale: 1,
  bottomOffsetPct: 14,
  background: !0,
  backgroundOpacity: 0.55,
  outline: !1,
  shadow: !0,
  showPanel: !0,
  provider: {
    kind: "local",
    endpoint: "http://localhost:8787",
    model: "default",
    temperature: 0.2
  },
  stt: {
    kind: "local",
    endpoint: "http://localhost:8787",
    model: "whisper-1"
  },
  consent: { remoteTranslation: !1, remoteAudio: !1 },
  glossary: ut,
  contextWindow: 3,
  mergeFragments: !0,
  customCaptionSelectors: ""
}, H = "settings", O = "secrets";
function mt(s) {
  const t = s ?? {};
  return {
    ...C,
    ...t,
    provider: { ...C.provider, ...t.provider ?? {} },
    stt: { ...C.stt, ...t.stt ?? {} },
    consent: { ...C.consent, ...t.consent ?? {} }
  };
}
async function D() {
  const s = await chrome.storage.sync.get(H);
  return mt(s[H]);
}
async function q() {
  const [s, t] = await Promise.all([
    chrome.storage.local.get(O),
    chrome.storage.session.get(O)
  ]);
  return { ...s[O] ?? {}, ...t[O] ?? {} };
}
function tt(s) {
  return s.provider.kind !== "mock" && !N(s.provider.endpoint);
}
function et(s) {
  return s.stt.kind !== "mock" && !N(s.stt.endpoint);
}
const W = (s) => s.hostname.toLowerCase(), pt = (s, ...t) => t.some((e) => W(s) === e || W(s).endsWith("." + e)), ft = ["skool.com"], st = (s) => pt(s, ...ft);
function nt(s, t) {
  if (!s) return null;
  try {
    return new URL(s, t);
  } catch {
    return null;
  }
}
const y = "translations";
function U(s) {
  return new Promise((t, e) => {
    s.onsuccess = () => t(s.result), s.onerror = () => e(s.error);
  });
}
function E(s) {
  return new Promise((t, e) => {
    s.oncomplete = () => t(), s.onerror = () => e(s.error), s.onabort = () => e(s.error);
  });
}
class gt {
  dbp = null;
  o;
  constructor(t = {}) {
    this.o = {
      dbName: t.dbName ?? "sst-cache",
      maxAgeMs: t.maxAgeMs ?? 1080 * 3600 * 1e3,
      maxEntries: t.maxEntries ?? 6e4,
      now: t.now ?? Date.now,
      indexedDB: t.indexedDB
    };
  }
  db() {
    if (!this.dbp) {
      const t = this.o.indexedDB ?? indexedDB;
      this.dbp = new Promise((e, n) => {
        const r = t.open(this.o.dbName, 1);
        r.onupgradeneeded = () => {
          const o = r.result.createObjectStore(y, { keyPath: "key" });
          o.createIndex("videoKey", "videoKey"), o.createIndex("lastUsedAt", "lastUsedAt");
        }, r.onsuccess = () => e(r.result), r.onerror = () => n(r.error);
      }), this.dbp.catch(() => this.dbp = null);
    }
    return this.dbp;
  }
  async getMany(t) {
    const e = /* @__PURE__ */ new Map();
    if (!t.length) return e;
    const r = (await this.db()).transaction(y, "readwrite"), i = r.objectStore(y), o = this.o.now();
    return await Promise.all(
      t.map(async (a) => {
        const c = await U(i.get(a));
        if (c) {
          if (o - c.lastUsedAt > this.o.maxAgeMs) {
            i.delete(a);
            return;
          }
          e.set(a, c.vi), o - c.lastUsedAt > 36e5 && i.put({ ...c, lastUsedAt: o });
        }
      })
    ), await E(r), e;
  }
  async putMany(t) {
    if (!t.length) return;
    const n = (await this.db()).transaction(y, "readwrite"), r = n.objectStore(y), i = this.o.now();
    for (const o of t)
      r.put({ ...o, createdAt: i, lastUsedAt: i, size: o.key.length + o.vi.length * 2 });
    await E(n);
  }
  async stats() {
    const n = (await this.db()).transaction(y, "readonly").objectStore(y), r = await U(n.count());
    let i = 0;
    return await new Promise((o, a) => {
      const c = n.openCursor();
      c.onsuccess = () => {
        const l = c.result;
        if (!l) return o();
        i += l.value.size ?? 0, l.continue();
      }, c.onerror = () => a(c.error);
    }), { entries: r, approxBytes: i };
  }
  async clear() {
    const e = (await this.db()).transaction(y, "readwrite");
    e.objectStore(y).clear(), await E(e);
  }
  /** Invalidate all cached translations of one video. */
  async deleteVideo(t) {
    const n = (await this.db()).transaction(y, "readwrite"), r = n.objectStore(y).index("videoKey");
    let i = 0;
    return await new Promise((o, a) => {
      const c = r.openCursor(IDBKeyRange.only(t));
      c.onsuccess = () => {
        const l = c.result;
        if (!l) return o();
        l.delete(), i++, l.continue();
      }, c.onerror = () => a(c.error);
    }), await E(n), i;
  }
  /** Remove expired entries and enforce the LRU cap. */
  async prune() {
    const e = (await this.db()).transaction(y, "readwrite"), n = e.objectStore(y), r = await U(n.count()), i = this.o.now() - this.o.maxAgeMs;
    let o = Math.max(0, r - this.o.maxEntries), a = 0;
    return await new Promise((c, l) => {
      const d = n.index("lastUsedAt").openCursor();
      d.onsuccess = () => {
        const u = d.result;
        if (!u) return c();
        u.value.lastUsedAt < i || o > 0 ? (u.delete(), a++, o > 0 && o--, u.continue()) : c();
      }, d.onerror = () => l(d.error);
    }), await E(e), a;
  }
}
function B(s, t = 0) {
  let e = 3735928559 ^ t, n = 1103547991 ^ t;
  for (let r = 0; r < s.length; r++) {
    const i = s.charCodeAt(r);
    e = Math.imul(e ^ i, 2654435761), n = Math.imul(n ^ i, 1597334677);
  }
  return e = Math.imul(e ^ e >>> 16, 2246822507) ^ Math.imul(n ^ n >>> 13, 3266489909), n = Math.imul(n ^ n >>> 16, 2246822507) ^ Math.imul(e ^ e >>> 13, 3266489909), (4294967296 * (2097151 & n) + (e >>> 0)).toString(36);
}
class S extends Error {
  constructor(t, e, n) {
    super(e), this.status = t, this.retryAfterMs = n, this.name = "HttpError";
  }
  get retryable() {
    return this.status === 408 || this.status === 409 || this.status === 425 || this.status === 429 || this.status >= 500;
  }
}
class w extends Error {
  constructor(t) {
    super(t), this.name = "ConfigError";
  }
}
class v extends Error {
  constructor(t) {
    super(t), this.name = "ParseError";
  }
}
function yt(s) {
  if (!s) return;
  const t = Number(s);
  if (Number.isFinite(t)) return Math.max(0, t * 1e3);
  const e = Date.parse(s);
  return Number.isFinite(e) ? Math.max(0, e - Date.now()) : void 0;
}
async function L(s, t) {
  if (s.ok) return s;
  let e = "";
  try {
    e = (await s.text()).slice(0, 300);
  } catch {
  }
  const n = yt(s.headers.get("retry-after")), r = s.status === 401 || s.status === 403 ? " (check the API key / permissions)" : s.status === 429 ? " (rate limited)" : "";
  throw new S(s.status, `${t} HTTP ${s.status}${r}${e ? ": " + e : ""}`, n);
}
function rt(s) {
  const t = [], e = /* @__PURE__ */ new Set();
  for (const n of s.split(/\r?\n/)) {
    const r = n.trim();
    if (!r || r.startsWith("#")) continue;
    const [i, o] = r.split(/\s*(?:=>|→)\s*/, 2), a = i.trim().toLowerCase();
    !a || e.has(a) || (e.add(a), t.push({ term: i.trim(), translation: o?.trim() || void 0 }));
  }
  return t;
}
function wt(s) {
  return B(rt(s).map((t) => `${t.term}=${t.translation ?? ""}`).join(`
`));
}
const bt = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
function vt(s, t) {
  const e = t.join(`
`);
  return s.filter((n) => new RegExp(`(^|[^\\p{L}\\p{N}])${bt(n.term)}(?=$|[^\\p{L}\\p{N}])`, "iu").test(e));
}
const St = {
  concurrency: 2,
  maxBatchItems: 16,
  maxBatchChars: 1800,
  minBatchChars: 200,
  maxRetries: 4,
  baseDelayMs: 800,
  maxDelayMs: 2e4,
  timeoutMs: 45e3,
  sleep: Z,
  random: Math.random
};
class kt {
  opts;
  inflight = /* @__PURE__ */ new Map();
  groups = /* @__PURE__ */ new Map();
  active = 0;
  waiters = [];
  budget;
  constructor(t = {}) {
    this.opts = { ...St, ...t }, this.budget = this.opts.maxBatchChars;
  }
  get batchBudget() {
    return this.budget;
  }
  get inflightCount() {
    return this.inflight.size;
  }
  cancelGroup(t) {
    this.groups.get(t)?.abort(), this.groups.delete(t);
  }
  groupSignal(t) {
    let e = this.groups.get(t);
    return (!e || e.signal.aborted) && (e = new AbortController(), this.groups.set(t, e)), e.signal;
  }
  async translate(t, e) {
    const n = this.groupSignal(e.group), r = /* @__PURE__ */ new Map(), i = [];
    for (const a of t) {
      if (r.has(a.key)) continue;
      const c = this.inflight.get(a.key);
      c ? r.set(a.key, c) : (i.push(a), r.set(a.key, null));
    }
    for (const a of this.makeBatches(i)) {
      const c = /* @__PURE__ */ new Map();
      for (const l of a) {
        const d = new Promise((u, m) => c.set(l.key, { resolve: u, reject: m }));
        d.catch(() => {
        }), this.inflight.set(l.key, d), r.set(l.key, d), d.finally(() => {
          this.inflight.get(l.key) === d && this.inflight.delete(l.key);
        }).catch(() => {
        });
      }
      this.runBatch(a, e, n, 0).then((l) => {
        for (const d of a) {
          const u = c.get(d.key), m = l.get(d.key);
          m?.vi !== void 0 ? u.resolve(m.vi) : u.reject(m?.error ?? new Error("Translation missing"));
        }
      }).catch((l) => {
        for (const d of c.values()) d.reject(l);
      });
    }
    const o = /* @__PURE__ */ new Map();
    return await Promise.all(
      [...r.entries()].map(async ([a, c]) => {
        try {
          o.set(a, { vi: await c });
        } catch (l) {
          o.set(a, { error: l });
        }
      })
    ), o;
  }
  makeBatches(t) {
    const e = [];
    let n = [], r = 0;
    for (const i of t)
      n.length && (n.length >= this.opts.maxBatchItems || r + i.text.length > this.budget) && (e.push(n), n = [], r = 0), n.push(i), r += i.text.length;
    return n.length && e.push(n), e;
  }
  async acquire(t) {
    for (; this.active >= this.opts.concurrency; )
      if (await new Promise((e) => this.waiters.push(e)), t.aborted) throw I();
    this.active++;
  }
  release() {
    this.active--, this.waiters.shift()?.();
  }
  async runBatch(t, e, n, r) {
    if (n.aborted) throw I();
    await this.acquire(n);
    const i = Date.now(), o = new AbortController(), a = setTimeout(() => o.abort(), this.opts.timeoutMs), c = Tt([n, o.signal]), l = t.map((h, p) => ({ id: "s" + p, text: h.text }));
    let d, u;
    try {
      this.opts.onEvent?.({ type: "request", size: t.length }), u = await e.provider.translateBatch({
        segments: l,
        context: e.context,
        glossary: vt(e.glossary, t.map((h) => h.text)),
        sourceLang: e.sourceLang ?? "en",
        targetLang: e.targetLang ?? "vi",
        signal: c
      });
    } catch (h) {
      d = o.signal.aborted && !n.aborted ? Object.assign(new Error("Translation request timed out"), { name: "TimeoutError" }) : h;
    } finally {
      clearTimeout(a), this.release();
    }
    if (u) {
      const h = /* @__PURE__ */ new Map(), p = [];
      if (t.forEach((f, A) => {
        const M = u[l[A].id];
        typeof M == "string" && M.trim() ? h.set(f.key, { vi: M.trim() }) : p.push(f);
      }), this.opts.onEvent?.({ type: "success", size: t.length - p.length, latencyMs: Date.now() - i }), !p.length)
        return this.budget = Math.min(this.opts.maxBatchChars, Math.round(this.budget * 1.25)), h;
      if (r < this.opts.maxRetries) {
        const f = await this.retryLater(p, e, n, r, new v("Model omitted segments"));
        for (const [A, M] of f) h.set(A, M);
      } else for (const f of p) h.set(f.key, { error: new v("Model omitted this segment") });
      return h;
    }
    if (n.aborted || ct(d) && d.name === "AbortError") throw I();
    const m = d;
    if (!(m instanceof S && m.retryable || m instanceof v || m.name === "TimeoutError" || m instanceof TypeError) || m instanceof w || r >= this.opts.maxRetries) {
      this.opts.onEvent?.({ type: "failure", size: t.length, reason: m.message });
      const h = /* @__PURE__ */ new Map();
      for (const p of t) h.set(p.key, { error: m });
      return h;
    }
    return (m instanceof v || m.name === "TimeoutError") && (this.budget = Math.max(this.opts.minBatchChars, Math.round(this.budget / 2))), this.retryLater(t, e, n, r, m);
  }
  async retryLater(t, e, n, r, i) {
    let o = Math.min(this.opts.maxDelayMs, this.opts.baseDelayMs * 2 ** r) * (0.75 + this.opts.random() * 0.5);
    if (i instanceof S && i.status === 429 && (i.retryAfterMs !== void 0 && (o = Math.min(this.opts.maxDelayMs * 3, i.retryAfterMs)), this.opts.onEvent?.({ type: "rate-limited", delayMs: o })), o = Math.round(o), this.opts.onEvent?.({ type: "retry", attempt: r + 1, delayMs: o, reason: i.message }), await this.opts.sleep(o, n), (i instanceof v || i.name === "TimeoutError") && t.length > 1) {
      const a = Math.ceil(t.length / 2), [c, l] = await Promise.all([
        this.runBatch(t.slice(0, a), e, n, r + 1),
        this.runBatch(t.slice(a), e, n, r + 1)
      ]);
      return new Map([...c, ...l]);
    }
    return this.runBatch(t, e, n, r + 1);
  }
}
function Tt(s) {
  const t = AbortSignal.any;
  if (t) return t(s);
  const e = new AbortController();
  for (const n of s) {
    if (n.aborted) {
      e.abort();
      break;
    }
    n.addEventListener("abort", () => e.abort(), { once: !0 });
  }
  return e.signal;
}
const xt = "p3", it = `You are a professional English→Vietnamese subtitle translator for online courses (marketing, digital advertising, e-commerce, dropshipping, software engineering, business strategy, AI and automation, technical tutorials).

Rules:
- Translate each segment into natural, fluent, spoken Vietnamese that a Vietnamese learner would understand immediately. Avoid stiff word-for-word translation, but never change the instructor's meaning.
- Keep technical terms, product names, brand names, people's names, code, commands, URLs and acronyms (ROAS, CTR, API, SEO…) unchanged unless the glossary says otherwise.
- Preserve all numbers, percentages, currencies, units and dates exactly (e.g. "$1,500" stays "$1,500", "30%" stays "30%").
- Follow the glossary strictly.
- Segments may be incomplete spoken sentences; translate them as natural incomplete Vietnamese, consistent with neighbouring segments. Use the context only for understanding — do NOT translate the context.
- Keep each translation roughly as short as the original so it fits on screen. No explanations, no notes, no quotation marks around the output.
- Return ONLY JSON: {"t":[{"i":"<id>","v":"<vietnamese>"}]} with exactly one item per input id.`;
function ot(s) {
  const t = [];
  return s.glossary.length && t.push(
    `Glossary:
` + s.glossary.map((e) => e.translation ? `- ${e.term} => ${e.translation}` : `- ${e.term} => (keep as "${e.term}")`).join(`
`)
  ), s.context.length && t.push(`Context (previous lines, do not translate):
` + s.context.map((e) => `> ${e}`).join(`
`)), t.push(
    `Segments:
` + JSON.stringify(s.segments.map((e) => ({ i: e.id, s: e.text })))
  ), t.join(`

`);
}
function at(s) {
  const t = s.trim().replace(/^```(?:json)?\s*/i, "").replace(/```\s*$/, "");
  try {
    return JSON.parse(t);
  } catch {
    const e = t.indexOf("{"), n = t.lastIndexOf("}");
    if (e >= 0 && n > e)
      try {
        return JSON.parse(t.slice(e, n + 1));
      } catch {
      }
    throw new v("Model reply is not valid JSON");
  }
}
function _(s, t) {
  let e = s;
  if (e && typeof e == "object" && !Array.isArray(e)) {
    const i = e;
    e = i.t ?? i.translations ?? i.items ?? i.segments;
  }
  if (!Array.isArray(e)) throw new v("Model reply has no translation list");
  const n = {}, r = new Set(t);
  return e.forEach((i, o) => {
    if (typeof i == "string") {
      t[o] && (n[t[o]] = i);
      return;
    }
    if (!i || typeof i != "object") return;
    const a = i, c = String(a.i ?? a.id ?? t[o] ?? ""), l = a.v ?? a.vi ?? a.text ?? a.translation;
    r.has(c) && typeof l == "string" && l.trim() && (n[c] = l.trim());
  }), n;
}
class At {
  constructor(t) {
    if (this.o = t, !t.endpoint) throw new w("Gemini endpoint is not configured");
  }
  id = "gemini";
  async translateBatch(t) {
    const e = this.o.fetchImpl ?? fetch, n = this.o.model.replace(/^models\//, ""), r = `${this.o.endpoint.replace(/\/+$/, "")}/models/${encodeURIComponent(n)}:generateContent`, i = { "Content-Type": "application/json" };
    this.o.apiKey && (i["x-goog-api-key"] = this.o.apiKey);
    const o = await e(r, {
      method: "POST",
      headers: i,
      signal: t.signal,
      body: JSON.stringify({
        systemInstruction: { parts: [{ text: it }] },
        contents: [{ role: "user", parts: [{ text: ot(t) }] }],
        generationConfig: { temperature: this.o.temperature, responseMimeType: "application/json" }
      })
    });
    await L(o, "Gemini");
    const a = await o.json();
    if (a.promptFeedback?.blockReason) throw new w(`Gemini blocked the request: ${a.promptFeedback.blockReason}`);
    const c = a.candidates?.[0]?.content?.parts?.map((l) => l.text ?? "").join("") ?? "";
    return _(at(c), t.segments.map((l) => l.id));
  }
}
class Mt {
  constructor(t) {
    if (this.o = t, !t.endpoint) throw new w("Local backend endpoint is not configured");
  }
  id = "local";
  async translateBatch(t) {
    const e = this.o.fetchImpl ?? fetch, n = { "Content-Type": "application/json" };
    this.o.apiKey && (n.Authorization = `Bearer ${this.o.apiKey}`);
    const r = await e(this.o.endpoint.replace(/\/+$/, "") + "/translate", {
      method: "POST",
      headers: n,
      signal: t.signal,
      body: JSON.stringify({
        source: t.sourceLang,
        target: t.targetLang,
        model: this.o.model,
        segments: t.segments,
        context: t.context,
        glossary: t.glossary
      })
    });
    return await L(r, "Local backend"), _(await r.json(), t.segments.map((i) => i.id));
  }
}
class Et {
  constructor(t = 0) {
    this.latencyMs = t;
  }
  id = "mock";
  calls = 0;
  async translateBatch(t) {
    this.calls++, this.latencyMs && await Z(this.latencyMs, t.signal);
    const e = {};
    for (const n of t.segments) e[n.id] = `[VI] ${n.text}`;
    return e;
  }
}
class It {
  constructor(t) {
    if (this.o = t, !t.endpoint) throw new w("OpenAI-compatible endpoint is not configured");
  }
  id = "openai";
  async translateBatch(t) {
    const e = this.o.fetchImpl ?? fetch, n = this.o.endpoint.replace(/\/+$/, "") + "/chat/completions", r = { "Content-Type": "application/json" };
    this.o.apiKey && (r.Authorization = `Bearer ${this.o.apiKey}`);
    const i = await e(n, {
      method: "POST",
      headers: r,
      signal: t.signal,
      body: JSON.stringify({
        model: this.o.model,
        temperature: this.o.temperature,
        response_format: { type: "json_object" },
        messages: [
          { role: "system", content: it },
          { role: "user", content: ot(t) }
        ]
      })
    });
    await L(i, "OpenAI-compatible");
    const a = (await i.json()).choices?.[0]?.message?.content ?? "";
    return _(at(a), t.segments.map((c) => c.id));
  }
}
function Lt(s, t, e) {
  const n = t.translationApiKey;
  switch (s.kind) {
    case "openai":
      return new It({ endpoint: s.endpoint, model: s.model, apiKey: n, temperature: s.temperature, fetchImpl: e });
    case "gemini":
      return new At({ endpoint: s.endpoint, model: s.model, apiKey: n, temperature: s.temperature, fetchImpl: e });
    case "local":
      return new Mt({ endpoint: s.endpoint, model: s.model, apiKey: n, fetchImpl: e });
    case "mock":
    default:
      return new Et(150);
  }
}
function Ct(s) {
  return B(
    [s.provider.kind, s.provider.endpoint, s.provider.model, s.provider.temperature, xt, wt(s.glossary), "en", "vi"].join("|")
  );
}
function Ot(s, t, e) {
  return `${s}|${B(t)}|${B(e.trim().toLowerCase())}:${e.length}`;
}
class Pt {
  requests = 0;
  failedRequests = 0;
  retries = 0;
  rateLimited = 0;
  segmentsTranslated = 0;
  cacheHits = 0;
  cacheMisses = 0;
  latencies = [];
  recordLatency(t) {
    this.latencies.push(t), this.latencies.length > 200 && this.latencies.shift();
  }
  snapshot() {
    const t = this.latencies.length ? this.latencies.reduce((e, n) => e + n, 0) / this.latencies.length : 0;
    return {
      requests: this.requests,
      failedRequests: this.failedRequests,
      retries: this.retries,
      rateLimited: this.rateLimited,
      segmentsTranslated: this.segmentsTranslated,
      cacheHits: this.cacheHits,
      cacheMisses: this.cacheMisses,
      avgLatencyMs: Math.round(t),
      p95LatencyMs: Math.round(ht(this.latencies, 95))
    };
  }
}
class $t {
  constructor(t) {
    this.deps = t, this.queue = new kt({
      ...t.queueOptions,
      onEvent: (e) => {
        e.type === "request" ? this.metrics.requests++ : e.type === "success" ? (this.metrics.segmentsTranslated += e.size, this.metrics.recordLatency(e.latencyMs)) : e.type === "retry" ? this.metrics.retries++ : e.type === "rate-limited" ? this.metrics.rateLimited++ : e.type === "failure" && this.metrics.failedRequests++, t.queueOptions?.onEvent?.(e);
      }
    });
  }
  metrics = new Pt();
  queue;
  async checkConfig(t) {
    if (tt(t) && !t.consent.remoteTranslation)
      throw new w(
        'Chưa cho phép gửi phụ đề tới dịch vụ dịch từ xa. Mở Cài đặt → bật "Cho phép gửi phụ đề" (remote translation consent required).'
      );
    if (t.provider.kind !== "mock" && this.deps.hasEndpointPermission && !await this.deps.hasEndpointPermission(t.provider.endpoint))
      throw new w('Chưa cấp quyền truy cập endpoint dịch. Mở Cài đặt và bấm "Lưu" để cấp quyền (host permission missing).');
  }
  async translateUnits(t, e, n) {
    const r = await this.deps.getSettings();
    try {
      await this.checkConfig(r);
    } catch (d) {
      return e.map((u) => ({ id: u.id, error: d.message, fatal: !0 }));
    }
    const i = Ct(r), o = e.map((d) => ({ ...d, key: Ot(i, t, d.text) }));
    let a = /* @__PURE__ */ new Map();
    try {
      a = await this.deps.cache.getMany(o.map((d) => d.key));
    } catch {
    }
    const c = /* @__PURE__ */ new Map(), l = o.filter((d) => {
      const u = a.get(d.key);
      return u !== void 0 ? (c.set(d.id, { id: d.id, vi: u, cached: !0 }), !1) : !0;
    });
    if (this.metrics.cacheHits += o.length - l.length, this.metrics.cacheMisses += l.length, l.length) {
      const d = await this.deps.getSecrets();
      let u;
      try {
        u = this.deps.providerFactory ? this.deps.providerFactory(r, d) : Lt(r.provider, d);
      } catch (h) {
        for (const p of l) c.set(p.id, { id: p.id, error: h.message, fatal: !0 });
        return e.map((p) => c.get(p.id));
      }
      const m = await this.queue.translate(
        l.map((h) => ({ key: h.key, text: h.text })),
        {
          provider: u,
          context: n.slice(-Math.max(0, r.contextWindow)),
          glossary: rt(r.glossary),
          group: t
        }
      ), j = [];
      for (const h of l) {
        const p = m.get(h.key);
        if (p?.vi !== void 0)
          c.set(h.id, { id: h.id, vi: p.vi }), j.push({ key: h.key, videoKey: t, vi: p.vi });
        else {
          const f = p?.error, A = f instanceof w || f instanceof S && (f.status === 401 || f.status === 403 || f.status === 404 || f.status === 400);
          c.set(h.id, { id: h.id, error: f?.message ?? "Translation failed", fatal: A });
        }
      }
      this.deps.cache.putMany(j).catch(() => {
      });
    }
    return e.map((d) => c.get(d.id));
  }
  cancel(t) {
    this.queue.cancelGroup(t);
  }
}
const P = "tabRegistry", z = () => ({ active: !1, chunks: 0, droppedChunks: 0 });
class Ft {
  constructor(t) {
    this.store = t, this.loaded = this.load();
  }
  tabs = /* @__PURE__ */ new Map();
  loaded;
  saveTimer;
  async load() {
    try {
      const e = (await this.store.get(P))[P] ?? {};
      for (const [n, r] of Object.entries(e)) this.tabs.set(Number(n), r);
    } catch {
    }
  }
  ready() {
    return this.loaded;
  }
  persist() {
    clearTimeout(this.saveTimer), this.saveTimer = setTimeout(() => {
      const t = {};
      for (const [e, n] of this.tabs) t[e] = n;
      this.store.set({ [P]: t }).catch(() => {
      });
    }, 100);
  }
  /** Flush pending writes immediately (tests / shutdown). */
  async flush() {
    clearTimeout(this.saveTimer);
    const t = {};
    for (const [e, n] of this.tabs) t[e] = n;
    await this.store.set({ [P]: t });
  }
  rec(t) {
    let e = this.tabs.get(t);
    return e || (e = { isSkool: !1, frames: {}, audio: z() }, this.tabs.set(t, e)), e;
  }
  setSkool(t, e) {
    this.rec(t).isSkool = e, this.persist();
  }
  updateFrame(t, e, n) {
    this.rec(t).frames[e] = { ...n, frameId: e }, this.persist();
  }
  removeFrame(t, e) {
    const n = this.tabs.get(t);
    n && (delete n.frames[e], e === 0 && (n.frames = {}), this.persist());
  }
  setAudio(t, e) {
    const n = this.rec(t);
    return n.audio = { ...n.audio, ...e }, this.persist(), n.audio;
  }
  removeTab(t) {
    this.tabs.delete(t), this.persist();
  }
  tabIds() {
    return [...this.tabs.keys()];
  }
  /** Frame that should display subtitles: largest real <video>, else the top frame. */
  primaryFrame(t) {
    const e = this.tabs.get(t);
    if (!e) return null;
    const n = Object.values(e.frames), r = n.filter((a) => a.targetKind === "video").sort((a, c) => c.targetArea - a.targetArea);
    if (r.length) return r[0].frameId;
    const i = n.find((a) => a.targetKind === "media");
    if (i) return i.frameId;
    const o = n.find((a) => a.targetKind === "iframe");
    return o ? o.frameId : n.length ? 0 : null;
  }
  get(t) {
    const e = this.tabs.get(t) ?? { isSkool: !1, frames: {}, audio: z() };
    return {
      tabId: t,
      isSkool: e.isSkool,
      frames: Object.values(e.frames).sort((n, r) => n.frameId - r.frameId),
      primaryFrameId: this.primaryFrame(t),
      audio: e.audio
    };
  }
}
class Bt {
  constructor(t, e, n, r = fetch) {
    if (this.endpoint = t, this.model = e, this.apiKey = n, this.fetchImpl = r, !t) throw new w("STT endpoint is not configured");
  }
  id = "openai-stt";
  async transcribe(t) {
    const e = new FormData();
    e.append("file", new Blob([t.wav], { type: "audio/wav" }), "chunk.wav"), e.append("model", this.model), e.append("language", t.language), e.append("response_format", "json"), e.append("temperature", "0"), t.prompt && e.append("prompt", t.prompt.slice(-200));
    const n = {};
    this.apiKey && (n.Authorization = `Bearer ${this.apiKey}`);
    const r = await this.fetchImpl(this.endpoint.replace(/\/+$/, "") + "/audio/transcriptions", {
      method: "POST",
      headers: n,
      body: e,
      signal: t.signal
    });
    await L(r, "STT");
    const i = await r.json();
    return { text: (i.text ?? "").trim(), segments: i.segments };
  }
}
class Rt {
  constructor(t, e, n = fetch) {
    if (this.endpoint = t, this.apiKey = e, this.fetchImpl = n, !t) throw new w("Local STT endpoint is not configured");
  }
  id = "local-stt";
  async transcribe(t) {
    const e = { "Content-Type": "audio/wav", "X-Language": t.language };
    t.prompt && (e["X-Prompt"] = encodeURIComponent(t.prompt.slice(-200))), this.apiKey && (e.Authorization = `Bearer ${this.apiKey}`);
    const n = await this.fetchImpl(this.endpoint.replace(/\/+$/, "") + "/transcribe", {
      method: "POST",
      headers: e,
      body: t.wav,
      signal: t.signal
    });
    return await L(n, "Local STT"), { text: ((await n.json()).text ?? "").trim() };
  }
}
class jt {
  id = "mock-stt";
  n = 0;
  async transcribe() {
    return this.n++, { text: `This is mock speech segment number ${this.n}.` };
  }
}
function Ut(s, t, e) {
  switch (s.kind) {
    case "openai":
      return new Bt(s.endpoint, s.model, t.sttApiKey, e);
    case "local":
      return new Rt(s.endpoint, t.sttApiKey, e);
    default:
      return new jt();
  }
}
const Kt = [
  /^thanks? (you )?for watching[.!]*$/i,
  /^thank you[.!]*$/i,
  /^please subscribe.*$/i,
  /^subtitles? by .*$/i,
  /^\[?(music|applause|silence|blank_audio)\]?$/i,
  /^you$/i,
  /^\.+$/
];
function Nt(s, t) {
  const e = s.trim();
  return e ? t < 0.02 && Kt.some((n) => n.test(e)) : !0;
}
class Dt {
  constructor(t = 4, e = 3) {
    this.minWords = t, this.maxHoldSec = e;
  }
  seq = 0;
  pending = null;
  lastWords = [];
  push(t, e, n, r = 1) {
    let i = t.replace(/\s+/g, " ").trim();
    if (Nt(i, r)) return this.pending && n - this.pending.startSec > this.maxHoldSec ? this.flush() : [];
    if (i = this.dropOverlap(i), !i) return [];
    const o = [];
    let a;
    this.pending ? (a = { ...this.pending, text: `${this.pending.text} ${i}`, endSec: n }, this.pending = null) : a = { id: "", text: i, startSec: e, endSec: n };
    const c = a.text.split(" ").length;
    return !/[.!?…]["')\]]?$/.test(a.text) && c < this.minWords && n - a.startSec < this.maxHoldSec ? (this.pending = a, o) : (a.id = `live-${++this.seq}`, this.remember(a.text), o.push(a), o);
  }
  /** Emit any held fragment (on timeout or stop). */
  flush() {
    if (!this.pending) return [];
    const t = { ...this.pending, id: `live-${++this.seq}` };
    return this.pending = null, this.remember(t.text), [t];
  }
  get hasPending() {
    return !!this.pending;
  }
  remember(t) {
    this.lastWords = t.split(" ").slice(-8);
  }
  dropOverlap(t) {
    const e = t.split(" "), n = (r) => r.toLowerCase().replace(/[^\p{L}\p{N}']/gu, "");
    for (let r = Math.min(6, this.lastWords.length, e.length - 1); r >= 2; r--) {
      const i = this.lastWords.slice(-r).map(n).join(" "), o = e.slice(0, r).map(n).join(" ");
      if (i === o) return e.slice(r).join(" ");
    }
    return t;
  }
}
const qt = 2, _t = 3, $ = "audioSession";
class Gt {
  constructor(t) {
    this.d = t, this.restored = this.restore();
  }
  session = null;
  restored;
  now() {
    return (this.d.now ?? Date.now)();
  }
  /** After a service-worker restart, re-attach to a session the offscreen doc still runs. */
  async restore() {
    const e = (await this.d.sessionStore?.get($).catch(() => ({})))?.[$];
    e && (this.session = this.newSession(e.id, e.tabId, e.startedAt));
  }
  newSession(t, e, n) {
    return {
      id: t,
      tabId: e,
      startedAt: n,
      assembler: new Dt(),
      context: [],
      sttInFlight: 0,
      consecutiveFailures: 0,
      abort: new AbortController(),
      sttLatencies: [],
      totalLatencies: [],
      nextSeqToEmit: 0,
      readyBySeq: /* @__PURE__ */ new Map(),
      seenAny: !1
    };
  }
  get active() {
    return this.session ? { id: this.session.id, tabId: this.session.tabId } : null;
  }
  async start(t, e) {
    await this.restored;
    const n = await this.d.getSettings();
    if (et(n) && !n.consent.remoteAudio)
      throw new Error("Chưa cho phép gửi âm thanh tới dịch vụ STT từ xa. Bật trong Cài đặt → Quyền riêng tư (remote audio consent required).");
    if (n.stt.kind !== "mock" && this.d.hasEndpointPermission && !await this.d.hasEndpointPermission(n.stt.endpoint))
      throw new Error('Chưa cấp quyền truy cập endpoint STT. Mở Cài đặt và bấm "Lưu".');
    this.session && await this.stop(this.session.tabId, "replaced");
    const r = `a${this.now().toString(36)}${Math.random().toString(36).slice(2, 6)}`;
    this.session = this.newSession(r, t, this.now()), await this.d.sessionStore?.set({ [$]: { id: r, tabId: t, startedAt: this.session.startedAt } }), this.d.registry.setAudio(t, { active: !0, sessionId: r, startedAt: this.session.startedAt, error: void 0, chunks: 0, droppedChunks: 0 }), this.d.setBadge(t, "REC"), await this.d.ensureOffscreen(), await this.d.sendOffscreen({ type: "start", streamId: e, sessionId: r }), await this.notifyState(t, !0);
  }
  async stop(t, e = "user", n) {
    await this.restored;
    const r = this.session;
    !r || t !== void 0 && r.tabId !== t || (this.session = null, r.abort.abort(), clearTimeout(r.holdTimer), await this.d.sessionStore?.set({ [$]: null }).catch(() => {
    }), await this.d.sendOffscreen({ type: "stop" }).catch(() => {
    }), await this.d.closeOffscreen().catch(() => {
    }), this.d.setBadge(r.tabId, ""), this.d.registry.setAudio(r.tabId, { active: !1, error: n }), await this.notifyState(r.tabId, !1, n));
  }
  async notifyState(t, e, n) {
    const r = this.d.registry.primaryFrame(t), i = this.d.registry.get(t);
    await Promise.all(
      (i.frames.length ? i.frames : [{ frameId: 0 }]).map(
        (o) => this.d.sendToFrame(t, o.frameId, { type: "audio:state", active: e, primary: o.frameId === (r ?? 0), error: n })
      )
    );
  }
  async onOffscreenError(t, e) {
    await this.restored, this.session?.id === t && await this.stop(this.session.tabId, "error", e);
  }
  async onOffscreenStopped(t, e) {
    await this.restored, this.session?.id === t && await this.stop(this.session.tabId, e, e === "ended" ? "Âm thanh tab đã dừng (tab đóng hoặc điều hướng)." : void 0);
  }
  async onChunk(t) {
    await this.restored;
    const e = this.session;
    if (!e || e.id !== t.sessionId) return;
    const n = this.d.registry.setAudio(e.tabId, {});
    if (this.d.registry.setAudio(e.tabId, { chunks: n.chunks + 1 }), !e.seenAny && t.seq > e.nextSeqToEmit && (e.nextSeqToEmit = t.seq), e.seenAny = !0, e.sttInFlight >= qt + 1) {
      this.d.registry.setAudio(e.tabId, { droppedChunks: n.droppedChunks + 1 }), e.readyBySeq.set(t.seq, null), this.drain(e);
      return;
    }
    e.sttInFlight++;
    const r = await this.d.getSettings(), i = await this.d.getSecrets();
    let o = "";
    try {
      const a = (this.d.sttFactory ?? ((l, d) => Ut(l.stt, d)))(r, i);
      o = await this.transcribeWithRetry(a, dt(t.wavBase64), e), e.consecutiveFailures = 0;
      const c = this.now() - t.endedAt;
      e.sttLatencies.push(c), e.sttLatencies.length > 30 && e.sttLatencies.shift(), this.d.registry.setAudio(e.tabId, { sttLatencyMs: V(e.sttLatencies), error: void 0 });
    } catch (a) {
      if (e.abort.signal.aborted) return;
      e.consecutiveFailures++;
      const c = `Lỗi nhận dạng giọng nói (STT): ${a.message}`;
      if (this.d.registry.setAudio(e.tabId, { error: c }), e.consecutiveFailures >= _t || a instanceof S && (a.status === 401 || a.status === 403)) {
        await this.stop(e.tabId, "error", c + " — Audio Mode đã dừng. Kiểm tra backend STT trong Cài đặt.");
        return;
      }
    } finally {
      e.sttInFlight--;
    }
    e.readyBySeq.set(t.seq, o ? { text: o, startSec: t.startSec, endSec: t.endSec, rms: t.rms, endedAt: t.endedAt } : null), this.drain(e);
  }
  async transcribeWithRetry(t, e, n) {
    let r;
    for (let i = 0; i < 2; i++)
      try {
        return (await t.transcribe({ wav: e, language: "en", prompt: n.context.slice(-2).join(" "), signal: n.abort.signal })).text;
      } catch (o) {
        if (r = o, n.abort.signal.aborted || o instanceof S && !o.retryable) throw o;
        await new Promise((a) => setTimeout(a, o instanceof S && o.retryAfterMs ? Math.min(o.retryAfterMs, 3e3) : 600));
      }
    throw r;
  }
  /** Emit transcripts strictly in capture order. */
  drain(t) {
    for (; t.readyBySeq.has(t.nextSeqToEmit); ) {
      const e = t.readyBySeq.get(t.nextSeqToEmit);
      if (t.readyBySeq.delete(t.nextSeqToEmit), t.nextSeqToEmit++, !e) continue;
      const n = t.assembler.push(e.text, e.startSec, e.endSec, e.rms);
      for (const r of n) this.emitSegment(t, r, e.endedAt);
      clearTimeout(t.holdTimer), t.assembler.hasPending && (t.holdTimer = setTimeout(() => {
        for (const r of t.assembler.flush()) this.emitSegment(t, r, e.endedAt);
      }, 2500));
    }
  }
  async emitSegment(t, e, n) {
    const r = this.d.registry.primaryFrame(t.tabId);
    await this.d.sendToFrame(t.tabId, r, { type: "live:segment", id: e.id, en: e.text, final: !1 });
    const i = t.context.slice(-3);
    t.context.push(e.text), t.context.length > 10 && t.context.shift();
    const o = await this.d.translate(`audio:${t.id}`, e.text, e.id, i);
    this.session === t && (o.vi ? (t.totalLatencies.push(this.now() - n), t.totalLatencies.length > 30 && t.totalLatencies.shift(), this.d.registry.setAudio(t.tabId, { totalLatencyMs: V(t.totalLatencies) }), await this.d.sendToFrame(t.tabId, r, { type: "live:segment", id: e.id, en: e.text, vi: o.vi, final: !0 })) : o.error && this.d.registry.setAudio(t.tabId, { error: `Lỗi dịch: ${o.error}` }));
  }
}
const V = (s) => s.length ? Math.round(s.reduce((t, e) => t + e, 0) / s.length) : void 0;
async function J(s, t) {
  const e = new AbortController(), n = setTimeout(() => e.abort(), t.timeoutMs ?? 2500);
  try {
    return (await (t.fetchImpl ?? fetch)(s, { signal: e.signal })).ok;
  } catch {
    return !1;
  } finally {
    clearTimeout(n);
  }
}
async function Y(s, t, e, n, r, i) {
  if (s === "mock") return { state: "mock" };
  if (e && !n) return { state: "no-consent" };
  if (!await i.hasPermission(t)) return { state: "no-permission" };
  const o = t.replace(/\/+$/, "");
  return s === "local" ? await J(o + "/health", i) ? { state: "ready" } : { state: "unreachable", detail: o } : N(t) ? await J(o + "/models", i) ? { state: "ready" } : { state: "unreachable", detail: o } : r ? { state: "configured" } : { state: "no-key" };
}
async function Ht(s, t, e) {
  const [n, r] = await Promise.all([
    Y(s.provider.kind, s.provider.endpoint, tt(s), s.consent.remoteTranslation, !!t.translationApiKey, e),
    Y(s.stt.kind, s.stt.endpoint, et(s), s.consent.remoteAudio, !!t.sttApiKey, e)
  ]);
  return { translation: n, stt: r };
}
const X = "audio/offscreen.html", x = new gt(), g = new Ft(chrome.storage.session);
async function G(s) {
  const t = lt(s);
  if (!t) return !1;
  try {
    return await chrome.permissions.contains({ origins: [t] });
  } catch {
    return !1;
  }
}
const T = new $t({
  cache: x,
  getSettings: D,
  getSecrets: q,
  hasEndpointPermission: G
});
async function R(s, t, e) {
  try {
    await chrome.tabs.sendMessage(s, e, { frameId: t ?? 0 });
  } catch {
  }
}
let F = null;
async function Wt() {
  (await chrome.runtime.getContexts({
    contextTypes: [chrome.runtime.ContextType.OFFSCREEN_DOCUMENT],
    documentUrls: [chrome.runtime.getURL(X)]
  })).length || (F || (F = chrome.offscreen.createDocument({
    url: X,
    reasons: [chrome.offscreen.Reason.USER_MEDIA],
    justification: "Process user-approved tab audio for live speech-to-text subtitles."
  }).then(() => new Promise((t) => setTimeout(t, 50))).finally(() => F = null)), await F);
}
async function zt() {
  (await chrome.runtime.getContexts({ contextTypes: [chrome.runtime.ContextType.OFFSCREEN_DOCUMENT] })).length && await chrome.offscreen.closeDocument();
}
const b = new Gt({
  registry: g,
  getSettings: D,
  getSecrets: q,
  ensureOffscreen: Wt,
  closeOffscreen: zt,
  sendOffscreen: async (s) => {
    await chrome.runtime.sendMessage({ target: "offscreen", ...s });
  },
  sendToFrame: R,
  broadcast: (s, t) => R(s, 0, t),
  translate: async (s, t, e, n) => {
    const [r] = await T.translateUnits(s, [{ id: e, text: t }], n);
    return r;
  },
  setBadge: (s, t) => {
    chrome.action.setBadgeText({ tabId: s, text: t }), t && chrome.action.setBadgeBackgroundColor({ tabId: s, color: "#d1242f" });
  },
  hasEndpointPermission: G,
  sessionStore: chrome.storage.session
}), K = /* @__PURE__ */ new Map();
function k(s) {
  clearTimeout(K.get(s)), K.set(
    s,
    setTimeout(() => {
      K.delete(s), R(s, 0, { type: "tab:status:changed", status: g.get(s) });
    }, 200)
  );
}
async function Q(s) {
  const t = g.get(s);
  await Promise.all(
    t.frames.map(async (e) => {
      try {
        await Promise.race([
          chrome.tabs.sendMessage(s, { type: "frame:ping" }, { frameId: e.frameId }),
          new Promise((n, r) => setTimeout(() => r(new Error("timeout")), 400))
        ]);
      } catch {
        g.removeFrame(s, e.frameId);
      }
    })
  );
}
async function Vt(s, t) {
  await g.ready();
  const e = t.tab?.id, n = t.frameId ?? 0;
  switch (s.type) {
    case "frame:hello": {
      if (e === void 0) return { active: !1, frameId: n };
      const r = nt(t.tab?.url ?? (n === 0 ? t.url : void 0)), i = !!r && st(r);
      return n === 0 && g.setSkool(e, i), { active: i, frameId: n };
    }
    case "frame:status":
      return e === void 0 ? null : (g.updateFrame(e, n, s.status), k(e), { ok: !0 });
    case "frame:gone":
      return e !== void 0 && (g.removeFrame(e, n), k(e)), { ok: !0 };
    case "translate:units":
      return { results: await T.translateUnits(s.videoKey, s.units, s.context) };
    case "translate:cancel":
      return T.cancel(s.videoKey), { ok: !0 };
    case "translate:test": {
      const [r] = await T.translateUnits(`test:${Date.now()}`, [{ id: "t", text: "Welcome back! Today we will set up our first Facebook Ads campaign with a $50 daily budget." }], []);
      return r;
    }
    case "tab:status":
      return await Q(s.tabId), {
        status: g.get(s.tabId),
        metrics: T.metrics.snapshot(),
        cache: await x.stats().catch(() => ({ entries: 0, approxBytes: 0 }))
      };
    case "backend:check":
      return Ht(await D(), await q(), { hasPermission: G });
    case "diag:run": {
      await Q(s.tabId);
      const r = /* @__PURE__ */ new Set([0, ...g.get(s.tabId).frames.map((o) => o.frameId)]), i = await Promise.all(
        [...r].map(async (o) => {
          try {
            return { frameId: o, report: await chrome.tabs.sendMessage(s.tabId, { type: "diag:collect" }, { frameId: o }) };
          } catch (a) {
            return { frameId: o, error: a.message };
          }
        })
      );
      return { collectedAt: (/* @__PURE__ */ new Date()).toISOString(), extensionVersion: chrome.runtime.getManifest().version, frames: i };
    }
    case "metrics:get":
      return T.metrics.snapshot();
    case "cache:stats":
      return x.stats();
    case "cache:clear":
      return await x.clear(), { ok: !0 };
    case "audio:start":
      try {
        return await b.start(s.tabId, s.streamId), k(s.tabId), { ok: !0 };
      } catch (r) {
        return g.setAudio(s.tabId, { active: !1, error: r.message }), { ok: !1, error: r.message };
      }
    case "audio:stop": {
      const r = s.tabId ?? e;
      return await b.stop(r), r !== void 0 && k(r), { ok: !0 };
    }
    case "manual:cues": {
      const r = g.primaryFrame(s.tabId);
      return await R(s.tabId, r, { type: "manual:cues", cues: s.cues, label: s.label }), { ok: !0, frameId: r };
    }
    case "offscreen:ready":
      return { ok: !0 };
    case "offscreen:started": {
      const r = b.active;
      return r && k(r.tabId), { ok: !0 };
    }
    case "offscreen:chunk":
      return b.onChunk(s).then(() => {
        const r = b.active;
        r && k(r.tabId);
      }), { ok: !0 };
    case "offscreen:error":
      return await b.onOffscreenError(s.sessionId, s.error), { ok: !0 };
    case "offscreen:stopped":
      return await b.onOffscreenStopped(s.sessionId, s.reason), { ok: !0 };
  }
  return null;
}
chrome.runtime.onMessage.addListener((s, t, e) => !s || typeof s != "object" || s.target === "offscreen" || t.id !== chrome.runtime.id ? !1 : (Vt(s, t).then(e, (n) => e({ __error: n.message })), !0));
chrome.tabs.onRemoved.addListener((s) => {
  b.stop(s, "tab-closed"), g.removeTab(s);
});
chrome.tabs.onUpdated.addListener((s, t) => {
  t.url && !st(nt(t.url) ?? new URL("about:blank")) && (b.stop(s, "navigated"), g.removeTab(s));
});
chrome.runtime.onInstalled.addListener(() => {
  x.prune().catch(() => {
  });
});
chrome.runtime.onStartup.addListener(() => {
  x.prune().catch(() => {
  });
});
