import{i as d}from"./util-B8mpwbVq.js";const u=["Receiving end does not exist","message port closed","Could not establish connection","The message port closed before a response was received"];function h(e){const t=e instanceof Error?e.message:String(e);return u.some(o=>t.includes(o))}function p(e){try{if(!chrome?.runtime?.id)return!0}catch{return!0}return(e instanceof Error?e.message:String(e??"")).includes("Extension context invalidated")}async function k(e,t={}){const o=t.retries??4,a=t.baseDelayMs??150;let g;for(let i=0;i<=o;i++)try{const n=await chrome.runtime.sendMessage(e);if(n&&typeof n=="object"&&"__error"in n&&n.__error)throw new Error(n.__error);return n}catch(n){if(g=n,p(n)||!h(n)||i===o)throw n;await new Promise(m=>setTimeout(m,a*2**i))}throw g}const f=`# One entry per line. "English => Vietnamese" forces a translation,
# a bare term is kept exactly as written. Lines starting with # are ignored.
Skool
dropshipping
Shopify
Facebook Ads
Google Ads
TikTok Ads
ROAS
CTR
CPC
CPM
CPA
KPI
SEO
API
SaaS
AI
ChatGPT
prompt
landing page => landing page (trang đích)
funnel => phễu bán hàng (funnel)
sales funnel => phễu bán hàng
conversion rate => tỷ lệ chuyển đổi
ad set => nhóm quảng cáo (ad set)
ad account => tài khoản quảng cáo
lead => khách hàng tiềm năng (lead)
retargeting => tiếp thị lại (retargeting)
upsell => bán thêm (upsell)
cross-sell => bán chéo
niche => thị trường ngách
supplier => nhà cung cấp
fulfillment => xử lý đơn hàng (fulfillment)
workflow => quy trình (workflow)
automation => tự động hóa
deploy => triển khai (deploy)
repository => repository (kho mã)
`,c={enabled:!0,modePreference:"auto",displayMode:"vi",fontScale:1,bottomOffsetPct:14,background:!0,backgroundOpacity:.55,outline:!1,shadow:!0,showPanel:!0,provider:{kind:"local",endpoint:"http://localhost:8787",model:"default",temperature:.2},stt:{kind:"local",endpoint:"http://localhost:8787",model:"whisper-1"},consent:{remoteTranslation:!1,remoteAudio:!1},glossary:f,contextWindow:3,mergeFragments:!0,customCaptionSelectors:""},r="settings",s="secrets";function l(e){const t=e??{};return{...c,...t,provider:{...c.provider,...t.provider??{}},stt:{...c.stt,...t.stt??{}},consent:{...c.consent,...t.consent??{}}}}async function S(){const e=await chrome.storage.sync.get(r);return l(e[r])}async function y(e){const t=await S(),o=l({...t,...e});return await chrome.storage.sync.set({[r]:o}),o}function v(e){const t=(o,a)=>{a==="sync"&&o[r]&&e(l(o[r].newValue))};return chrome.storage.onChanged.addListener(t),()=>chrome.storage.onChanged.removeListener(t)}async function E(){const[e,t]=await Promise.all([chrome.storage.local.get(s),chrome.storage.session.get(s)]);return{...e[s]??{},...t[s]??{}}}async function T(e,t){const o=t?chrome.storage.session:chrome.storage.local;await(t?chrome.storage.local:chrome.storage.session).remove(s),await o.set({[s]:e})}async function b(){await Promise.all([chrome.storage.local.remove(s),chrome.storage.session.remove(s)])}function P(e){return e.provider.kind!=="mock"&&!d(e.provider.endpoint)}function A(e){return e.stt.kind!=="mock"&&!d(e.stt.endpoint)}const C={openai:{endpoint:"https://api.openai.com/v1",model:"gpt-4o-mini"},gemini:{endpoint:"https://generativelanguage.googleapis.com/v1beta",model:"gemini-2.0-flash"},local:{endpoint:"http://localhost:8787",model:"default"},mock:{endpoint:"mock://",model:"mock"}};export{C as P,y as a,E as b,b as c,T as d,A as e,S as l,v as o,k as s,P as t};
