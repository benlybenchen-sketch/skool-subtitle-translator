import{i as u}from"./util-B8mpwbVq.js";const m=["Receiving end does not exist","message port closed","Could not establish connection","The message port closed before a response was received"];function h(e){const t=e instanceof Error?e.message:String(e);return m.some(n=>t.includes(n))}function p(e){try{if(!chrome?.runtime?.id)return!0}catch{return!0}return(e instanceof Error?e.message:String(e??"")).includes("Extension context invalidated")}async function k(e,t={}){const n=t.retries??4,a=t.baseDelayMs??150;let g;for(let i=0;i<=n;i++)try{const o=await chrome.runtime.sendMessage(e);if(o&&typeof o=="object"&&"__error"in o&&o.__error)throw new Error(o.__error);return o}catch(o){if(g=o,p(o)||!h(o)||i===n)throw o;await new Promise(d=>setTimeout(d,a*2**i))}throw g}const f=`# One entry per line. "English => Vietnamese" forces a translation,
# a bare term is kept exactly as written. Lines starting with # are ignored.
Skool
dropshipping
Shopify
Facebook Ads
Google Ads
TikTok Ads
ROAS
CTR
CPC
CPM
CPA
KPI
SEO
API
SaaS
AI
ChatGPT
prompt
landing page => landing page (trang đích)
funnel => phễu bán hàng (funnel)
sales funnel => phễu bán hàng
conversion rate => tỷ lệ chuyển đổi
ad set => nhóm quảng cáo (ad set)
ad account => tài khoản quảng cáo
lead => khách hàng tiềm năng (lead)
retargeting => tiếp thị lại (retargeting)
upsell => bán thêm (upsell)
cross-sell => bán chéo
niche => thị trường ngách
supplier => nhà cung cấp
fulfillment => xử lý đơn hàng (fulfillment)
workflow => quy trình (workflow)
automation => tự động hóa
deploy => triển khai (deploy)
repository => repository (kho mã)
`,c={enabled:!0,modePreference:"auto",displayMode:"vi",fontScale:1,bottomOffsetPct:14,background:!0,backgroundOpacity:.55,outline:!1,shadow:!0,showPanel:!0,provider:{kind:"local",endpoint:"http://localhost:8787",model:"default",temperature:.2},stt:{kind:"local",endpoint:"http://localhost:8787",model:"whisper-1"},consent:{remoteTranslation:!1,remoteAudio:!1},glossary:f,contextWindow:3,pretranslateAll:!0,autoStart:!0,autoEnableCaptions:!1,autoEnableCaptionsAsked:!1,autoInitOnNavigation:!0,sourceLanguage:"en",targetLanguage:"vi",mergeFragments:!0,customCaptionSelectors:""},s="settings",r="secrets";function l(e){const t=e??{};return{...c,...t,provider:{...c.provider,...t.provider??{}},stt:{...c.stt,...t.stt??{}},consent:{...c.consent,...t.consent??{}}}}async function S(){const e=await chrome.storage.sync.get(s);return l(e[s])}async function y(e){const t=await S(),n=l({...t,...e});return await chrome.storage.sync.set({[s]:n}),n}function v(e){const t=(n,a)=>{a==="sync"&&n[s]&&e(l(n[s].newValue))};return chrome.storage.onChanged.addListener(t),()=>chrome.storage.onChanged.removeListener(t)}async function E(){const[e,t]=await Promise.all([chrome.storage.local.get(r),chrome.storage.session.get(r)]);return{...e[r]??{},...t[r]??{}}}async function T(e,t){const n=t?chrome.storage.session:chrome.storage.local;await(t?chrome.storage.local:chrome.storage.session).remove(r),await n.set({[r]:e})}async function b(){await Promise.all([chrome.storage.local.remove(r),chrome.storage.session.remove(r)])}function P(e){return e.provider.kind!=="mock"&&!u(e.provider.endpoint)}function A(e){return e.stt.kind!=="mock"&&!u(e.stt.endpoint)}const C={openai:{endpoint:"https://api.openai.com/v1",model:"gpt-4o-mini"},gemini:{endpoint:"https://generativelanguage.googleapis.com/v1beta",model:"gemini-3.5-flash-lite"},local:{endpoint:"http://localhost:8787",model:"default"},mock:{endpoint:"mock://",model:"mock"}};export{C as P,y as a,E as b,b as c,T as d,A as e,S as l,v as o,k as s,P as t};
